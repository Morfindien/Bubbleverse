from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction as F
from hashlib import sha1, sha256
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path.cwd()
src = root / "upload"
out = root / "output/V102"
out.mkdir(parents=True, exist_ok=True)
stamp = datetime.now(timezone.utc).isoformat()
repo = "https://github.com/Morfindien/Bubbleverse"
head = "e3f992d1fc745788cd4f234bdea108ba90ecb388"
tree = json.loads(Path("work/intake102/tree.json").read_bytes())
assert tree["sha"] == "26945e7356f4cd22dbd8f7a74256451942b16129" and not tree["truncated"]
paths = {r["path"]: r["sha"] for r in tree["tree"]}
engine = "BUBBLEVERSE.MATHEMATICS 2.3.0"
enginepath = "Bubbleverse_Matematikmotor_2.3.0.md"
intake_engine = src / "Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0-48.md"
parent = "Q052_SKALAR_PREFIXCERTIFIKAT_V101.zip"
journal101 = "Q052_MATEMATIK_OG_SAMLET_JOURNAL_V101.md"
task101 = "Q052_RESULTATINDTAG_OPGAVE_V101.json"
short101 = "Q052_KORT_RESULTAT_V101.md"
journal102 = "Q052_INGESTION_OG_SAMLET_JOURNAL_V102.md"
task102 = "Q052_MATEMATIKOPGAVE_V102.json"
short102 = "Q052_KORT_RESULTAT_V102.md"
cert102 = "Q052_INGESTION_CERTIFICATE_V102.zip"
run = "LOCAL-Q052-V101-PREFIX-INGESTION-V102"
event = "Q052-ACTIVITY-V101-PREFIX-INGESTION-V102"

def h(data):
    return sha256(data).hexdigest()

def blob(data):
    return sha1(f"blob {len(data)}\0".encode()+data).hexdigest()

def dump(obj):
    return (json.dumps(obj, indent=2, ensure_ascii=False)+"\n").encode()

def fingerprint(obj):
    return h(json.dumps(obj, sort_keys=True, separators=(",",":"), ensure_ascii=False).encode())

def contained(inner, outer):
    assert len(inner) == len(outer) == 2
    return all(F(c[0]) <= F(b[0]) <= F(b[1]) <= F(c[1]) for b,c in zip(inner,outer))

assert not any(p in paths for p in [journal102,task102,short102,cert102])
canonical = {}
for name in [parent,journal101,task101,short101]:
    data = (src/name).read_bytes()
    assert blob(data) == paths[name], name
    canonical[name] = {"git_blob": paths[name], "sha256": h(data), "bytes": len(data), "url": f"{repo}/blob/{head}/{name}"}

with ZipFile(src/parent) as z:
    assert z.testzip() is None and len(set(z.namelist())) == len(z.namelist())
    entries = {name:z.read(name) for name in z.namelist()}
def read(name):
    return json.loads(entries[name])

man = read("manifest.json")
assert {x["path"] for x in man["files"]} == set(entries)-{"manifest.json"}
for x in man["files"]:
    data = entries[x["path"]]
    assert (len(data),h(data)) == (x["bytes"],x["sha256"])
for x in man["external_deliverables"]:
    location = src/x["name"] if (src/x["name"]).exists() else root/"output/V101"/x["name"]
    data = location.read_bytes()
    assert (len(data),h(data)) == (x["bytes"],x["sha256"])
for name in [task101,short101]:
    assert (src/name).read_bytes() == entries[name]
j = (src/journal101).read_bytes()
assert h(j[:man["parent_journal"]["bytes"]]) == man["parent_journal"]["sha256"]
incoming = read(task101)
incoming_fingerprint = incoming.pop("fingerprint_sha256")
assert fingerprint(incoming) == incoming_fingerprint
r, p, v, previous, old = map(read,["result101.json","prototype_result.json","verification101.json","activity_ledger.json","result99.json"])
history_handoff = read("handoff101.json")
assert history_handoff["next_task_fingerprint"] == incoming_fingerprint
assert r["result_id"] == incoming["parent_result_id"] == history_handoff["handoff_id"]
assert r["source_commit"] == incoming["source_commit"] == history_handoff["source_commit"]
assert r["exact_question"] == incoming["exact_question"] == history_handoff["exact_question"]
assert incoming["current_q"] == incoming["target_q"] == "Q052"
assert h(entries["result101.json"]) == man["result_snapshot_sha256"]
capture = h(entries["capture.json"])
assert capture == r["capture_sha256"] == read("v73.json")["capture_sha256"]
assert blob(entries["inputs/ENGINE_MATHEMATICS_2.3.0.md"]) == paths[enginepath]
assert h(entries["inputs/ENGINE_MATHEMATICS_2.3.0.md"]) == history_handoff["engine_sha256"]
assert h(entries["prototype101.py"]) == v["prototype_sha256"]
assert h(entries["prototype_result.json"]) == v["prototype_result_sha256"]
assert v["status"] == "PASS_CONDITIONAL" and v["failures"] == []
assert r["verification_checks"] == v["checks"]
assert F(v["uniform_guard_G_lower"]) > 0 and F(v["uniform_H_squared_lower"]) > 0
assert not p["target_reached"] and F(p["target_a"]) == F(1,801)
assert r["new_native_pairs"] == r["new_full_history_integrations"] == r["new_weight_evaluations"] == 0
assert all(old[k] == value for k,value in r["inherited_unchanged"].items())
initial = read("initial.json")
cells = p["cells"]
assert len(cells) == p["accepted_cells"] == v["checked_cells"] == r["accepted_cells"] == 1071
a = F(initial["a"][0])
state = initial["scalar_state"]
sizes = Counter()
for cell in cells:
    b = F(cell["a1"])
    step = F(cell["h"])
    assert a == F(cell["a0"]) < b and step == (b-a)/a
    assert contained(state,cell["initial"])
    assert contained(cell["initial"],cell["picard_box"])
    assert contained(cell["endpoint"],cell["picard_box"])
    assert contained(cell["picard_image"],cell["picard_box"])
    closest = min((F(1,32),F(1,64),F(1,128)),key=lambda x:abs(x-step))
    assert abs(closest-step) < F(1,10**20)
    sizes[str(closest)] += 1
    a,state = b,cell["endpoint"]
assert a == F(p["certified_end_a"]) < F(1,801)
assert F(p["certified_end_z"]) == 1/a-1
for key in r["checkpoint"]:
    assert r["checkpoint"][key] == p[key]
assert state == p["endpoint"] == r["checkpoint"]["endpoint"]
assert all(F(b[0]) <= F(c[0]) <= F(c[1]) <= F(b[1]) for b,c in [(p["energy_endpoint"],v["last_energy_independent"])])
phi_width,x_width = (F(b)-F(a) for a,b in state)
energy_width = F(p["energy_endpoint"][1])-F(p["energy_endpoint"][0])
assert energy_width > 0
thresholds = [F(c["scalar_energy_cap"]) for c in old["cells"]]
sufficient_cap = F(3,4)*min(thresholds)
assert previous["total_points_after"] == incoming["total_points"] == 13070
assert sum(e.get("run_points",0) for e in previous["entries"]) == 13070
assert previous["pending_packages"] == [] and previous["milestone_records"][-1]["package_state"] == "DELIVERED"
ledger = previous.copy()
breakdown = {"artifact_and_exact_connection_audit":25,"mathematical_continuation_design_and_diagnostics":30,"repository_and_engine_identity":10}
ledger["entries"] = previous["entries"] + [{"activity_event_id":event,"run_id":run,"engine":incoming["engine"],"run_points":65,"breakdown":breakdown,"counted_once":True,"basis":"Rounded heuristic for new artifact/connection audit, signed comparison design, step diagnostic and live repository identity. No V101 replay or package-production credit."}]
ledger.update(previous_ledger_ref=journal101,previous_total_points=13070,total_points_after=13135,cycle_progress=135,next_publication_at=14000,points_to_next_publication=865,new_milestones=[],pending_packages=[],ready_milestone_ids=[],ledger_revision="V102",parent_ledger_sha256=h(entries["activity_ledger.json"]),last_updated_utc=stamp,reconciliation={"prior_total":13070,"new_unique_event_points":65,"current_total":13135},note="One new ingestion event. M013 delivery retained. Later video packaging is separate from the research ledger.")
assert sum(e["run_points"] for e in ledger["entries"]) == 13135

task = {
    "schema_version":"UNVALIDATED_LOCAL_CONTRACT",
    "task_id":"LOCAL-Q052-V102-CENTERED-DEFECT-SCALAR-CONTINUATION",
    "engine":engine,"engine_prompt_sha256":history_handoff["engine_sha256"],"state":"PREPARED_NOT_EXECUTED",
    "case_id":incoming["case_id"],"current_q":"Q052","target_q":"Q052","exact_question":incoming["exact_question"],
    "source_commit":r["source_commit"],"capture_sha256":capture,
    "objective":"Test one validated centered residual propagation from the authenticated V101 scalar endpoint on the same fixed B-star. Seek the z800 anchor and measure useful progress if time expires first.",
    "input_certificate":parent,"input_certificate_sha256":canonical[parent]["sha256"],
    "input_result_sha256":h(entries["result101.json"]),
    "input_checkpoint":r["checkpoint"],"input_last_relative_step":cells[-1]["h"],
    "frozen":"V73 literal source-real scalar IVP, exact captured binary64 parameters, all 11 massive-neutrino nodes, common B-star, matched z810 thermal start, all V99 subcells and weight and electron contracts.",
    "execution_limits":{"max_new_prototypes":1,"validated_propagation_and_new_cell_checks_wall_seconds":300,"max_retries_per_cell":12,"new_native_pairs":0,"new_full_history_integrations":0,"max_new_weight_evaluations":1},
    "coverage":{"a_start":str(a),"a_waypoint":str(2*a),"a_target":"1/801","z_target":"800","exact_connection_required":True},
    "method":{
        "coordinates":"Use t=(a-a_left)/a_left for a single cell, retaining exact rational a. y=(phi,X). In u=ln(a), y'=(X/H,-3X-U_phi/H), with H²=B0+(X²/2+U+f)/3. Divide the field by 1+t for t.",
        "center":"Start a degree-12 reference polynomial P at the exact midpoint of the two stored intervals. Coefficients are exact representations of selected numerical values. A polynomial is a reference curve, and every truncation and rounding error enters the validated defect.",
        "tube_and_defect":"Certify a convex state box B containing the true trajectory by whole-cell Picard inclusion and containing P([0,h]). Certify H²>0 and the literal EDE guard over the whole cell. Use outward Taylor algebra with rigorous remainder to bound each component of F(t,P(t))-P'(t), preserving cancellation in the polynomial coefficients. Bound the absolute defect by r_i.",
        "comparison":"On [0,h]×B bound J=∂_yF. Take constant M_ii≥sup J_ii, M_ij≥sup|J_ij| (i≠j), with exact/outward bounds. Do not replace a proven negative diagonal by its absolute value. From the initial componentwise radii, enclose w'=Mw+r and use |y-P|≤w. Use a positive shift of the augmented Metzler matrix and a certified exponential series/tail with directed rounding, or an equivalent separately justified enclosure of the same comparison. Intersect the endpoint box with B only after proving both inclusions. An empty intersection is a defect.",
        "acceptance_and_controller":"First proposal is the last V101 relative step. Then use the last accepted relative step; halve on rejection, grow by 3/2 after two consecutive no-retry accepts with defect <= one quarter of budget, cap relative step at 1/16. Round interior right endpoints down to the 2^-120 grid, clip at exact waypoint and target, and reject a nonadvancing grid step. Use a declared per-unit-t absolute defect budget 1e-8 in phi and 1e-8 Mpc^-1 in X, measured on the entire cell. This replaces the 1e-22 Taylor-tail heuristic. Record defects, comparisons, retry reasons, runtime and widths."
    },
    "decision_gates":{
        "waypoint":"Operational feasibility requires reaching exactly 2*a_start within 300 seconds with energy interval width at most 10 times the V101 endpoint width. Stop and retain the last valid enclosure if reached but too wide. This threshold assesses early transport and does not establish a pilot anchor.",
        "waypoint_max_energy_width_Mpc_minus_2":str(10*energy_width),
        "anchor":"Exact a=1/801, certified source linkage, contiguous cells and validated finite endpoint energy. Record attained interval width and upper bound.",
        "sufficient_screen_energy_cap_Mpc_minus_2":str(sufficient_cap),
        "screen":"Only at a certified z800 anchor, use de/dln(a)=-3X² and intersect the new upper cap with the old per-cell caps across [750,800]. Reuse the identical 105 subcells. Recompute and independently check the one weight screen against the frozen width ceiling. The stated sufficient energy cap is a conservative design diagnostic, not a necessary condition for running the screen. Record a certified anchor separately from the weight decision.",
        "weight_width_ceiling":old["weight_width_ceiling"]
    },
    "verification":"Verify exact chain and interval inclusion, recompute defect and comparison bounds at increased precision for the accepted cells within the budget, and independently check the first/last cell field, guard and comparison inequalities using a separate interval evaluation. Mark only the verified prefix as eligible. Record shared code and independently checked scope.",
    "stop_condition":"Stop at the target and one eligible weight evaluation, first unresolved premise/invalid comparison/empty intersection, waypoint tightness failure, retry cap, or 300 seconds for propagation and its new-cell checks. Keep the last verified exact checkpoint; report the first failing condition and no extrapolated completion time.",
    "no_repeat":incoming["no_repeat"]+["Do not replay the V101 initial-to-checkpoint integration. The new calculation starts at its certified joint endpoint."],
    "return_engine":incoming["engine"],"continue_same_q":True,"total_points":13135,"next_milestone":14000,"points_to_next_publication":865
}
task["fingerprint_sha256"] = fingerprint(task)
audit = {"run_id":run,"created_at_utc":stamp,"repository_head":head,"tree_sha":tree["sha"],"canonical_matches":canonical,"new_paths_absent_at_head":[journal102,task102,short102,cert102],"verified_math_engine":{"path":enginepath,"git_blob":paths[enginepath],"sha256":task["engine_prompt_sha256"]},"intake_engine_sha256":h(intake_engine.read_bytes()),"archive_entries_verified":len(man["files"]),"parent_prefix":man["parent_journal"],"incoming_task_fingerprint":incoming_fingerprint,"new_result_snapshot_sha256":h(entries["result101.json"]),"exact_checkpoint":r["checkpoint"],"verified_connections":len(cells),"reused_verification":{"status":v["status"],"checks":v["checks"],"shared_component":v["shared_component"],"independent_components":v["independent_components"]},"observed":{"step_histogram_by_nominal_ratio":dict(sizes),"accepted":len(cells),"rejected":p["rejected_candidates"],"wall_seconds":p["prototype_wall_seconds"],"widths":[str(phi_width),str(x_width),str(energy_width)]},"scope":"Archive and certificate-record audit. No new scalar propagation, Taylor replay, native run or weight test.","inherited_v99":r["inherited_unchanged"]}

historical = read("q048_prefix_final_v1.json")["raw_results"]["hillipop-ede_n3"]
captured = read("capture.json")
assert historical["source_initialization"] == initial
assert historical["source_commit"] == captured["source_commit"] == r["source_commit"]
assert historical["source_input_hashes"] == captured["cases"]["hillipop-ede_n3"]["source_input_hashes"]
audit["initial_source_linkage"] = {"commit":r["source_commit"],"historical_record":"q048_prefix_final_v1.json","capture_ref":"capture.json","result":"MATCHED_CONDITIONAL"}

status = "ACTIVE / CONTINUE / INCONCLUSIVE"
reason = "The early scalar enclosure terminates before z800. Source/native consistency and numerical error remain open."
memory = {
    "repository_url":repo,"base_commit_sha":head,"branch":"main","source_freshness":"VERIFIED_AT_INTAKE",
    "source_journal":journal101,"proposed_journal_path":journal102,"current_state_path":None,"index_refs":[],
    "sync_status":"USER_UPLOAD_PENDING","commit_sha":None,"pull_request_url":None,
    "target_paths_status":"FOUR_NEW_ROOT_FILES_AT_OBSERVED_BASE",
    "proposed_files":[journal102,task102,short102,cert102],
    "upload_instructions_ref":f"{cert102}#README.md",
    "notes":"Upload four new files at repository root after checking for a concurrent Q052 update. Retain V101 and older versions. Advance Q052 navigation only when all new references resolve and the canonical existing pointer is identified. No repository mutation performed."
}
handoff = {
    "schema_id":"bubbleverse.result_ingestion_handoff","schema_version":"3.0.0",
    "prompt_id":"bubbleverse.result_ingestion_routing","prompt_version":"2.3.0","handoff_id":run,"created_at_utc":stamp,
    "case_id":task["case_id"],"current_q":"Q052","target_q":"Q052","exact_question":task["exact_question"],
    "evidence_cutoff":{"target_q":"Q052","source_commit":r["source_commit"],"parent_snapshot":"V101"},
    "case_lifecycle":"ACTIVE","disposition":"CONTINUE","epistemic_status":"INCONCLUSIVE",
    "ingestion_state":"ACCEPTED_CONDITIONAL_PARTIAL_PREFIX","source_state_version":"V101","target_state_version":"V102",
    "new_result_ids":[r["result_id"]],"selected_next_engine_id":engine,"engine_registry_ref":audit["verified_math_engine"],
    "execution_profile_ref":{"primary":"Mathematics engine with local Python directed interval arithmetic and monotonic timing","available":"Local Python verified for ingestion. Validated continuation implementation remains to be produced.","optional":"Independent interval evaluator for first/last new cells"},
    "journal_ref":journal102,"source_register_ref":f"{parent}#source_register.json",
    "claim_evidence_map_ref":f"{cert102}#claim_map.json","result_provenance_ref":f"{cert102}#audit102.json",
    "completed_task_ledger_ref":f"{cert102}#completed_tasks.json","route_history_ref":journal102,
    "anomaly_tension_registry_ref":f"{cert102}#audit102.json","integrity_manifest_ref":f"{cert102}#manifest.json",
    "closure_snapshot_ref":None,"frozen_configuration_refs":[f"{parent}#v73.json",f"{parent}#capture.json",f"{parent}#result99.json"],
    "what_changed":["Accepted V101 conditional scalar prefix for checkpoint reuse","Prepared a signed residual comparison continuation with a progress and width gate"],
    "open_material_uncertainties":["Reachability and tightness of a validated z800 energy anchor","V99 weight screen improvement","Native pair trajectory error, consistency and reproducibility"],
    "missing_information":["No certified z800 scalar anchor or new weight evaluation"],
    "next_task":task102,"next_task_fingerprint":task["fingerprint_sha256"],
    "success_condition":task["decision_gates"],"failure_or_falsification_condition":"A failed runtime, width or enclosure gate limits the chosen method only.",
    "stop_condition":task["stop_condition"],"completion_gate_satisfied":False,"completion_gate_reason":reason,
    "handoff_completeness":"READY_LOCAL_MANUAL_CONTRACT_CHECK","writeback_status":"GITHUB_USER_UPLOAD_PENDING","delivery_status":"FILES_WITH_HANDOFF",
    "operator_gate":"NONE_FOR_LOCAL_PREPARATION","output_file_refs":[journal102,task102,short102,cert102],"output_manifest_ref":f"{cert102}#manifest.json",
    "repository_memory":memory,
    "question_activity_points":{"policy_id":"bubbleverse.question_activity_some_milestones","policy_version":"2.0.0","ledger_id":"Q052","ledger_ref":f"{cert102}#activity_ledger.json","ledger_version":"V102","parent_ledger_version":"V101","run_id":run,"activity_event_id":event,"parent_total_pts":13070,"assessed_run_points":65,"assessment_breakdown":breakdown,"assessment_basis":ledger["entries"][-1]["basis"],"assessment_confidence":"Rounded heuristic estimate","newly_applied_event_ids":[event],"total_pts":13135,"status":"RECONCILED"},
    "some_milestones":{"interval_pts":1000,"highest_threshold_reached_pts":13000,"crossed_this_run":[],"ready_package_ids":[],"pending_milestones":[],"next_threshold_pts":14000,"points_to_next_threshold":865,"milestone_ledger_ref":f"{cert102}#activity_ledger.json","package_file_refs":[f"{parent}#Q052_SOME_M013_R1/PUBLICATION_MANIFEST.json"],"package_creation_status":"NOT_DUE","external_publication_status":"NOT_REQUESTED","scientific_route_changed_by_points":False}
}
claims = [
    {"id":"Q052-V102-C1","scope":"Conditional early scalar solution of the fixed source-real IVP","statement":"1071 contiguous verified cells supply a reusable joint endpoint.","evidence":[f"{parent}#prototype_result.json",f"{parent}#verification101.json","audit102.json"],"independence":"Recorded rational field, Picard, guard and energy checks. Higher precision Taylor replay reused recurrence code. Intake audited stored records."},
    {"id":"Q052-V102-C2","scope":"V99 weight pilot and global bounds","statement":"V99 remains the latest pilot and global bound evidence. The z800 anchor and a new weight test are pending.","evidence":[f"{parent}#result99.json",f"{parent}#result101.json"]},
    {"id":"Q052-V102-C3","scope":"Proposed numerical method","statement":"V102 prepares a centered residual enclosure with signed Jacobian diagonals and measurable feasibility gates.","evidence":[task102,"METHOD.md"],"status":"PROPOSED_NOT_EXECUTED"}
]
completed = {
    "historical_ledger_ref":f"{parent}#github_memory_update.json",
    "events":[{"task_id":incoming["task_id"],"fingerprint":incoming_fingerprint,"status":"COMPLETED_INGESTION","run_id":run,"points_event":event},
              {"task_id":r["task_id"],"fingerprint":r["task_fingerprint"],"status":"COMPLETED_BOUNDED_PROTOTYPE_TARGET_UNREACHED","run_id":r["result_id"]}],
    "no_repeat":task["no_repeat"]
}

method = r"""# Matematisk grundlag for den planlagte fortsættelse

For en celle bruges den faste kildeligning $y'=F(t,y)$ i lokal tid
$t=(a-a_\mathrm{left})/a_\mathrm{left}$. Den validerede Picard-boks $B$
indeslutter alle løsninger fra indgangsboksen på hele cellen. Kontrollér glathed,
positiv $H^2$ og kildeguarden. En separat Taylor-reference $P$ holdes i den
samme konvekse boks. Hele defekten $d(t)=F(t,P(t))-P'(t)$ indesluttes med
udadrettet afrunding og rigorøst restled. Startfejlen er den gemte boks'
radius om det eksakte midtpunkt.

Med $e=y-P$ giver middelværdiintegralet
$e'=J_*(t)e+d(t)$, hvor $J_*$ er middelværdien af Jacobi-matricen på
segmentet mellem $y$ og $P$. Derfor opfylder $|e_i|$ den øvre Dini-ulighed
$D^+|e_i|\le M_{ii}|e_i|+\sum_{j\ne i}M_{ij}|e_j|+r_i$.
Diagonalposten bevarer sit fortegn. Dette følger for $e_i\ne0$ ved at
differentiere absolutværdien, og for $e_i=0$ ved den øvre højre afledte.
$M$ er konstant over cellen med ikke-negative poster uden for diagonalen.
Den positive lineære sammenligning $w'=Mw+r$ giver $|e|\le w$.
Anvend en verificeret indhylling af $w(h)$ til slutboksen $P(h)\pm w(h)$.

For en simpel implementering sættes
$L=\left[\begin{smallmatrix}M&r\\0&0\end{smallmatrix}\right]$ og
$N=L+sI\ge0$ med $s\ge0$. Beregn $e^{-sh} e^{hN}(w(0),1)^T$ udadrettet.
En eksakt øvre grænse $b\ge h\|N\|_\infty$ giver en halebarriere for
serieordenen $k$ på $b^{k+1}/(k+1)!\,(1-b/(k+2))^{-1}$ når $b/(k+2)<1$.
Gang halen med den maksimale startkomponent. Afrund også eksponentialfaktoren
udad. Registrér indhyllingsmetoden og intervalprimitiverne.

Ved z=800 giver $de/d\ln a=-3X^2$ et fremadrettet energiloft på pilotområdet.
Et konstant loft på højst $\tfrac34\min E_{99,i}$ er tilstrækkeligt til at
være mindst lige så stramt som V100's hypotetiske skalering af hvert loft
til tre fjerdedele. Det følger af monotoniteten af den nedre vægtgrænse i
energiloftet med de øvrige V99-led fastholdt. Kriteriet er et
planlægningsmål. Den endelige afgørelse bruger de 105 delcellers faktiske,
uafhængigt kontrollerede vægtbredde. Grænserne og eventuelle skæringer
følger den identiske baggrund, dækning og enhedskonvention fra V99.

De valgte trin- og defekttolerancer samt fordoblingsporten i a er
operationelle beslutninger for forsøget. Det er endnu uvist, om de kan
opfyldes, og om den validerede beregning når z=800 inden for tidsgrænsen.
"""
append = f"""# BUBBLEVERSE — RESULT INGESTION & ROUTING HANDOFF

## Q052 V102 · Resultatindtag og næste beregning

**V101 er optaget som et betinget certifikat for 1.071 sammenhængende skalartrin.** Det gemte punkt ligger ved z ≈ {float(1/a-1):.3f}. Målet er z=800, og Q052 er fortsat åbent. Matematikmotoren får én afgrænset opgave, der genbruger den eksakte fælles slutboks og tager højde for dæmpningen i skalarfeltets ligning.

CASE ID `{task['case_id']}` · CURRENT Q Q052 · TARGET_Q Q052 · ACTIVE / CONTINUE / INCONCLUSIVE. Handoff `{run}` · schema 3.0.0 · intake engine 2.3.0 · {stamp}.

> {task['exact_question']}

## Resultat og provenance

De fire V101-filer matcher GitHub-blobs ved `{head}`. Manifestets {len(man['files'])} interne poster, eksterne leverancer og det historiske journalpræfiks matcher deres SHA-256. Indtaget kontrollerede sammenhæng og indeslutning for alle gemte intervaller med eksakte brøker. Den betingede start binder det gemte Q048-initialiseringsobjekt til capture og kildecommit `{r['source_commit']}`. V101's kontrolstatus er PASS_CONDITIONAL. Felt, Picard, energi og guard har de dokumenterede selvstændige kontroller, mens Taylor-genberegningen deler rekurrenskode. V102 er et indtag af de gemte beviser.

Ved checkpointet er a ≈ {float(a):.12g}. Boksbredderne i phi og X er henholdsvis {float(phi_width):.8g} og {float(x_width):.8g} Mpc⁻¹ for X. Energibredden er {float(energy_width):.8g} Mpc⁻². Det eksakte tidspunkt, den fælles boks og energien står i opgaven og auditfilen. V99's pilot- og globale grænser videreføres med de eksakte brøker fra V101. De næste videnskabelige mangler er det validerede anker ved z=800, et eventuelt strammere vægtinterval og dokumentation for native banefejl, overensstemmelse og reproducerbarhed. Betingelserne for at afslutte Q052 er endnu ikke opfyldt.

## Næste motor og forsøg

**{engine}** er verificeret mod den arkiverede prompt og GitHub-blob `{paths[enginepath]}`. Lokal Python med udadrettet intervalaritmetik, monotont ur og dokumenterede kontrolmetoder er det anbefalede setup. V102 har klargjort opgaven. Implementering og udførelse hører til næste motor.

V101 gemte 333 accepterede trin omkring h=1/32, 333 omkring 1/64 og 405 omkring 1/128. Den nulstillede forslaget til 1/32 for hver ny celle og registrerede 1.145 afvisninger. Det er en konstateret kilde til ekstra forsøg. Den nye kontrakt genbruger sidste accepterede trin og validerer defekten for en centreret referencekurve. En komponentvis fejlindhylling med fortegn på Jacobi-diagonalen medregner dæmpning. Hver celle skal have gyldig Picard-indeslutning, kildeguard og en kontrolleret fejlgrænse. Det faste B★, startbetingelserne og V99's vægtkriterier er bundet i opgaven.

Der er højst ét forsøg med 300 sekunder til fremføring og nye cellekontroller. En tidlig gennemførlighedsport kræver en fordobling af a fra det gemte punkt med højst ti gange den hidtidige energibredde. Trintilpasning og tolerancer er valgt til dette metodeforsøg. Et certificeret z=800 åbner højst én vægttest på de samme 105 delceller. Et konservativt tilstrækkeligt energiloft til planlægning er {float(sufficient_cap):.9g} Mpc⁻², udledt af V100's allerede arkiverede regneprøve. Den faktiske vægttest afgør resultatet. Ved tidsstop eller en manglende præmis bevares sidste verificerede punkt og den konkrete stopårsag.

## Journal, filer og aktivitet

V101 er bevaret byte for byte som præfiks. Kilderegister og rå evidens kan åbnes via det commit-fikserede V101-certifikat. V102-arkivet indeholder audit, claim-map, rute, metode, opgave, aktivitetsledger og instruktioner til GitHub. Ny GitHub-version afventer brugerupload af de fire nye filer.

RUN COST: 65 pts  
TOTAL WORK POINTS: 13135 pts  
SOME INTERVAL: 1000 pts  
NEWLY CROSSED SOME MILESTONES: []  
NEXT SOME MILESTONE: 14000 pts  
POINTS TO NEXT SOME MILESTONE: 865 pts  
SOME PACKAGE STATUS: NOT_DUE  
SCIENTIFIC STATUS: {status}  
NEXT SCIENTIFIC ENGINE: {engine}

Det nye aktivitetsbidrag er et afrundet skøn fordelt på 25 for certifikat og forbindelser, 30 for metode og trinundersøgelse og 10 for repository- og motoridentitet. V101's 180 point står som det samme historiske event. M013 forbliver leveret i det bevarede ledger.
"""
short = f"""# Q052 V102 · Resultatindtag

**Q052 fortsætter til Matematikmotor 2.3.0.** V101’s 1.071 tidlige trin er optaget som betinget certifikat. Det sidste validerede punkt ligger omkring z=868.538. Skalarenergien ved z=800 og den efterfølgende vægttest mangler stadig.

Næste opgave starter i den eksakte fælles slutboks. Den genbruger sidste accepterede trin og bruger en valideret fejlindhylling, der medregner dæmpning. Forsøget har en tidlig test af dækning og intervalbredde og højst 300 sekunder til fremføring og nye cellekontroller. V102 har forberedt opgaven til næste motor.

Aktivitetstotalen er **13.135 point**. Der er **865 point til næste SoMe-milepæl**. M013 er allerede leveret.

De fire V101-input matcher GitHub ved `{head}`. V102-filerne er klargjort til upload. Arkivet indeholder den fulde maskinlæsbare overlevering og instruktioner.
"""
readme = f"""# Q052 V102 · Indtagspakke

Læs `{short102}` og `{task102}` først. Den komplette journal leveres separat som `{journal102}`.

Upload `{journal102}`, `{task102}`, `{short102}` og `{cert102}` som fire nye filer i roden af {repo}. Sammenlign først med den observerede base `{head}` og kontrollér for en nyere Q052-version. Opdatér den eksisterende Q052-navigation, når den korrekte post og alle nye filer er tilgængelige. Historiske filer bevares.

V101-evidens og SoMe-snapshot ligger i {repo}/blob/{head}/{parent}. Manifestet binder dette arkiv og den fulde V101-journal til eksakte hashes. Outputmanifestet udelader sin egen hash og containerens selvhash.

Kør `verify102.py` fra projektmappen med de identificerede V101-input og det gemte repository-træ, hvis indtagsaudit skal reproduceres. Scriptet skriver resultaterne til output/V102. Den validerede skalarfortsættelse er en separat opgave.
"""
(out/short102).write_text(short)
(out/task102).write_bytes(dump(task))
(out/journal102).write_bytes(j+b"\n\n---\n\n"+append.encode()+b"\n## Maskinlaesbar overlevering V102\n\n```json\n"+dump(handoff)+b"```\n\n## Kumulativt aktivitetsledger V102\n\n```json\n"+dump(ledger)+b"```\n")
assert (out/journal102).read_bytes()[:len(j)] == j

payload = {
    "README.md":readme.encode(),"METHOD.md":method.encode(),"audit102.json":dump(audit),
    "handoff102.json":dump(handoff),"activity_ledger.json":dump(ledger),
    "github_memory_update.json":dump(memory),"claim_map.json":dump(claims),"completed_tasks.json":dump(completed),
    "source_register.json":entries["source_register.json"], "verify102.py":Path(__file__).read_bytes(),
    "repository_audit.json":dump({"head":head,"tree_sha":tree["sha"],"blobs":{k:paths[k] for k in [*canonical,enginepath]}}),
    task102:(out/task102).read_bytes(),
    "repository_tree.json":Path("work/intake102/tree.json").read_bytes()
}
manifest = {"schema":"Q052_V102_OUTPUT_MANIFEST","case_id":task["case_id"],"q":"Q052","version":"V102","run_id":run,
    "repository":repo,"base_commit":head,"parent_artifacts":canonical,
    "archive_members":[{"path":name,"bytes":len(data),"sha256":h(data)} for name,data in sorted(payload.items())],
    "deliverables":[{"filename":name,"role":role,"target_path":name,"operation":"ADD","bytes":(out/name).stat().st_size,"sha256":h((out/name).read_bytes())} for name,role in [(journal102,"complete_cumulative_journal"),(task102,"next_task"),(short102,"short_result")]]+
      [{"filename":cert102,"role":"audit_and_handoff_archive","target_path":cert102,"operation":"ADD","self_hash_omitted":True}],
    "manual_contract_check":"PASS"}
payload["manifest.json"] = dump(manifest)
with ZipFile(out/cert102,"w",compression=ZIP_DEFLATED) as z:
    for name,data in payload.items():
        z.writestr(name,data)
with ZipFile(out/cert102) as z:
    assert z.testzip() is None and set(z.namelist()) == set(payload)
    for name,data in payload.items():
        assert z.read(name) == data
        if name.endswith(".json"):
            json.loads(data)
assert handoff["next_task_fingerprint"] == fingerprint({k:v for k,v in task.items() if k != "fingerprint_sha256"})
assert handoff["selected_next_engine_id"] == task["engine"]
print(json.dumps({"status":"PASS","prefix_bytes":len(j),"checked_cells":len(cells),"checkpoint_z":float(1/a-1),"sufficient_cap":float(sufficient_cap),"new_points":65,"total":13135,"files":[{"path":str((out/n).resolve()),"bytes":(out/n).stat().st_size,"sha256":h((out/n).read_bytes())} for n in [short102,journal102,task102,cert102]]},indent=2))
