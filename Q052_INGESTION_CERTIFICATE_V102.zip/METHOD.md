# Matematisk grundlag for den planlagte fortsættelse

For en celle bruges den faste kildeligning $y'=F(t,y)$ i lokal tid
$t=(a-a_\mathrm{left})/a_\mathrm{left}$. Den validerede Picard-boks $B$
indeslutter alle løsninger fra indgangsboksen på hele cellen. Kontrollér glathed,
positiv $H^2$ og kildeguarden. En separat Taylor-reference $P$ holdes i den
samme konvekse boks. Hele defekten $d(t)=F(t,P(t))-P'(t)$ indesluttes med
udadrettet afrunding og rigorøst restled. Startfejlen er den gemte boks'
radius om det eksakte midtpunkt.

Med $e=y-P$ giver middelværdiintegralet
$e'=J_*(t)e+d(t)$, hvor $J_*$ er middelværdien af Jacobi-matricen på
segmentet mellem $y$ og $P$. Derfor opfylder $|e_i|$ den øvre Dini-ulighed
$D^+|e_i|\le M_{ii}|e_i|+\sum_{j\ne i}M_{ij}|e_j|+r_i$.
Diagonalposten bevarer sit fortegn. Dette følger for $e_i\ne0$ ved at
differentiere absolutværdien, og for $e_i=0$ ved den øvre højre afledte.
$M$ er konstant over cellen med ikke-negative poster uden for diagonalen.
Den positive lineære sammenligning $w'=Mw+r$ giver $|e|\le w$.
Anvend en verificeret indhylling af $w(h)$ til slutboksen $P(h)\pm w(h)$.

For en simpel implementering sættes
$L=\left[\begin{smallmatrix}M&r\\0&0\end{smallmatrix}\right]$ og
$N=L+sI\ge0$ med $s\ge0$. Beregn $e^{-sh} e^{hN}(w(0),1)^T$ udadrettet.
En eksakt øvre grænse $b\ge h\|N\|_\infty$ giver en halebarriere for
serieordenen $k$ på $b^{k+1}/(k+1)!\,(1-b/(k+2))^{-1}$ når $b/(k+2)<1$.
Gang halen med den maksimale startkomponent. Afrund også eksponentialfaktoren
udad. Registrér indhyllingsmetoden og intervalprimitiverne.

Ved z=800 giver $de/d\ln a=-3X^2$ et fremadrettet energiloft på pilotområdet.
Et konstant loft på højst $\tfrac34\min E_{99,i}$ er tilstrækkeligt til at
være mindst lige så stramt som V100's hypotetiske skalering af hvert loft
til tre fjerdedele. Det følger af monotoniteten af den nedre vægtgrænse i
energiloftet med de øvrige V99-led fastholdt. Kriteriet er et
planlægningsmål. Den endelige afgørelse bruger de 105 delcellers faktiske,
uafhængigt kontrollerede vægtbredde. Grænserne og eventuelle skæringer
følger den identiske baggrund, dækning og enhedskonvention fra V99.

De valgte trin- og defekttolerancer samt fordoblingsporten i a er
operationelle beslutninger for forsøget. Det er endnu uvist, om de kan
opfyldes, og om den validerede beregning når z=800 inden for tidsgrænsen.
