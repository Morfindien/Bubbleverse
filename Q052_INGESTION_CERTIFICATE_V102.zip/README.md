# Q052 V102 · Indtagspakke

Læs `Q052_KORT_RESULTAT_V102.md` og `Q052_MATEMATIKOPGAVE_V102.json` først. Den komplette journal leveres separat som `Q052_INGESTION_OG_SAMLET_JOURNAL_V102.md`.

Upload `Q052_INGESTION_OG_SAMLET_JOURNAL_V102.md`, `Q052_MATEMATIKOPGAVE_V102.json`, `Q052_KORT_RESULTAT_V102.md` og `Q052_INGESTION_CERTIFICATE_V102.zip` som fire nye filer i roden af https://github.com/Morfindien/Bubbleverse. Sammenlign først med den observerede base `e3f992d1fc745788cd4f234bdea108ba90ecb388` og kontrollér for en nyere Q052-version. Opdatér den eksisterende Q052-navigation, når den korrekte post og alle nye filer er tilgængelige. Historiske filer bevares.

V101-evidens og SoMe-snapshot ligger i https://github.com/Morfindien/Bubbleverse/blob/e3f992d1fc745788cd4f234bdea108ba90ecb388/Q052_SKALAR_PREFIXCERTIFIKAT_V101.zip. Manifestet binder dette arkiv og den fulde V101-journal til eksakte hashes. Outputmanifestet udelader sin egen hash og containerens selvhash.

Kør `verify102.py` fra projektmappen med de identificerede V101-input og det gemte repository-træ, hvis indtagsaudit skal reproduceres. Scriptet skriver resultaterne til output/V102. Den validerede skalarfortsættelse er en separat opgave.
