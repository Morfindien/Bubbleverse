# Q052 V101 · Betinget certificeret tidlig skalarpræfiks

Det afgrænsede forsøg er afsluttet. Målet ved z=800 blev ikke nået. Det nye resultat er en sammenhængende, betinget certificeret tidlig præfiks af den samme kildebane B★. V99's optiske pilot og globale grænser står uændret. Q052 er INCONCLUSIVE.

## Fastlåsning og startgrundlag

Det præcise spørgsmål er uændret:

> Under the pinned hillipop-ede_n3 source/configuration, the same fixed admitted common background and matched validated z=810 start state used by Q051, does the actual native CLASS/P6 low-z implementation produce q=xHeII=10^-6 versus q=0 electron-fraction and Thomson-optical-depth histories that are reproducible, trajectory-consistent with the literal source-real dynamics, and contained within Q051's uniform analytic bounds; and what are the realized sup|Delta x_e| and sup|Delta tau_T| with a validated numerical error certificate?

Kildecommit: `5a131c91d657dd9a7c6364cc45b038710f8d0d97`. Capture-SHA-256: `2514e250d20c456530be63e790a079176293a87a82c927b1e748d1eec405da9b`. De indfangede binary64-tal behandles som eksakte reelle konstanter; dette er ikke en påstand om en flydende native banes fejl. Begge q-arme beholder samme faste B★ og matchet termodynamisk start ved z=810. Der er ikke udført nye q-arme eller termodynamiske integrationer.

Den genfundne Q048-præfiks indeholder en autentificeret tidlig fælles tilstand. Kildecommit og alle tre source_input_hashes matcher capture. Dens `source_initialization` matches som identiske JSON-data mod `initial.json`. De historiske optagelsesbetingelser er stadig betingede. Den senere genfundne tilstand omkring z=4980 har brede phi/X-intervaller og giver ikke et smalt pilotanker. Energi- og virialprojektioner giver heller ikke ret til en uafhængig snæver tilstandsgenstart.

Den anvendte eksakte start er

\[
a_0=\frac{6338253001141147}{633825300114114700748351602688},\qquad
\phi_0=\frac{8485763490152717}{36028797018963968},\qquad X_0=0.
\]

## Kildeligninger og metode

Med u=ln(a), X=phi_prime/a, U=A(1-cos(lambda phi))³ og f som det konstante gulv anvendes

\[
\frac{d\phi}{du}=\frac{X}{H},\quad
\frac{dX}{du}=-3X-\frac{U_\phi}{H},\quad
H^2=B_0(a)+\frac{X^2/2+U+f}{3}.
\]

A er den eksakte binary64-konstant 4152.39 gange de indfangede m²F²; lambda er den eksakte binary64-konstant 2.435e27 divideret med F; f er det indfangede B gange den eksakte binary64-konstant 3.968e-8. Eksponenten i den indfangede model er præcis 3. Materie, stråling og alle 11 indfangede massive-neutrino-knuder indgår i B0. Fladhed og fravær af øvrige arter er kontrolleret mod capture. H har enhed Mpc⁻¹, X Mpc⁻¹ og e=X²/2+U Mpc⁻².

For hver celle bruges lokal tid t=(a−a_left)/a_left. Højresiden ovenfor divideres med 1+t. Et interval B opfylder Picard-indeslutningen y_left+[0,h]F([0,h],B) ⊂ B. H og alle nævnere er strengt positive; feltet er glat på den verificerede boks. Dermed findes den lokale løsning, og den forbliver i boksen. Startboksen indeholder den tidligere accepterede slutboks. Ingen celle genstarter på en uafhængigt udvalgt bane.

Taylor-koefficienterne genereres ved almindelig interval-jet-aritmetik til orden 12. Orden 13 genereres på hele tids- og tilstandsboksen og indkapsler Lagrange-restleddet. Polynomiet evalueres med Horner, og restleddet tilføjes udadrettet. Slutboksen skal også ligge i Picard-boksen. Alle gemte intervalendepunkter og tider er eksakte rationale tal. Grundkørslen bruger mpmath.iv 1.3.0 med 50 decimalcifre. Koordinatbokse kan blive bredere på grund af tab af korrelation; det ændrer ikke den faste parameters identitet.

Implementationsvalget var relativt foreslået trin 1/32, op til 24 halveringer pr. trin, orden 12 og lokalt absolut restledsmål 10⁻²²(1+|tilstand|). Disse er numeriske arbejdsvalg, ikke nye fysiske antagelser. Trinforslaget nulstilles efter hvert accepteret trin; det medfører gentagne afvisninger og er en konkret mulighed for metodeforbedring. Tidsgrænsen afsluttede forsøget, ikke en påvist fysisk modstrid.

## Resultat og eksakt checkpoint

- Accepterede celler: **1071**. Afviste kandidatforsøg: **1145**.
- Målt prototype-tid: **299.009915334 s** inden for 300 s. Stop: PROTOTYPE_TIME_LIMIT.
- Sidste a ≈ **1.151358543812973e-06**, svarende til z ≈ **868538.175197574776**.
- Phi ≈ [0.23552725007520414, 0.23552725008003381].
- X ≈ [-0.00086480143236008578, -0.00082555622740172101] Mpc⁻¹.
- e ≈ [1908.094084689562, 1908.094084756005] Mpc⁻².

Decimalvisningerne er orienterende; certificering og genoptagelse bruger de eksakte brøker i `result101.json` og `prototype_result.json`. Dette er et checkpoint langt tidligere end z=800. Det må ikke omdøbes som en skalarenergi ved 800.

## Kontrol og begrænsning

En separat rationel implementering med udadrettet afrunding på et 2⁻²⁴⁰-gitter har kontrolleret alle 1071 cellers Picard-feltindeslutning og slutenergi. Sinus/cosinus beregnes med Taylor-rækker og eksakte restledsgrænser; cosinus' monotoni verificeres på de små argumentintervaller. Kvadratrødder indkapsles ved heltalskvadratrødder og eksakte kvadreringsgrænser. Tidssammenhæng og tilstandssammenhæng kontrolleres eksakt.

Desuden genberegnes hver gemt Taylor-slutboks og hvert restled med 80 decimalcifre og skal være indeholdt i de gemte 50-cifrede grænser. Denne del bruger samme Taylor-implementering. Den udgør derfor ikke en fuldstændigt uafhængig Taylor-kode eller et formaliseret maskinbevis. Resultat: **9643 kontroller, ingen fejlede**, PASS_CONDITIONAL. Verifikationstiden er 139.517 s; den er efterkontrol af de allerede gemte celler og ikke en anden prototype eller fremføring mod målet.

Den bogstavelige source-guard U/(3H²)<1/2 er bevist på hele den nye præfiks med

\[
G=3H^2-2U=3B_0+X^2/2-U+f
\ge 3(M/a_{end}^3+R/a_{end}^4)-8A+f>0.
\]

Materie og stråling er positive og aftager med a; neutrinoleddet er ikke-negativt. Den eksakte positive nedre grænse står i `verification101.json`. Samme argument giver H²>0. Energiidentiteten de/du=−3X² følger algebraisk af de samme ligninger. Den er ikke anvendt til en ny pilotgrænse, fordi det krævede z800-anker mangler.

Første kontrolimplementering gav for brede rationelle energibokse og kunne derfor ikke bekræfte indeslutning i de smallere gemte energigrænser. Den havde 1071 energigates uden indeslutning, mens dens øvrige gates bestod. Store potenser ganget med meget små inverse fakulteter skabte unødigt bred intervalafrunding; rekurrerende Taylor-led og monoton endpoint-evaluering løste dette kontrolproblem. De oprindelige prototypedata blev ikke ændret. Den oprindelige kontroldiagnostik er bevaret. En tidligere type-dispatch-fejl før første accepterede prototypecelle blev også rettet; den gav ingen ekstra beregningsbane.

## Konsekvens for Q052 og næste trin

Ingen ny vægtevaluering er udført. V99-pilotintervallet er fortsat cirka [1,38764788856×10⁻⁶; 3,81921195829×10⁻⁶], og det globale source-interval er fortsat cirka [1,43348504759×10⁻⁶; 4,57064839822×10⁻⁵]. Den globale bredde er cirka 4,42729989346×10⁻⁵, omtrent 11068 gange det foreløbige breddeønske 4×10⁻⁹. Disse er arvede source-grænser, ikke nye native fejlcertifikater. De eksakte V99-brøker er videreført uændret.

Tilbage står at nå z=800 med en brugbar fælles skalarboks, teste den samme 105-subcellepilot ved et gyldigt anker og afklare native banefejl, medlemskab og reproducerbarhed. Ingen procentvis forskningsfærdiggørelse kan udledes af antallet af celler, point eller tidsforbruget.

Næste motor er **BUBBLEVERSE.RESULT_INGESTION_ROUTING 2.3.0**. Opgaven er et præcist resultatindtag og en ny afgrænset matematikopgave, som adresserer de gentagne trinhalveringer og intervalbreddevækst. Genbrug det autentificerede checkpoint efter egnethedskontrol. Dette forsøg gentages ikke uændret. Se `Q052_RESULTATINDTAG_OPGAVE_V101.json`. Ingen nye native par eller komplette historiesimulationer er tilladt i den definerede næste opgave.

## Provenance, points og levering

GitHub-base `e5b74925fe7a44cbaca5d5c6e41c9fd454772716`, træ `3b03a159529f276469fe19c72d8795dfac911506`. Tre V100-inputfiler matcher repoets blobs. Den fulde V100-journal mangler ved repoets rod, men den vedhæftede autoritative journal er autentificeret mod arkivet og videreføres byte-for-byte som de første 8.026.394 bytes. GITHUB_READ_STATE er derfor PARTIAL for rodjournalen; GITHUB_WRITE_STATE er NOT_ATTEMPTED. Ingen GitHub-publicering eller SoMe-posting påstås. Filerne er klar til brugerens upload.

RUN POINTS: 180 = analyse 45 + beregning 65 + kildegenfinding 30 + validering 40. TOTAL POINTS: 13070 fra verificeret 12890. Det er et dokumenteret heuristisk aktivitetsindeks, ikke en præcisionsmåling eller en procentdel af løsningen. Pakkeproduktion, journalkopiering og gamle resultater tæller 0. V100-ledgerens gamle prosanote om 135 point var forældet; dens 65-pointpost og totalsum var konsistente og er bevaret.

M013 er nået. Pakken `Q052-SOME-M013-R1` leveres med ni separate engelske indholdsfiler og ZIP, baseret på dette låste resultatsnapshot `b1a468d22a42cb4b2b021e57b686aeea6f530f5b356d28d1fd73db869804de87`. Offentlig status er ONGOING. Næste milepæl 14000, afstand 930. Q052 fortsætter. Kilder, kildehashes, kode, råresultater, kontrol og hele den tidligere certifikatpakke er vedlagt.
