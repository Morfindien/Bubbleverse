# A checked partial path through a cosmological calculation

**Status: ONGOING.**

The question is whether a fixed cosmological model yields reproducible differences in electron fraction and Thomson optical depth with a validated numerical error bound.

This step examined only the scalar background. A bounded interval calculation produced **1,071 accepted steps** before stopping after **299.01 seconds**. Its last checkpoint was at redshift approximately **868,538**, while the requested checkpoint was **800**, at a later stage of expansion.

The recorded steps were checked for exact continuity, whole-step interval inclusion, energy bounds and the source equations' guard condition. The field and energy checks used a separate rational interval implementation. The higher-precision Taylor replay reused the original recurrence code.

We now have a conditional certificate for an early partial path. The required scalar anchor was not reached, and the previous optical-depth bounds remain unchanged. This calculation does not certify the actual native implementation's complete trajectories or establish a physical discovery.

Next: review step-size efficiency and interval-width growth, then define a bounded continuation from the verified checkpoint. The full scientific question remains open.

Sources: the accompanying calculation and verification records; [research repository](https://github.com/Morfindien/Bubbleverse); [frozen source-initialization record](https://github.com/Morfindien/Bubbleverse/blob/e5b74925fe7a44cbaca5d5c6e41c9fd454772716/q048_prefix_final_v1.json). The new files are supplied with this update; repository publication of them is not claimed.
