"""Assemble the V101 handoff from the recorded prototype and its verification."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime, timezone
import copy, hashlib, json, platform, sys, zipfile, mpmath

P=Path(__file__).resolve().parent
ROOT=P.parents[1]
OUT=ROOT/'output'/'V101'
OUT.mkdir(parents=True,exist_ok=True)
PKG=OUT/'Q052_SOME_M013_R1';PKG.mkdir(exist_ok=True)
CERT=P/'package';CERT.mkdir(exist_ok=True)
def read(n):return json.loads((P/n).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def put(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text((json.dumps(value,ensure_ascii=False,indent=2)+'\n') if not isinstance(value,str) else value,encoding='utf-8')
def zwrite(path,files):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,data in sorted(files.items()):z.writestr(name,data)
    with zipfile.ZipFile(path) as z:assert z.testzip() is None

task=read('task100.json');raw=read('prototype_result.json');validation=read('verification101.json')
assert validation['status']=='PASS_CONDITIONAL' and not validation['failures']
assert raw['accepted_cells']==validation['checked_cells']==1071 and not raw['target_reached']
assert raw['prototype_wall_seconds']<=task['execution_limits']['prototype_wall_seconds']
stamp=datetime.now(timezone.utc).isoformat()
RUN='LOCAL-Q052-SOURCE-REAL-SCALAR-PREFIX-V101'
EVENT='Q052-ACTIVITY-SOURCE-REAL-SCALAR-PREFIX-V101'
PUB='Q052-SOME-M013-R1'
JNAME='Q052_MATEMATIK_OG_SAMLET_JOURNAL_V101.md'
CNAME='Q052_SKALAR_PREFIXCERTIFIKAT_V101.zip'
SNAME='Q052_KORT_RESULTAT_V101.md'
TNAME='Q052_RESULTATINDTAG_OPGAVE_V101.json'
parent=ROOT/'upload'/'Q052_INGESTION_OG_SAMLET_JOURNAL_V100.md'
assert len(parent.read_bytes())==8026394
assert sha(parent.read_bytes())=='6425887c04d77d6a28b88e5ae9d5461b2b60396c53f5926d056d8b636001f233'
audit=read('input_audit.json');head=read('head.json')['sha'];tree=read('tree.json')
assert not tree['truncated'] and not any('Q052' in x['path'] and 'V101' in x['path'] for x in tree['tree'])
capture=read('capture.json')['cases']['hillipop-ede_n3'];old=read('q048_prefix_final_v1.json')['raw_results']['hillipop-ede_n3']
assert capture['source_input_hashes']==old['source_input_hashes']
assert old['source_commit']==task['source_commit']
assert old['source_initialization']==read('initial.json')
assert sha((P/'capture.json').read_bytes())==audit['capture_sha256']
ref=read('result99.json')
result={
 'schema':'Q052_V101_SCALAR_PREFIX_RESULT','created_at_utc':stamp,'result_id':RUN,'task_id':task['task_id'],
 'task_fingerprint':task['fingerprint_sha256'],'exact_question':task['exact_question'],'source_commit':task['source_commit'],
 'capture_sha256':audit['capture_sha256'],'engine':'BUBBLEVERSE.MATHEMATICS 2.3.0',
 'scientific_state':'INCONCLUSIVE','technical_state':'PARTIAL_VALIDATED_PREFIX_CONDITIONAL','workflow_state':'READY_FOR_HANDOFF',
 'anchor_z800_gate':'NOT_REACHED','weight_screen':'NOT_EXECUTED_ANCHOR_PREREQUISITE_UNMET',
 'scope':'Exact-real scalar-only IVP for the same V73 fixed B-star, under inherited source/capture/initialization premises. No native floating-point trajectory certificate.',
 'initialization_ref':'initial.json','checkpoint':{k:raw[k] for k in ['certified_end_a','certified_end_z','endpoint','energy_endpoint']},
 'display_only':{'a':float(F(raw['certified_end_a'])),'z':float(F(raw['certified_end_z'])),
                 'phi':list(map(lambda x:float(F(x)),raw['endpoint'][0])),
                 'X_Mpc_inverse':list(map(lambda x:float(F(x)),raw['endpoint'][1])),
                 'energy_Mpc_inverse_squared':list(map(lambda x:float(F(x)),raw['energy_endpoint']))},
 'accepted_cells':raw['accepted_cells'],'rejected_candidates':raw['rejected_candidates'],
 'prototype_wall_seconds':raw['prototype_wall_seconds'],'prototype_limit_seconds':300,'stop_reason':raw['stop_reason'],
 'verification_ref':'verification101.json','verification_status':validation['status'],'verification_checks':validation['checks'],
 'verification_independence':validation['shared_component'],
 'new_native_pairs':0,'new_full_history_integrations':0,'new_weight_evaluations':0,
 'inherited_unchanged':{k:ref[k] for k in ['pilot_interval','new_global_interval','global_width','global_width_goal_ratio','new_weight_width','weight_width_ceiling','maximum_location']},
 'new_energy_cap_at_z800':None,'improvement_to_pilot_or_global_bound':False,'q052_completion_gate':False,
 'limitations':['Target z800 not reached; partial prefix cannot replace a z800 scalar anchor.',
   'Local order12/13 Taylor replay shares implementation; independent checks cover field, Picard enclosure, energy, guard and continuity.',
   'Original source initialization and captured-real interpretation remain inherited conditional premises.',
   'Wall-clock-limited search is machine-dependent; the stored fixed-cell certificate can be rechecked independently of search timing.',
   'Native source identity, trajectory error, reproducibility and requested numerical-error certificate remain open.'],
 'next_engine':task['return_engine'],'continue_same_q':True}
put(CERT/'result101.json',result)
snapshot_hash=sha((CERT/'result101.json').read_bytes())

repo='https://github.com/Morfindien/Bubbleverse'
sources=[{'id':'S1','title':'Frozen Q052 mathematical task','file':'inputs/Q052_MATEMATIKOPGAVE_V100.json','sha256':sha((ROOT/'upload'/'Q052_MATEMATIKOPGAVE_V100.json').read_bytes())},
 {'id':'S2','title':'Captured hillipop-ede_n3 background','file':'capture.json','sha256':audit['capture_sha256']},
 {'id':'S3','title':'Historical exact-real source initialization','file':'q048_prefix_final_v1.json','sha256':sha((P/'q048_prefix_final_v1.json').read_bytes()),'url':f'{repo}/blob/{head}/q048_prefix_final_v1.json'},
 {'id':'S4','title':'Historical broad joint scalar enclosure','file':'q048_resume_final_v5.json','sha256':sha((P/'q048_resume_final_v5.json').read_bytes()),'url':f'{repo}/blob/{head}/q048_resume_final_v5.json'},
 {'id':'S5','title':'Pinned source background.c','file':'background.c','sha256':sha((P/'background.c').read_bytes()),'source_commit':task['source_commit'],'relevant_lines':[475,485,609,2759,2760,3020,3037]},
 {'id':'S6','title':'New recorded scalar steps','file':'prototype_result.json','sha256':sha((P/'prototype_result.json').read_bytes())},
 {'id':'S7','title':'Independent rational checks and shared-code higher precision Taylor replay','file':'verification101.json','sha256':sha((P/'verification101.json').read_bytes())},
 {'id':'S8','title':'Inherited V99 optical-weight result','file':'result99.json','sha256':sha((P/'result99.json').read_bytes())}]
put(CERT/'source_register.json',sources)
claims=[{'id':'C101-1','claim':'1071 contiguous recorded scalar cells satisfy verified inclusion gates under the inherited fixed-source premises.','status':'CONDITIONAL_VERIFIED','evidence':['initial.json','prototype_result.json','verification101.json']},
 {'id':'C101-2','claim':'The 299.009915334 second prototype stopped at z approximately 868538.175; z800 was not reached.','status':'MEASURED_COMPUTATIONAL_OUTCOME','evidence':['prototype_result.json']},
 {'id':'C101-3','claim':'No new optical-weight evaluation or improvement to V99 pilot/global bounds is claimed.','status':'UNCHANGED','evidence':['result101.json','result99.json']},
 {'id':'C101-4','claim':'Q052 remains open; no native trajectory or physical model validation follows from this scalar prefix.','status':'INCONCLUSIVE','evidence':['result101.json','inputs/Q052_MATEMATIKOPGAVE_V100.json']}]
put(CERT/'claim_map.json',claims)

public_question='Can a fixed cosmological model produce reproducible electron-fraction and Thomson-optical-depth differences with a validated numerical error bound?'
narration='''How much of a cosmological calculation have we actually checked?

We held the model parameters and starting state fixed, then followed its scalar field using intervals that bound numerical uncertainty.

The trial produced one thousand and seventy-one checked steps. It stopped after about five minutes, well before the required checkpoint.

We checked the connections between steps, the energy bounds, and the conditions needed by the equations. Part of the higher-precision check reused the original Taylor code, so that limitation stays explicit.

The requested final error certificate remains open. Our next task is to improve the propagation method and reach the checkpoint while preserving those bounds.

This is ongoing computational research. The partial calculation is now documented for review.
'''
put(PKG/'SHORT_FORM_SCRIPT.txt',narration)
put(PKG/'SOME_UPDATE.md',f'''# A checked partial path through a cosmological calculation

**Status: ONGOING.**

The question is whether a fixed cosmological model yields reproducible differences in electron fraction and Thomson optical depth with a validated numerical error bound.

This step examined only the scalar background. A bounded interval calculation produced **1,071 accepted steps** before stopping after **299.01 seconds**. Its last checkpoint was at redshift approximately **868,538**, while the requested checkpoint was **800**, at a later stage of expansion.

The recorded steps were checked for exact continuity, whole-step interval inclusion, energy bounds and the source equations' guard condition. The field and energy checks used a separate rational interval implementation. The higher-precision Taylor replay reused the original recurrence code.

We now have a conditional certificate for an early partial path. The required scalar anchor was not reached, and the previous optical-depth bounds remain unchanged. This calculation does not certify the actual native implementation's complete trajectories or establish a physical discovery.

Next: review step-size efficiency and interval-width growth, then define a bounded continuation from the verified checkpoint. The full scientific question remains open.

Sources: the accompanying calculation and verification records; [research repository]({repo}); [frozen source-initialization record]({sources[2]['url']}). The new files are supplied with this update; repository publication of them is not claimed.
''')
put(PKG/'VIDEO_PROMPT.txt',f'''Create a 65–75 second English vertical research update, 1080x1920. Calm, precise narration and large accessible captions. Do not imply a discovery or show a measured astronomical signal. All diagrams must be labelled “Model illustration”. No fabricated telescope images, data plots, error bars, or invented trajectories.

Narration, verbatim:
{narration}
Scene direction:
0–7 seconds: Abstract model equation and title “How much have we checked?” Caption: “ONGOING RESEARCH”.
7–22 seconds: Simple illustrative path surrounded by shaded interval boxes. Caption: “Fixed model • fixed starting state”. Do not use a quantitative curve.
22–34 seconds: Display “1,071 checked steps” and “Trial: 299.01 s”. Then show an early checkpoint and a clearly unreached target. Captions: “Final redshift ≈ 868,538” and “Target redshift = 800”. Add “Later expansion lies toward smaller redshift”.
34–49 seconds: Four readable labels appear: “Connected steps”, “Interval inclusion”, “Energy bounds”, “Equation guard”. Caption: “Taylor replay shares original code”.
49–65 seconds: Caption “Target checkpoint unreached”. Then “Final error certificate: still open”.
65–75 seconds: End card “Next: improve propagation and retain verified bounds”. Footer “Model illustration • Ongoing computational research”.

Match the scientific meaning of the narration. The result is a conditional scalar-background prefix, not a completed electron-history or optical-depth certificate. Do not display internal project points or version labels. No dramatic discovery claims. Use a quiet neutral background; no stock footage presented as evidence.
''')
put(PKG/'YOUTUBE_TITLE.txt','1,071 Checked Steps in an Unfinished Cosmology Calculation\n')
put(PKG/'YOUTUBE_DESCRIPTION.txt',f'''A five-minute interval calculation produced 1,071 checked steps through a fixed cosmological model's scalar background. The required later checkpoint was not reached, so the final numerical-error certificate remains open.

Separate rational checks covered step inclusion, energy and the equation guard. A higher-precision Taylor replay shared the original code. Previous optical-depth bounds remain unchanged.

Status: ongoing computational research. Visuals are model illustrations.
Research and historical source records: {repo}
{sources[2]['url']}
The accompanying calculation files document this update; their repository publication is not claimed.

#Cosmology #NumericalMethods #ResearchUpdate
''')
put(PKG/'YOUTUBE_TAGS.txt','cosmology,interval arithmetic,validated numerics,numerical methods,scalar field,computational research,reproducibility,scientific uncertainty,research update\n')
put(PKG/'TIKTOK_DESCRIPTION.txt','1,071 checked steps, with the target checkpoint still ahead. A partial interval calculation through a cosmological model is documented; the final error certificate remains open. Model illustrations only. #Cosmology #NumericalMethods #ResearchUpdate #ScientificUncertainty\n')
put(PKG/'PUBLICATION_PACKAGE.json',{'schema':'BV_PUBLICATION_PACKAGE_1','publication_id':PUB,'language':'en','question':public_question,'status':'ONGOING','canonical_claims':claims,'source_references':[{'id':s['id'],'title':s['title'],**({'url':s['url']} if 'url' in s else {'accompanying_certificate_entry':s['file']})} for s in sources],'limitations':result['limitations'],'next_research_task':'Review propagation efficiency and interval growth, then define a bounded continuation from the verified scalar checkpoint.','publications_posted':False})
assert len((PKG/'VIDEO_PROMPT.txt').read_text())<=8000
put(PKG/'PUBLICATION_MANIFEST.json',{'schema':'BV_PUBLICATION_MANIFEST_1','q':'Q052','publication_id':PUB,'milestone_id':'Q052-SOME-M013','threshold_points':13000,'snapshot_result_sha256':snapshot_hash,'snapshot_ref':'result101.json','journal_ref':JNAME,'point_ledger_ref':'activity_ledger.json','created_at_utc':stamp,'delivery_state':'NINE_SEPARATE_FILES_AND_DOWNLOADABLE_ARCHIVE_WITH_THIS_HANDOFF','external_publication':'NOT_POSTED','files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(PKG.iterdir()) if p.name!='PUBLICATION_MANIFEST.json']})
assert len(list(PKG.iterdir()))==9
zwrite(OUT/'Q052_SOME_M013_R1.zip',{p.name:p.read_bytes() for p in PKG.iterdir()})

ledger=read('ledger100.json');prior=copy.deepcopy(ledger);assert prior['total_points_after']==sum(e.get('run_points',0) for e in prior['entries'])==12890
assert not any(e.get('activity_event_id')==EVENT for e in prior['entries'])
entry={'activity_event_id':EVENT,'run_id':RUN,'engine':'BUBBLEVERSE.MATHEMATICS 2.3.0','run_points':180,
 'breakdown':{'analysis':45,'computation':65,'source_recovery_and_search':30,'validation':40},'counted_once':True,
 'assessment_type':'HEURISTIC_DOCUMENTED_ACTIVITY_INDEX',
 'basis':'New source-real IVP/initialization audit, order12 interval Taylor prototype with 1071 accepted and 1145 rejected attempts in 299.009915334 seconds, independent rational field/Picard/energy/guard checks and 80-digit Taylor replay. Validation debugging included once. Historical results, copying, hashing, packaging and SoMe production are not charged.',
 'uncertainty':'Rounded subjective activity estimate, not measured tokens, FLOPs, money, completion percentage or scientific confidence.'}
ledger['entries'].append(entry)
ledger.update({'previous_ledger_ref':parent.name,'previous_total_points':12890,'total_points_after':13070,'cycle_progress':70,'next_publication_at':14000,'points_to_next_publication':930,'new_milestones':['Q052-SOME-M013'],'pending_packages':[],'ready_milestone_ids':[],'scientific_state':'INCONCLUSIVE','workflow_state':'READY_FOR_HANDOFF','point_state':'VERIFIED','note':'180 new heuristic research-activity points. M013 files delivered with this handoff; same Q052 continues. Historical stale V100 note stating 135 new points is superseded by its verified 65-point entry and preserved in the parent journal.','ledger_revision':'V101','parent_ledger_sha256':sha((P/'ledger100.json').read_bytes()),'last_updated_utc':stamp,'reconciliation':{'prior_total':12890,'new_unique_event_points':180,'current_total':13070}})
ledger['delivered_milestone_ids'].append('Q052-SOME-M013')
ledger['milestone_records'].append({'milestone_id':'Q052-SOME-M013','publication_id':PUB,'threshold_points':13000,'snapshot_ref':JNAME,'snapshot_result_sha256':snapshot_hash,'package_state':'DELIVERED','delivery_state':'NINE_SEPARATE_FILES_AND_DOWNLOADABLE_ARCHIVE_WITH_V101','file':'Q052_SOME_M013_R1.zip','file_sha256':sha((OUT/'Q052_SOME_M013_R1.zip').read_bytes()),'package_manifest_ref':'Q052_SOME_M013_R1/PUBLICATION_MANIFEST.json','package_manifest_sha256':sha((PKG/'PUBLICATION_MANIFEST.json').read_bytes()),'external_publication':'NOT_POSTED','fulfillment_event_id':'Q052-SOME-M013-FILE-DELIVERY-V101'})
assert sum(e.get('run_points',0) for e in ledger['entries'])==13070
assert ledger['entries'][:-1]==prior['entries']
put(CERT/'activity_ledger.json',ledger)

nexttask={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','task_id':'LOCAL-Q052-V101-SCALAR-PREFIX-RESULT-INGESTION','engine':task['return_engine'],'state':'PREPARED_NOT_EXECUTED','case_id':task['case_id'],'current_q':'Q052','target_q':'Q052','exact_question':task['exact_question'],'source_commit':task['source_commit'],'parent_result_id':RUN,'result_ref':'result101.json','journal_ref':JNAME,'objective':'Ingest the bounded partial scalar result without promoting it to a z800 anchor; define one improved bounded continuation on the same fixed B-star.','ordered_work':['Verify archive manifest, journal prefix, exact endpoint connection and result/verification scope. Ingest only the certified early prefix.','Retain V99 pilot and global bounds. Record z800 and new weight evaluation as unmet prerequisites, with no new native result.','Review unnecessary repeated halving from a reset 1/32 proposal, the 1e-22 local remainder target and accumulated interval width. Specify one parameter-preserving improved continuation with an explicit time/coverage/tightness gate.','Prefer the exact stored endpoint and joint state after authenticated source linkage. Do not restart from a native spline or independently selected projection. A numerically poor checkpoint requires a documented choice, not silent reuse.','Create one mathematics handoff with no new native pair or full-history integration. Continue Q052; M013 delivery gives no closure.'],'no_repeat':task['no_repeat']+['V101 wall-clock prototype or its fixed-cell verification as new research credit without a new failure or changed premise.'],'acceptance':'An exact scoped result receipt and one genuinely improved finite continuation contract, with frozen source parameters and explicit failure criteria.','stop_condition':'Stop after result ingestion and one finite next-task definition. Do not execute a second scalar prototype as part of this receipt.','new_native_pairs':0,'new_full_history_integrations':0,'continue_same_q':True,'total_points':13070,'next_milestone':14000,'points_to_next_publication':930}
nexttask['fingerprint_sha256']=sha(json.dumps(nexttask,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
put(OUT/TNAME,nexttask);put(CERT/TNAME,nexttask)
handoff={'schema':'Q052_V101_MATHEMATICS_HANDOFF','schema_validation':'LOCAL_CONTRACT; no external schema registry assertion','handoff_id':RUN,'created_at_utc':stamp,'case_id':task['case_id'],'current_q':'Q052','target_q':'Q052','exact_question':task['exact_question'],'prompt_id':'BUBBLEVERSE.MATHEMATICS','prompt_version':'2.3.0','engine_sha256':task['engine_prompt_sha256'],'scientific_state':'INCONCLUSIVE','technical_state':result['technical_state'],'workflow_state':'READY_FOR_HANDOFF','source_commit':task['source_commit'],'capture_sha256':audit['capture_sha256'],'result_ref':'result101.json','source_register_ref':'source_register.json','claim_evidence_map_ref':'claim_map.json','journal_ref':JNAME,'point_ledger_ref':'activity_ledger.json','integrity_manifest_ref':'manifest.json','selected_next_engine_id':task['return_engine'],'next_task':TNAME,'next_task_fingerprint':nexttask['fingerprint_sha256'],'next_research_task':nexttask['objective'],'continue_same_q':True,'completion_gate_satisfied':False,'completion_gate_reason':'No z800 anchor; native/source trajectory error and reproducibility remain unresolved.','operator_gate':'NONE_FOR_LOCAL_HANDOFF','question_activity_points':{'run_points':180,'total_points':13070,'points_to_next_publication':930,'point_state':'VERIFIED'},'some_milestones':{'crossed_this_run':['Q052-SOME-M013'],'publication_state':'DELIVERED','external_publication':'NOT_POSTED','pending':[]},'repository_memory':{'repository_url':repo,'base_commit_sha':head,'tree_sha':tree['sha'],'github_read_state':'PARTIAL_ROOT_JOURNAL_ABSENT; three V100 inputs match repository blobs; attached journal authenticated against archive','github_write_state':'NOT_ATTEMPTED_USER_UPLOAD_FILES','memory_update_ref':'github_memory_update.json'},'delivery_status':'FILES_WITH_THIS_HANDOFF'}
put(CERT/'handoff101.json',handoff)

e=raw['energy_endpoint'];a=raw['certified_end_a'];z=raw['certified_end_z']
proof=rf'''# Q052 V101 · Betinget certificeret tidlig skalarpræfiks

Det afgrænsede forsøg er afsluttet. Målet ved z=800 blev ikke nået. Det nye resultat er en sammenhængende, betinget certificeret tidlig præfiks af den samme kildebane B★. V99's optiske pilot og globale grænser står uændret. Q052 er INCONCLUSIVE.

## Fastlåsning og startgrundlag

Det præcise spørgsmål er uændret:

> {task['exact_question']}

Kildecommit: `{task['source_commit']}`. Capture-SHA-256: `{audit['capture_sha256']}`. De indfangede binary64-tal behandles som eksakte reelle konstanter; dette er ikke en påstand om en flydende native banes fejl. Begge q-arme beholder samme faste B★ og matchet termodynamisk start ved z=810. Der er ikke udført nye q-arme eller termodynamiske integrationer.

Den genfundne Q048-præfiks indeholder en autentificeret tidlig fælles tilstand. Kildecommit og alle tre source_input_hashes matcher capture. Dens `source_initialization` matches byteuafhængigt som JSON mod `initial.json`. De historiske optagelsesbetingelser er stadig betingede. Den senere genfundne tilstand omkring z=4980 har brede phi/X-intervaller og giver ikke et smalt pilotanker. Energi- og virialprojektioner giver heller ikke ret til en uafhængig snæver tilstandsgenstart.

Den anvendte eksakte start er

\[
a_0=\frac{{6338253001141147}}{{633825300114114700748351602688}},\qquad
\phi_0=\frac{{8485763490152717}}{{36028797018963968}},\qquad X_0=0.
\]

## Kildeligninger og metode

Med u=ln(a), X=phi_prime/a, U=A(1-cos(lambda phi))³ og f som det konstante gulv anvendes

\[
\frac{{d\phi}}{{du}}=\frac{{X}}{{H}},\quad
\frac{{dX}}{{du}}=-3X-\frac{{U_\phi}}{{H}},\quad
H^2=B_0(a)+\frac{{X^2/2+U+f}}{{3}}.
\]

A er den eksakte binary64-konstant 4152.39 gange de indfangede m²F²; lambda er den eksakte binary64-konstant 2.435e27 divideret med F; f er det indfangede B gange den eksakte binary64-konstant 3.968e-8. Eksponenten i den indfangede model er præcis 3. Materie, stråling og alle 11 indfangede massive-neutrino-knuder indgår i B0. Fladhed og fravær af øvrige arter er kontrolleret mod capture. H har enhed Mpc⁻¹, X Mpc⁻¹ og e=X²/2+U Mpc⁻².

For hver celle bruges lokal tid t=(a−a_left)/a_left. Højresiden ovenfor divideres med 1+t. Et interval B opfylder Picard-indeslutningen y_left+[0,h]F([0,h],B) ⊂ B. H og alle nævnere er strengt positive; feltet er glat på den verificerede boks. Dermed findes den lokale løsning, og den forbliver i boksen. Startboksen indeholder den tidligere accepterede slutboks. Ingen celle genstarter på en uafhængigt udvalgt bane.

Taylor-koefficienterne genereres ved almindelig interval-jet-aritmetik til orden 12. Orden 13 genereres på hele tids- og tilstandsboksen og indkapsler Lagrange-restleddet. Polynomiet evalueres med Horner, og restleddet tilføjes udadrettet. Slutboksen skal også ligge i Picard-boksen. Alle gemte intervalendepunkter og tider er eksakte rationale tal. Grundkørslen bruger mpmath.iv 1.3.0 med 50 decimalcifre. Koordinatbokse kan blive bredere på grund af tab af korrelation; det ændrer ikke den faste parameters identitet.

Implementationsvalget var relativt foreslået trin 1/32, op til 24 halveringer pr. trin, orden 12 og lokalt absolut restledsmål 10⁻²²(1+|tilstand|). Disse er numeriske arbejdsvalg, ikke nye fysiske antagelser. Trinforslaget nulstilles efter hvert accepteret trin; det medfører gentagne afvisninger og er en konkret mulighed for metodeforbedring. Tidsgrænsen afsluttede forsøget, ikke en påvist fysisk modstrid.

## Resultat og eksakt checkpoint

- Accepterede celler: **1071**. Afviste kandidatforsøg: **1145**.
- Målt prototype-tid: **{raw['prototype_wall_seconds']:.9f} s** inden for 300 s. Stop: PROTOTYPE_TIME_LIMIT.
- Sidste a ≈ **{float(F(a)):.16g}**, svarende til z ≈ **{float(F(z)):.12f}**.
- Phi ≈ [{result['display_only']['phi'][0]:.17g}, {result['display_only']['phi'][1]:.17g}].
- X ≈ [{result['display_only']['X_Mpc_inverse'][0]:.17g}, {result['display_only']['X_Mpc_inverse'][1]:.17g}] Mpc⁻¹.
- e ≈ [{float(F(e[0])):.16g}, {float(F(e[1])):.16g}] Mpc⁻².

Decimalvisningerne er orienterende; certificering og genoptagelse bruger de eksakte brøker i `result101.json` og `prototype_result.json`. Dette er et checkpoint langt tidligere end z=800. Det må ikke relabels som en skalarenergi ved 800.

## Kontrol og begrænsning

En separat rationel implementering med udadrettet afrunding på et 2⁻²⁴⁰-gitter har kontrolleret alle 1071 cellers Picard-feltindeslutning og slutenergi. Sinus/cosinus beregnes med Taylor-rækker og eksakte restledsgrænser; cosinus' monotoni verificeres på de små argumentintervaller. Kvadratrødder indkapsles ved heltalskvadratrødder og eksakte kvadreringsgrænser. Tidssammenhæng og tilstandssammenhæng kontrolleres eksakt.

Desuden genberegnes hver gemt Taylor-slutboks og hvert restled med 80 decimalcifre og skal være indeholdt i de gemte 50-cifrede grænser. Denne del bruger samme Taylor-implementering. Den udgør derfor ikke en fuldstændigt uafhængig Taylor-kode eller et formaliseret maskinbevis. Resultat: **{validation['checks']} kontroller, ingen fejlede**, PASS_CONDITIONAL. Verifikationstiden er {validation['wall_seconds']:.3f} s; den er efterkontrol af de allerede gemte celler og ikke en anden prototype eller fremføring mod målet.

Den bogstavelige source-guard U/(3H²)<1/2 er bevist på hele den nye præfiks med

\[
G=3H^2-2U=3B_0+X^2/2-U+f
\ge 3(M/a_{{end}}^3+R/a_{{end}}^4)-8A+f>0.
\]

Materie og stråling er positive og aftager med a; neutrinoleddet er ikke-negativt. Den eksakte positive nedre grænse står i `verification101.json`. Samme argument giver H²>0. Energiidentiteten de/du=−3X² følger algebraisk af de samme ligninger. Den er ikke anvendt til en ny pilotgrænse, fordi det krævede z800-anker mangler.

Første kontrolimplementering gav for brede rationelle energibokse og kunne derfor ikke bekræfte indeslutning i de smallere gemte energigrænser. Den havde 1071 energigates uden indeslutning, mens dens øvrige gates bestod. Store potenser ganget med meget små inverse fakulteter skabte unødigt bred intervalafrunding; rekurrerende Taylor-led og monoton endpoint-evaluering løste dette kontrolproblem. De oprindelige prototypedata blev ikke ændret. Den oprindelige kontroldiagnostik er bevaret. En tidligere type-dispatch-fejl før første accepterede prototypecelle blev også rettet; den gav ingen ekstra beregningsbane.

## Konsekvens for Q052 og næste trin

Ingen ny vægtevaluering er udført. V99-pilotintervallet er fortsat cirka [1,38764788856×10⁻⁶; 3,81921195829×10⁻⁶], og det globale source-interval er fortsat cirka [1,43348504759×10⁻⁶; 4,57064839822×10⁻⁵]. Den globale bredde er cirka 4,42729989346×10⁻⁵, omtrent 11068 gange det foreløbige breddeønske 4×10⁻⁹. Disse er arvede source-grænser, ikke nye native fejlcertifikater. De eksakte V99-brøker er videreført uændret.

Tilbage står at nå z=800 med en brugbar fælles skalarboks, teste den samme 105-subcellepilot ved et gyldigt anker og afklare native banefejl, medlemskab og reproducerbarhed. Ingen procentvis forskningsfærdiggørelse kan udledes af antallet af celler, point eller tidsforbruget.

Næste motor er **{task['return_engine']}**. Opgaven er et præcist resultatindtag og en ny afgrænset matematikopgave, som adresserer de gentagne trinhalveringer og intervalbreddevækst. Genbrug det autentificerede checkpoint efter egnethedskontrol. Dette forsøg gentages ikke uændret. Se `{TNAME}`. Ingen nye native par eller komplette historiesimulationer er tilladt i den definerede næste opgave.

## Provenance, points og levering

GitHub-base `{head}`, træ `{tree['sha']}`. Tre V100-inputfiler matcher repoets blobs. Den fulde V100-journal mangler ved repoets rod, men den vedhæftede autoritative journal er autentificeret mod arkivet og videreføres byte-for-byte som de første 8.026.394 bytes. GITHUB_READ_STATE er derfor PARTIAL for rodjournalen; GITHUB_WRITE_STATE er NOT_ATTEMPTED. Ingen GitHub-publicering eller SoMe-posting påstås. Filerne er klar til brugerens upload.

RUN POINTS: 180 = analyse45 + beregning65 + kildegenfinding30 + validering40. TOTAL POINTS: 13070 fra verificeret12890. Det er et dokumenteret heuristisk aktivitetsindeks, ikke en præcisionsmåling eller en procentdel af løsningen. Pakkeproduktion, journalkopiering og gamle resultater tæller0. V100-ledgerens gamle prosanote om135 point var forældet; dens65-pointpost og totalsum var konsistente og er bevaret.

M013 er nået. Pakken `{PUB}` leveres med ni separate engelske indholdsfiler og ZIP, baseret på dette låste resultatsnapshot `{snapshot_hash}`. Offentlig status er ONGOING. Næste milepæl14000, afstand930. Q052 fortsætter. Kilder, kildehashes, kode, råresultater, kontrol og hele den tidligere certifikatpakke er vedlagt.
'''
proof=proof.replace('byteuafhængigt som JSON','som identiske JSON-data').replace('relabels','omdøbes').replace('analyse45','analyse 45').replace('beregning65','beregning 65').replace('kildegenfinding30','kildegenfinding 30').replace('validering40','validering 40').replace('verificeret12890','verificeret 12890').replace('tæller0','tæller 0').replace('om135','om 135').replace('dens65','dens 65').replace('milepæl14000','milepæl 14000').replace('afstand930','afstand 930')
put(CERT/'PROOF_V101.md',proof)

short=f'''# BUBBLEVERSE — OVERLEVERING

**V101: Et tidligt delresultat er dokumenteret. Målet ved z=800 er ikke nået.**

STATUS: FORTSÆTTER · WORKFLOW_STATE: READY_FOR_HANDOFF · SCIENTIFIC_STATE: INCONCLUSIVE · TECHNICAL_STATE: PARTIAL_VALIDATED_PREFIX_CONDITIONAL.

TARGET_Q: Q052. Evidensgrænse: samme fastlåste source-real B★ og de arvede startbetingelser; ingen certificering af native banefejl. PROMPT_ID: BUBBLEVERSE.MATHEMATICS, version2.3.0. Valgt næste motor: {task['return_engine']}.

## Afgjort og nyt

Forsøget accepterede **1.071 trin** på **299,01 sekunder**. Det sidste kontrollerede punkt er **z≈868.538,175**, langt før målet800. Alle gemte celler bestod efterkontrollen: **{validation['checks']} gates**, herunder uafhængige rationelle intervalkontroller. Taylor-kontrollen ved højere præcision genbruger den oprindelige kode; den begrænsning er dokumenteret.

Der er ikke udført en ny optisk vægttest. V99's pilot og globale grænser er uændrede. Hovedspørgsmålet mangler fortsat et tilstrækkeligt præcist resultat og dokumentation for native banefejl og reproducerbarhed.

## Aktuel overlevering

BLOCKER_ID: V101_TARGET_ANCHOR_NOT_REACHED_WITHIN_BOUNDED_PROTOTYPE. Næste opgave er at indtage delcertifikatet og definere en forbedret, afgrænset fortsættelse, der håndterer gentagne trinhalveringer og voksende intervalbredde. Genoptagelse kræver autentificeret kobling til det gemte checkpoint og en konkret forbedret numerisk kontrakt. Se `{TNAME}`.

Accept: et korrekt afgrænset resultatindtag og én ny finite opgave på samme kildebane. Afvis: at kalde dette et z800-anker eller skærpe pilotgrænserne uden et sådant anker. INCONCLUSIVE: checkpointets bredde eller beregningshastighed er utilstrækkelig. Det uændrede forsøg og tidligere afsluttede piloter skal ikke gentages uden ny grund.

Ligninger: dphi/dln(a)=X/H, dX/dln(a)=−3X−U_phi/H, H²=B0+(X²/2+U+f)/3. X og H måles i Mpc⁻¹, skalarenergien i Mpc⁻². Eksakte input, usikkerheder, restled og begrundelse findes i certifikatets `PROOF_V101.md`, `result101.json`, råceller og kontrolkode.

## Samlet journal og provenance

`{JNAME}` bevarer hele den tidligere journal uændret og tilføjer dette resultat, handoff og komplet ledger. Certifikatet `{CNAME}` indeholder kode, data, kilder og kontrolresultater. Kildecommit: `{task['source_commit']}`. Den aktuelle repo-base er `{head}`. Tre V100-filer blev verificeret i repoet; den fulde journal blev verificeret fra vedhæftningen. Ingen filer er skrevet til GitHub.

## Point- og udgivelsesstatus

RUN POINTS **180**: analyse45, beregning65, kildegenfinding30, validering40. TOTAL POINTS **13070**. Cyklus70/1000; næste milepæl14000; afstand930. RUN_ID: `{RUN}`. Forrige pointpost: `{prior['entries'][-1]['activity_event_id']}`. POINTS_STATE: VERIFIED. Pointene er et heuristisk aktivitetsmål; ingen gamle beregninger eller pakkeproduktion er genkrediteret.

**SoMe M013 leveres nu**: ni separate engelske filer og `Q052_SOME_M013_R1.zip`. PUBLICATION_STATE: DELIVERED_FILES_WITH_THIS_HANDOFF; ingen offentlig posting. Ingen udestående pakker. Historiske M001–M012 bevares. Bedste nye resultat er den betinget validerede tidlige skalarpræfiks. Det ønskede slutcertifikat mangler stadig. CONTINUE_SAME_Q: true.

## ChatGPT-setupvurdering og kontrakt

Aktuelt setup: ChatGPT Work Mode med lokal Python3.12 og mpmath1.3.0. Det er egnet og tilgængeligt til resultatindtag, kildekontrol og et nyt begrænset intervalforsøg. Anbefalet primært setup er samme lokale miljø med eksplicit rationel/interval kontrol og grundig matematisk gennemgang. Kapabilitetsklasse: kildeaudit og valideret numerik. Ingen målt anbefaling om en bestemt modelvariant eller ekstra compute kan udledes af dette forsøg. Fallback er en filbaseret overlevering af de autentificerede celler. Opgradering kræves, hvis en forbedret konkret metode stadig rammer en dokumenteret runtimegrænse; rutinemæssigt indtag kræver ikke en opgradering. Nødvendige tools er lokal kodekørsel og læseadgang til projektkilder.

JSON, hashmanifest, intervalforbindelser, journalpræfiks og ledger er kontrolleret. Kontrakterne er lokale og påstår ikke ekstern skemaregistrering. Den fastsatte ene prototype er afsluttet; en ny fremføring er ikke udført i denne aflevering.
'''
short=short.replace('version2.3.0','version 2.3.0').replace('målet800','målet 800').replace('én ny finite opgave','én ny afgrænset opgave').replace('analyse45','analyse 45').replace('beregning65','beregning 65').replace('kildegenfinding30','kildegenfinding 30').replace('validering40','validering 40').replace('Cyklus70/1000','Cyklus 70/1000').replace('milepæl14000','milepæl 14000').replace('afstand930','afstand 930').replace('Python3.12','Python 3.12').replace('mpmath1.3.0','mpmath 1.3.0')
put(OUT/SNAME,short)
put(CERT/SNAME,short)
put(CERT/'environment.json',{'python':sys.version,'platform':platform.platform(),'mpmath':mpmath.__version__,'interval_precision_decimal':50,'Taylor_replay_precision_decimal':80,'independent_interval_grid_bits':240,'prototype_seconds':raw['prototype_wall_seconds'],'verification_seconds':validation['wall_seconds'],'timing_reproducibility':'Stored fixed cells are the reproducible certificate; wall-clock adaptive-search endpoint depends on machine and load.'})
put(CERT/'diagnostics.json',{'prototype_prestart_issue':'NotImplementedError from an mpmath.iv left operand applied to Jet. Corrected operator dispatch before any accepted cell; no extra numerical prototype.','coarse_verification':'First rational checker used very large powers with tiny reciprocal factorials at fixed absolute precision, producing broad energy boxes. All 1071 energy containment comparisons were inconclusive; all other gates passed. Recurrent terms and monotone cosine endpoints removed that needless widening. Raw prototype data unchanged.','coarse_control_ref':'verification_coarse_diagnostic.json','final_control_ref':'verification101.json','new_weight_evaluation':'NOT_EXECUTED','native_pairs':0,'full_history_integrations':0})
memory={'schema':'Q052_V101_GITHUB_MEMORY_UPDATE','q':'Q052','prompt_id':'BUBBLEVERSE.MATHEMATICS','prompt_version':'2.3.0','run_id':RUN,'result_ref':'result101.json','journal_ref':JNAME,'source_register_ref':'source_register.json','point_ledger_ref':'activity_ledger.json','points':handoff['question_activity_points'],'publication':handoff['some_milestones'],'exact_question':task['exact_question'],'status_axes':{k:result[k] for k in ['scientific_state','technical_state','workflow_state']},'new_contribution':'1071-cell conditional validated early scalar prefix; target z800 not reached; no tighter optical bound.','claim_map_ref':'claim_map.json','completed_no_repeat':nexttask['no_repeat'],'blocker':'V101_TARGET_ANCHOR_NOT_REACHED_WITHIN_BOUNDED_PROTOTYPE','next_engine':task['return_engine'],'next_task':TNAME,'next_task_fingerprint':nexttask['fingerprint_sha256'],'repository':handoff['repository_memory'],'proposed_destinations':{'root':[JNAME,SNAME,CNAME,TNAME],'publication_directory':'content/publication/Q052_SOME_M013_R1/'},'proposed_paths_are_existing':False,'index_updates':'Update the operator-selected current Q052 journal/state references to V101 after uploading these files. No unverified registry path is invented.','file_integrity_ref':'manifest.json','related_qs':['Q048','Q050','Q051'],'write_authorization_exercised':False}
put(CERT/'github_memory_update.json',memory)
put(CERT/'README.md',f'''# Q052 V101 scalar-prefix certificate

Read `{SNAME}` and `PROOF_V101.md` first. The requested z800 anchor was not reached. Q052 remains open.

The evidence is `prototype_result.json` plus `verification101.json`, with the inherited exact-real source premises. To recheck recorded cells, extract this archive to a directory with Python3.12 and mpmath1.3.0 and run `python verify101.py`. This verifies the saved cells without selecting or advancing new steps. Do not rerun `prototype101.py` merely to reproduce a wall-clock stopping endpoint.

`result101.json` contains the exact resumable endpoint. `activity_ledger.json` preserves all prior point entries. `{TNAME}` returns the result to {task['return_engine']}. `history/` preserves the V100 input certificate. The complete cumulative journal is delivered separately as `{JNAME}`; its hash is in the manifest. Archive paths are relative after extraction.

Upload-ready repository artifacts are the full journal, short result, certificate and next task. The nine publication files may be placed in the proposed `content/publication/Q052_SOME_M013_R1/` directory. No GitHub write or social posting has been performed. The attached V100 journal is authoritative even though that full journal was absent at the audited repository root.

The manifest omits its own hash and this ZIP's hash to avoid circularity. External deliverable hashes are separate from in-archive file hashes.
''')
append='\n\n---\n\n'+proof+'\n\n## Maskinlæsbar aktuel overlevering V101\n\n```json\n'+json.dumps(handoff,indent=2,ensure_ascii=False)+'\n```\n\n## Maskinlæsbart kumulativt aktivitetsledger V101\n\n```json\n'+json.dumps(ledger,indent=2,ensure_ascii=False)+'\n```\n'
(OUT/JNAME).write_bytes(parent.read_bytes()+append.encode())
assert (OUT/JNAME).read_bytes()[:parent.stat().st_size]==parent.read_bytes()

files={p.name:p.read_bytes() for p in CERT.iterdir() if p.is_file() and p.name!='manifest.json'}
for name in ['prototype101.py','prototype_result.json','prototype.log','verify101.py','verification101.json','verification.log','verification_coarse_diagnostic.json','verification_coarse_diagnostic.log','capture.json','initial.json','input_audit.json','background.c','v73.json','guard.json','binding.json','PROOF_V73.md','q048_prefix_final_v1.json','q048_resume_final_v5.json','q048_p2p4_state_tube_result_v1.json','q047_math_v1.py','q047_precursor_check_v1.py','q048_math021_branch_independent_scalar_enclosure_v1.json','result99.json','control99.json','build101.py']:
    files[name]=(P/name).read_bytes()
for p in PKG.iterdir():files['Q052_SOME_M013_R1/'+p.name]=p.read_bytes()
files['inputs/Q052_MATEMATIKOPGAVE_V100.json']=(ROOT/'upload'/'Q052_MATEMATIKOPGAVE_V100.json').read_bytes()
files['inputs/ENGINE_MATHEMATICS_2.3.0.md']=(ROOT/'upload'/'Bubbleverse_Matematikmotor_2.3.0-60.md').read_bytes()
files['history/Q052_INGESTION_CERTIFICATE_V100.zip']=(ROOT/'upload'/'Q052_INGESTION_CERTIFICATE_V100.zip').read_bytes()
files['audit/repository_head.json']=(P/'head.json').read_bytes()
files['audit/repository_tree.json']=(P/'tree.json').read_bytes()
manifest={'schema':'Q052_V101_FILE_MANIFEST','created_at_utc':stamp,'q':'Q052','run_id':RUN,'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())],
 'external_deliverables':[{'name':n,'bytes':(OUT/n).stat().st_size,'sha256':sha((OUT/n).read_bytes())} for n in [JNAME,SNAME,TNAME,'Q052_SOME_M013_R1.zip']],
 'parent_journal':{'name':parent.name,'bytes':parent.stat().st_size,'sha256':sha(parent.read_bytes()),'prefix_preserved':True},
 'raw_task_fingerprint':task['fingerprint_sha256'],'result_snapshot_sha256':snapshot_hash,'self_hash_omitted':True,'zip_self_hash_omitted':True}
put(CERT/'manifest.json',manifest);files['manifest.json']=(CERT/'manifest.json').read_bytes()
zwrite(OUT/CNAME,files)
for n,b in files.items():
    if n.endswith('.json'):json.loads(b)
with zipfile.ZipFile(OUT/CNAME) as z:
    m=json.loads(z.read('manifest.json'))
    assert set(x['path'] for x in m['files'])==set(z.namelist())-{'manifest.json'}
    for x in m['files']:
        b=z.read(x['path']);assert len(b)==x['bytes'] and sha(b)==x['sha256']
for x in manifest['external_deliverables']:assert sha((OUT/x['name']).read_bytes())==x['sha256']

index='# SoMe M013 · Separate filer\n\nPakken beskriver igangværende forskning. Ingen video er produceret eller offentliggjort.\n\n'
for p in sorted(PKG.iterdir()):index+=f'- [{p.name}](sandbox:{p.resolve()})\n'
index+=f'\nSamlet: [Q052_SOME_M013_R1.zip](sandbox:{(OUT/"Q052_SOME_M013_R1.zip").resolve()})\n'
put(OUT/'Q052_SOME_M013_R1_FILOVERSIGT.md',index)
deliver=[OUT/SNAME,OUT/JNAME,OUT/CNAME,OUT/TNAME,OUT/'Q052_SOME_M013_R1.zip',OUT/'Q052_SOME_M013_R1_FILOVERSIGT.md']+sorted(PKG.iterdir())
put(P/'upload_request.json',{'uploads':[{'local_path':str(p.resolve()),'purpose':'create_library_file','library_artifact_type':'report' if p.suffix=='.md' else 'other'} for p in deliver]})
put(P/'delivery_validation.json',{'status':'PASS','files':len(deliver),'archive_entries':len(files),'prefix_bytes_preserved':parent.stat().st_size,'ledger_total':13070,'milestone':'Q052-SOME-M013','some_files':9,'video_prompt_characters':len((PKG/'VIDEO_PROMPT.txt').read_text()),'json_parse':'PASS','zip_crc_and_manifest':'PASS','notes':'No new source-result or pilot computation during packaging.'})
print(json.dumps({'status':'PASS','output':str(OUT),'files':[(p.name,p.stat().st_size,sha(p.read_bytes())) for p in deliver],'points':13070},indent=2))
