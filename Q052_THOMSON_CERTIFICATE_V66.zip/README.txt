Q052 V66 · Thomson depth · reproduction guide
Python 3.11+ (standard library). Run from the extracted certificate directory, without -O.
Inputs from the same Q052 case: V65 cumulative journal, V60 raw in four numbered parts, V62 and V64 certificate ZIPs. Supply your local filenames, including any suffixes from downloading. Each scientific input has a pinned SHA-256 in receipt.json. thermodynamics.c and the Q051 proof/report in this archive are scope and provenance witnesses. A source copy alone does not identify an unexported simulator value.

Example commands. J, Z62 and Z64 are paths to the V65 Markdown, the V62 ZIP and the V64 ZIP. Run the first command only if the original V60 raw is not already present.
  python recover_raw.py raw60.json /path/to/Q052_FULL_HISTORY_RAW_V60_PART_*.json
  python transfer66.py "$J" raw60.json "$Z62" "$Z64" rebuilt.json > rebuilt_summary.json
  python control66.py "$J" raw60.json "$Z62" "$Z64" rebuilt.json rebuilt_control.json
  python fusion66.py rebuilt.json Q051_GLOBAL_HYBRID_AND_OBSERVABLE_PROOF_V7.md rebuilt_bands.json > rebuilt_bands_summary.json
  python bandcontrol66.py rebuilt.json rebuilt_bands.json Q051_GLOBAL_HYBRID_AND_OBSERVABLE_PROOF_V7.md rebuilt_band_control.json
  cmp rebuilt.json receipt.json
  cmp rebuilt_control.json control.json
  cmp rebuilt_bands.json band_intersection.json
  cmp rebuilt_band_control.json band_control.json

receipt.json holds the direct source integration (source_segments), cubic-opacity antiderivative and knot controls (stored_cells), with source and signed error by cell. band_intersection.json gives tighter Q051/Q052 conditional bounds keyed by identical row indices. A rational is stored as "p/q" or as a decimal integer. Hex intervals encode directed binary64 bounds. Endpoints shown in prose are conservatively rounded where labelled as bounds. The ideal signed pair is L-R; source and stored cumulative observables both start at zero at z=0. The reference state, fixed common admitted background and Q051/Q052 source enclosures are assumptions. No native run was made in V66.

The historical alpha fork reference for thermodynamics.c is mwt5345/class_ede@5a131c91d657dd9a7c6364cc45b038710f8d0d97, file source/thermodynamics.c. The V60 capture and exact observed table are in the rebuilt raw. Sections 5–6 of the dated Q051 proof provide the three pointwise bounds. For native reionization see thermodynamics_reionization_get_tau in thermodynamics.c lines 3030–3125 and for source opacity lines 2999–3003. V26 weight and the V19 geometry are extracted from V65, not approximated from the public curves.
