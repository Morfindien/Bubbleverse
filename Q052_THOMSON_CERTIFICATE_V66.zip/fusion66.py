"""Combine previous pointwise Q051 estimates with the certified Q052 panel boxes."""
from fractions import Fraction as F
from pathlib import Path
from math import isqrt
import hashlib,json,sys

def digest(b):
    return hashlib.sha256(b).hexdigest()
def hx(s):
    return F(float.fromhex(s))
unit=1<<160
def down(x):
    return F(x*unit//1,unit)
def up(x):
    return -down(-x)
def lr(a,b):
    assert a<=b
    return [str(a),str(b)]
def rootbox(x):
    k=isqrt(x.numerator*unit**2//x.denominator)
    assert F(k*k,unit**2)<=x<F((k+1)**2,unit**2)
    return F(k,unit),F(k+1,unit)
def go(receipt,proof,outfile):
    rb=Path(receipt).read_bytes(); rp=json.loads(rb); source=Path(proof).read_bytes()
    assert digest(source)=='dfec339b7edf5e3c3631417242475d624feacf357c043bc8e10d0eaab7fde41c'
    caps=[F(n,100_000_000) for n in (238140,99225,33075)]
    cuts=[F(4006,49),F(695)]; s=rp['summary']; kc=s['kernel_constants_exact']; upper_c=F(kc['C_inverse_Mpc'][1])
    matter=F(kc['H0_inverse_Mpc'])*rootbox(F(kc['Omega_b_cdm']))[0]
    prev=(F(0),F(0)); ends={F(0):prev}; whole=[]; records=[]; group={}; clipped=0; bs={}; top=F(s['stored_domain_z'][-1])
    for src in rp['source_segments']:
        a,b=map(F,src['z']); tag=src['origin']
        if tag not in bs: bs[tag]=prev
        knots=[a]+[cut for cut in cuts if a<cut<b]+[b]; lo,hi=map(F,src['dx_exact']); wl,wu=map(F,src['K_over_H_exact'])
        ranges=[]; splits=[]
        for l,u in zip(knots,knots[1:]):
            index=sum((l+u)/2>cut for cut in cuts); narrow=caps[index]
            dl,du=max(lo,-narrow),min(hi,narrow); assert dl<=du
            clipped+=int(dl>lo or du<hi)
            # Values assigned differently at an isolated band endpoint do not affect the integral.
            moment=(u-l)*((1+l)**2+(1+l)*(1+u)+(1+u)**2)/3
            mlo=wl*moment
            powerupper=rootbox((1+u)**3)[1]-rootbox((1+l)**3)[0]
            mhi=min(wu*moment,F(2,3)*upper_c/matter*powerupper)
            assert 0<mlo<=mhi
            corners=[d*w for w in (mlo,mhi) for d in (dl,du)]
            dlo=down(min(corners)); dhi=up(max(corners))
            ranges.append((prev[0]+min(0,dlo),prev[1]+max(0,dhi)))
            prev=prev[0]+dlo,prev[1]+dhi
            splits.append([str(l),str(u),index])
        # Carry the independent positive two-cell increment by intersecting at z=810.
        # The group-two standalone V54 lower certificate is already valid in the direct endpoints.
        if b==810:
            cert=list(map(F,s['source_mandatory_positive_two_cell_increment']))
            prev=max(prev[0],down(bs['V54'][0]+cert[0])),min(prev[1],up(bs['V54'][1]+cert[1]))
        rawend=list(map(hx,src['end'])); prev=max(prev[0],rawend[0]),min(prev[1],rawend[1])
        assert prev[0]<=prev[1]; ends[b]=prev; group[tag]=lr(*prev)
        val=min(x for x,_ in ranges),max(y for _,y in ranges); whole.append(val)
        records.append({'source_row':len(records),'subinterval_bands':splits,'whole':lr(*val),'end':lr(*prev)})
    knotbounds=[F(0),F(0)]; continuous=[F(0),F(0)]; pair_records=[]
    for row in rp['stored_cells']:
        l,u=map(F,row['z']); i,j=row['source_rows_halfopen']
        sourcewhole=min(v[0] for v in whole[i:j]),max(v[1] for v in whole[i:j])
        ideal=list(map(hx,row['pair_ideal_whole'])); reported=F(float(F(row['reported_pair_end_exact'])))
        bounds=ideal[0]-sourcewhole[1],ideal[1]-sourcewhole[0]
        knot=reported-ends[u][1],reported-ends[u][0]
        continuous=[min(continuous[0],bounds[0]),max(continuous[1],bounds[1])]
        knotbounds=[min(knotbounds[0],knot[0]),max(knotbounds[1],knot[1])]
        pair_records.append({'i':row['i'],'ideal_minus_source':lr(*bounds),'reported_end_minus_source':lr(*knot)})
    sup=max(max(abs(l),abs(u)) for l,u in whole)
    compared=max(max(abs(l),abs(u)) for (l,u),p in zip(whole,rp['source_segments']) if F(p['z'][1])<=top)
    half=F(s['source_mandatory_positive_two_cell_increment'][0])/2
    assert 0<half<sup<F(s['Q051_upper'])
    summary={'full_sup_abs_source':lr(half,sup),'covered_sup_abs_source':lr(hx(s['source_sup_abs_dTau_on_stored_domain'][0]),compared),'signed_cumulative_group_endpoints':group,'stored_curve_minus_source':lr(*continuous),'reported_rounded_pair_minus_source_at_knots':lr(*knotbounds),'pointwise_clipped_subintervals':clipped,'subinterval_count':sum(len(r['subinterval_bands']) for r in records),'band_bounds':list(map(str,caps)),'cuts':list(map(str,cuts))}
    out={'schema':'Q052_Q051_BAND_INTERSECTION_V66','receipt_sha256':digest(rb),'Q051_proof_sha256':digest(source),'summary':summary,'source_segments':records,'stored_cells':pair_records}
    Path(outfile).write_text(json.dumps(out,separators=(',',':'))+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':go(*sys.argv[1:])
