"""Independent rational check of the V66 enclosure and stored quartic, using cubic Simpson quadrature."""
from fractions import Fraction as F
from math import comb
from pathlib import Path
import base64, csv, hashlib, io, json, re, sys, zipfile, zlib

def read(path):
    return Path(path).read_bytes()

def digest(b):
    return hashlib.sha256(b).hexdigest()

def hexnum(s):
    return F(float.fromhex(s))

def contains(record, key, lower, upper):
    a,b = map(hexnum,record[key])
    assert a <= lower <= upper <= b, (key, float(a), float(lower), float(upper), float(b))

def run(journal,rawfile,zip62,zip64,receipt,output):
    rawbytes=read(rawfile)
    data=json.loads(rawbytes)
    report=json.loads(read(receipt))
    parent=read(journal)
    for tag,b in [('V60',rawbytes),('V65',parent),('V62_zip',read(zip62)),('V64_zip',read(zip64))]:
        assert digest(b)==report['input_hashes'][tag]
    sources={o.get('schema'):o for o in map(json.loads,re.findall(rb'^' + b'```json\n(.*?)^' + b'```',parent,re.M|re.S)) if isinstance(o,dict) and isinstance(o.get('schema'),str)}
    cap=json.loads(re.findall(rb'^' + b'```q052-inputs\n(.*?)^' + b'```',parent,re.M|re.S)[0])
    v19=json.loads(zlib.decompress(base64.b64decode(cap['v19.json'])))
    v18=json.loads(v19['original_members']['Q052_BACKGROUND_TRANSFER_INPUTS_V18.json']['content'])
    files=v18['parent_v17_inputs']['parent_result']['validator_inputs_original']['files']
    config=json.loads(files['q048_prefix_config_v1.json']['content'])['cases']['hillipop-ede_n3']
    bounds=json.loads(files['Q050_CLEAN_BG_BINDING_V1.json']['content'])['cells']
    geom=[tuple(map(F, v['z']+v['H'])) for v in bounds]
    fields=config['background']['fields']
    matter_factor=hexnum(fields['H0'])**2*(hexnum(fields['Omega0_b'])+hexnum(fields['Omega0_cdm']))
    constants=sources['Q052_V50_INPUT_PROJECTION']['V26_weight']
    n=hexnum(config['thermal_starts'][0]['constants']['nH0_SI'])
    assert n==F(constants['nH0_m_minus3_exact'])
    c=[n*F(s)*F(m) for s,m in zip(constants['sigma_m2']['exact'],constants['Mpc_m']['exact'])]
    top2=sources['Q052_PAIRED_SECOND_CELL_RECEIPT_V54']
    upper,lower=map(F,top2['cell2_redshifts_exact'])
    prior=sources['Q052_PAIRED_SOURCE_FIRST_CELL_RECEIPT_V52']
    origins={}
    for archive,name,group,field,parser in [(zip64,'phase6_receipt.json','V64','pair',F),(zip62,'phase5_receipt.json','V62','pair_records',hexnum)]:
        with zipfile.ZipFile(archive) as z:
            content=json.loads(z.read(name))
        for entry in content[field]:
            b,a=map(parser,entry['z'])
            origins[a,b]=(group,*map(hexnum,entry['whole_dxe']))
    for entry in top2['panels']:
        b,a=map(F,entry['z_endpoints_exact'])
        origins[a,b]=('V54',*map(hexnum,entry['delta_xe_outward_hex']))
    for entry in prior['panel_bounds']:
        j=entry['j']; size=(810-upper)/64; bound=hexnum(entry['abs_Delta_h_upper_hex'])
        origins[810-(j+1)*size,810-j*size]=('V52',F(1,1000000)-bound,F(1,1000000)+bound)
    # Independent prefix enclosure with finer dyadic precision.
    prev=(F(0),F(0)); prevz=F(0); ends={prevz:prev}; wholes=[]; s=report['summary']
    for item in report['source_segments']:
        a,b=map(F,item['z']); assert a==prevz and a<b
        group,dl,du=origins.pop((a,b)); assert group==item['origin'] and [dl,du]==list(map(F,item['dx_exact']))
        wl,wh=map(F,item['K_over_H_exact'])
        assert 0<wl<=wh and any(hi<=c[0]/wl for zh,zl,lo,hi in geom if zh>=b)
        hef=c[1]/wh
        assert hef*hef<=matter_factor*(1+a)**3 or any(lo>=hef for zh,zl,lo,hi in geom if (zl<=a and b<=zh))
        # Simpson is exact for quadratic redshift kernel after bounding H and Delta xe separately.
        midpoint=(a+b)/2
        moment=(b-a)*((1+a)**2+4*(1+midpoint)**2+(1+b)**2)/6
        v=[moment*d*w for d in (dl,du) for w in (wl,wh)]
        inc=min(v),max(v)
        if a==lower: base=prev
        broad=(prev[0]+min(0,inc[0]), prev[1]+max(0,inc[1]))
        end=(prev[0]+inc[0],prev[1]+inc[1])
        if b in (upper,810):
            exact=list(map(F,top2['cell2_delta_T' if b==upper else 'two_cell_delta_T']['exact']))
            end=max(end[0],base[0]+exact[0]),min(end[1],base[1]+exact[1])
        finer=1<<160
        end=F((end[0]*finer)//1,finer),F(-(-end[1]*finer//1),finer)
        contains(item,'increment',*inc); contains(item,'start',*prev); contains(item,'whole',*broad); contains(item,'end',*end)
        ends[b]=end; wholes.append(broad); prevz,prev=b,end
    assert not origins and prevz==810 and len(wholes)==4990
    # Attainment proof via independent power expansion of the standard cubic, then degree-four basis change.
    arm={}; seen=[]
    for t in 'LR':
        csvdata=list(csv.DictReader(io.StringIO(data['arms'][t]['history.csv'])))
        arm[t]=[tuple(F(float(r[key])) for key in ('z','eta_Mpc','dkappa_per_Mpc','dkappa_eta_second','cumulative_tau_T')) for r in csvdata]
    assert len(arm['L'])==len(arm['R'])==len(report['stored_cells'])+1==4861
    assert arm['L'][0][0]==arm['R'][0][0]==arm['L'][0][4]==arm['R'][0][4]==0
    totals={a:F(0) for a in 'LR'}; maximum=F(0); highest=F(0); reportmax=F(0); maxround=F(0); k=0
    for i,cell in enumerate(report['stored_cells']):
        zz,ee=arm['L'][i][:2]; z1,e1=arm['L'][i+1][:2]; d=ee-e1
        assert d>0 and arm['R'][i][:2]==(zz,ee) and arm['R'][i+1][:2]==(z1,e1)
        assert i==cell['i'] and list(map(F,cell['z']))==[zz,z1] and F(cell['eta_width_Mpc'])==d
        poly=[totals['L']-totals['R'],F(0),F(0),F(0),F(0)]
        for t,sign in [('L',1),('R',-1)]:
            k0,m0=arm[t][i][2:4]; k1,m1,rep=arm[t][i+1][2:]
            # Cubic second derivatives linear in eta. u=(eta0-eta)/d.
            b2=d*d*m0/2; b3=d*d*(m1-m0)/6
            coeff=[k0,k1-k0-b2-b3,b2,b3]
            mid=sum(co/F(2)**j for j,co in enumerate(coeff))
            increment=d*(k0+4*mid+k1)/6
            totals[t]+=increment
            assert hexnum(cell['arm'][t]['reported_hex'])==rep
            contains(cell['arm'][t],'increment',increment,increment); contains(cell['arm'][t],'exact_cumulative',totals[t],totals[t])
            for j,value in enumerate(coeff,1):
                poly[j]+=sign*d*value/j
        controls=[sum(poly[j]*F(comb(l,j),comb(4,j)) for j in range(l+1)) for l in range(5)]
        truepair=totals['L']-totals['R']; obs=arm['L'][i+1][4]-arm['R'][i+1][4]
        assert sum(poly)==controls[-1]==truepair==F(cell['pair_end_exact']) and F(cell['reported_pair_end_exact'])==obs
        contains(cell,'pair_ideal_whole',min(controls),max(controls)); highest=max(highest,abs(truepair)); maximum=max(maximum,*map(abs,controls)); reportmax=max(reportmax,abs(obs))
        n0,n1=cell['source_rows_halfopen']; assert n0==k and n0<n1 and F(report['source_segments'][n0]['z'][0])==zz and F(report['source_segments'][n1-1]['z'][1])==z1; k=n1
        local=min(x[0] for x in wholes[n0:n1]),max(x[1] for x in wholes[n0:n1])
        error=min(controls)-local[1],max(controls)-local[0]; contains(cell,'pair_ideal_minus_source',*error); contains(s,'common_domain_ideal_pair_minus_source',*error)
        rounded=F(float(obs)); ek=rounded-ends[z1][1],rounded-ends[z1][0]; contains(cell,'reported_rounded_pair_minus_source_at_end',*ek)
        contains(s,'reported_rounded_pair_minus_source_at_knots',*ek)
        maxround=max(maxround,abs(obs-truepair),abs(rounded-truepair))
    assert k==4926 and maximum==highest==abs(truepair)==F(s['max_ideal_knot_abs_exact'])
    assert reportmax==abs(obs)==F(s['observed_knot_sup_abs_exact']) and z1==upper
    contains(s,'max_abs_reported_or_final_subtracted_pair_vs_ideal_at_knots',maxround,maxround)
    contains(s,'ideal_stored_sup_abs_dTau',maximum,maximum)
    out={'status':'PASS','method_source':'rational Simpson kernel, origin and H proof inequalities, independent outward 2^-160 prefix arithmetic','source_segments':len(wholes),'method_stored':'indirect cubic power coefficients, Simpson full cell, quartic power-to-Bernstein transform','stored_cells_per_arm':len(report['stored_cells']),'maximum_equals_final_knot_exactly':True,'coordinate_at_max_exact':str(z1),'ideal_maximum_exact':str(maximum),'reported_maximum_exact':str(reportmax),'pair_roundoff_max_exact':str(maxround),'both_replay_mismatch_counts':s['ordered_binary64_replay_mismatches'],'receipt_sha256':digest(read(receipt))}
    Path(output).write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__': run(*sys.argv[1:])
