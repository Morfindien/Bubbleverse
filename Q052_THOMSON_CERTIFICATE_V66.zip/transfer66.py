"""Q052 conditional cumulative Thomson-depth transfer. All primary bounds use exact rational arithmetic."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt, inf, nextafter
from collections import Counter
from bisect import bisect_left
import hashlib,json,re,zipfile,sys,zlib,base64,csv,io

PARENT='968b823c764a0ca853d7b779d031a283403848f972ac75ea717fe3bb244351f1'
RAW='e683333446b1ea3d889cd837520f8f475a8926c1bad4cdc4459150dffb11bfcb'
Z62='7fb60289f13cfbb1721b6528bb4b57dfd369b8d1939e28fbb51923591878d137'
Z64='969eeba82c0a3b23a21da3e8f68d7e5eb624cb453d762bdc303c4d211d77c91a'
SCALE=1<<128
sha=lambda b:hashlib.sha256(b).hexdigest()
hx=lambda s:F(float.fromhex(s))
def outward(x,up):
    y=float(x)
    if (F(y)<x if up else F(y)>x):y=nextafter(y,inf if up else -inf)
    return y.hex()
def pack(lo,hi):
    assert lo<=hi
    return [outward(lo,False),outward(hi,True)]
def ticks(x,up):return F(-((-x*SCALE)//1) if up else (x*SCALE)//1,SCALE)
def sqrtlo(r):
    n=isqrt((r.numerator*SCALE*SCALE)//r.denominator);assert F(n*n,SCALE*SCALE)<=r<F((n+1)**2,SCALE*SCALE);return F(n,SCALE)
def verified(path,h):
    b=Path(path).read_bytes();assert sha(b)==h;return b
def receipt(path,archivehash,n,h):
    verified(path,archivehash)
    with zipfile.ZipFile(path) as ar:
        b=ar.read(n);assert sha(b)==h==json.loads(ar.read('manifest.json'))['files'][n];return json.loads(b)
def split_controls(c):
    a=list(c);left=[a[0]];right=[a[-1]]
    while len(a)>1:
        a=[(x+y)/2 for x,y in zip(a,a[1:])];left.append(a[0]);right.append(a[-1])
    return left,right[::-1]

def run(journal,rawfile,file62,file64,dest):
    parent=verified(journal,PARENT);raw=json.loads(verified(rawfile,RAW));p62=receipt(file62,Z62,'phase5_receipt.json','63480c24d61350c9913ed3072e09c91c097049791165fa964cfa096f7d0d4ca8');p64=receipt(file64,Z64,'phase6_receipt.json','5ce7deba7580ab87b71340ca2d7aa4c8b042c068145f51f7833031a5bf98c813')
    js=[json.loads(b) for b in re.findall(rb'^```json\n(.*?)^```',parent,re.M|re.S)];obj=lambda schema:next(o for o in js if o.get('schema')==schema)
    ss1=obj('Q052_PAIRED_SOURCE_FIRST_CELL_RECEIPT_V52');ss2=obj('Q052_PAIRED_SECOND_CELL_RECEIPT_V54');weight=obj('Q052_V50_INPUT_PROJECTION')['V26_weight'];capture=raw['files']['capture60.c'];assert sha(capture.encode())=='dcc9ed1afce27b7da82c161f27440cead68565457f661c1f77b98dfbff75318f' and 'cum -= h*(dk+dk1)/2. - h*h*h*(m+m1)/24.;' in capture
    compressed=json.loads(re.findall(rb'^```q052-inputs\n(.*?)^```',parent,re.M|re.S)[0])['v19.json'];capsule=zlib.decompress(base64.b64decode(compressed,validate=True));assert sha(capsule)=='3f3838394c1a85b2fa592dc2fb4c66d7c67e3d6c74a07873b9a060c22aebe89c'
    v18=json.loads(json.loads(capsule)['original_members']['Q052_BACKGROUND_TRANSFER_INPUTS_V18.json']['content']);files=v18['parent_v17_inputs']['parent_result']['validator_inputs_original']['files'];config=json.loads(files['q048_prefix_config_v1.json']['content'])['cases']['hillipop-ede_n3'];bg=json.loads(files['Q050_CLEAN_BG_BINDING_V1.json']['content']);fields=config['background']['fields'];H0=hx(fields['H0']);om=hx(fields['Omega0_b'])+hx(fields['Omega0_cdm']);assert om>0 and H0>0 and hx(fields['K'])==0
    bgrows=[(F(x['z'][0]),F(x['z'][1]),*map(F,x['H'])) for x in bg['cells']];n=F(weight['nH0_m_minus3_exact']);assert n==hx(config['thermal_starts'][0]['constants']['nH0_SI']);sig=list(map(F,weight['sigma_m2']['exact']));mpc=list(map(F,weight['Mpc_m']['exact']));C=(n*sig[0]*mpc[0],n*sig[1]*mpc[1]);assert 0<C[0]<=C[1]
    def wbounds(a,b):
        hlo=max([sqrtlo(H0**2*om*(1+a)**3)]+[lo for zhi,zlo,lo,hi in bgrows if zhi>=b and a>=zlo]);hhi=min(hi for zhi,zlo,lo,hi in bgrows if zhi>=b);assert 0<hlo<=hhi
        return C[0]/hhi,C[1]/hlo
    # Build shared source partition in increasing redshift.
    parts=[]
    for s in reversed(p64['pair']):
        b,a=map(F,s['z']);parts.append((a,b,*map(hx,s['whole_dxe']),'V64'))
    for s in reversed(p62['pair_records']):
        b,a=map(hx,s['z']);parts.append((a,b,*map(hx,s['whole_dxe']),'V62'))
    for s in reversed(ss2['panels']):
        b,a=map(F,s['z_endpoints_exact']);parts.append((a,b,*map(hx,s['delta_xe_outward_hex']),'V54'))
    fract=F(1,10**6);top=F(ss2['cell2_redshifts_exact'][0]);w=810-top;assert len(ss1['panel_bounds'])==64
    for s in reversed(ss1['panel_bounds']):
        j=s['j'];a,b=810-w*(j+1)/64,810-w*j/64;dh=hx(s['abs_Delta_h_upper_hex']);parts.append((a,b,fract-dh,fract+dh,'V52'))
    assert parts[0][0]==0 and parts[-1][1]==810 and all(b==p[0] for (_,b,*_),p in zip(parts,parts[1:]))
    # Accumulate signed interval increments, maintaining whole-cell ranges separately from endpoints.
    prev=(F(0),F(0));start_of_group={};source=[];src_ranges=[];source_end={F(0):prev};group_summary={};two_cell_low=F(ss2['two_cell_delta_T']['exact'][0]);cell2_low=F(ss2['cell2_delta_T']['exact'][0]);assert 0<cell2_low<two_cell_low
    for a,b,xlo,xhi,tag in parts:
        assert xlo<=xhi and a<b;start_of_group.setdefault(tag,prev);wlo,whi=wbounds(a,b);M=((1+b)**3-(1+a)**3)/3;assert M==(b-a)*((1+a)**2+(1+a)*(1+b)+(1+b)**2)/3
        corners=[u*d*M for u in (wlo,whi) for d in (xlo,xhi)];dl,dh=ticks(min(corners),False),ticks(max(corners),True)
        whole=prev[0]+min(0,dl),prev[1]+max(0,dh);end=prev[0]+dl,prev[1]+dh
        if b==top or b==810:
            exact=list(map(F,(ss2['cell2_delta_T'] if b==top else ss2['two_cell_delta_T'])['exact']));base=start_of_group['V54'];end=max(end[0],ticks(base[0]+exact[0],False)),min(end[1],ticks(base[1]+exact[1],True));assert end[0]<=end[1]
        source.append({'z':list(map(str,(a,b))),'origin':tag,'dx_exact':list(map(str,(xlo,xhi))),'K_over_H_exact':list(map(str,(wlo,whi))),'increment':pack(dl,dh),'start':pack(*prev),'end':pack(*end),'whole':pack(*whole)});src_ranges.append(whole);source_end[b]=end;prev=end;group_summary[tag]=pack(*end)
    srcsup=max(max(abs(a),abs(b)) for a,b in src_ranges);source_LB=max(two_cell_low/2,max(max(F(0),l,-u) for l,u in source_end.values()));assert source_LB<=srcsup
    # Stored coordinates and output pipeline identification from both streams.
    tabs={};csvrows={};ids={};rawtau={}
    for a in 'LR':
        fs=raw['arms'][a];pub=list(map(json.loads,fs['public_table_hex.jsonl'].splitlines()));hdr=pub.pop(0);assert hdr['dkappa_column']==1 and hdr['eta_curvature_column']==3
        csvrows[a]=list(csv.DictReader(io.StringIO(fs['history.csv'])));assert len(csvrows[a])==len(pub)==4861
        tabs[a]=[];rawtau[a]=[];ids[a]=json.loads(fs['effective_identity.json'])['tau_reio_output']
        for i,(r,c) in enumerate(zip(pub,csvrows[a])):
            z,eta,k,m=map(hx,(r['z'],r['eta'],r['values'][1],r['values'][3]));assert r['i']==i and [z,eta,k,m]==[F(float(c[n])) for n in ('z','eta_Mpc','dkappa_per_Mpc','dkappa_eta_second')];tabs[a].append((z,eta,k,m));rawtau[a].append(F(float(c['cumulative_tau_T'])))
    assert [t[:2] for t in tabs['L']]==[t[:2] for t in tabs['R']];knots=[r[0] for r in tabs['L']];assert set(knots)<=set(source_end);assert knots[-1]==top
    cum={'L':F(0),'R':F(0)};max_round={a:F(0) for a in 'LR'};sumabs={a:F(0) for a in 'LR'};replay={a:0.0 for a in 'LR'};mismatch=Counter();first_mismatch={};round_pair=F(0);knot_pair_bound=(F(0),F(0));continuous_bound=(F(0),F(0));cells=[];polys=[];j=0;lastpair=F(0);max_knot_value=F(0);max_knot_z=F(0);maxexactl=F(0);best_z=F(0)
    for i,(lo,hi) in enumerate(zip(knots,knots[1:])):
        D=tabs['L'][i][1]-tabs['L'][i+1][1];assert D>0 and lo<hi;controls=[];arm_detail={};start_exact=cum['L']-cum['R'];assert start_exact==lastpair
        for a in 'LR':
            k0,m0=tabs[a][i][2:];k1,m1=tabs[a][i+1][2:];B=[k0,k0+(k1-k0)/3-D**2*(2*m0+m1)/18,k1-(k1-k0)/3-D**2*(m0+2*m1)/18,k1];controls.append(B);inc=D*(k0+k1)/2-D**3*(m0+m1)/24;assert inc==D*sum(B)/4;cum[a]+=inc
            observed=rawtau[a][i+1];local_error=observed-rawtau[a][i]-inc;sumabs[a]+=abs(local_error);max_round[a]=max(max_round[a],abs(observed-cum[a]));
            h=-float(D);assert F(h)==-D;replay[a]-=h*(float(k0)+float(k1))/2. - h*h*h*(float(m0)+float(m1))/24.
            if F(replay[a])!=observed:mismatch[a]+=1;first_mismatch.setdefault(a,i+1)
            arm_detail[a]={'increment':pack(inc,inc),'exact_cumulative':pack(cum[a],cum[a]),'reported_hex':float(observed).hex(),'signed_reported_minus_exact':pack(observed-cum[a],observed-cum[a])}
        G=[start_exact]
        for L,R in zip(*controls):G.append(G[-1]+D*(L-R)/4)
        lastpair=cum['L']-cum['R'];assert lastpair==G[-1];polys.append(G);numeric=(min(G),max(G))
        observed=rawtau['L'][i+1]-rawtau['R'][i+1];bn64=F(float(observed));round_pair=max(round_pair,abs(observed-lastpair),abs(bn64-lastpair));
        if abs(observed)>max_knot_value:max_knot_value=abs(observed);max_knot_z=hi
        if abs(lastpair)>maxexactl:maxexactl=abs(lastpair);best_z=hi
        s0=j
        while j<len(parts) and parts[j][1]<=hi:j+=1
        assert parts[s0][0]==lo and parts[j-1][1]==hi;sr=(min(sl for sl,_ in src_ranges[s0:j]),max(su for _,su in src_ranges[s0:j]));er=(numeric[0]-sr[1],numeric[1]-sr[0]);continuous_bound=(min(continuous_bound[0],er[0]),max(continuous_bound[1],er[1]));kerr=(bn64-source_end[hi][1],bn64-source_end[hi][0]);knot_pair_bound=min(knot_pair_bound[0],kerr[0]),max(knot_pair_bound[1],kerr[1]);cells.append({'i':i,'z':list(map(str,(lo,hi))),'eta_width_Mpc':str(D),'source_rows_halfopen':[s0,j],'arm':arm_detail,'pair_ideal_whole':pack(*numeric),'pair_end_exact':str(lastpair),'reported_pair_end_exact':str(observed),'source_whole':pack(*sr),'pair_ideal_minus_source':pack(*er),'reported_rounded_pair_minus_source_at_end':pack(*kerr)})
    assert j==len(parts)-64
    # Exact Bernstein branch-and-bound. Endpoint samples are a lower bound on the supremum.
    best=maxexactl;tolerance=F(1,10**21);upper=best;subdivisions=0
    for poly in polys:
        stack=[poly]
        while stack:
            c=stack.pop();hull=max(map(abs,c));best=max(best,abs(c[0]),abs(c[-1]));
            if hull<=best:continue
            if hull<=best+tolerance:upper=max(upper,hull);continue
            halves=split_controls(c);stack.extend(halves);subdivisions+=1
    upper=max(best,upper);assert upper-best<=tolerance
    srmax=max(max(abs(a),abs(b)) for a,b in src_ranges[:j]);reported_reio=F(float.fromhex(ids['L']))-F(float.fromhex(ids['R']))
    summary={'source_domain_z':['0','810'],'stored_domain_z':['0',str(top)],'kernel_constants_exact':{'nH0_m-3':str(n),'sigma_m2':list(map(str,sig)),'Mpc_m':list(map(str,mpc)),'C_inverse_Mpc':list(map(str,C)),'H0_inverse_Mpc':str(H0),'Omega_b_cdm':str(om)},'source_groups':dict(Counter(t[-1] for t in parts)),'source_cumulative_after_group':group_summary,'source_full_sup_abs_dTau':pack(source_LB,srcsup),'Q051_upper':str(F('0.04209103698658')),'new_full_source_upper_below_Q051_bound':srcsup<F('0.04209103698658'),'source_sup_abs_dTau_on_stored_domain':pack(cell2_low/2,srmax),'ideal_stored_sup_abs_dTau':pack(best,upper),'max_ideal_knot_z':str(best_z),'max_ideal_knot_abs_exact':str(maxexactl),'quartic_subdivisions':subdivisions,'observed_knot_sup_abs_exact':str(max_knot_value),'observed_max_knot_z':str(max_knot_z),'common_domain_ideal_pair_minus_source':pack(*continuous_bound),'reported_rounded_pair_minus_source_at_knots':pack(*knot_pair_bound),'max_abs_reported_or_final_subtracted_pair_vs_ideal_at_knots':pack(0,round_pair),'max_abs_reported_vs_ideal_at_knots':{a:pack(0,v) for a,v in max_round.items()},'sum_abs_local_discrepancies':{a:pack(0,v) for a,v in sumabs.items()},'ordered_binary64_replay_mismatches':{a:mismatch[a] for a in 'LR'},'ordered_binary64_first_mismatch':first_mismatch,'reported_tau_reio_output_pair_separate':str(reported_reio),'upper_uncovered_interval':[str(top),'810'],'source_mandatory_positive_two_cell_increment':ss2['two_cell_delta_T']['exact'],'upper_numeric_gap':'V60 emits no next upper knot or partial cumulative value at810; historical V48 top-cell coefficients have separate provenance.'}
    out={'schema':'Q052_THOMSON_TRANSFER_RECEIPT_V66','input_hashes':{'V65':PARENT,'V60':RAW,'V62_zip':Z62,'V64_zip':Z64,'V19':sha(capsule),'capture60.c':sha(capture.encode())},'incoming_task':js[-3]['next_task']['task_fingerprint_sha256'],'summary':summary,'source_segments':source,'stored_cells':cells};Path(dest).write_text(json.dumps(out,separators=(',',':'),allow_nan=False)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':run(*sys.argv[1:])
