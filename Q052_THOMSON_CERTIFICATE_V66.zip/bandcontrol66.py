"""Separate verification using rationalized power differences and narrower dyadic enclosures."""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import json,hashlib,sys

def run(primary,band,proof,output):
    file=lambda name:Path(name).read_bytes()
    sha=lambda b:hashlib.sha256(b).hexdigest()
    rb=file(primary); bb=file(band); r=json.loads(rb); fusion=json.loads(bb)
    assert sha(file(proof))==fusion['Q051_proof_sha256'] and sha(rb)==fusion['receipt_sha256']
    s=r['summary']; out=fusion['summary']; k=s['kernel_constants_exact']; scale=2**256
    def sqrt_bounds(f):
        q=isqrt((f.numerator*scale**2)//f.denominator)
        low=F(q,scale)
        return low,low+F(1,scale)
    def enclose(row,k,l,h):
        x,y=map(F,row[k]); assert x<=l<=h<=y,(k,float(x),float(l),float(h),float(y))
    hiC=F(k['C_inverse_Mpc'][1]); denom=sqrt_bounds(F(k['H0_inverse_Mpc'])**2*F(k['Omega_b_cdm']))[0]
    groups={}; whole=[]; ends={F(0):(F(0),F(0))}; z0=F(0); x=y=F(0)
    for p,f in zip(r['source_segments'],fusion['source_segments'],strict=True):
        a,b=map(F,p['z']); assert z0==a; z0=b
        groups.setdefault(p['origin'],(x,y)); parts=sorted({a,b,*[c for c in [F(695),F(4006,49)] if a<c<b]})
        dxlo,dxhi=map(F,p['dx_exact']); wlo,whi=map(F,p['K_over_H_exact']); seg=[]
        for aa,zz in zip(parts,parts[1:]):
            cap=F('0.00033075') if aa>=695 else F('0.00099225') if aa>=F(4006,49) else F('0.0023814')
            xlo,xhi=max(dxlo,-cap),min(dxhi,cap); assert xlo<=xhi
            A=1+aa; B=1+zz; mass=((zz-aa)/6)*(A*A+(A+B)**2+B*B)
            # B^(3/2)-A^(3/2)=(B-A)(B+sqrt(AB)+A)/(sqrt(B)+sqrt(A)).
            rationalized=(B-A)*(A+B+sqrt_bounds(A*B)[1])/(sqrt_bounds(A)[0]+sqrt_bounds(B)[0])
            mlo=wlo*mass; mhi=min(whi*mass,F(2,3)*hiC*rationalized/denom)
            low=xlo*(mlo if xlo>=0 else mhi); high=xhi*(mhi if xhi>=0 else mlo)
            seg.append((x+min(0,low),y+max(0,high)))
            x=F(((x+low)*scale)//1,scale);y=F(-(-(y+high)*scale//1),scale)
        if b==810:
            d0,d1=map(F,s['source_mandatory_positive_two_cell_increment']); x=max(x,groups['V54'][0]+d0);y=min(y,groups['V54'][1]+d1)
        base_lo,base_hi=(F(float.fromhex(v)) for v in p['end']);x=max(x,base_lo);y=min(y,base_hi)
        whole.append((min(t[0] for t in seg),max(t[1] for t in seg)));enclose(f,'whole',*whole[-1]); enclose(f,'end',x,y); ends[b]=(x,y)
    bound=max(max(abs(l),abs(u)) for l,u in whole)
    assert z0==810 and bound<=F(out['full_sup_abs_source'][1])<F('0.03991038')
    for p,f in zip(r['stored_cells'],fusion['stored_cells'],strict=True):
        a,b=p['source_rows_halfopen']; z=F(p['z'][1]); l,u=(F(float.fromhex(v)) for v in p['pair_ideal_whole']); knot=F(float(F(p['reported_pair_end_exact'])))
        err=(l-max(n[1] for n in whole[a:b]), u-min(n[0] for n in whole[a:b]));e2=knot-ends[z][1],knot-ends[z][0]
        enclose(f,'ideal_minus_source',*err);enclose(out,'stored_curve_minus_source',*err);enclose(f,'reported_end_minus_source',*e2); enclose(out,'reported_rounded_pair_minus_source_at_knots',*e2)
    doc={'status':'PASS','checks':['all fused segment endpoints and whole ranges','all ideal and reported pair-minus-source enclosures','upper mass via rationalized difference and 2^-256 sqrt intervals','outward reported full source supremum < 0.03991038'],'simulator_runs':0,'source_segments':len(whole),'stored_cells':len(r['stored_cells']),'independent_upper_bound_rational':str(bound),'band_intersection_sha256':sha(bb)}
    Path(output).write_text(json.dumps(doc,indent=2)+'\n')
if __name__=='__main__':run(*sys.argv[1:])
