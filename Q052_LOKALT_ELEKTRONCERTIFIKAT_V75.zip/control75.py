"""Rational vertex control on the shared, outward atomic inputs."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import hashlib
import json
import v20 as m

base = Path(__file__).resolve().parent
def load(n):
    return json.loads((base/n).read_bytes())
def ends(x):
    return [F(x.lo),F(x.hi)]
def hx(x):
    return [F(float.fromhex(a)) for a in x]
def solve():
    r=load('result.json'); c=m.Context(base/'v19.json')
    v62=load('v62_handoff.json'); dk=hx(v62['validated_result_refs']['positive_escape_denominator'])
    xl,_,top=map(F,r['z']); q=F(r['initial_X']); h0,h1,v0,v1=map(F,r['h_v_proof_box'])
    H0,H1=ends(c.Hs); lam=ends(c.lam); lya=ends(c.lya)
    minimum,maximum=None,None
    for iz in range(8):
        zp=m.enc(1+xl+(top-xl)*F(iz,8),1+xl+(top-xl)*F(iz+1,8))
        _,TR,nH,_=c.background(zp); n0,n1=ends(nH)
        a,_,_,w=c.rates(TR,m.enc(v0,v1))
        bs,bp=[hx(x['hex']) for x in w['beta']];j=hx(w['R2p2s']['hex'])
        for ih in range(16):
            Hl=H0+(H1-H0)*F(ih,16);Hr=H0+(H1-H0)*F(ih+1,16)
            E=[lya[0]*Hl/(n1*(1-h0)*dk[1]),lya[1]*Hr/(n0*(1-h1)*dk[0])]
            for B,P,J,L,e in product(bs,bp,j,lam,E):
                # Direct positive source quotients at all vertices. Each component is
                # separately linear-fractional in each of the five coordinates.
                gs=B+3*J+L; den=gs*(P+J+e)-3*J*J
                assert den>0
                cs=(L*(P+J+e)+3*J*e)/den;cp=(e*gs+J*L)/den
                assert 0<cs<1 and 0<cp<1
                lo=h0*n0/Hr*(F(a[0].lo)*cs+F(a[1].lo)*cp)
                hi=h1*n1/Hl*(F(a[0].hi)*cs+F(a[1].hi)*cp)
                minimum=lo if minimum is None else min(minimum,lo)
                maximum=hi if maximum is None else max(maximum,hi)
    low,up=map(F,r['force_caps'])
    assert low<=minimum<=maximum<=up
    hh,hv,vcap=map(F,r['hh_hv_dv_caps'])
    U=(top-xl)/(1+xl)
    # M(t)<= t*(hh*M(t)+hv*vcap+q*max_force) from the integrated equation.
    assert hh*U<1
    coarse=U*(hv*vcap+q*maximum)/(1-hh*U)
    assert coarse<F(r['trial'])
    ldot,udot=map(F,r['signed_slope_du'])
    assert ldot <= -q*maximum-hh*coarse-hv*vcap
    assert -q*minimum+hh*coarse+hv*vcap <= udot<0
    assert F(r['epsilon_upper']) == -ldot*U < q/100
    x=load('v71.json')['xe']
    z0,z1=map(F,x['winning_cell_z']);w0,w1=map(F,x['peak_normalized_root_interval'])
    assert [z0+(z1-z0)*s for s in (w0,w1)] == list(map(F,r['V71_peak_z']))
    p=list(map(F,x['peak_polynomial']))
    bern=[p[0],p[0]+p[1]/3,p[0]+2*p[1]/3+p[2]/3,sum(p)]
    s0=F(x['at_810'])
    assert min(bern)>s0 and F(x['top_range'][0])==s0
    gap=q-s0
    assert max(map(F,x['sup_abs']))-(q-F(r['epsilon_upper']))<gap
    assert list(map(F,r['sup_abs_stored_minus_source']))==[gap,gap]
    assert r['source_sup_abs']==[str(q)]*2
    zl,zh=map(F,x['z_max']);sl,sh=map(F,x['sup_abs'])
    # Upper/lower log estimates require no implementation of logarithm.
    assert list(map(F,r['signed_stored_minus_source_at_stored_peak']))==[
        sl-(q+udot*(top-zh)/811),sh-(q+ldot*(top-zl)/(1+zl))]
    return dict(status='PASS',method='Exact rational vertex bounds for positive multiaffine quotients; separate integral bound; stored polynomial endpoint and peak-transfer checks',
                shared_inputs='Frozen tables, outward MPFR rate back end, V52/V54 Jacobian and thermal bounds, V62 fit and V71 stored certificate',
                rational_vertices=8*16*32, force_lower=str(minimum),force_upper=str(maximum),
                alternative_uniform_change_upper=str(coarse),new_native_runs=0)
if __name__=='__main__':
    print(json.dumps(solve(),indent=2))
