# Reproduktion af Q052 V75

Udpak ZIP-filen i en mappe. Kør med almindelig Python 3 og systembiblioteket libmpfr. Brug normal Python med assertions slået til. Alle nødvendige input til V75-kørslen ligger i arkivet.

    python certify75.py > replay-result.json
    cmp result.json replay-result.json
    python control75.py > replay-control.json
    cmp control.json replay-control.json

Det første program genbruger de kvalificerede tidligere certifikater og bygger V75-grænser fra intervalrater og rationel aritmetik. Det andet beregner sit eget hjørneestimat og kontrollerer ekstremumoverførslen. Kontrolprogrammet læser den medleverede result.json. SHA-256 for arkivets øvrige medlemmer findes i manifest.json. PROOF_V75.md forklarer ligninger, fortegn, enheder og rækkevidde. I JSON-filerne er brøker eksakte, og hex-koordinater er eksakte binære intervalgrænser. V19-bundtet indeholder den fastholdte fysiske kilde, atomtabeller, capture og MPFR-modul. De arvede bevisforudsætninger og deres oprindelige afprøvninger er dokumenteret i den kumulative journal.
