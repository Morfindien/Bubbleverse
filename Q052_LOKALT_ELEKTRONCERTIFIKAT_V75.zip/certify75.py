"""Q052 V75. Run with Python 3 and system MPFR. Emits deterministic JSON."""
import hashlib
import json
import math
from fractions import Fraction as F
from pathlib import Path
import v20 as m

BASE = Path(__file__).resolve().parent

def load(name):
    return json.loads((BASE / name).read_bytes())

def sha(name):
    return hashlib.sha256((BASE / name).read_bytes()).hexdigest()

def interval(strings):
    return m.I(*map(float.fromhex, strings))

def hx(s):
    return F(float.fromhex(s))

def endpoints(x):
    return list(map(str, x))

def enclosure(x, lo, hi):
    assert F(x.lo) >= lo and F(x.hi) <= hi

def solve():
    t, first, second, data, old, stored, background = map(load, (
        'task74.json', 'v52.json', 'v54.json', 'v23.json', 'v62_handoff.json',
        'v71.json', 'v73.json'))
    assert sha('v20.py') == 'd0feecd36359005a55fb91c26aee2381f9ed1652177395acf7ec482ea0e880fa'
    assert sha('v23.json') == second['input_hashes']['V23_data']
    assert sha('v71.json') == t['compact_reuse']['V71_result_sha256']
    assert background['capture_sha256'] == t['compact_reuse']['V73_capture_sha256']
    assert background['guard_sha256'] == t['compact_reuse']['V73_guard_sha256']
    c = m.Context(BASE/'v19.json')
    assert c.raw['q048_prefix_config_v1.json']['sha256'] == background['capture_sha256']
    I, enc = m.I, m.enc
    start = t['matched_start_exact']
    assert c.starts['L'] == c.starts['R'] == [F(start['h']), F(start['v'])]
    q = F(first['q_difference'])
    assert q == F(second['cell2_q']) == F(1, 10**6)
    zlo, top = map(F, t['domain_z'])
    join, end = map(F, second['cell2_redshifts_exact'])
    assert end == zlo and join == c.z1 and top == 810
    assert c.binding['cells'][0] == data['background_projection']['original_cell']
    assert list(map(F,c.binding['cells'][0]['z'])) == [810,800]
    assert first['status'] == 'CONDITIONAL_STRICT_POSITIVE_FIRST_CELL'
    assert second['status'] == 'PASS_CONDITIONAL_POSITIVE_TWO_CELL_SOURCE_INCREMENT'
    assert second['input_V52']['delta_v_abs'] == first['abs_physical_state_delta_upper_v']
    assert second['input_V52']['delta_h_abs'] == first['abs_physical_state_delta_upper_h']
    hh, hv, vcap = F('25.4'), F('.057'), F('4.36e-7')
    for rows, key in [(first['panel_bounds'], 'coeff_upper_hex'),
                      (second['panels'], 'M_hh_hv_hq_vh_upper_hex')]:
        assert [r['j'] for r in rows] == list(range(64))
        for row in rows:
            assert row['stencil'] == [83,37]
            assert hx(row[key][0]) <= hh and hx(row[key][1]) <= hv
    assert F(first['abs_physical_state_delta_upper_v']['exact'][1]) <= vcap
    assert max(abs(F(x)) for x in second['whole_and_endpoint_delta_v']['exact']) <= vcap
    # V22 and V24 certify full Hermite tubes in h and v in both arms.
    v22,v24=load('v22.json'),load('v24.json')
    assert sha('v22.json')=='8a5bc83012cd56a1968499486e0a7dcc9ddc78d033305d056330c960ad3aea87'
    assert sha('v24.json')==second['input_hashes']['V24_receipt']
    assert v22['conditional_comparison_transport_certificate'] and v24['conditional_first_two_cell_chain_certificate']
    for arm in 'LR':
        for a,radii,key in [(v22['arms'][arm],['1/50000','1/2000'],'zero_start_strict_component_flags'),
                            (v24['arms'][arm],['1/25000','1/2000'],'whole_strict_component_flags')]:
            assert a['radii_exact']==radii and len(a['cells'])==64
            assert all(all(row[key]) for row in a['cells'])
    hmin,hmax,vmin,vmax = map(F, ['.00395','.00407','.9987','.9999'])
    h, v = enc(hmin,hmax),enc(vmin,vmax)
    for arm in 'LR':
        d = data['arms'][arm]
        assert list(map(F,d['z_exact'])) == [join,zlo] and F(d['q_exact']) == (q if arm=='L' else 0)
        assert c.ctx['arms'][arm]['first_cell_exact_representation']['phase'] == 5
        assert d['start_node']['phase'] == d['end_node']['phase'] == 5
        _,h1,v1,_,_ = c.curve(arm,F(0),F(1))
        H,D = [list(map(F,d['bernstein_exact'][k])) for k in ['h','D']]
        h2 = enc(min(H),max(H))
        v2 = 1+enc(min(D),max(D))/(enc(c.T0)*enc(1+zlo,1+join))
        for curve_h,curve_v,radius in [(h1,v1,F(1,50000)),(h2,v2,F(1,25000))]:
            enclosure(curve_h+enc(-radius,radius),hmin,hmax)
            enclosure(curve_v+enc(-F(1,2000),F(1,2000)),vmin,vmax)
    zp = enc(1+zlo,811)
    branch = c.branch(zp,h,v)
    T,tr,_,_ = c.background(zp)
    fit_index = (T-c.fit_first)/10
    assert 43 < fit_index.lo <= fit_index.hi < 44
    reio = F(c.capture['frozen_reionization']['fixed_reio_start_exact'])
    assert reio < zlo
    dk = interval(old['validated_result_refs']['positive_escape_denominator'])
    assert F('.9') < F(dk.lo) <= F(dk.hi) < F('1.1')
    assert old['claim_evidence']['C3'].startswith('Positive escape')
    bins = []
    hlo,hhi = F(c.Hs.lo),F(c.Hs.hi)
    for iz in range(8):
        za = zlo+(810-zlo)*F(iz,8)
        zb = zlo+(810-zlo)*F(iz+1,8)
        _,tr,nh,_ = c.background(enc(1+za,1+zb))
        alpha,_,_,receipt = c.rates(tr,v)
        assert receipt['stencils'] == [[83,37]]
        bs,bp = [interval(x['hex']) for x in receipt['beta']]
        j = interval(receipt['R2p2s']['hex'])
        gs = bs+c.lam+3*j
        for ih in range(16):
            hs = enc(hlo+(hhi-hlo)*F(ih,16),hlo+(hhi-hlo)*F(ih+1,16))
            e = c.lya*hs/nh/(1-h)/dk
            den = (bs+c.lam)*(bp+j)+3*j*bp+gs*e
            assert den.lo>0 and e.lo>0
            # Exact complements of the pinned source C_2s and C_2p.
            cs = 1-(bs*(bp+j+e)+3*j*bp)/den
            cp = 1-(gs*bp+j*bs)/den
            assert min(cs.lo,cp.lo)>0 and max(cs.hi,cp.hi)<1
            force = h*nh/hs*(alpha[0]*cs+alpha[1]*cp)
            bins.append(force)
    force = m.hull(bins)
    lower,upper = F('6.58'),F('9.60')
    enclosure(force,lower,upper)
    trial = q/100
    feedback = hh*trial+hv*vcap
    a,b = upper*q+feedback,lower*q-feedback
    u_lo = lambda z:(810-z)/811
    u_hi = lambda z:(810-z)/(1+z)
    eps = a*u_hi(zlo)
    assert 0 < b < a and eps < trial
    # First contact excluded. Signed slopes now hold unconditionally on this strip
    # under the frozen input premises. d(0)=0.
    Xlo = lambda z:q-a*u_hi(z)
    Xhi = lambda z:q-b*u_lo(z)
    assert Xlo(zlo)>0
    # Width at z <= (a/(1+zlo)-b/811)*(810-zlo) by inspection.
    width = Xhi(zlo)-Xlo(zlo)
    assert width < F(t['numerical_resolution_goal']['pointwise_tube_width_max_if_variable'])
    xe = stored['xe']
    zpklo,zpkhi = map(F,xe['z_max'])
    smin,smax = map(F,xe['sup_abs'])
    p = list(map(F,xe['peak_polynomial']))
    bern = [sum(p[j]*F(math.comb(i,j),math.comb(3,j)) for j in range(i+1)) for i in range(4)]
    s0 = F(xe['at_810'])
    assert list(map(F,xe['winning_cell_z'])) == [zlo,join] and zlo<zpklo<=zpkhi<join
    assert min(bern)>s0>0 and F(xe['top_range'][0])==s0
    assert xe['top_stationary_roots']==[] and max(map(F,xe['top_derivative_bernstein']))<0
    gap = q-s0
    assert smax-Xlo(zlo)<gap and F(xe['signed_error_at_810'])==-gap
    epeak = [smin-Xhi(zpkhi),smax-Xlo(zpklo)]
    assert 0<epeak[0]<=epeak[1]<gap
    return dict(schema='Q052_V75_EARLY_PAIR_CERTIFICATE',scope='B_star and V73/Q048 source premises; frozen V62 fit; dimensionless L minus R; two cells only',
                z=endpoints([zlo,join,top]), initial_X=str(q), local_source_phase=5,
                ionization_guard_hex=branch['Pion']['hex'],Tgamma_hex=T.hex(), fit_interval_index=43,
                atomic_stencil=[83,37], reio_start=str(reio), one_plus_DK=dk.hex(),
                h_v_proof_box=endpoints([hmin,hmax,vmin,vmax]), H_per_s_hex=c.Hs.hex(),
                rate_z_H_partition=[8,16], force_hk_hex=force.hex(), force_caps=endpoints([lower,upper]),
                hh_hv_dv_caps=endpoints([hh,hv,vcap]), trial=str(trial), signed_slope_du=endpoints([-a,-b]),
                tube_formula='q-a*(810-z)/(1+z) <= DeltaXe_source <= q-b*(810-z)/811',
                epsilon_upper=str(eps), sup_abs_change_interval=endpoints([b*u_lo(zlo),eps]),
                tube_width_upper=str(width), source_sup_abs=endpoints([q,q]), source_argmax_unique_z='810',
                V71_peak_z=xe['z_max'], source_at_stored_peak=endpoints([Xlo(zpklo),Xhi(zpkhi)]),
                signed_stored_minus_source_at_stored_peak=endpoints(epeak),
                stored_peak_cell_Bernstein_lower=str(min(bern)), stored_min=str(s0),
                max_positive_error_upper=str(smax-Xlo(zlo)), signed_error_at_start=str(-gap),
                sup_abs_stored_minus_source=endpoints([gap,gap]), error_argmax_unique_z='810',
                constant_goal_met=True, variable_goal_met=True,new_native_pairs=0,full_history_integrations=0,
                global_source_xe_sup=None,global_source_tau_sup=None)

if __name__=='__main__':
    print(json.dumps(solve(),indent=2))
