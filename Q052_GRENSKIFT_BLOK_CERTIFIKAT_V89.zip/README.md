# Reproducer Q052 V89

PROOF_V89.md er beviset. result.json indeholder alle 160 primærbokse og ti kontrolresultater. control.json er resultatet fra den selvstændige kontrolkørsel. Den komplette journal og det korte resultat leveres som separate Markdown-filer.

## Krav

Python 3.10+ på Linux, aktiverede assertions og MPFR præcis 4.2.1. Det historiske intervalbibliotek kontrollerer versionsnummeret. MPFR 4.2.2 afvises af versionsporten. Ændr ikke porten eller de fastlåste filer for at få en kørsel til at passere.

Hvis MPFR 4.2.1 allerede er tilgængeligt som libmpfr.so.6, køres fra den udpakkede mappe

```sh
python3 run89.py > replay.json
cmp replay.json result.json
python3 check89.py > replay-control.json
cmp replay-control.json control.json
```

Ellers indeholder pakken det uændrede officielle MPFR 4.2.1-kildearkiv. Med gcc, make og GMP-udviklingsfiler installeret kan man bygge en lokal kopi med standardværktøjer

```sh
sha256sum mpfr-4.2.1.tar.xz
tar -xf mpfr-4.2.1.tar.xz
cd mpfr-4.2.1
./configure --prefix="$PWD/../mpfr421" --disable-static --disable-float128
make -j4
make install
cd ..
LD_LIBRARY_PATH="$PWD/mpfr421/lib" python3 run89.py > replay.json
cmp replay.json result.json
LD_LIBRARY_PATH="$PWD/mpfr421/lib" python3 check89.py > replay-control.json
cmp replay-control.json control.json
```

Arkivets SHA-256 skal være 277807353a6726978996945af13e52829e3abd7a9a5b7fb2793894e18f1fcbb2. Projektets officielle udgave findes på https://www.mpfr.org/mpfr-4.2.1/. Kildearkivet indeholder MPFR's licens- og copyrightfiler. En lokal afhængighedsbygning ændrer ingen kildeligninger eller historiske pins.

certify87.py og control87.py bruges kun til import af de tidligere kontrollerede funktioner. Deres gamle hovedprogrammer er ikke V89's indgangspunkter. De kræver gamle opgavefiler og skal ikke køres som V89-tests. v20.py er tilsvarende den uændrede historiske backend. Ingen eksterne Python-pakker kræves.

manifest.json hasher alle medlemmer undtagen sig selv. manifest87.json og manifest88.json dokumenterer historiske inputarkiver og refererer derfor også til historiske filer, som ikke alle er kopieret ind i denne kompakte pakke. Alle input til de to V89-kørsler ligger i pakken. verification.json dokumenterer genkørsel fra frisk udpakning med den krævede runtime-version. return_task.json er en forberedt overdragelse og er ikke en udført ny forskningsopgave.

De tre V89-filer er klar til manuel placering i roden af Morfindien/Bubbleverse efter kontrol af aktuel branch. Bevar tidligere versioner og opdatér den eksisterende Q052-navigation. Den senest kontrollerede GitHub-snapshot dækkede kun tre af V88-inputtene. Se sources.json. Der er ikke skrevet til GitHub i denne runde.
