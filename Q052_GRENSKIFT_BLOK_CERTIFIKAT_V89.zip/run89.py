"""Join the two conditional face bounds in redshift order, stopping at the first obstruction."""
import hashlib
import json
import time
from fractions import Fraction as F
from pathlib import Path
from certify87 import check_slab, pair, rational_hex as hx
from check89 import check_cell
import v20 as m

ROOT = Path(__file__).resolve().parent
Q = F(1,10**6)
SLABS = 16

def read(name):
    return json.loads((ROOT/name).read_bytes())

def run():
    start = time.monotonic()
    for n, pin in read('pins.json').items():
        assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest() == pin['sha256']
    task, v62, v77 = read('task88.json'), read('v62.json'), read('v77.json')
    assert task['current_q'] == task['target_q'] == 'Q052'
    assert v77['status'] == 'PASS_UNDER_FROZEN_PREMISES'
    assert F(v77['thermal_forcing_max']) < F(v77['thermal_cap']) == F(99,100)
    previous = read('result87.json')
    assert previous['status']=='INWARD_ON_ALL_BRANCHES' and read('control_result87.json')['status']=='PASS'
    current = F(previous['z_exact'][0])
    assert current == F(task['interface']['z'])
    ctx = m.Context(ROOT/'v19.json')
    assert ctx.ctx['frozen']['physics_commit']==task['source_commit']
    neff = list(map(hx,v62['Neff_from_archived_row']))
    assert F('3.04')<neff[0]<=neff[1]<F('3.05')
    ratio = (m.lit('2.7255')/m.enc(ctx.T0)).power(m.I(3))
    shifts = [m.I(1), (m.I(0,1)-m.lit('.14175'))*ratio,
              (m.enc(0,F('.03'))-m.lit('.02242')*(1-m.lit('.246738546372')))*ratio,
              m.enc(F('3.04'),F('3.05'))-m.lit('3.046')]
    fit = [[m.lit(x) for x in line.split()] for line in ctx.sources['fit_swift.dat']['content'].splitlines() if line.strip()]
    cells = []
    assert [r['cell_one_based'] for r in task['cells']]==list(range(236,246))
    for requested in task['cells']:
        number = requested['cell_one_based']
        L,R = [v62['arms'][arm]['records'][number-1] for arm in 'LR']
        assert L['z']==R['z'] and L['H_per_s']==R['H_per_s']
        assert L['allowed_branches']==R['allowed_branches']==['HMLA','SWIFT']
        hi,lo = map(hx,R['z'])
        assert hi==current and requested['z_exact']==list(map(str,[lo,hi]))
        h_lo = max(hx(R['whole_source'][0][0]), hx(L['whole_source'][0][0])+Q)
        h_hi = min(hx(R['whole_source'][0][1]), hx(L['whole_source'][0][1])+Q)
        assert Q<h_lo<=h_hi<1
        h = m.enc(h_lo,h_hi)
        v = m.hull(pair(row['whole_source'][1]) for row in [L,R])
        assert ctx.vmin.hi < v.lo <= v.hi < 1
        # Locate the actual published V77 group covering this cell, including its v domain.
        groups=[g for g in v77['elasticity_blocks'] if F(g['z'][0])>=hi and lo>=F(g['z'][1])]
        assert len(groups)==1
        group=groups[0]
        assert F(v.lo)>=F(group['v_lower'])
        assert -1<hx(group['elasticity_hex'][0])<=hx(group['elasticity_hex'][1])<0
        assert 0<=F(group['saha_over_h_squared_upper'])<1
        hs = pair(R['H_per_s'])
        parts = []
        for k in reversed(range(SLABS)):
            a,b = lo+(hi-lo)*k/SLABS, lo+(hi-lo)*(k+1)/SLABS
            slab=check_slab(ctx,a,b,h,v,hs,fit,shifts)
            parts.append(slab)
            if slab['status']=='UNRESOLVED':
                break
        common = Q/F(h.hi)
        primary = min([common]+[F(s['margin']) for s in parts if 'margin' in s])
        saved_jump = next(j for j in v77['mixed_branch_checks'] if j['z']==R['z'])
        check = check_cell(ctx,L,R,saved_jump)
        ok = len(parts)==SLABS and primary>0 and F(check['margin'])>0
        cells.append({'cell':number,'z_exact':requested['z_exact'],'h_face':h.hex(),'whole_v':v.hex(),
                      'whole_H_per_s':hs.hex(),'V77_rate_group':group,'common_margin':str(common),
                      'primary_margin':str(primary),'mixed_excluded':sum(s['status']=='MIXED_EXCLUDED' for s in parts),
                      'slabs':parts,'separate_control':check,'status':'PASS' if ok else 'INCONCLUSIVE'})
        if not ok:
            break
        current=lo
        assert time.monotonic()-start < 300
    finished = cells[-1]['cell']==245 and cells[-1]['status']=='PASS'
    interface=None
    if finished:
        next_rows=[v62['arms'][arm]['records'][245] for arm in 'LR']
        assert all(hx(row['z'][0])==current and row['allowed_branches']==['HMLA'] for row in next_rows)
        interface={'next_cell':246,'z':str(current),'mask':['HMLA'],'checked_beyond_boundary':False}
    return {'status':'ALL_TEN_PASS' if finished else 'FIRST_OBSTRUCTION','cells':cells,
            'proven_z':[str(current),'810'],'interface':interface,
            'native_pairs':0,'full_history_integrations':0,'resource_limit_seconds':300}
if __name__=='__main__':
    print(json.dumps(run(),indent=2))
