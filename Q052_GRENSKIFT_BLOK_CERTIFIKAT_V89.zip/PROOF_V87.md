# Q052 V87 · Fortegnet gennem celle 235

På det fastholdte fælles B★ og med de matchede starttilstande ved z = 810 har beregningen med heliumbidraget flere frie elektroner pr. hydrogenkerne end beregningen uden bidraget, gennem hele det nu beviste interval fra 810 ned til

\[
z_b=761161663339561/1099511627776\simeq692,2725.
\]

V85 nåede til z_a = 1523417340748759/2199023255552 (cirka 692,77). V87 dækker præcis den efterfølgende V62-celle, nummer 235. Alle konklusioner arver de dokumenterede kilde-, baggrunds- og banepræmisser. Beregningerne gælder løsningerne af kildeligningerne.

## Hvornår kan de to arme vælge forskellige formler?

Sæt q = 10⁻⁶, h = h_R og d = h_L − h. Den interne elektronforskel er E = d + q. På den kritiske rand E = 0 er h_L = h − q, mens begge armes interne elektronfraktion er h. Den offentlige elektronfraktion følger den interne i denne fase før reionisation. Fra V85 kommer parret ind i cellen med E > 0. På vej mod en mulig første kontakt gælder v_L ≥ v_R, hvor v er stof- over strålingstemperatur. Den tidligere temperaturgrænse og enkeltarmsboksene gælder fortsat.

Den fastholdte kilde har fysisk strålingstemperatur og temperaturforhold inden for de relevante tabeller i cellen. SWIFT-fittets temperaturkrav er opfyldt. I hyrec.c, linje 1065–1076, når z < 900, sætter kildekoden

\[
e(h)=L_{\rm Ly\alpha}H/[n_H(1-h)],\qquad
P(h)=B/[3e(h)+\Lambda+B],
\quad B=S_0T_R^{3/2}e^{-E_I/(4T_R)}\alpha_B(T_R).
\]

Her er H i s⁻¹, n_H i cm⁻³ og T_R i eV. B, e og Λ er rater i s⁻¹. P er dimensionsløs. Hydrogen.h fastlægger p = PION_MAX = 0,01. P < p vælger HMLA, mens P ≥ p vælger SWIFT i dette temperaturinterval. Testen bruger rå escape før SWIFT-korrektionen. B afhænger af den fælles strålingstemperatur. q og v indgår gennem de tilladte tilstande, mens selve selectorformlen kun ser h, H, n_H og strålingstemperaturen. I wrapperen kan Peebles vælges ved den lave strålingstemperatur- eller temperaturforholdsgrænse. Ingen af disse grænser nås her under V62/V77-præmisserne.

Sæt c = [(1/p−1)B−Λ]/3. Gennem cellen er c positiv. Da h_L < h_R og H er fælles, er e_L < e_R og P_L > P_R på randen. Den eneste blandede mulighed er SWIFT i L og HMLA i R. De præcise betingelser er e_L ≤ c < e_R. For den samme baggrundsværdi svarer det præcis til

\[
c\,n_H(1-h)/L_{\rm Ly\alpha}<H\le
c\,n_H(1-h+q)/L_{\rm Ly\alpha}.
\]

Dermed ligger e_R på enhver blandet randtilstand i den meget smalle korridor mellem c og c[1+q/(1−h)]. I de udadrettede bounds medtager vi også lighed ved begge ender for at dække ensidige felter. Begge grene bruger samme z, H og kildekonstanter. Intervalregningen må udvide den tilladte mængde konservativt efter den fælles betingelse er udledt.

## Bevis på randen E = 0

For hver af de to atomare kanaler har V85, med den beviste temperaturorden og aftagende rekombinationsrate, vist

\[
U_R>0,\qquad U_L\le(1-q/h)U_R.
\]

På hver fælles gren vokser C med escape-raten og dermed med h. C_L ≤ C_R giver derfor d′/|f_R| ≥ q/h > 0. Prim er differentiation i fremadrettet u = ln[811/(1+z)]. For det blandede felt er en øvre grænse J på begge kanalers relative C-forøgelse tilstrækkelig. Hvis U_L < 0 i en kanal, er dens bidrag allerede gunstigt. Ellers kan den positive øvre grænse multipliceres med C. Summation med de fælles positive faktorer giver

\[
\frac{d'}{|f_R|}\ge 1-(1+J)(1-q/h_{\max}).
\]

Her tages h_max på fællesmængden af højre boks og venstre boks forskudt med q. V87 bruger C_SWIFT(h) som konservativt loft på C_SWIFT(h−q). Det følger af at det fælles DK er uafhængigt af h og 1+DK er positivt.

## To beregninger af den nye margin

Primærkontrollen deler kun den ene celle i 16 sammenhængende, lukkede z-intervaller. Den afskærer e_R med både den fælles H-boks og selectorens korridor. I 11 intervaller er overlap tomt. I de øvrige fem evalueres de to kanaler med den pin-verificerede MPFR-intervalbackend. Logtabeller, endestencils, fitparametergrænser og ratepræmisser følger V77. Alle intervalendepunkter og de beregnede marginer er gemt i result.json.

Med beta_s, beta_p som fotoionisationsrater og j som 2p→2s-raten sætter vi

\[
G=\beta_s+\Lambda+3j,\quad K=G\beta_p+j\beta_s,\quad
D(e)=(\beta_s+\Lambda)(\beta_p+j)+3j\beta_p+Ge.
\]

Kanaltællerne er N_s(e)=Λ(β_p+j)+(Λ+3j)e og N_p(e)=Λj+Ge. I begge tilfælde er C=N/D. For e_S=e/(1+DK) er den eksakte relative forøgelse

\[
C_i(e_S)/C_i(e)-1=(e_S-e)\eta_i K/[D(e_S)N_i(e)],
\qquad (\eta_s,\eta_p)=(3j,G).
\]

Den mindste certificerede nedre margin på det blandede felt er større end 0,00008914 for d′/|f_R|. Den gamle grenuafhængige nedre grænse fra V85 var negativ i samme celle. Forbedringen skyldes, at både HMLA- og SWIFT-betingelsen nu skal gælde samtidigt.

Kontrollen i control87.py behandler hele cellen i én boks. B er voksende med T_R, da den logaritmiske hældning er 1,5−a+E_I/(4T_R)−bY/(1+Y)>0 for de fastholdte PPB-konstanter. Kontrollen bruger temperaturendepunkterne til at indhegne c og omsætter først selectorulighederne til et interval for det fælles H. Den bruger V77's helcelleloft for DK. For hver kanal integreres derefter

\[
(\log C_i)'(e)=\eta_i K/[D(e)N_i(e)].
\]

Nævneren er positiv og voksende i e. Produktet af det længste tilladte escape-interval og et loft på den logaritmiske afledte indhegner log-forøgelsen. For 0 ≤ x < 1 giver exp(x) ≤ 1/(1−x) et rationelt loft på C-forholdet. Denne metode giver en nedre margin større end 0,00006368 over hele den blandede del af cellen. Begge metoder giver en streng indadrettet afledt. De deler de oprindelige intervaldata, atomtabeller, literal kilde og MPFR-primitiver. Den separate kontrol deler hverken primærmetodens opdeling eller dens beregning af den endelige C-ratio.

Kontrollen giver desuden et eksakt rationelt eksempel i de arkiverede intervalbokse, hvor P_L > p > P_R, med samme H og z og en lille positiv temperaturforskel inden for korrelationsloftet. Tallene og de udadrettede P-intervaller står i control.json. Eksemplet viser, at denne intervalbeskrivelse tillader blandet dispatch. Om den bestemte baggrund og de matchede baner faktisk besøger et sådant punkt står åbent. Den uniforme margin dækker begge muligheder.

## Fortsættelse og optisk konsekvens

Ved en første kontakt med E=0 er E′=d′. Tilstanden er kontinuert under de tidligere kildepræmisser. For alle kildefelter som kan nærme sig randen fra E>0, inklusive de ensidige skiftefelter, er den afledte strengt positiv. Kontinuitet af hvert grenfelt giver samme fortegn i et indre nabolag af kontaktpunktet. Integration over det sidste korte tidsinterval udelukker første kontakt. Derfor når parret cellens nedre endepunkt med E>0. V85 giver positiviteten op til dette nye interval.

For F(Z)=Δτ_T(0,Z) er F′(Z)=w(Z)ΔX_e(Z), med den tidligere verificerede positive Thomson-vægt. F vokser derfor med Z på [z_b,810]. Den akkumulerede værdi ved z_b afhænger af de lavere rødforskydninger. Det globale maksimumsted, dets værdi og den fulde simulationsfejl er åbne krav i Q052.

Begge beregninger bruger nul nye native par og nul fulde historieintegrationer. V86's stopkriterium er nået for celle 235. Overdragelsen går til **Resultatindtag og routing 2.3.0** med en præcis reference til den nye positive slutknude og metoden til at vurdere det næste tilladte grenskift.
