"""Q052 bounded first-cell direct defect. No native run, no global certificate.

Replay: python q052_direct_defect_v20.py --bundle Q052_DIRECT_DEFECT_EXECUTION_BUNDLE_V19.json --output result.json
The exact V19 bundle carries the unchanged scalar MPFR module and all sources.
Conditional on the inherited fixed admitted background and positive-escape domain.
"""
from pathlib import Path
from fractions import Fraction as Q
import argparse, datetime, hashlib, importlib.util, json, math, platform, sys, tempfile, time

BUNDLE_SHA = '3f3838394c1a85b2fa592dc2fb4c66d7c67e3d6c74a07873b9a060c22aebe89c'
BACKEND_SHA = '558592e20969dbfc063570f2224c36b4e8d7dca37db20009cb5dd2a993e0d160'
SPEC_SHA = '419edf76c43f7740e3cc94610612ab4760e06355df8457d2b5b94dad35c4ded5'
I = None

class ObligationError(ValueError): pass

def require(ok, reason):
    if not ok: raise ObligationError(reason)

def sha(b): return hashlib.sha256(b).hexdigest()
def fq(s): return Q.from_float(float.fromhex(s))
def enc(lo, hi=None):
    lo=Q(lo); hi=lo if hi is None else Q(hi)
    require(lo<=hi, 'REVERSED_RATIONAL_INTERVAL')
    a=float(lo); b=float(hi)
    if Q.from_float(a)>lo: a=math.nextafter(a,-math.inf)
    if Q.from_float(b)<hi: b=math.nextafter(b,math.inf)
    return I(a,b)

def lit(s):
    a=Q(s); b=Q.from_float(float(s))
    return enc(min(a,b),max(a,b))

def hull(xs):
    xs=list(xs);require(bool(xs),'EMPTY_HULL')
    return I(min(x.lo for x in xs),max(x.hi for x in xs))

def ab(x): return I(0 if x.lo<=0<=x.hi else min(abs(x.lo),abs(x.hi)),max(abs(x.lo),abs(x.hi)))
def out(x): return {'hex':x.hex(),'display':x.pair()}
def upper(x): return I(x.hi)

def split(b,t):
    """Exact rational de Casteljau; t in [0,1]."""
    require(Q(0)<=t<=Q(1),'BERNSTEIN_SPLIT_DOMAIN')
    a=list(b); left=[a[0]]; right=[a[-1]]
    while len(a)>1:
        a=[(1-t)*a[i]+t*a[i+1] for i in range(len(a)-1)]
        left.append(a[0]);right.append(a[-1])
    return left,right[::-1]

def restrict(b,a,c):
    require(0<=a<=c<=1,'BERNSTEIN_RESTRICTION_DOMAIN')
    if a==c: return [split(b,a)[0][-1]]*len(b)
    l=split(b,c)[0]
    return split(l,a/c)[1]

def bern_range(b,a,c):
    r=restrict(b,a,c);return enc(min(r),max(r))

def weights(t):
    return [t*(t-1)*(2-t)/6,(1+t)*(1-t)*(2-t)/2,(1+t)*t*(2-t)/2,(1+t)*t*(t-1)/6]

def dweights(t):
    return [(-3*t*t+6*t-2)/6,(3*t*t-4*t-1)/2,(-3*t*t+2*t+2)/2,(3*t*t-1)/6]

def cubic(y,t):
    # Exact partition of unity removes a common log-rate offset.
    w=weights(t)
    return y[1]+sum(((y[k]-y[1])*w[k] for k in (0,2,3)),I(0))

def dcubic(y,t):
    w=dweights(t)
    return sum(((y[k]-y[1])*w[k] for k in (0,2,3)),I(0))

def stencils(q,n):
    """All closed pieces of floor clamped to [1,n-3]."""
    for j in range(1,n-2):
        lo=q.lo if j==1 else max(q.lo,float(j))
        hi=q.hi if j==n-3 else min(q.hi,float(j+1))
        if lo<=hi: yield j,I(lo,hi)-j

def norm_rows(J,r):
    return [sum((ab(J[i][j])*r[j]/r[i] for j in range(2)),I(0)) for i in range(2)]

def closure(d,L,T,E0=None):
    E0=I(0) if E0 is None else E0
    require(d.lo>=0 and L.lo>=0 and T.lo>=0 and E0.lo>=0,'NEGATIVE_CLOSURE_INPUT')
    # L,d below are certified nonnegative upper constants, not lower bounds on the optimal constants.
    require(L.lo==L.hi,'CLOSURE_EXPECTS_FIXED_UPPER_L')
    e=(L*T).exp()
    phi=T if L.hi==0 else (e-1)/L
    bound=E0*e+d*phi
    return bound, bound.hi<1

class Context:
    def __init__(self,bundle_path):
        global I
        raw=Path(bundle_path).read_bytes();require(sha(raw)==BUNDLE_SHA,'BUNDLE_SHA256_MISMATCH')
        self.bundle=json.loads(raw);members=self.bundle['original_members'];self.pins=[]
        for n,e in members.items(): self.check_member(n,e)
        be=members['q052_scalar_interval_v18.py']['content'].encode()
        require(sha(be)==BACKEND_SHA,'BACKEND_SHA256_MISMATCH')
        self.tmp=tempfile.TemporaryDirectory(prefix='q052_scalar_')
        bp=Path(self.tmp.name)/'q052_scalar_interval_v18.py';bp.write_bytes(be)
        spec=importlib.util.spec_from_file_location('q052_scalar_pinned',bp)
        self.mp=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.mp);I=self.mp.I
        self.data=json.loads(members['Q052_BACKGROUND_TRANSFER_INPUTS_V18.json']['content'])
        self.parent=self.data['parent_v17_inputs'];self.ctx=self.parent['native_first_cell_context']
        self.raw=self.parent['parent_result']['validator_inputs_original']['files']
        for n,e in self.raw.items(): self.check_member(n,e)
        self.sources={**self.ctx['source_files'],**self.data['additional_pinned_sources']}
        for n,e in self.sources.items():self.check_member(n,e)
        self.capture=json.loads(self.raw['q048_prefix_config_v1.json']['content'])['cases']['hillipop-ede_n3']
        self.binding=json.loads(self.raw['Q050_CLEAN_BG_BINDING_V1.json']['content'])
        qual=self.parent['parent_result']['receipt']['qualification']
        require(qual['conditional_binding_receipt']=='PASS_REUSED' and qual['retained_guard_final_receipt']=='PASS_REUSED','CONDITIONAL_BINDING_QUALIFICATION')
        require(self.capture['background']['thermal_flags']=={'has_varconst':0,'has_exotic_injection':0,'has_idm_b':0,'has_idm_g':0,'has_idm_dr':0,'recombination':1},'ACTIVE_FLAGS')
        require(self.capture['background']['flags']['has_idm']==0 and self.capture['background']['flags']['has_idr']==0,'IDM_FLAGS')
        require(self.binding['q_branches'][0]['background_dependency_id']==self.binding['q_branches'][1]['background_dependency_id'],'COMMON_BACKGROUND_ID')
        require(self.ctx['frozen']['physics_commit']=='5a131c91d657dd9a7c6364cc45b038710f8d0d97','PHYSICS_COMMIT')
        self.H=enc(*map(Q,self.binding['cells'][0]['H']))
        constants=self.capture['thermal_starts'][0]['constants'];fields=self.capture['background']['fields']
        self.T0=fq(constants['Tcmb']);self.n0=fq(constants['nH0_SI']);self.he=fq(constants['fHe_CLASS'])
        self.rho0=fq(fields['Omega0_g'])*fq(fields['H0'])**2
        self.z1=fq(self.ctx['cell']['z_lower_binary64_hex']);self.dx=Q(810)-self.z1
        self.T=enc(Q(811)/(1+self.z1)).log()
        self.k=lit('8.617343e-5');self.EI=lit('13.598286071938324');self.saha=lit('3.016103031869581e21')
        self.lya=lit('4.662899067555897e15');self.lam=lit('8.2206')
        self.Hs=self.H*lit('2.99792458e8')/lit('3.085677581282e22')
        self.K=(2*lit('6.6524616e-29')/(lit('9.10938215e-31')*lit('2.99792458e8')))*(I(4)/3)*lit('0.0151730087')
        self.trmin=lit('0.004');self.trmax=lit('0.4');self.vmin=lit('0.1')
        self.logmin=self.trmin.log();self.dlog=(self.trmax.log()-self.logmin)/99
        self.dv=(1-self.vmin)/39
        at=self.sources['Alpha_inf.dat']['content'].split();rt=self.sources['R_inf.dat']['content'].split()
        require(len(at)==100*40*4 and len(rt)==100,'TABLE_LENGTH')
        require(all(Q(x)>0 for x in at+rt),'TABLE_POSITIVITY')
        # Every log-table input is enclosed; no native libm result is assumed rounded.
        logs=[lit(x).log() for x in at]
        self.alpha=[[[logs[(i*40+j)*4+l] for i in range(100)] for j in range(40)] for l in range(4)]
        self.R=[lit(x).log() for x in rt]
        fit=self.sources['fit_swift.dat']['content'].split()
        require(len(fit)==265*5,'FIT_TABLE_LENGTH')
        self.fit_first=lit(fit[0]);self.fit_last=lit(fit[-5])
        require('1+DK>0' in members['Q052_BACKGROUND_TRANSFER_PROOF_V18.md']['content'],'POSITIVE_ESCAPE_PREMISE_NOT_FOUND')
        # The proof supplies conditional applicability, not a computed native DK range.
        self.starts={}
        for arm,a in self.ctx['arms'].items():
            cell=a['first_cell_exact_representation'];require(cell['phase']==5,'ACTIVE_PHASE')
            initial=a['first_z810_rhs_record'];h0=fq(initial['y'][initial['indices']['x_H']]);D0=fq(initial['y'][initial['indices']['D_Tmat']])
            require(Q(cell['h_bernstein'][0])==h0 and Q(cell['D_bernstein'][0])==D0,'CURVE_START_MISMATCH')
            self.starts[arm]=[h0,1+D0/(self.T0*811)]
        require(self.starts['L']==self.starts['R'],'MATCHED_STARTS')
        require(0<=self.starts['L'][0]<=Q(99999,100000) and Q(98,100)<=self.starts['L'][1]<=Q(1000001,1000000),'INITIAL_CLASS')

    def check_member(self,n,e):
        b=e['content'].encode('utf-8');require(sha(b)==e['sha256'],'MEMBER_SHA256:'+n)
        if 'size_bytes' in e:require(len(b)==e['size_bytes'],'MEMBER_SIZE:'+n)
        self.pins.append({'name':n,'sha256':sha(b),'size_bytes':len(b)})

    def curve(self,arm,a,c):
        cell=self.ctx['arms'][arm]['first_cell_exact_representation']
        hb=list(map(Q,cell['h_bernstein']));db=list(map(Q,cell['D_bernstein']))
        zp=enc(Q(811)-self.dx*c,Q(811)-self.dx*a)
        h=bern_range(hb,a,c);D=bern_range(db,a,c)
        hx=bern_range([3*(hb[k+1]-hb[k])/self.dx for k in range(3)],a,c)
        Dx=bern_range([3*(db[k+1]-db[k])/self.dx for k in range(3)],a,c)
        v=1+D/(enc(self.T0)*zp)
        return zp,h,v,zp*hx,Dx/enc(self.T0)+v-1

    def background(self,zp):
        T=enc(self.T0)*zp;TR=T*self.k;nH=enc(self.n0)*lit('1e-6')*zp*zp*zp
        rho=enc(self.rho0)*zp*zp*zp*zp
        return T,TR,nH,rho

    def branch(self,zp,h,v):
        T,TR,nH,rho=self.background(zp)
        require(0<h.lo and h.hi<1,'HYDROGEN_DOMAIN')
        require(self.trmin.hi<TR.lo and TR.hi<self.trmax.lo,'RADIATION_RATE_DOMAIN')
        require(self.vmin.hi<v.lo and v.hi<1,'COLD_RATE_DOMAIN')
        require(T.lo>self.fit_first.hi and T.hi<self.fit_last.lo,'SWIFT_FIT_DOMAIN')
        t4=TR/self.k/10000
        alpha=lit('4.309e-13')*t4.power(lit('-0.6166'))/(1+lit('0.6703')*t4.power(lit('0.5300')))
        B=self.saha*TR*TR.sqrt()*(-self.EI/(4*TR)).exp()*alpha
        R=self.lya*self.Hs/nH/(1-h)
        pion=B/(3*R+self.lam+B);margin=99*B-self.lam-3*R
        require(pion.lo>lit('0.01').hi and margin.lo>0,'SWIFT_PION_GUARD')
        return {'h':out(h),'v':out(v),'TR_eV':out(TR),'Tgamma_K':out(T),'Pion':out(pion),'99B_lambda_3R_margin':out(margin),'positive_escape':'INHERITED_CONDITIONAL_1+DK>0_NOT_NATIVE_VERIFIED','status':'PASS_CONDITIONAL'}

    def rates(self,TR,v):
        require(TR.lo>=self.trmin.hi and TR.hi<=self.trmax.lo and v.lo>=self.vmin.hi and v.hi<=1,'RATE_BOX_DOMAIN')
        qt=(TR.log()-self.logmin)/self.dlog;qv=(v-self.vmin)/self.dv
        al=[[],[]];eq=[[],[]];dav=[[],[]];rr=[];used=[]
        for it,t in stencils(qt,100):
            for l in range(2):eq[l].append(cubic(self.alpha[l][-1][it-1:it+3],t).exp())
            rr.append(cubic(self.R[it-1:it+3],t).exp())
            for iv,s in stencils(qv,40):
                used.append([it,iv])
                for l in range(2):
                    yy=[cubic(self.alpha[l][j][it-1:it+3],t) for j in range(iv-1,iv+3)]
                    a=cubic(yy,s).exp();al[l].append(a);dav[l].append(a*dcubic(yy,s)/self.dv)
        require(bool(used),'NO_RATE_STENCIL')
        alpha=list(map(hull,al));ae=list(map(hull,eq));da=list(map(hull,dav));R=hull(rr)
        # These positive derived rates also verify the denominators behind the C theorem.
        beta=[ae[l]*self.saha*TR*TR.sqrt()*(-self.EI/(4*TR)).exp()/(2*l+1) for l in range(2)]
        require(R.lo>0 and min(a.lo for a in alpha+ae+beta)>0,'POSITIVE_ATOMIC_RATES')
        # D0=(bs+3j+lambda)(bp+j)-3j², evaluated without cancelling positive j².
        D0=(beta[0]+self.lam)*(beta[1]+R)+3*R*beta[1]
        require(D0.lo>0,'C_FACTOR_DENOMINATOR')
        return alpha,ae,da,{'stencils':used,'qTR':out(qt),'qV':out(qv),'alpha':[out(a) for a in alpha],'alpha_eq':[out(a) for a in ae],'dalpha_dv':[out(a) for a in da],'R2p2s':out(R),'beta':[out(a) for a in beta],'C_D0':out(D0)}

    def field(self,zp,h,v,q,want_J):
        T,TR,nH,rho=self.background(zp)
        alpha,ae,da,receipt=self.rates(TR,v)
        s=self.saha*TR*TR.sqrt()*(-self.EI/TR).exp()/nH
        X=h+enc(q);U=[alpha[k]*h*X-ae[k]*s*(1-h) for k in range(2)]
        f=-(nH/self.Hs)*sum((u*I(0,1) for u in U),I(0))
        scale=self.K*rho/self.Hs;A=scale*X/(1+enc(self.he)+X)
        g=-v+A*(1-v)
        J=None
        if want_J:
            fh=nH/self.Hs*sum((alpha[k]*(2*h+enc(q))+ae[k]*s+ab(U[k])/(4*(1-h)) for k in range(2)),I(0))
            fv=nH/self.Hs*h*X*sum((ab(d) for d in da),I(0))
            gh=scale*(1+enc(self.he))*(1-v)/((1+enc(self.he)+X)*(1+enc(self.he)+X))
            gv=-(1+A)
            # f_h/f_v are absolute envelopes, g_h/g_v retain source signs.
            J=[[I(-fh.hi,fh.hi),I(-fv.hi,fv.hi)],[gh,gv]]
        return (f,g),J,receipt

    def attempt(self,radii):
        rh,rv=map(Q,radii);r=[enc(rh),enc(rv)];arms={}
        for arm,q in [('L',Q(1,1000000)),('R',Q(0))]:
            zp,h,v,_,_=self.curve(arm,Q(0),Q(1))
            branch=self.branch(zp,h+enc(-rh,rh),v+enc(-rv,rv))
            cells=[]
            for j in range(64):
                a=Q(j,64);c=Q(j+1,64);zp,h,v,hp,vp=self.curve(arm,a,c)
                F,_,rate=self.field(zp,h,v,q,False)
                _,J,trate=self.field(zp,h+enc(-rh,rh),v+enc(-rv,rv),q,True)
                defect=[hp-F[0],vp-F[1]];weighted=[ab(defect[i])/r[i] for i in range(2)]
                rows=norm_rows(J,r)
                cells.append({'j':j,'normalized_x':[str(a),str(c)],'zplus1':out(zp),'curve':[out(h),out(v)],'curve_derivative_du':[out(hp),out(vp)],'F_on_curve':[out(f) for f in F],'defect':[out(d) for d in defect],'d_component_upper':[x.hi for x in weighted],'J_tube':[[out(x) for x in row] for row in J],'weighted_J_row_upper':[x.hi for x in rows],'curve_rates':rate,'tube_rates':trate})
            ds=[max(c['d_component_upper'][i] for c in cells) for i in range(2)]
            ls=[max(c['weighted_J_row_upper'][i] for c in cells) for i in range(2)]
            d=I(max(ds));L=I(max(ls));bound,passed=closure(d,L,self.T)
            arms[arm]={'q_exact':str(q),'branch_domain':branch,'d_upper':out(d),'d_component_upper':ds,'L_upper':out(L),'L_row_upper':ls,'T':out(self.T),'E0_exact':'0','bound_expression_interval':out(bound),'strict_upper_less_than_one':passed,'conditional_first_cell_status':'PASS' if passed else 'INCONCLUSIVE_METHOD_WIDTH','error_components_if_pass':[out(bound*x) for x in r] if passed else None,'cells':cells}
        passed=all(a['strict_upper_less_than_one'] for a in arms.values())
        return {'radii_exact':radii,'W':'diag(1/rho_h,1/rho_v)','subcells':64,'status':'PASS' if passed else 'INCONCLUSIVE_METHOD_WIDTH','arms':arms}

def run(bundle_path,spec_path):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.perf_counter()
    sraw=Path(spec_path).read_bytes();require(sha(sraw)==SPEC_SHA,'SPEC_HASH_MISMATCH')
    spec=json.loads(sraw);ctx=Context(bundle_path);attempts=[];failure=None
    for radii in spec['radius_pairs']:
        try: attempt=ctx.attempt(radii);attempts.append(attempt)
        except ObligationError as exc:
            failure={'type':'DOMAIN_OR_INPUT_OBLIGATION','message':str(exc),'radii':radii};break
        if attempt['status']=='PASS':break
    status='BLOCKED_DOMAIN_OR_INPUT' if failure else attempts[-1]['status']
    result={'schema':'LOCAL-Q052-DIRECT-DEFECT-RECEIPT-V20','q':'Q052','target_q':'Q052','program_id':'Q052-DIRECTDEFECT-V1','program_registration':'LOCAL_NOT_REGISTERED','run_id':'LOCAL-Q052-DIRECT-DEFECT-20261027-V20','status':status,'scope':spec['target'],'E0_scope':spec['E0_scope'],'exact_start_h_v':list(map(str,ctx.starts['L'])),'spec_sha256':sha(sraw),'bundle_sha256':BUNDLE_SHA,'source_pins':ctx.pins,'source_real_initialization_semantics':spec['table_semantics'],'C_factor_domain':'Inherited conditional positive escape, with evaluated positive atomic rates and D0 on both whole tubes. No native DK parameter selection or membership claim.','attempts':attempts,'first_failed_obligation':failure,'global_error_fields':{'r':None,'beta':None,'native_a':None,'E0':None,'L':None,'sup_delta_xe':None,'sup_delta_tau':None},'source_real_certificate':False,'native_background_membership_certified':False,'full_q052_gate':'UNRESOLVED','new_native_runs':0,'return_route':'BUBBLEVERSE.RESULT_INGESTION_ROUTING2.3.0','execution':{'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.perf_counter()-t,'MPFR':ctx.mp.VERSION,'precision_bits':256,'rounding':'RNDD/RNDU; outward binary64 exports','python':sys.version,'platform':platform.platform()}}
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,required=True);p.add_argument('--spec',type=Path,default=Path(__file__).with_name('Q052_DIRECT_DEFECT_SPEC_V20.json'));p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    result=run(a.bundle,a.spec)
    with a.output.open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({'status':result['status'],'elapsed_seconds':result['execution']['elapsed_seconds'],'failure':result['first_failed_obligation'],'attempts':[{'radii':a['radii_exact'],'status':a['status'],'arms':{k:{f:v[f] for f in ('d_upper','L_upper','bound_expression_interval','strict_upper_less_than_one')} for k,v in a['arms'].items()}} for a in result['attempts']]},indent=2))
