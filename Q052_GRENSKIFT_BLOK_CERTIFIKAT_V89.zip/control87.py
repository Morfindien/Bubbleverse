"""One whole-cell control via a bound on the logarithmic derivative of each C."""
from pathlib import Path
from fractions import Fraction as F
import json
import v20 as m

P=Path(__file__).resolve().parent
Q=F(1,1000000)
def load(n):
    return json.loads((P/n).read_bytes())
def hx(x):
    return F(float.fromhex(x))
def ends(interval):
    return F(interval.lo), F(interval.hi)
def guard_beta(c,tr):
    x=tr/(10000*c.k)
    return c.saha*tr*tr.sqrt()*(-c.EI/(4*tr)).exp()*m.lit('4.309e-13')*x.power(m.lit('-0.6166'))/(1+m.lit('0.6703')*x.power(m.lit('0.5300')))

def main():
    ctx=m.Context(P/'v19.json')
    archive=load('v62.json')
    L,R=[archive['arms'][a]['records'][234] for a in 'LR']
    assert L['z']==R['z'] and L['H_per_s']==R['H_per_s']
    zlo,zhi=sorted(map(hx,R['z']))
    Hlo,Hhi=map(hx,R['H_per_s'])
    hmin=max(hx(R['whole_source'][0][0]),hx(L['whole_source'][0][0])+Q)
    hmax=min(hx(R['whole_source'][0][1]),hx(L['whole_source'][0][1])+Q)
    pmin,pmax=ends(m.lit('0.01'));lam_min,lam_max=ends(ctx.lam)
    _,tr,n,_=ctx.background(m.enc(1+zlo,1+zhi))
    # B is increasing: log slope wrt TR is 1.5-a+EI/(4 TR)-bY/(1+Y)>0.
    assert m.lit('0.6166').hi+m.lit('0.5300').hi<1.5
    bl=F(guard_beta(ctx,m.I(tr.lo)).lo);bh=F(guard_beta(ctx,m.I(tr.hi)).hi)
    ec_min=((1/pmax-1)*bl-lam_max)/3
    ec_max=((1/pmin-1)*bh-lam_min)/3
    assert ec_min>0 and hmin>Q and hmax<1
    # Project constraints into H first. Then bound e_R again via its ordinary definition.
    nlo,nhi=ends(n);lya_lo,lya_hi=ends(ctx.lya)
    H_lower=max(Hlo,ec_min*nlo*(1-hmax)/lya_hi)
    H_upper=min(Hhi,ec_max*nhi*(1-hmin+Q)/lya_lo)
    assert H_upper>=H_lower
    emin=lya_lo*H_lower/(nhi*(1-hmin))
    emax=lya_hi*H_upper/(nlo*(1-hmax))
    old=load('v77.json')['mixed_branch_checks'][0]
    assert old['z']==R['z']; dklo,dkhi=map(hx,old['DK'])
    assert -1<dklo<=dkhi<0
    # Independently use derivative of log(C) integrated over e to e/(1+DK).
    # For positive C=(N0+N1*e)/(D0+g*e), this derivative decreases in e.
    width=emax*(-dklo)/(1+dklo)
    _,_,_,rates=ctx.rates(tr,m.I(1))
    bs,bp=[tuple(map(hx,v['hex'])) for v in rates['beta']]
    jlo,jhi=map(hx,rates['R2p2s']['hex'])
    gl=bs[0]+lam_min+3*jlo;gh=bs[1]+lam_max+3*jhi
    K=gh*bp[1]+jhi*bs[1]
    D=(bs[0]+lam_min)*(bp[0]+jlo)+3*jlo*bp[0]+gl*emin
    Ns=lam_min*(bp[0]+jlo)+(lam_min+3*jlo)*emin
    Np=lam_min*jlo+gl*emin
    logs=[width*3*jhi*K/(D*Ns),width*gh*K/(D*Np)]
    assert all(0<x<1 for x in logs)
    # exp(x)<=1/(1-x) on [0,1); exact arithmetic hereafter.
    ratio=max(1/(1-x) for x in logs)
    margin=1-ratio*(1-Q/hmax)
    # Check a strict mixed-dispatch witness for the archived interval relaxation only.
    z=zlo+(zhi-zlo)/64; h=(hmin+hmax)/2
    _,trp,np,_=ctx.background(m.enc(1+z))
    B=guard_beta(ctx,trp); critical=((1/m.lit('0.01')-1)*B-ctx.lam)/3
    # Open interval of shared H values on which both selectors are strict.
    low=F((critical*np*m.enc(1-h)/ctx.lya).hi)
    high=F((critical*np*m.enc(1-h+Q)/ctx.lya).lo)
    assert max(low,Hlo)<min(high,Hhi)
    H=(max(low,Hlo)+min(high,Hhi))/2
    v=(max(hx(x['whole_source'][1][0]) for x in [L,R])+min(hx(x['whole_source'][1][1]) for x in [L,R]))/2
    assert all(hx(x['whole_source'][1][0])<v<hx(x['whole_source'][1][1]) for x in [L,R])
    v_left=v+Q/100
    assert v_left<hx(L['whole_source'][1][1]) and (h+Q)*(v_left-v)/(Q*v_left)<F(99,100)
    def pion(hh):
        e=ctx.lya*m.enc(H)/(np*m.enc(1-hh))
        return B/(3*e+ctx.lam+B)
    left,right=pion(h-Q),pion(h)
    assert F(left.lo)>pmax and F(right.hi)<pmin
    return {'status':'PASS' if margin>0 else 'INCONCLUSIVE','whole_cell_normalized_lower':str(margin),'whole_cell_lower_display':float(margin),'log_ratio_caps':list(map(str,logs)),'selector_conditioned_H':list(map(str,[H_lower,H_upper])),'witness_scope':'Input interval relaxation only. Actual fixed B_star H(z) and trajectory occupancy not inferred.','witness':{'z':str(z),'hR':str(h),'hL':str(h-Q),'vR':str(v),'vL':str(v_left),'common_H_per_s':str(H),'Pion_L':left.hex(),'Pion_R':right.hex()},'method':'Whole-cell H projection; integrated log-C derivative with exact rational bounds; archived whole-cell DK, positive rate boxes at v=1. Shared source and MPFR primitive inputs.'}
if __name__=='__main__':
    print(json.dumps(main(),indent=2))
