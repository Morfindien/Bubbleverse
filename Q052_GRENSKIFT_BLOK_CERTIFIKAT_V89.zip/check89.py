"""Check one cell by a whole-cell H projection and an integrated log-C bound."""
from fractions import Fraction
from control87 import guard_beta, ends, hx
import v20 as m

Q = Fraction(1, 10**6)

def check_cell(ctx, left, right, archived_jump):
    """Use the archived cell DK bound and radiation endpoint rates."""
    assert archived_jump['z'] == left['z'] == right['z']
    assert right['H_per_s'] == left['H_per_s']
    lo, hi = sorted(map(hx, right['z']))
    h_lo = max(hx(right['whole_source'][0][0]), hx(left['whole_source'][0][0]) + Q)
    h_hi = min(hx(right['whole_source'][0][1]), hx(left['whole_source'][0][1]) + Q)
    assert Q < h_lo <= h_hi < 1
    H_lo, H_hi = map(hx, right['H_per_s'])
    temperature, tr, density, _ = ctx.background(m.enc(1 + lo, 1 + hi))
    assert ctx.fit_first.hi < temperature.lo <= temperature.hi < ctx.fit_last.lo
    assert ctx.trmin.hi < tr.lo <= tr.hi < ctx.trmax.lo
    # d(log B)/d(log TR) >= 1.5 - a - b > 0 (the exponential adds a positive term).
    assert m.lit('.6166').hi + m.lit('.5300').hi < 1.5
    beta_lo = Fraction(guard_beta(ctx, m.I(tr.lo)).lo)
    beta_hi = Fraction(guard_beta(ctx, m.I(tr.hi)).hi)
    p_lo, p_hi = ends(m.lit('.01'))
    lam_lo, lam_hi = ends(ctx.lam)
    crit_lo = ((1/p_hi - 1)*beta_lo - lam_hi)/3
    crit_hi = ((1/p_lo - 1)*beta_hi - lam_lo)/3
    assert crit_lo > 0
    n_lo, n_hi = ends(density)
    lya_lo, lya_hi = ends(ctx.lya)
    lower = max(H_lo, crit_lo*n_lo*(1-h_hi)/lya_hi)
    upper = min(H_hi, crit_hi*n_hi*(1-h_lo+Q)/lya_lo)
    receipt = {'z': [str(lo), str(hi)], 'H_intersection_bounds': [str(lower), str(upper)],
               'common_margin': str(Q/h_hi)}
    if lower > upper:
        return dict(receipt, status='MIXED_EXCLUDED', margin=str(Q/h_hi))
    emin = lya_lo*lower/(n_hi*(1-h_lo))
    emax = lya_hi*upper/(n_lo*(1-h_hi))
    dk_lo, dk_hi = map(hx, archived_jump['DK'])
    assert -1 < dk_lo <= dk_hi < 0 and emin > 0
    width = emax*(-dk_lo)/(1+dk_lo)
    _, _, _, rates = ctx.rates(tr, m.I(1))
    bs, bp = [list(map(hx, box['hex'])) for box in rates['beta']]
    j_lo, j_hi = map(hx, rates['R2p2s']['hex'])
    assert min(bs+bp+[j_lo,lam_lo]) > 0
    g_lo, g_hi = bs[0]+lam_lo+3*j_lo, bs[1]+lam_hi+3*j_hi
    k_hi = g_hi*bp[1]+j_hi*bs[1]
    den_lo = (bs[0]+lam_lo)*(bp[0]+j_lo)+3*j_lo*bp[0]+g_lo*emin
    ns_lo = lam_lo*(bp[0]+j_lo)+(lam_lo+3*j_lo)*emin
    np_lo = lam_lo*j_lo+g_lo*emin
    caps = [width*3*j_hi*k_hi/(den_lo*ns_lo), width*g_hi*k_hi/(den_lo*np_lo)]
    assert 0 < max(caps) < 1
    ratio = 1/(1-max(caps))
    margin = 1-ratio*(1-Q/h_hi)
    return dict(receipt,status='INWARD' if margin>0 else 'INCONCLUSIVE',margin=str(margin),
                log_caps=list(map(str,caps)),escape=[str(emin),str(emax)],DK=archived_jump['DK'])

if __name__ == '__main__':
    import json
    from pathlib import Path
    from time import monotonic
    folder = Path(__file__).resolve().parent
    started = monotonic()
    archive = json.loads((folder/'v62.json').read_bytes())
    task = json.loads((folder/'task88.json').read_bytes())
    jump_data = json.loads((folder/'v77.json').read_bytes())['mixed_branch_checks']
    context = m.Context(folder/'v19.json')
    checked = []
    boundary = Fraction(task['interface']['z'])
    for request in task['cells']:
        number = request['cell_one_based']
        left, right = [archive['arms'][arm]['records'][number-1] for arm in 'LR']
        assert hx(right['z'][0]) == boundary
        jump = next(record for record in jump_data if record['z']==right['z'])
        receipt = check_cell(context,left,right,jump)
        assert receipt['z']==request['z_exact']
        checked.append({'cell':number,'check':receipt})
        if Fraction(receipt['margin']) <= 0:
            break
        boundary = Fraction(receipt['z'][0])
    assert monotonic()-started < 300
    print(json.dumps({'separate_checks':checked,'reached_z':str(boundary)},indent=2))
