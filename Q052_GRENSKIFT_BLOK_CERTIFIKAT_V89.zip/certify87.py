"""Validated joint-selector enclosure on the lower electron face in V62 cell 235."""
import hashlib
import json
from fractions import Fraction as F
from pathlib import Path
import time
import v20 as m

BASE = Path(__file__).resolve().parent
Q = F(1, 1_000_000)
SLABS = 16

def read(name):
    return json.loads((BASE / name).read_bytes())

def rational_hex(value):
    return F(float.fromhex(value))

def pair(values):
    return m.enc(*map(rational_hex, values))

def data_for_cell():
    archived = read('v62.json')
    left, right = [archived['arms'][arm]['records'][234] for arm in 'LR']
    assert left['z'] == right['z'] and left['H_per_s'] == right['H_per_s']
    assert left['allowed_branches'] == right['allowed_branches'] == ['HMLA','SWIFT']
    right_h = list(map(rational_hex, right['whole_source'][0]))
    left_h = list(map(rational_hex, left['whole_source'][0]))
    lower = max(right_h[0], left_h[0]+Q)
    upper = min(right_h[1], left_h[1]+Q)
    assert Q < lower < upper < 1
    temperature = m.hull(pair(row['whole_source'][1]) for row in (left, right))
    assert temperature.lo > .1 and temperature.hi < 1
    return sorted(map(rational_hex, right['z'])), m.enc(lower, upper), temperature, pair(right['H_per_s'])

def selector_threshold(context, tr):
    t4 = tr / context.k / 10000
    alpha = m.lit('4.309e-13') * t4.power(m.lit('-0.6166')) / (1+m.lit('0.6703')*t4.power(m.lit('0.5300')))
    beta = context.saha*tr*tr.sqrt()*(-context.EI/(4*tr)).exp()*alpha
    return ((1/m.lit('0.01')-1)*beta-context.lam)/3

def fitted_correction(context, temperature, fit, shifts):
    coord = (temperature-context.fit_first)/10
    return m.hull(sum((mult*m.cubic([fit[k][col] for k in range(idx-1,idx+3)],t)
                       for col,mult in enumerate(shifts,1)),m.I(0))
                  for idx,t in m.stencils(coord,len(fit)))

def check_slab(context, a, b, h, v, hs, fit, shifts):
    temperature,tr,nh,_ = context.background(m.enc(1+a,1+b))
    assert context.fit_first.hi < temperature.lo <= temperature.hi < context.fit_last.lo
    critical = selector_threshold(context,tr)
    assert critical.lo > 0
    # Right HMLA requires e_R >= ecrit in closure. Left SWIFT requires e_L <= ecrit.
    # e_L=e_R*(1-h)/(1-h+q), exactly the same uncorrected H/nH in both arms.
    relaxation = 1 + m.enc(Q)/(1-h)
    right_escape = context.lya * hs / (nh*(1-h))
    low = max(critical.lo,right_escape.lo)
    high = min((critical*relaxation).hi,right_escape.hi)
    record = {'z':list(map(str,[a,b])),'critical':critical.hex(),'physical_escape':right_escape.hex(),'relaxation':relaxation.hex()}
    if low > high:
        return dict(record,status='MIXED_EXCLUDED')
    e = m.I(low,high)
    dk = fitted_correction(context,temperature,fit,shifts)
    assert -1 < dk.lo <= dk.hi < 0
    # Using h instead of h-q in the fitted escape is conservative by C monotonicity.
    e_swift = e/(1+dk)
    _,_,_,rates = context.rates(tr,v)
    bs,bp = [pair(x['hex']) for x in rates['beta']]
    j = pair(rates['R2p2s']['hex'])
    lam = context.lam
    g = bs+lam+3*j
    D0 = (bs+lam)*(bp+j)+3*j*bp
    K = g*bp+j*bs
    ns = lam*(bp+j)+(lam+3*j)*e
    np = lam*j+g*e
    de = (-dk)*e/(1+dk)
    excesses = [de*y*K/((D0+g*e_swift)*n) for y,n in [(3*j,ns),(g,np)]]
    excess = max(F(x.hi) for x in excesses)
    ceiling = F(h.hi)
    margin = 1-(1+excess)*(1-Q/ceiling)
    return dict(record,status='INWARD' if margin>0 else 'UNRESOLVED',escape=e.hex(),
                dk=dk.hex(),beta_s=bs.hex(),beta_p=bp.hex(),j=j.hex(),lam=lam.hex(),
                excess=[x.hex() for x in excesses],margin=str(margin))

def main():
    start = time.monotonic()
    for n,entry in read('pins.json').items():
        assert hashlib.sha256((BASE/n).read_bytes()).hexdigest()==entry['sha256']
    c = m.Context(BASE/'v19.json')
    (lo,hi),h,v,hs = data_for_cell()
    assert list(map(F,read('task86.json')['domain_z_exact'])) == [lo,hi]
    ratio = (m.lit('2.7255')/m.enc(c.T0)).power(m.I(3))
    shifts = [m.I(1),(m.I(0,1)-m.lit('.14175'))*ratio,
              (m.enc(0,F('.03'))-m.lit('.02242')*(1-m.lit('.246738546372')))*ratio,
              m.enc(F('3.04'),F('3.05'))-m.lit('3.046')]
    fit = [[m.lit(x) for x in line.split()] for line in c.sources['fit_swift.dat']['content'].splitlines() if line.strip()]
    rows = [check_slab(c,lo+(hi-lo)*k/SLABS,lo+(hi-lo)*(k+1)/SLABS,h,v,hs,fit,shifts)
            for k in range(SLABS)]
    margins = [F(row['margin']) for row in rows if 'margin' in row]
    passed = all(row['status']!='UNRESOLVED' for row in rows)
    assert time.monotonic()-start < 300
    return {'cell':235,'z_exact':list(map(str,[lo,hi])),'h_face':h.hex(),'H_s':hs.hex(),'q':str(Q),
            'scope':'fixed source-real pair under inherited background and trajectory premises',
            'status':'INWARD_ON_ALL_BRANCHES' if passed else 'INCONCLUSIVE',
            'common_branch_margin':str(Q/F(h.hi)),
            'mixed_margin_min':str(min(margins)) if margins else None,'rows':rows,
            'elapsed_limit_seconds':300,'native_pairs':0,'full_history_integrations':0}
if __name__=='__main__':
    print(json.dumps(main(),indent=2))
