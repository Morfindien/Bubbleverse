# Q052 V89 · Fortegnet gennem cellerne 236–245

## Resultat og præcis afgrænsning

Under det fastholdte fælles B★, de matchede starttilstande ved z = 810 og de arvede kilde- og banepræmisser er den signerede elektronforskel strengt positiv gennem alle ti nye celler. Sammen med V85 og V87 giver det

\[
\Delta X_e(z)>0,\qquad
z\in[6045532743931003/8796093022208,810].
\]

Det nye nedre endepunkt er cirka 687,2975. V89 føjer intervallet fra 761161663339561/1099511627776, cirka 692,2725, ned til dette endepunkt til det tidligere bevis. Cellebetegnelserne er V62's enbaserede indeks. I JSON er posterne 235–244. Resultatet gælder løsningerne af de fastholdte kildeligninger med q = xHeII = 10⁻⁶ henholdsvis q = 0. Det er et betinget matematisk delresultat. Q052 er fortsat ACTIVE/INCONCLUSIVE.

## Præmisser og enheder

Sæt h = h_R, d = h_L − h_R og E = d + q. På den kritiske rand E = 0 gælder h_L = h − q, mens begge armes interne elektronfraktion er h. Den offentlige elektronfraktion følger den interne i dette interval før reionisation. Tiden er u = ln[811/(1+z)], voksende når z falder. En prim angiver differentiation med hensyn til u. h, E, q, z og temperaturforholdet v = T_m/T_R er dimensionsløse. Elektronfraktionerne er antal elektroner pr. hydrogenkerne.

Begge arme har samme H, strålingstemperatur, tæthed, kildekonstanter og fitparametre. H er i s⁻¹, n_H i cm⁻³ og T_R i eV. Fotoionisation, escape, blandingsraten j og Λ er rater i s⁻¹. Ingen fitparameter, grentest eller model er ændret.

Den positive indgangsværdi ved z ≈ 692,2725 importeres fra det accepterede V87-resultat. Temperaturordenen v_L ≥ v_R frem til en mulig første kontakt med E = 0 følger det tidligere sammenligningsargument. For hver ny celle kontrollerer run89.py, at den ligger i den relevante V77-rategruppe, at dens v-boks er indeholdt i gruppens domæne, at rateelasticiteten ligger strengt mellem −1 og 0, og at S/h² < 1. Det giver de genbrugte kanaluligheder

\[
U_R>0,\qquad U_L\le(1-q/h)U_R.
\]

Den arvede temperaturkraft ligger under 0,99. H-boksene er identiske i de to arme. Randens h-boks er fællesmængden af højre arms h-boks og venstre arms h-boks forskudt med q. Dens nedre grænse ligger over q. Temperatur- og fitdomænerne kontrolleres med de fastholdte udadrettede intervalgrænser. V19/V20/V62/V77 indlæses fra de hashkontrollerede filer i pakken.

## Samtidigt gyldige grentests

Den kildefaste selector og dens lighedskonvention er dokumenteret i PROOF_V87.md. For z < 900 i det aktuelle temperaturdomæne er

\[
e(h)=L_{\rm Ly\alpha}H/[n_H(1-h)],\qquad
P(h)=\frac{B}{3e(h)+\Lambda+B},\qquad
B=S_0T_R^{3/2}e^{-E_I/(4T_R)}\alpha_B(T_R).
\]

HMLA vælges ved P < p og SWIFT ved P ≥ p, hvor p = 0,01. Kildens decimaler indhegnes med deres arvede rational-/binærliteral-konvention. Testen anvender rå escape før SWIFT-korrektionen. De lave temperaturgrænser, som kunne udløse Peebles, nås ikke her.

På E = 0 er e_L < e_R og P_L > P_R. Den eneste blandede mulighed er derfor SWIFT i L og HMLA i R. Sæt c = [(1/p−1)B−Λ]/3 > 0. Betingelserne e_L ≤ c < e_R giver for det samme H

\[
\frac{cn_H(1-h)}{L_{\rm Ly\alpha}}<H\le
\frac{cn_H(1-h+q)}{L_{\rm Ly\alpha}}.
\]

Dermed ligger e_R i lukningen af intervallet [c,c(1+q/(1−h))]. Begge ender medtages i beregningen for også at dække ensidige grænsefelter. Denne fælles selectorbetingelse udledes før intervalrelaksationen. Den tillader ikke at vælge de to armes H uafhængigt.

## Primær kontrol af alle 160 delintervaller

Ved fælles gren er C_L ≤ C_R. De positive fælles faktorer og kanalulighederne giver d′/|f_R| ≥ q/h > 0. For et blandet felt er et loft J på begge kanalers relative C-forøgelse tilstrækkeligt til

\[
\frac{d'}{|f_R|}\ge\mu
=1-(1+J)(1-q/h_{\max}).
\]

Et negativt U_L giver allerede et gunstigt bidrag. I den øvrige situation kan den positive øvre grænse multipliceres med C. C_SWIFT(h) er et konservativt loft på C_SWIFT(h−q), fordi det fælles DK er uafhængigt af h og 1+DK > 0.

Hver celle opdeles i 16 sammenhængende, lukkede z-intervaller. På hvert interval kombineres selectorens escape-korridor med den fælles H-boks. Et tomt overlap udelukker det blandede felt. Ellers anvendes den eksakte relative C-identitet fra V87. Med

\[
G=\beta_s+\Lambda+3j,\quad K=G\beta_p+j\beta_s,
\quad D(e)=(\beta_s+\Lambda)(\beta_p+j)+3j\beta_p+Ge,
\]

og N_s(e)=Λ(β_p+j)+(Λ+3j)e, N_p(e)=Λj+Ge er C_i=N_i/D. For e_S=e/(1+DK) fås

\[
\frac{C_i(e_S)}{C_i(e)}-1
=\frac{(e_S-e)\eta_iK}{D(e_S)N_i(e)},\qquad
(\eta_s,\eta_p)=(3j,G).
\]

run89.py genbruger den uændrede V87-funktion check_slab og evaluerer nye boksinput for hver celle. MPFR-backenden omslutter de transcendente funktioner, mens slutmarginerne gemmes som eksakte brøker. Alle 160 intervaller er dækket. I 7 af dem udelukkes det blandede felt. I de resterende 153 er den blandede randmargin positiv. De 7 udelukkelser ligger alle i celle 245. Ingen celle er sprunget over.

## Separat kontrol på hele celler

check89.py har en selvstændig kommandolinjekørsel og bruger hver celle som én hel boks. Den læser ingen af de nye primærresultater og bruger ingen af de 16 delintervaller. Metoden er den alternative V87-kontrol, anvendt på hver celles egne input og den tilsvarende V77-post for DK.

B er voksende med T_R. For den fastholdte PPB-formel er den logaritmiske afledte 1,5−a+E_I/(4T_R)−bY/(1+Y), og a+b < 1,5. Derfor kan temperaturendepunkterne omslutte c. Selectorulighederne projiceres først på det fælles H og derefter tilbage på e_R.

For hver kanal bruges

\[
\frac{d\log C_i}{de}=\frac{\eta_iK}{D(e)N_i(e)}.
\]

Den positive nævner vokser med e. Længden af det største tilladte escape-interval gange et loft på den logaritmiske afledte giver derfor et loft x på log-forholdet. Alle ti kontroller opfylder 0 < x < 1. Uligheden exp(x) ≤ 1/(1−x) giver et rationelt loft på C-forholdet og dermed en separat nedre margin.

Kontrollerne deler kilde, atomtabeller, arvede boksdata og MPFR-primitiver. De adskiller sig i selectorprojektion, opdeling og beregning af C-forholdet. Dette er en separat matematisk kontrol af samme betingede model. Det er ikke uafhængige observationer eller en ny fuld baneintegration.

## Kontroltal

Tabellens tal er afrundede visninger af nedre grænser for den dimensionsløse randstørrelse d′/|f_R| på E = 0. De er ikke nedre grænser for ΔX_e langs banen. De eksakte brøker findes i result.json og control.json.

| V62-celle | Primær margin, cirka | Separat margin, cirka | Blandede felter udelukket af 16 |
| --- | ---: | ---: | ---: |
| 236 | 8,73218355 × 10⁻⁵ | 5,22583204 × 10⁻⁵ | 0 |
| 237 | 8,55437263 × 10⁻⁵ | 5,05967556 × 10⁻⁵ | 0 |
| 238 | 8,38153974 × 10⁻⁵ | 4,90307683 × 10⁻⁵ | 0 |
| 239 | 8,19925827 × 10⁻⁵ | 4,62335349 × 10⁻⁵ | 0 |
| 240 | 8,03581721 × 10⁻⁵ | 4,34384550 × 10⁻⁵ | 0 |
| 241 | 7,87198539 × 10⁻⁵ | 4,17101908 × 10⁻⁵ | 0 |
| 242 | 7,72730870 × 10⁻⁵ | 4,02152920 × 10⁻⁵ | 0 |
| 243 | 7,59104030 × 10⁻⁵ | 3,88448230 × 10⁻⁵ | 0 |
| 244 | 7,46416065 × 10⁻⁵ | 3,76075783 × 10⁻⁵ | 0 |
| 245 | 7,44327453 × 10⁻⁵ | 4,66753651 × 10⁻⁵ | 7 |

Sikre, nedad afrundede fælles udsagn er μ_primær > 7,44 × 10⁻⁵ og μ_separat > 3,76 × 10⁻⁵. Alle ti celler har status PASS i begge beregninger. Det bestemte kildepars faktiske valg af gren inde i de blandede bokse er ikke bestemt af disse tests.

## Sammenføjning, optisk konsekvens og stop

Hver celle begynder præcis ved den foregående celles nedre endepunkt. De eksakte knuder matches til V62 og V88-opgaven. På en mulig første kontakt med E = 0 er E′ = d′. Den strengt positive nedre randmargin gælder alle tilladte grenfelter og deres ensidige grænser. Under de arvede kontinuitetspræmisser udelukker første-kontakt-argumentet i V87, at banen når E = 0. Derfor forlader parret hver celle med E > 0, og argumentet kan gentages gennem hele blokken.

For F(Z)=Δτ_T(0,Z)=∫₀ᶻ w(z)ΔX_e(z) dz, hvor den arvede Thomson-vægt er positiv, følger F′(Z)>0 på det samlede beviste interval. F vokser altså med sin øvre grænse Z fra cirka 687,2975 til 810. Den akkumulerede værdi ved det nedre endepunkt afhænger af historien ved lavere z. Derfor afgør V89 hverken det globale maksimum af |Δτ_T|, dets placering eller den fulde numeriske fejl mellem native output og kildeløsningerne. V83's tidligere betingede globale elektronmaksimum ændres ikke.

Celle 246 begynder ved den nye slutknude og har kun HMLA i begge armes arkiverede maskelister. Denne grænseidentitet er kontrolleret. Ingen fortegnsberegning efter grænsen er udført i V89. Opgavens stopkriterium er opfyldt efter celle 245.

Der er kørt nul nye native simulationspar og nul fulde historieintegrationer. Næste motor er **Resultatindtag og routing 2.3.0**. Den skal indtage blokresultatet, fastholde Q052 som åbent og vurdere en ny, afgrænset fortsættelse med det fælles HMLA-lemma fra celle 246. Den nye opgave er endnu ikke udført.
