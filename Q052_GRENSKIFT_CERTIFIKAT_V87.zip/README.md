# Reproducer V87

Krav: Python 3.10+ og det systembibliotek til MPFR, som den medfølgende V20-backend anvender. Kør uden Python-optimering fra den udpakkede mappe.

    python3 certify87.py > replay.json
    cmp replay.json result.json
    python3 control87.py > replay-control.json
    cmp replay-control.json control.json

PROOF_V87.md indeholder udledningen, afgrænsningen og den optiske konsekvens. Begge scripts har alle deres beregningsinput her. sources.json henviser til den større V86-historik på det verificerede Git-commit og pins.json angiver den præcise placering af de genbrugte input. Samlet journal leveres separat. manifest.json hasher alle medlemmer undtagen sig selv.

De tre nye V87-filer kan lægges i roden af Morfindien/Bubbleverse. Bevar de tidligere versioner. Opdatér den eksisterende Q052-navigation efter kontrol af den aktuelle branch.
