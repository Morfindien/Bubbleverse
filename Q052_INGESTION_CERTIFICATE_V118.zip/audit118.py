from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256, sha1
from fractions import Fraction as F
import json
P=Path(__file__).resolve().parent
U=P.parents[1]/'upload'
def sha(b): return sha256(b).hexdigest()
def read(z,n): return json.loads(z.read(n))
def hx(s): return F(float.fromhex(s))
def fingerprint(x):
    return sha(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
def save(n,x): (P/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
zip117='Q052_Q16_GRENSKIFT_CERTIFIKAT_V117.zip'
zip89='Q052_GRENSKIFT_BLOK_CERTIFIKAT_V89.zip'
task117='Q052_RESULTATINDTAG_OPGAVE_V117.json'
journal117='Q052_MATEMATIK_OG_SAMLET_JOURNAL_V117.md'
prompt='Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0.md'
math='Bubbleverse_Matematikmotor_2.3.0.md'
tree=json.loads((P/'tree.json').read_bytes())
assert tree['truncated'] is False
repo={x['path']:x for x in tree['files']}
def confirm(n,b):
    s=sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    assert s==repo[n]['sha'] and len(b)==repo[n]['size'],n
    return {'git_blob_sha1':s,'sha256':sha(b),'bytes':len(b)}
with ZipFile(U/zip117) as a, ZipFile(P/zip89) as b:
    assert a.testzip() is b.testzip() is None
    ma=read(a,'manifest117.json');mb=read(b,'manifest.json')
    for r in ma['members']:
        raw=a.read(r['path']);assert len(raw)==r['size_bytes'] and sha(raw)==r['sha256']
    for n,h in mb['members_sha256'].items(): assert sha(b.read(n))==h,n
    assert sha((P/zip89).read_bytes())=='b188493c42d442fa3dc74085bc0d37489b678d371bdb9e3809ef845388c0ed3e'
    github={n:confirm(n,(U/n).read_bytes()) for n in [zip117,task117,journal117,'Q052_KORT_RESULTAT_V117.md']}
    github[zip89]=confirm(zip89,(P/zip89).read_bytes())
    github[prompt]=confirm(prompt,(U/'Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0-61.md').read_bytes())
    github[math]=confirm(math,a.read('prompts/'+math))
    t=read(a,task117);fp=t.pop('fingerprint_sha256')
    assert fingerprint(t)==fp and t['current_q']==t['target_q']=='Q052'
    for n in [task117,journal117,'Q052_KORT_RESULTAT_V117.md']:assert a.read(n)==(U/n).read_bytes()
    for n,h in t['input_refs'].items(): assert sha(a.read(n))==h
    j=a.read(journal117);off=ma['parent_prefix_bytes']
    assert sha(j[:off])==ma['parent_journal_sha256'] and j[off:]==a.read('journal_append117.md')
    assert b'V118-Q16-CERTIFICATE-INTAKE' not in j
    p=read(a,'primary117.json');c=read(a,'control117.json');e=read(a,'execution117.json')
    result=read(a,'result117.json');st=read(a,'input/Q052_MATEMATIKOPGAVE_V116.json')
    assert e['technical_state']=='PASS' and e['primary_passes']==e['independent_controls']==1 and e['wall_seconds']<300
    for field in ['code_sha256','output_sha256']:
        for n,h in e[field].items(): assert sha(a.read(n))==h,n
    assert e['task_sha256']==sha(a.read('input/Q052_MATEMATIKOPGAVE_V116.json'))
    for field in ['new_native_pairs','new_optical_evaluations','new_scalar_integrations','new_full_history_integrations','parameter_searches']: assert e[field]==0
    assert p['status']==c['status']=='PASS_CONDITIONAL_CONSTANT_BARRIER'
    for k in ['z_ascending','hR_face_bounds','seed_z','entry_E_lower','constant_b','q']:assert p[k]==c[k]
    lo,hi=map(F,p['z_ascending']);q=F(p['q']);bar=F(p['constant_b'])
    assert F(p['entry_E_lower'])==q/2>bar==q/16 and F(p['seed_z'])==hi
    assert p['source_commit']==t['source_commit']==st['source_commit']
    assert p['background_dependency_id']==st['target']['frozen_background']
    common=(q-2*bar)/F(p['hR_face_bounds'][1]);assert common==F(p['common_branch_normalized_lower'])
    margins=[];excluded=0
    for i,r in enumerate(p['rows']):
        assert list(map(F,r['z']))==[lo+(hi-lo)*i/16,lo+(hi-lo)*(i+1)/16]
        x,y=map(F,r['new_projection'])
        if r['status']=='MIXED_EXCLUDED':
            assert x>y and F(r['strict_exclusion_margin'])>0
            excluded+=1
        else:
            l,h=map(hx,r['old_escape']);assert l<=x<=y<=h
            ms=[1-(1+F(v))*(1-common) for v in r['channel_excess_upper']]
            assert ms==list(map(F,r['channel_normalized_lower'])) and min(ms)==F(r['margin'])>0
            margins+=ms
    assert len(p['rows'])==16 and excluded==11 and len(margins)==10 and min(margins)==F(result['primary_mixed_normalized_lower'])
    assert min(1-(1-common)/(1-F(x)) for x in c['log_ratio_caps'])==F(result['control_mixed_normalized_lower'])>0
    assert read(a,'runtime_check117.json')['version']=='4.2.1' and read(a,'runtime_check117.json')['status']=='PASS'
    assert len(read(a,'symbolic_check117.json')['checks'])==16 and all(x['residual']=='0' for x in read(a,'symbolic_check117.json')['checks'])
    for n in ['v19.json','v20.py','v62.json','v77.json','certify87.py','control87.py']:assert a.read('calc/'+n)==b.read(n)
    v=read(b,'verification.json')
    for replay in v['replays']:assert replay['byte_identical'] and sha(b.read(replay['output']))==replay['sha256']
    assert v['mpfr_version']=='4.2.1' and v['mpfr_built_library_sha256']==sha(a.read('runtime/libmpfr.so.6'))
    va=read(b,'v62.json')['arms'];v77=read(b,'v77.json')
    saved=read(b,'result.json');control=read(b,'control.json')
    assert saved['status']=='ALL_TEN_PASS' and len(saved['cells'])==len(control['separate_checks'])==10
    domain=[];node=lo
    for i,(row,old) in enumerate(zip(saved['cells'],control['separate_checks']),235):
        L,R=[va[arm]['records'][i] for arm in 'LR']
        assert L['z']==R['z'] and L['H_per_s']==R['H_per_s']
        l,h=sorted(map(hx,R['z']))
        assert h==node and [l,h]==list(map(F,row['z_exact']))==list(map(F,old['check']['z']))
        assert i+1==row['cell']==old['cell']
        assert L['allowed_branches']==R['allowed_branches']==['HMLA','SWIFT']
        oldh=max(hx(R['whole_source'][0][0]),hx(L['whole_source'][0][0])+q)
        newh=max(hx(R['whole_source'][0][0]),hx(L['whole_source'][0][0])+q-bar)
        hmax=min(hx(R['whole_source'][0][1]),hx(L['whole_source'][0][1])+q-bar)
        assert hmax==min(hx(R['whole_source'][0][1]),hx(L['whole_source'][0][1])+q)
        assert 0<q<newh<=oldh<hmax<1
        checked=0
        fresh_candidates=[]; exclusions=[]
        h_old_rounded=hx(row['h_face'][0])
        for si,slab in enumerate(row['slabs']):
            assert list(map(F,slab['z']))==[h-(h-l)*(si+1)/16,h-(h-l)*si/16]
            cmin,cmax=map(hx,slab['critical'])
            emin,emax=map(hx,slab['physical_escape'])
            # Scale the historical lower bound at the old rounded h boundary.
            emin*=min(F(1),(1-h_old_rounded)/(1-newh))
            lower=max(cmin,emin)
            upper=min(emax,cmax*(1+(q-bar)/(1-hmax)))
            if lower>upper:
                exclusions.append(si);continue
            if slab['status']!='INWARD':
                fresh_candidates.append(si);continue
            el,eh=map(hx,slab['escape'])
            if el<=lower<=upper<=eh:checked+=1
            else:fresh_candidates.append(si)
        assert checked+len(fresh_candidates)+len(exclusions)==16
        old_common=F(old['check']['common_margin']);assert old_common==q/hmax
        assert len(row['slabs'])==16
        J=max(hx(pair[1]) for slab in row['slabs'] if slab['status']=='INWARD' for pair in slab['excess'])
        primary=1-(1+J)*(1-(q-2*bar)/hmax)
        stress=1-(1-F(old['check']['margin']))/(1-old_common)*(1-(q-2*bar)/hmax)
        jump=next(x for x in v77['mixed_branch_checks'] if x['z']==R['z'])
        assert jump['DK']==old['check']['DK']
        domain.append({'V62_row':i,'historical_cell':i+1,'z_ascending':[str(l),str(h)],
                       'hR_face_bounds':[str(newh),str(hmax)],'old_h_min':str(oldh),
                       'primary_stored_J_screen':str(primary),'old_whole_cell_ratio_stress_screen':str(stress),
                       'candidate_cache_inclusions':checked,'candidate_strict_exclusions':exclusions,'candidate_fresh_slabs':fresh_candidates,'old_mixed_excluded':row['mixed_excluded']})
        node=l
    assert node==F(control['reached_z'])==F('6045532743931003/8796093022208')
    assert all(F(x['primary_stored_J_screen'])>0 for x in domain)
    ledger=read(a,'activity_ledger117.json')
    assert sum(x.get('run_id')==e['run_id'] for x in ledger['entries'])==1
    assert sum(x['run_points'] for x in ledger['entries'])==ledger['total_points_after']==14365
    assert 'Q052-SOME-M014' in ledger['delivered_milestone_ids']
    save('audit118.json',{'status':'PASS','V117_ingested_once':True,'V117_run_id':e['run_id'],'V117_task_fingerprint':fp,
        'V117_exact_primary_margin':result['primary_mixed_normalized_lower'],'V117_exact_control_margin':result['control_mixed_normalized_lower'],
        'V117_scope':'CONDITIONAL_SOURCE_REAL_ROW_234','V117_runtime_receipt':read(a,'runtime_check117.json'),
        'V89_member_sha256':mb['members_sha256'],'V89_manifest_sha256':sha(b.read('manifest.json')),
        'V117_member_sha256':{r['path']:r['sha256'] for r in ma['members']},
        'repository':{'name':'Morfindien/Bubbleverse','branch':'main','commit':tree['commit'],'files':github},
        'next_domain':domain,'screen_scope':'Archived arithmetic only. Primary J needs projection inclusion on each slab. The whole-cell control stress screen reuses an E=0 ratio and is not a changed-face certificate or counterexample.',
        'new_physical_evaluations':0,'next_exit_z':str(node)})
print('PASS',len(domain),sum(F(x['old_whole_cell_ratio_stress_screen'])<=0 for x in domain),'old-control stress flags')
