"""Package the executed theorem and one intake task."""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile
import json

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[1]
OUT=BASE/'output/V121'
OUT.mkdir(parents=True,exist_ok=True)
SHORT='Q052_KORT_RESULTAT_V121.md'
JOURNAL='Q052_MATEMATIK_OG_SAMLET_JOURNAL_V121.md'
NEXT='Q052_RESULTATINDTAG_OPGAVE_V121.json'
ZIP='Q052_Q16_HMLA_CERTIFIKAT_V121.zip'
LIMIT=25_000_000
sha=lambda data: sha256(data).hexdigest()
enc=lambda obj:(json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode()
def read(name):
    return json.loads((ROOT/name).read_bytes())
def save(name,obj):
    (ROOT/name).write_bytes(enc(obj))
def fingerprint(obj):
    return sha(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())

task=read('input/Q052_MATEMATIKOPGAVE_V120.json')
raw=read('raw121.json')
validation=read('validation121.json')
execution=read('execution121.json')
inputs=read('inputs121.json')
assert raw['status']=='ALL_1281_PASS' and validation['status']=='PASS'
prefix=(BASE/'output/V120'/task['journal_ref']).read_bytes()
assert sha(prefix)==inputs['files'][task['journal_ref']]['sha256']
assert execution['run_id']==task['task_id']==raw['run_id']
now=datetime.now(timezone.utc).isoformat()
rid=task['task_id']
claim='LOCAL-Q052-V121-C1'
event='Q052-ACTIVITY-Q16-COMMON-HMLA-V121'
previous_bytes=(ROOT/'input/activity_ledger120.json').read_bytes()
ledger=json.loads(previous_bytes)
assert not any(e.get('run_id')==rid for e in ledger['entries'])
previous_event=ledger['entries'][-1]['activity_event_id']
before=ledger['total_points_after']
parts={'analysis_points':45,'computation_points':35,'search_points':5,'validation_points':35}
points=sum(parts.values())
total=before+points
threshold=ledger['next_publication_at']
basis=('Redaktionelt skøn for den ændrede kontaktflades fulde Saha- og HMLA-argument, '
       '1.281 celleberegninger og en separat 21-gruppers kontrol, '
       'kildeidentitet, sammenføjninger og eksakt efterkontrol. '
       'Arkivforberedelsen i V120, V91-evalueringen, pakning og genlevering giver nul nye point.')
assert before==14600 and total<threshold==15000
ledger['entries'].append({'activity_event_id':event,'run_id':rid,'engine':task['engine'],
    'run_points':points,'breakdown':parts,'basis':basis,'counted_once':True,
    'measured_execution_seconds':execution['wall_seconds']})
ledger.update(previous_ledger_ref=task['input_archive']+'!activity_ledger120.json',
    previous_total_points=before,parent_ledger_sha256=sha(previous_bytes),
    total_points_after=total,cycle_progress=total%1000,next_publication_at=threshold,
    points_to_next_publication=threshold-total,new_milestones=[],pending_packages=[],
    ledger_revision='V121',last_updated_utc=now,scientific_state='INCONCLUSIVE',
    workflow_state='READY_FOR_HANDOFF',point_state='VERIFIED',
    note='V121 changed-face computation counted once. Prior ledger records are retained.')
assert sum(e['run_points'] for e in ledger['entries'])==total
save('activity_ledger121.json',ledger)

result={**raw,'target_q':'Q052','version':'V121','created_utc':now,'claim_id':claim,
    'claim':'E>q/16 on the closed common-HMLA block from the exact V119 exit to z=50, under the frozen shared background and inherited trajectory premises.',
    'joined_conditional_z_ascending':['50','800'],
    'joined_claims':['V111 joined with V107/V97','LOCAL-Q052-V117-C1','LOCAL-Q052-V119-C1',claim],
    'exact_question':task['exact_question'],'source_commit':task['source_commit'],
    'capture_sha256':task['capture_sha256'],'background_dependency_id':task['background_dependency_id'],
    'workflow_state':'READY_FOR_HANDOFF','technical_state':'PASS','scientific_state':'INCONCLUSIVE',
    'local_scientific_state':'SUPPORTED_WITHIN_TESTED_DOMAIN','knowledge_type':['BEREGNET','MODELINFERERET'],
    'inherited_assumptions':['Fixed admitted common Bstar and literal source/configuration.',
        'Matched starts at z=810 and the inherited conditional source-real solution with continuous trajectories and validated boxes.',
        'V119 strict E>b at the exact entry and V77 temperature, rate elasticity and Saha domains.',
        'For the joined [50,800] statement, all prior V111/V117/V119 applicability conditions.'],
    'exit_temperature_order':'vL>=vR by inherited temperature comparison',
    'endpoint_scope':'Phase-5 field arriving at z=50. Phase-6 applicability is unresolved for q/16.',
    'margin_meaning':'Lower bounds for E_prime/abs(f_R) at E=b.',
    'execution_ref':'execution121.json','primary_ref':'primary121.json','control_ref':'control121.json',
    'validation_ref':'validation121.json','proof_ref':'PROOF_V121.md',
    'new_native_pairs':0,'new_optical_evaluations':0,'new_scalar_integrations':0,
    'new_full_history_integrations':0,'run_points':points,'total_points':total,
    'next_milestone':threshold,'points_to_next_publication':threshold-total,'publication_state':'NOT_DUE'}
save('result121.json',result)
files=[SHORT,JOURNAL,NEXT,ZIP]
base=inputs['repository_head']
memory={'repository':'Morfindien/Bubbleverse','branch':'main','verified_base':base,
    'source_freshness':'V119 and engine checked on main. V120 supplied from last local delivery and compared to its verified manifest.',
    'sync_status':'USER_UPLOAD_PENDING','target_paths':'Existing root-file naming convention',
    'upload_new_root_files':files,'parent_V120_pending_files':list(inputs['files']),
    'upload_instructions':'If V120 still is absent, add the four original V120 files first. Add V121 as new root files. Keep original historical files.',
    'proposed_index_updates':{'case':'Q052 ACTIVE / INCONCLUSIVE','journal':JOURNAL,'task':NEXT,'claim':claim,'completed_run':rid,
        'total_points':total,'publication_state':'NOT_DUE'}}
save('github_memory_update121.json',memory)
refs={n:sha((ROOT/n).read_bytes()) for n in ['result121.json','raw121.json','primary121.json','control121.json','execution121.json',
    'validation121.json','PROOF_V121.md','inputs121.json','activity_ledger121.json']}
no_repeat=task['no_repeat']+[
    'V121 fixed-q/16 cellwise proof and separate V77-group control on unchanged phase-5 inputs.',
    'V121 stored-result arithmetic as newly executed field work or a second scientific credit.',
    'No second use of the V111 lower contribution on any overlapping optical piece.',
    'A q/16 phase-6 claim requires an independent applicable phase-6 contract.']
follow={
    'schema_version':'UNVALIDATED_LOCAL_CONTRACT','task_id':'LOCAL-Q052-V122-Q16-PHASE5-INTAKE-OPTICAL-PREPARATION',
    'state':'PREPARED_NOT_EXECUTED','engine':task['return_engine'],'case_id':task['case_id'],
    'current_q':'Q052','target_q':'Q052','continue_same_q':True,'exact_question':task['exact_question'],
    'source_state_version':'V121','evidence_boundary':'Q052 through V121','journal_ref':JOURNAL,
    'input_archive':ZIP,'input_refs':refs,
    'source_commit':task['source_commit'],'capture_sha256':task['capture_sha256'],
    'background_dependency_id':task['background_dependency_id'],
    'result_to_ingest':{k:result[k] for k in ['claim_id','claim','b','exact_z_ascending','joined_conditional_z_ascending','joint_cells','joint_groups',
        'entry_claim','primary_normalized_lower','control_normalized_lower','exit_E_strictly_greater_than','extra_exit_distance_above_b','inherited_assumptions']},
    'objective':'Admit the conditional V121 continuation once and prepare one bounded signed optical lower-bound update from the new certified floor and archived V66 positive weights.',
    'required_actions':[
        'Verify journal prefix, all package hashes, execution limits and zero forbidden counters, two separate receipts, all 1281 exact cell joins, 21 groups and exact z=50. Check proof assumptions and the V119, V117 and V111 joins without re-running source fields.',
        'Admit only the conditional phase-5 result. Preserve the existing V93 phase-6 sign result and V115 method limitation. Q052 native reproducibility, native/source identity and realized error-certified suprema remain open.',
        'Verify the latest applicable archived V111 signed optical state, provenance of the unchanged upper bounds and the V66 weight convention, identities, cached positive bounds and interval coverage.',
        'Prepare one bounded Mathematics contract for an optical lower-bound update on the newly covered interval z in [50,1523417340748759/2199023255552], whose upper endpoint is the start of the already credited V111 strip. Split at existing archive/bin interfaces when needed. Exclude overlaps with already credited support and take the maximum of certified lower bounds on each shared piece, not their sum.',
        'Specify exact rational weighted polynomial masses, directed grid rounding, separate independently coded sum/control, coverage accounting, a measured improvement against the prior certified global width and an explicit stop budget. Preserve older upper bounds and distinguish a stronger lower bound from attainment or a native error bound.',
        'In intake perform only identity, geometry and preparation work. If the archived optical minimum weights or contribution bookkeeping cannot be verified, return the first concrete blocker and a focused input-recovery task instead of a new integral value.',
        'Append the journal and apply the activity ledger once. Preserve M014 delivery and the original exact question.'],
    'acceptance_criteria':'Verified V121 intake and one executable exact optical-update task with pinned weights and explicit nonoverlap checks, or a documented blocker at the first failed mandatory identity/coverage gate.',
    'rejection_criteria':'Invalid source identity, contact proof or optical domain mapping requires a forward correction with the affected historical artifacts preserved.',
    'inconclusive_criteria':'Missing current optical baseline, unverified weights or unclosed one-sided coverage means no strengthened bound may be inferred.',
    'stop_condition':'After one prepared task or one exact blocking condition. Intake performs no optical evaluation, integration or native pair.',
    'expected_output':'V122 intake evidence, append-only journal and one next Mathematics task.',
    'execution_limits':{'new_physical_evaluations':0,'new_native_pairs':0,'new_optical_evaluations':0,'new_integrations':0},
    'no_repeat':no_repeat,'total_points':total,'next_milestone':threshold,'points_to_next_publication':threshold-total,
    'activity_ledger_ref':'activity_ledger121.json','publication_state':'NOT_DUE','max_deliverable_bytes':LIMIT}
follow['fingerprint_sha256']=fingerprint(follow)
(OUT/NEXT).write_bytes(enc(follow))
source={'target_q':'Q052','evidence_boundary':'Q052 through V121','physical_source':{
    'url':'https://github.com/mwt5345/class_ede/blob/'+task['source_commit']+'/external/HyRec2020/hydrogen.c',
    'source_commit':task['source_commit'],'capture_sha256':task['capture_sha256'],
    'background_dependency_id':task['background_dependency_id'],'use':'Pinned archived bytes, hash checked. HMLA field and selector.',
    'file_ref':'input/v91/v19.json'},
    'historical_archive':task['inputs']['input_refs'],'V91_member_sha256':task['inputs']['V91_member_sha256'],
    'claim_map':{claim:['PROOF_V121.md','primary121.json','control121.json','validation121.json'],
        'LOCAL-Q052-V119-C1':['input/input/V119/result119.json']},
    'repository':memory,'external_replication':'NOT_PERFORMED','later_Q_evidence_used':False}
save('source_register121.json',source)
handoff={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','prompt_id':'BUBBLEVERSE.MATHEMATICS','prompt_version':'2.3.0',
    'target_q':'Q052','authorized_q_range':['Q052'],'evidence_boundary':'Q052 through V121','main_question':task['exact_question'],
    'journal_ref':JOURNAL,'journal_version':'V121','journal_completeness':'V120 full bytes plus a new V121 append.',
    'workflow_state':'READY_FOR_HANDOFF','scientific_state':'INCONCLUSIVE','technical_state':'PASS',
    'completed_tests':['Changed q/16 face on 1281 common-HMLA cells','Separate outer-box control on 21 groups','Stored exact receipt audit'],
    'new_information_this_round':result['claim'],'blocker_id':'LOCAL-Q052-OPTICAL-PRECISION-AND-NATIVE-ERROR',
    'blocker_description':'Archived optical bounds require a quantitative update. Native/source error and reproducibility are material closure obligations.',
    'next_engine':follow['engine'],'next_task':NEXT,'input_refs':refs,'source_refs':['source_register121.json'],
    'claim_refs':[claim,raw['entry_claim']],'equations':'E=hL+q-hR, b=q/16, D=(q-2b)h+b(q-b); proof in PROOF_V121.md.',
    'parameters':{'q':raw['q'],'b':raw['b'],'z_ascending':raw['exact_z_ascending']},
    'units':'E, h, b, q, z and normalized margins dimensionless, H and escape in s^-1, nH in cm^-3, TR in eV.',
    'uncertainty':'Conditional on fixed admitted background and archived bounding hypotheses. No quantified exit clearance or realized native error.',
    'acceptance_criteria':follow['acceptance_criteria'],'rejection_criteria':follow['rejection_criteria'],
    'inconclusive_criteria':follow['inconclusive_criteria'],'expected_output_artifact':follow['expected_output'],
    'no_repeat_constraints':no_repeat,'resume_condition':'Ingest the two V121 methods and pin V66/V111 for the next optical task.',
    'run_manifest_ref':'manifest121.json','setup_assessment':{
        'current':'Python standard library and exact Fraction arithmetic in separate processes, plus GitHub read and local archive audit.',
        'recommended':'Same archive and exact arithmetic capability for intake. Its next task requires V66/V111 bytes.',
        'reasoning_level':'Not independently measured.','fallback':'Use packaged frozen inputs and pinned local snapshots.',
        'upgrade_trigger':'An identified unverified numerical premise or native proof obligation.'},
    'publication_interval':1000,'run_points':points,'total_points':total,'cycle_progress':total%1000,
    'next_milestone':threshold,'points_to_next_publication':threshold-total,'new_milestones':[],
    'run_id':rid,'previous_points_entry':previous_event,'points_breakdown':parts,'points_basis':basis,
    'points_state':'VERIFIED','publication_state':'NOT_DUE','pending_packages':[],
    'delivered_milestone_ids':ledger['delivered_milestone_ids'],'delivery_files':files,
    'github_memory_update':memory,'github_read_state':'V119_BASE_AND_ENGINE_VERIFIED','github_write_state':'USER_UPLOAD_PENDING'}
save('handoff121.json',handoff)

short=f"""# Bubbleverse — Overlevering V121

**Den betingede q/16-grænse holder nu helt ned til z=50.**

På det nye lukkede interval fra z≈687,2975 til z=50 gælder
E=h_L+q−h_R>q/16=6,25×10⁻⁸ under de fastlåste kilde-, baggrunds-,
start- og baneforudsætninger. Begge metoder bestod for alle 1.281
celler. Sammen med de tidligere certifikater giver det samme
nedre grænse på hele [50,800] under deres fælles forudsætninger.

| Kontrol | V121-resultat |
|---|---:|
| Primære HMLA-celler | 1.281 af 1.281 |
| Separate rategrupper | 21 af 21 |
| Mindste margin E′/|f_R| på kontaktfladen i begge metoder | >0,00036942431 |
| Samlet beregningstid | {execution['wall_seconds']:.2f} sekunder |
| Nye native par, optiske evalueringer og historieintegrationer | 0 |

Q052 forbliver åbent. De faktiske CLASS/P6-forløb og deres samlede
numeriske fejl skal stadig certificeres. Den næste forskningsmulighed
er at omsætte det nye positive gulv til en strengere nedre optisk
grænse ved hjælp af arkiverede vægte. Fase 6 kræver sin egen
kontrol, hvis q/16-grænsen skal føres under z=50.

**Næste motor** Resultatindtag og routing 2.3.0. Opgaven ligger i
`{NEXT}`. Bevis, rå beregningsfiler, efterkontrol, kilder og
GitHub-opdateringsforslag ligger i ZIP-filen. Den samlede journal
bevarer V120 som byteidentisk præfiks.

**Point** {points} for runden, 14.720 i alt og {threshold-total} til
næste SoMe-pakke. Tidligere milepæl M014 er registreret som leveret.

STATUS FORTSÆTTER · WORKFLOW READY_FOR_HANDOFF · TECHNICAL PASS ·
SCIENTIFIC INCONCLUSIVE · TARGET_Q Q052 · Matematikmotor 2.3.0.
""".replace('E′/|f_R|','E′/&#124;f_R&#124;').replace(f"{execution['wall_seconds']:.2f} sekunder",f"{execution['wall_seconds']:.2f}".replace('.',',')+' sekunder')
(OUT/SHORT).write_text(short)
append=f"""

---

# Q052 V121 — q/16-grænsen når fasegrænsen z=50

Dato UTC {now}. Run `{rid}`. Claim `{claim}`.
BUBBLEVERSE.MATHEMATICS 2.3.0. Evidensgrænse Q052 til og med V121.
WORKFLOW READY_FOR_HANDOFF · TECHNICAL PASS · SCIENTIFIC INCONCLUSIVE.

## Oprindeligt spørgsmål

{task['exact_question']}

## Dokumenteret delresultat

På det frosne fælles B★, med matchede z810-starter og de arvede
kilde- og baneforudsætninger, er E=h_L+q−h_R>1/16000000 på det
lukkede interval [50, {raw['exact_z_ascending'][1]}].
Indgangen er den strenge V119-grænse. Der er 1.281 godkendte HMLA-celler
og 21 grupper. Sammenføjet med V117, V119 og V111's stærkere
grænse på det tidligere interval gælder E>q/16 på [50,800] under
de fælles forudsætninger. Den nyest certificerede udgang z=50
inkluderes med det indkommende fase-5-felt. V121 giver ingen
kvantificeret ekstra afstand over q/16 ved slutknuden.

Cellevis primær minimumsmargin på E′/|f_R| er
`{raw['primary_normalized_lower']}`. Separat gruppeminimum er
`{raw['control_normalized_lower']}`. Begge er >0,00036942431.
Fuld Saha-sammenligning og positiv voksende HMLA-koefficient giver
indadrettet fortegn på hver kontaktflade. Primærmetoden bruger
ændrede celleintersektioner. Den separate kontrol bruger ydre
h/v-gruppebokse og heltalsdekodede hex-tal. Begge verificerer
baggrund, grenmasker, rateforudsætninger og eksakte sammenføjninger.

Der er én primær gennemgang og én separat kontrol. 42 subprocesser
bestod. Kørsel {execution['wall_seconds']:.9f} sekunder under
300-sekundersgrænsen. Ingen native par, optiske beregninger,
integrationskørsler eller fase-6-celler. Den gemte efterkontrol
genbruger receipts og kører hverken hovedmetoden eller den separate
kontrol igen. Se `PROOF_V121.md` og `validation121.json`.

## Provenance og næste opgave

Fysikkilden er {task['source_commit']}. Capture SHA-256
`{task['capture_sha256']}`. Fælles baggrund `{task['background_dependency_id']}`.
V120 og V91's manifestmedlemmer, V119-journalpræfiks, motorkilde,
input- og kodeidentiteter er kontrolleret. GitHub-main ved `{base}`
indeholder V119-grundlaget og motoren. V120 blev læst fra den
verificerede lokale levering. Filerne er klar til manuel upload.

Næste motor er `{follow['engine']}`. Dens kontrakt `{NEXT}`
indlæser det nye resultat og forbereder én afgrænset optisk opgave
på [50,1523417340748759/2199023255552] efter vægt- og baselinekontrol.
Det er intervallet op til begyndelsen af den allerede krediterede
V111-strimmel. Den næste opgave skal undgå optisk dobbeltregning,
bevare validerede øvre grænser og måle den faktiske
breddeforbedring. Ingen ny optisk talværdi er fremlagt i V121.
Native historik, realiserede suprema og samlet fejlcertifikat er
fortsat særskilte afslutningskrav. CONTINUE_SAME_Q=true.

## Pointpost

POINTS_EVENT RESEARCH_RUN · EVENT_ID `{event}`.
Forrige event `{previous_event}`. Analyse 45, beregning 35,
kildesporing 5 og validering 35. RUN POINTS {points}. TOTAL {total}.
Næste SoMe-tærskel {threshold}, med {threshold-total} point tilbage.
POINTS_STATE VERIFIED. PUBLICATION_STATE NOT_DUE.
Ingen nye milepæle. M001–M014 står som leveret i ledgeren.

{basis}
"""
(OUT/JOURNAL).write_bytes(prefix+append.encode())
(ROOT/'journal_append121.md').write_text(append)
(ROOT/'LAES_MIG_V121.txt').write_text(f"""Q052 V121 — {SHORT}

Beviset står i PROOF_V121.md. De to gennemgange står i primary121.json
og control121.json. Input, kontrolkode, resultat, handoff og ledger følger
med. Det historiske V120-arkiv er bevaret uændret under history/.

Kontrollér lagrede kvitteringer efter udpakning med python3 validate121.py.
Dette er en regne- og hashkontrol af de gemte resultater. Den udfører
ingen ny kørsel af de to metoder. En eventuel særskilt metodereproduktion
kan køres med python3 run121.py i en ny kopi uden run121.lock. Det er
en ekstra kørsel og blev ikke udført i denne runde.

Næste motor bruger {NEXT} sammen med ZIP-filen og {JOURNAL}.
Alle filer er under 25.000.000 byte. GitHub-vejledning følger i
github_memory_update121.json.
""")

names=['prepare121.py','run121.py','validate121.py','build121.py','inputs121.json','repository121.json','PROOF_V121.md',
    'freeze121.json','checkpoint121.json','execution121.json','raw121.json','primary121.json','control121.json',
    'validation121.json','result121.json','source_register121.json','activity_ledger121.json','handoff121.json',
    'github_memory_update121.json','journal_append121.md','LAES_MIG_V121.txt','run121.lock']
members={n:(ROOT/n).read_bytes() for n in names}
members.update({n:(OUT/n).read_bytes() for n in [SHORT,JOURNAL,NEXT]})
for folder in ['calc','input']:
    for path in (ROOT/folder).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            members[str(path.relative_to(ROOT))]=path.read_bytes()
prior_archive=(BASE/'output/V120'/task['input_archive']).read_bytes()
assert sha(prior_archive)==inputs['files'][task['input_archive']]['sha256']
members['history/'+task['input_archive']]=prior_archive
manifest={'target_q':'Q052','version':'V121','run_id':rid,'created_utc':now,
    'parent_journal_sha256':sha(prefix),'parent_prefix_bytes':len(prefix),'append_sha256':sha(append.encode()),
    'next_task_fingerprint':follow['fingerprint_sha256'],'max_deliverable_bytes':LIMIT,'github_memory_update':memory,
    'self_hash_convention':'Manifest is excluded from its own member list.',
    'members':[{'path':n,'size_bytes':len(data),'sha256':sha(data)} for n,data in sorted(members.items())]}
members['manifest121.json']=enc(manifest)
with ZipFile(OUT/ZIP,'w',ZIP_DEFLATED,compresslevel=6) as z:
    for n,data in members.items():
        z.writestr(n,data)
with ZipFile(OUT/ZIP) as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for n,data in members.items():
        assert data==z.read(n) and len(data)<LIMIT
        if n.endswith('.json'):
            json.loads(data)
    for n,h in refs.items():
        assert sha(z.read(n))==h,n
    for n,h in (execution['code_sha256_after']|execution['output_sha256']).items():
        assert sha(z.read(n))==h
    assert z.read(JOURNAL)==prefix+append.encode()
    verify_next=json.loads(z.read(NEXT))
    expected=verify_next.pop('fingerprint_sha256')
    assert fingerprint(verify_next)==expected
    assert verify_next['engine']==handoff['next_engine'] and verify_next['target_q']=='Q052'
delivery=[]
for n in [ZIP,SHORT,JOURNAL,NEXT]:
    data=(OUT/n).read_bytes()
    assert 0<len(data)<LIMIT
    delivery.append({'name':n,'size_bytes':len(data),'sha256':sha(data)})
save('delivery121.json',{'status':'PASS','files':delivery,'journal_prefix':'BYTE_IDENTICAL','zip_crc':'PASS',
    'local_contract':'Q, engine, fingerprint, paths, evidence refs, statuses and hash identities verified.'})
save('upload121.json',{'uploads':[{'local_path':str(OUT/r['name']),'purpose':'create_library_file',
    'library_artifact_type':'report' if r['name'].endswith('.md') else 'other'} for r in delivery]})
print(json.dumps(delivery,indent=2))
