"""Validate stored provenance, coverage and exact margins without re-running the methods."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parent
def read(name):
    return json.loads((ROOT/name).read_bytes())
def sha(name):
    return sha256((ROOT/name).read_bytes()).hexdigest()

run=read('execution121.json')
frozen=read('freeze121.json')
raw=read('raw121.json')
task=read('input/Q052_MATEMATIKOPGAVE_V120.json')
seed=read('input/input/V119/result119.json')
target=task['target']
assert run['run_id']==raw['run_id']==task['task_id']
assert run['task_sha256']==sha('input/Q052_MATEMATIKOPGAVE_V120.json')
assert run['input_check_sha256']==sha('inputs121.json')
assert frozen['code_sha256_before']==run['code_sha256_before']==run['code_sha256_after']
assert all(sha(n)==h for n,h in (run['code_sha256_after']|run['output_sha256']).items())
assert 0<run['wall_seconds']<run['limits']['wall_seconds_combined']==300
assert run['primary_passes']==run['separate_control_passes']==1
assert all(run[k]==0 for k in ['parameter_searches','new_native_pairs','new_optical_evaluations','new_scalar_integrations','new_full_history_integrations','phase6_cells'])
assert run['result_state']==raw['status']=='ALL_1281_PASS' and raw['obstruction'] is None
q,b=F(raw['q']),F(raw['b'])
assert b==q/16
primary=read('primary121.json')['groups']
control=read('control121.json')['groups']
assert len(primary)==len(control)==raw['joint_groups']==21
assert all(x['exit_code']==0 for x in run['attempts'])
assert [(a['role'],a['args']) for a in run['attempts']]==[
    pair for p in primary for pair in [('primary',[p['group']]),('control',[p['group'],len(p['records'])])]]
current=F(target['entry']['z'])
assert current==F(seed['exit_z']) and F(seed['exit_E_strictly_greater_than'])==b
assert raw['entry_claim']==seed['claim_id']
expected_cell=246
primary_margin=[]
control_margin=[]
saha_upper=[]
for group_index,(p,c) in enumerate(zip(primary,control,strict=True),3):
    assert p['group']==c['group']==group_index
    assert p['start_z']==c['start_z']==str(current) and p['obstruction'] is None
    assert p['chain_entry']==c['chain_entry']==seed['exit_z']
    assert p['group_premises']['matched_start']==c['matched_start']
    assert p['group_premises']['h_floor']==c['original_h_floor']
    assert p['group_premises']['v_floor']==c['original_v_floor']
    assert p['b']==c['b']==str(b)
    lower,upper=map(F,c['h_outer'])
    margin=(q-2*b)/upper
    assert 0<margin==F(c['normalized_lower'])
    assert F(c['kappa_lower'])==1-(q-2*b)/lower-b*(q-b)/lower**2>0
    assert c['status']=='PASS'
    control_margin.append((margin,group_index))
    saha_upper.append(F(p['group_premises']['Saha_h_floor_squared_upper']))
    for r,s in zip(p['records'],c['records'],strict=True):
        assert r['cell']==s['cell']==expected_cell and r['z_ascending']==s['z_ascending']
        zlo,zhi=map(F,r['z_ascending'])
        assert zlo<zhi==current
        assert r['status']=='INWARD'
        hmin,hmax=map(F,r['h_face'])
        assert q<lower<=hmin<=hmax<=upper<1
        assert 0<F(r['kappa_lower'])==1-(q-2*b)/hmin-b*(q-b)/hmin**2<1
        assert 0<F(r['normalized_lower'])==(q-2*b)/hmax
        assert F(r['normalized_lower'])>=margin
        primary_margin.append((F(r['normalized_lower']),expected_cell))
        expected_cell+=1
        current=zlo
    assert p['reached_z']==c['reached_z']==str(current)
assert str(current)==raw['exact_z_ascending'][0]==run['exit_z']=='50'
assert expected_cell==1527 and len(primary_margin)==raw['closed_faces']==raw['joint_cells']==1281
assert raw['empty_faces']==0 and raw['cells_one_based']==[246,1526]
pm,p_cell=min(primary_margin)
cm,c_group=min(control_margin)
assert pm==F(raw['primary_normalized_lower']) and cm==F(raw['control_normalized_lower'])
assert min(pm,cm)>F('0.00036942431')
receipt={'status':'PASS','scope':'Stored claims, joins, exact arithmetic and hash validation. Neither subprocess method rerun.',
    'exact_z_ascending':raw['exact_z_ascending'],'cells':1281,'groups':21,'successful_subprocesses':42,
    'minimum_primary_cell':p_cell,'minimum_control_group_zero_based':c_group,
    'primary_normalized_lower':str(pm),'control_normalized_lower':str(cm),'max_group_Saha_bound':str(max(saha_upper)),
    'normalized_margin_decimal_lower':'0.00036942431','new_field_evaluations_in_validation':0}
(ROOT/'validation121.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
