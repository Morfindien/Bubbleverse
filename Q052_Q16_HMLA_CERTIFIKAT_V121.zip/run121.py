"""Execute one interleaved primary/control pass with a shared wall-clock limit."""
from datetime import datetime, timezone
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from time import monotonic
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
TASK = ROOT/'input/Q052_MATEMATIKOPGAVE_V120.json'
task = json.loads(TASK.read_bytes())
target = task['target']
limits = task['execution_limits']
def now():
    return datetime.now(timezone.utc).isoformat()
def digest(path):
    return sha256(path.read_bytes()).hexdigest()
def save(name,obj):
    (ROOT/name).write_text(json.dumps(obj,indent=2)+'\n')
def require(check,reason):
    if not check:
        raise ValueError(reason)

with (ROOT/'run121.lock').open('x') as lock:
    lock.write(now()+'\n')
code = ['run121.py','calc/inputs121.py','calc/primary121.py','calc/control121.py']
frozen = {p:digest(ROOT/p) for p in code}
metadata={'run_id':task['task_id'],'started_utc':now(),'code_sha256_before':frozen,
          'task_sha256':digest(TASK),'input_check_sha256':digest(ROOT/'inputs121.json'),
          'exact_rational_arithmetic':'Python Fraction, endpoints represented exactly',
          'limits':limits,'attempts':[],'primary_passes':1,'separate_control_passes':1,
          'parameter_searches':0,'new_native_pairs':0,'new_optical_evaluations':0,
          'new_scalar_integrations':0,'new_full_history_integrations':0,'phase6_cells':0}
save('freeze121.json',metadata)
start = monotonic()
entry = target['entry']['z']
current = entry
number = target['historical_cells_one_based'][0]
primary_groups = []
control_groups = []
promoted = []
stop = None

def run_role(role, *args):
    command = [sys.executable, str(ROOT/f'calc/{role}121.py'),*map(str,args)]
    remaining = limits['wall_seconds_combined']-(monotonic()-start)
    require(remaining>0, 'combined timer exhausted before subprocess')
    tick=monotonic()
    attempt={'role':role,'args':list(args)}
    metadata['attempts'].append(attempt)
    try:
        p=subprocess.run(command, cwd=ROOT,capture_output=True,text=True,timeout=remaining)
    except subprocess.TimeoutExpired:
        attempt.update(wall_seconds=monotonic()-tick,status='TIMEOUT')
        raise
    attempt.update(wall_seconds=monotonic()-tick,exit_code=p.returncode,status='PASS' if p.returncode==0 else 'FAIL')
    if p.returncode:
        attempt['stderr']=p.stderr
        raise ValueError(f'{role} {args}: {p.stderr.strip().splitlines()[-1]}')
    return json.loads(p.stdout)

try:
    for group in range(target['V77_groups_zero_based'][0],target['V77_groups_zero_based'][1]+1):
        pr=run_role('primary',group)
        primary_groups.append(pr)
        rows=pr['records']
        if not rows:
            stop=pr['obstruction'] or {'reason':'PRIMARY_EMPTY_PREFIX'}
            break
        co=run_role('control',group,len(rows))
        control_groups.append(co)
        for key in ['group','chain_entry','b','start_z','reached_z']:
            require(pr[key]==co[key],f'{group} mismatched {key}')
        require(pr['start_z']==current and pr['chain_entry']==entry and pr['b']==target['constant_b'],'group join')
        require(co['status']=='PASS' and F(co['normalized_lower'])>0,'group control positivity')
        require(co['records']==[{'cell':r['cell'],'z_ascending':r['z_ascending']} for r in rows],'cell coverage agreement')
        require([r['cell'] for r in rows]==list(range(number,number+len(rows))),'prefix cell sequence')
        for row in rows:
            passed_sign=row['status']=='INWARD' and F(row['normalized_lower'])>0
            excluded=row['status']=='EMPTY_FACE' and F(row['exclusion_gap'])>0
            require(passed_sign or excluded,'primary field sign')
        promoted.extend(rows)
        current=pr['reached_z']
        number+=len(rows)
        save('checkpoint121.json',{'entry_z':entry,'exit_z':current,'joint_cells':len(promoted),'last_group':group})
        if pr['obstruction']:
            stop=pr['obstruction']
            break
except (ValueError, subprocess.TimeoutExpired, KeyError, IndexError) as exc:
    stop={'next_unpromoted_cell':number,'reason':str(exc) or type(exc).__name__}

pmin=min((F(r['normalized_lower']) for r in promoted if r['status']=='INWARD'),default=None)
cmin=min((F(g['normalized_lower']) for g in control_groups if g['records'][-1]['cell']<number),default=None)
full=(stop is None and len(promoted)==target['cell_count'] and current==target['phase_boundary'])
if not full and stop is None:
    stop={'next_unpromoted_cell':number,'reason':'Incomplete exact coverage'}
state='ALL_1281_PASS' if full else 'PARTIAL_PREFIX' if promoted else 'BLOCKED_AT_ENTRY'
save('primary121.json',{'groups':primary_groups,'method':'cellespecifik h-intersektion','attempted_cells':sum(len(g['records'])+bool(g['obstruction']) for g in primary_groups)})
save('control121.json',{'groups':control_groups,'method':'ydre gruppebokse, heltalsdekodet hex','completed_cells':sum(len(g['records']) for g in control_groups)})
save('raw121.json',{'status':state,'run_id':task['task_id'],'exact_z_ascending':[current,entry],
    'entry_claim':target['entry']['claim'],'q':target['q'],'b':target['constant_b'],
    'cells_one_based':[promoted[0]['cell'],promoted[-1]['cell']] if promoted else [],
    'joint_cells':len(promoted),'closed_faces':sum(r['status']=='INWARD' for r in promoted),
    'empty_faces':sum(r['status']=='EMPTY_FACE' for r in promoted),
    'joint_groups':sum(g['records'][-1]['cell']<number for g in control_groups),
    'primary_normalized_lower':str(pmin) if pmin is not None else None,
    'control_normalized_lower':str(cmin) if cmin is not None else None,
    'exit_E_strictly_greater_than':target['constant_b'] if promoted else None,
    'extra_exit_distance_above_b':'NOT_QUANTIFIED','obstruction':stop})
metadata.update(ended_utc=now(), wall_seconds=monotonic()-start, exit_z=current,
    result_state=state, code_sha256_after={p:digest(ROOT/p) for p in code},
    output_sha256={n:digest(ROOT/n) for n in ['primary121.json','control121.json','raw121.json']})
require(metadata['code_sha256_before']==metadata['code_sha256_after'],'frozen code changed')
save('execution121.json',metadata)
print(state,current,len(promoted),metadata['wall_seconds'],str(pmin),str(cmin))
