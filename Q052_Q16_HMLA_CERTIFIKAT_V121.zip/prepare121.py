"""Bind exact input bytes before starting the changed-face computation."""
from hashlib import sha1, sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
import json

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parents[1]
V120 = BASE / 'output/V120'
UPLOAD = BASE / 'upload'
TASK = 'Q052_MATEMATIKOPGAVE_V120.json'
PACK = 'Q052_INGESTION_CERTIFICATE_V120.zip'
ENGINE = 'Bubbleverse_Matematikmotor_2.3.0.md'
JOURNAL = 'Q052_INGESTION_OG_SAMLET_JOURNAL_V120.md'

def digest(raw):
    return sha256(raw).hexdigest()

def require(condition, message):
    if not condition:
        raise ValueError(message)

def unpack(destination, raw):
    path = ROOT / destination
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)

task = json.loads((V120 / TASK).read_bytes())
expected = task['fingerprint_sha256']
unsigned = {k: v for k, v in task.items() if k != 'fingerprint_sha256'}
canonical = json.dumps(unsigned, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
require(digest(canonical) == expected, 'V120 task fingerprint')
require(task['current_q'] == task['target_q'] == 'Q052', 'Q identity')

repo = json.loads((ROOT / 'repository121.json').read_bytes())
require(not repo['truncated'], 'repository tree complete')
paths = {row['path']:row for row in repo['files']}
engine = (UPLOAD / ENGINE.replace('.md', '-50.md')).read_bytes()
require(digest(engine) == task['engine_prompt_sha256'], 'engine SHA-256')
engine_blob = sha1(b'blob '+str(len(engine)).encode()+b'\0'+engine).hexdigest()
require(paths[ENGINE]['sha'] == engine_blob, 'engine Git identity')
identity = {}
for name in [TASK, PACK, JOURNAL, 'Q052_KORT_RESULTAT_V120.md']:
    raw = (V120 / name).read_bytes()
    blob = sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    if name in paths:
        require((blob,len(raw)) == (paths[name]['sha'],paths[name]['size']), f'{name} repository identity')
    identity[name] = {'sha256':digest(raw),'git_blob':blob,'size_bytes':len(raw),
                      'status':'REPOSITORY_MATCH' if name in paths else 'LOCAL_V120_DELIVERY_VERIFIED'}

with ZipFile(V120 / PACK) as z:
    require(z.testzip() is None, 'V120 ZIP checksum')
    m = json.loads(z.read('manifest120.json'))
    require(m['task_fingerprint'] == expected, 'manifest task fingerprint')
    require(len(z.namelist()) == len(set(z.namelist())), 'unique ZIP names')
    require(set(z.namelist()) == {a['path'] for a in m['members']} | {'manifest120.json'}, 'manifest coverage')
    for row in m['members']:
        raw = z.read(row['path'])
        require(digest(raw) == row['sha256'] and len(raw) == row['size_bytes'], row['path'])
    for name in [TASK,JOURNAL,'Q052_KORT_RESULTAT_V120.md']:
        require(z.read(name) == (V120 / name).read_bytes(), name)
    journal = z.read(JOURNAL)
    prefix = journal[:m['parent_prefix_bytes']]
    require(digest(prefix) == m['parent_journal_sha256'], 'V119 prefix hash')
    require(journal[m['parent_prefix_bytes']:] == z.read('journal_append120.md'), 'V120 appendix')
    v119 = task['inputs']['V119_full_archive']
    v119_path = UPLOAD / v119['path']
    raw119 = v119_path.read_bytes()
    require(digest(raw119) == v119['sha256'], 'V119 archive identity')
    with ZipFile(BytesIO(raw119)) as prior:
        require(prefix == prior.read('Q052_MATEMATIK_OG_SAMLET_JOURNAL_V119.md'), 'V119 journal byte prefix')
    for name, h in task['inputs']['input_refs'].items():
        raw = z.read(name)
        require(digest(raw) == h, name)
        unpack('input/'+name,raw)
    with ZipFile(BytesIO(z.read('history/Q052_HMLA_FORTEGNSCERTIFIKAT_V91.zip'))) as v91:
        require(v91.testzip() is None, 'V91 ZIP checksum')
        members = json.loads(v91.read('manifest.json'))['members_sha256']
        require(set(v91.namelist()) == set(members) | {'manifest.json'}, 'V91 manifest coverage')
        for name,h in members.items():
            require(digest(v91.read(name)) == h, name)
        for name,h in task['inputs']['V91_member_sha256'].items():
            raw = v91.read(name)
            require(digest(raw)==h, name)
            unpack('input/v91/'+name, raw)
        unpack('input/v91/manifest.json',v91.read('manifest.json'))
    unpack('input/manifest120.json', z.read('manifest120.json'))
    unpack('input/'+TASK,z.read(TASK))
ledger = json.loads((ROOT/'input/activity_ledger120.json').read_bytes())
require(sum(e['run_points'] for e in ledger['entries']) == 14600 == ledger['total_points_after'], 'point sum')
require(not any(e.get('run_id') == task['task_id'] for e in ledger['entries']), 'prior run')
require('Q052-SOME-M014' in ledger['delivered_milestone_ids'] and not ledger['pending_packages'], 'milestones')
receipt = {'status':'PASS','task_fingerprint':expected,'files':identity,'V120_manifest_members':len(m['members']),
           'V91_manifest_members':len(members),'journal_prefix':'BYTE_IDENTICAL','engine_sha256':digest(engine),
           'engine_git_blob':engine_blob,'repository_head':repo['head'],'physical_evaluations':0}
(ROOT/'inputs121.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
