"""Input loading shared by the two separate exact-arithmetic methods."""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / 'input'
TASK = 'Q052_MATEMATIKOPGAVE_V120.json'

def require(condition, message):
    if not condition:
        raise ValueError(message)

def read(path):
    return json.loads(path.read_bytes())

def sha(raw):
    return sha256(raw).hexdigest()

def load_inputs(parse_hex):
    task = read(INPUT / TASK)
    archive = INPUT / 'v91'
    for name,h in task['inputs']['V91_member_sha256'].items():
        require(sha((archive/name).read_bytes()) == h, f'V91 hash {name}')
    seed_name = 'input/V119/result119.json'
    seed = read(INPUT / seed_name)
    require(sha((INPUT/seed_name).read_bytes()) == task['inputs']['input_refs'][seed_name], 'entry digest')
    target = task['target']
    q,b = F(target['q']),F(target['constant_b'])
    require(q == F(1,10**6) and b == q/16, 'frozen barrier')
    require(seed['claim_id'] == target['entry']['claim'] and seed['exit_z'] == target['entry']['z'] == target['z_ascending'][1], 'entry geometry')
    require(seed['local_result']=='PASS_CONDITIONAL_CONSTANT_Q16_TEN_CELL_CONTINUATION'
            and F(seed['exit_E_strictly_greater_than'])==b
            and seed['extra_exit_distance_above_b']=='NOT_QUANTIFIED', 'strict entry')
    require(task['current_q']==task['target_q']==seed['target_q']=='Q052'
            and seed['exact_question']==task['exact_question'], 'Q052 identity')
    for key in ['capture_sha256','source_commit','background_dependency_id']:
        require(seed[key]==task[key], key)
    original = read(archive/'v19.json')['original_members']
    for name,entry in original.items():
        require(sha(entry['content'].encode())==entry['sha256'], f'V19 member {name}')
    source = json.loads(original['Q052_BACKGROUND_TRANSFER_INPUTS_V18.json']['content'])
    parent = source['parent_v17_inputs']
    context = parent['native_first_cell_context']
    require(context['target_q']=='Q052' and context['frozen']['z_event']=='810'
            and context['frozen']['physics_commit']==task['source_commit'], 'source context')
    old_result = parent['parent_result']
    entries = old_result['validator_inputs_original']['files']
    for name,entry in entries.items():
        require(sha(entry['content'].encode())==entry['sha256'], f'captured member {name}')
    capture_entry = entries['q048_prefix_config_v1.json']
    require(capture_entry['sha256']==task['capture_sha256'], 'capture identity')
    capture = json.loads(capture_entry['content'])['cases']['hillipop-ede_n3']
    binding = json.loads(entries['Q050_CLEAN_BG_BINDING_V1.json']['content'])
    require([F(row['q']) for row in binding['q_branches']]==[q,F(0)], 'q arms')
    require(all(row['background_dependency_id']==task['background_dependency_id'] for row in binding['q_branches']), 'common background')
    qualification = old_result['receipt']['qualification']
    require(qualification['conditional_binding_receipt']=='PASS_REUSED'
            and qualification['retained_guard_final_receipt']=='PASS_REUSED'
            and qualification['accepted_z810_checkpoint']=='HASH_AND_GLUE_VERIFIED', 'conditional adoption')
    flags = capture['background']
    require(flags['thermal_flags']=={'has_varconst':0,'has_exotic_injection':0,
            'has_idm_b':0,'has_idm_g':0,'has_idm_dr':0,'recombination':1}
            and flags['flags']['has_idm']==flags['flags']['has_idr']==0, 'thermal flags')
    reio = F(capture['frozen_reionization']['fixed_reio_start_exact'])
    require(reio < F(target['phase_boundary']) == 50, 'public electron mapping')
    constants = capture['thermal_starts'][0]['constants']
    t0 = parse_hex(constants['Tcmb'])
    require(min(t0,parse_hex(constants['nH0_SI']),parse_hex(constants['fHe_CLASS']))>0, 'positive background')
    starts = {}
    for key, arm in context['arms'].items():
        first = arm['first_z810_rhs_record']
        rep = arm['first_cell_exact_representation']
        idx = first['indices']
        h = parse_hex(first['y'][idx['x_H']])
        dt = parse_hex(first['y'][idx['D_Tmat']])
        require(rep['phase']==5 and F(rep['h_bernstein'][0])==h and F(rep['D_bernstein'][0])==dt, 'captured phase-5 start')
        starts[key] = [h,1+dt/(811*t0)]
    require(starts['L']==starts['R'], 'matched h and v at 810')
    sources = context['source_files'] | source['additional_pinned_sources']
    for name,entry in sources.items():
        require(sha(entry['content'].encode())==entry['sha256'], f'source {name}')
    for name,length in [('Alpha_inf.dat',16000),('R_inf.dat',100)]:
        values = [F(value) for value in sources[name]['content'].split()]
        require(len(values)==length and min(values)>0, f'positive {name}')
    data,rates = read(archive/'v62.json'),read(archive/'v77.json')
    require(data['case_id']==task['case_id'] and data['conditional'], 'conditional V62')
    pairs = list(zip(data['arms']['L']['records'],data['arms']['R']['records'],strict=True))
    require(len(pairs)==1526 and rates['status']=='PASS_UNDER_FROZEN_PREMISES', 'V62/V77 scope')
    require(F(rates['thermal_forcing_max']) < F(rates['thermal_cap'])==F('.99'), 'thermal cap')
    return task,seed,pairs,rates,t0,starts
