"""Cellwise changed-face intersection with exact rational bounds."""
from fractions import Fraction as F
import json
import sys
from inputs121 import INPUT, load_inputs, require, read, sha

def hx(value):
    return F(float.fromhex(value))

def main(group_index):
    task, seed, pairs, rates, t0, starts = load_inputs(hx)
    target = task['target']
    q,b = F(target['q']), F(target['constant_b'])
    first,last = target['historical_cells_one_based']
    group = rates['elasticity_blocks'][group_index]
    orig_first = group_index*64+1
    orig_last = min(orig_first+63,len(pairs))
    original = [r for pair in pairs[orig_first-1:orig_last] for r in pair]
    h_floor = min(hx(r['whole_source'][0][0]) for r in original)
    v_floor = min(hx(r['whole_source'][1][0]) for r in original)
    highest = max(hx(r['z'][0]) for r in original)
    lowest = min(hx(r['z'][1]) for r in original)
    require([highest,lowest]==list(map(F,group['z'])) and v_floor==F(group['v_lower']), 'original group geometry')
    require(-1<hx(group['elasticity_hex'][0])<=hx(group['elasticity_hex'][1])<0, 'negative elasticity')
    saha = F(group['saha_over_h_squared_upper'])
    require(0<=saha<=F(rates['saha_over_h_squared_max'])<1, 'V77 Saha cap')
    start_number = max(first,orig_first)
    stop_number = min(last,orig_last)
    require(start_number<=stop_number, 'nonempty target group')
    inventory_name = task['inputs']['next_task_inventory']
    inventory_path = INPUT/inventory_name
    require(sha(inventory_path.read_bytes())==task['inputs']['input_refs'][inventory_name], 'inventory digest')
    inventory = read(inventory_path)
    k0,k1 = sorted([F('8.617343e-5'),F(float('8.617343e-5'))])
    v_min = max(F('.1'),F(float('.1')))
    tr_min = max(F('.004'),F(float('.004')))
    tr_max = min(F('.4'),F(float('.4')))
    current = F(seed['exit_z']) if start_number==first else hx(pairs[start_number-2][1]['z'][1])
    start = current
    cells = []
    obstruction = None
    for number in range(start_number,stop_number+1):
        left,right = pairs[number-1]
        try:
            hi,lo = map(hx,right['z'])
            require(hi==current and lo<hi and left['z']==right['z'], 'closed adjacent z cells')
            require(all(r['initial']==old['end_source'] for r,old in zip((left,right),pairs[number-2],strict=True)), 'V62 state enclosure joins')
            require(left['H_per_s']==right['H_per_s'], 'common H')
            Hlo,Hhi=map(hx,right['H_per_s'])
            require(0<Hlo<=Hhi, 'positive H')
            require(left['allowed_branches']==right['allowed_branches']==['HMLA'], 'both fields common HMLA')
            hl,hr = [list(map(hx,r['whole_source'][0])) for r in (left,right)]
            vl,vr = [list(map(hx,r['whole_source'][1])) for r in (left,right)]
            require(all(q<a<=bnd<1 for a,bnd in (hl,hr)), 'h domain')
            require(all(v_min<a<=bnd<1 and v_floor<=a for a,bnd in (vl,vr)), 'v domain')
            require(lowest<=lo<hi<=highest, 'V77 z applicability')
            tr = (t0*(1+lo)*k0,t0*(1+hi)*k1)
            require(tr_min<tr[0]<=tr[1]<tr_max, 'radiation table domain')
            thermal=(hr[0]+q)*(1-vr[0])/(hr[0]-q)
            require(thermal<=F(rates['thermal_forcing_max']), 'thermal forcing inclusion')
            h_min = max(hr[0],hl[0]+q-b)
            h_max = min(hr[1],hl[1]+q-b)
            zexact=list(map(str,(lo,hi)))
            old=inventory[number-first]
            require(old['cell_one_based']==number and old['V77_group_zero_based']==group_index and old['z_ascending']==zexact, 'inventory identity')
            require(old['candidate_h_face']==list(map(str,(h_min,h_max))), 'inventory face consistency')
            row={'cell':number,'z_ascending':zexact,'h_face':list(map(str,(h_min,h_max))),
                 'v_boxes':[[str(x) for x in box] for box in (vl,vr)],
                 'TR_eV':list(map(str,tr)),'H_per_s_hex':right['H_per_s'],
                 'thermal_upper':str(thermal),'group':group_index}
            if h_min>h_max:
                row.update(status='EMPTY_FACE', exclusion_gap=str(h_min-h_max), normalized_lower=None)
            else:
                require(q<h_min<=h_max<1 and h_floor<=h_min, 'changed face and Saha floor')
                kappa = 1-(q-2*b)/h_min-b*(q-b)/h_min**2
                margin = (q-2*b)/h_max
                require(0<kappa<1 and 0<margin<1, 'strict inwardness')
                row.update(status='INWARD',kappa_lower=str(kappa),normalized_lower=str(margin))
            cells.append(row)
            current=lo
        except ValueError as error:
            obstruction={'cell':number,'reason':str(error),'z_hex':right['z'],'L_hv':left['whole_source'],'R_hv':right['whole_source']}
            break
    return {'method':'EXACT_PER_CELL_CHANGED_FACE','group':group_index,'chain_entry':seed['exit_z'],
            'b':str(b),'start_z':str(start),'reached_z':str(current),'records':cells,'obstruction':obstruction,
            'group_premises':{'z_ascending':list(map(str,[lowest,highest])),'h_floor':str(h_floor),
            'v_floor':str(v_floor),'Saha_h_floor_squared_upper':str(saha),'matched_start':list(map(str,starts['L']))}}

if __name__=='__main__':
    print(json.dumps(main(int(sys.argv[1])),indent=2))
