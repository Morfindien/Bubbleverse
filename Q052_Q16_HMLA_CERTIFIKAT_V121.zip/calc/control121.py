"""Independent whole-group bounds using integer decoding of binary64 literals."""
from fractions import Fraction
import json
import sys
from inputs121 import load_inputs, require

def exact_hex(text):
    mantissa, exponent = text.lower().split('p')
    sign = -1 if mantissa.startswith('-') else 1
    integer, fraction = mantissa.lstrip('+-').removeprefix('0x').split('.')
    return sign*Fraction(int(integer+fraction,16))*Fraction(2)**(int(exponent)-4*len(fraction))

def main(group_index, count):
    task, seed, pairs, rate, t0, starts = load_inputs(exact_hex)
    target = task['target']
    q,b = Fraction(target['q']),Fraction(target['constant_b'])
    first,last = target['historical_cells_one_based']
    group_first=1+64*group_index
    group_last=min(64*(group_index+1),len(pairs))
    start_number=max(first,group_first)
    stop_number=start_number+count-1
    require(0<count<=64 and stop_number<=min(last,group_last), 'group length')
    groups=rate['elasticity_blocks']
    g=groups[group_index]
    bounds=[tuple(map(Fraction,record['z'])) for record in groups]
    outer=[r for pair in pairs[group_first-1:group_last] for r in pair]
    outer_h_floor=min(exact_hex(r['whole_source'][0][0]) for r in outer)
    outer_v_floor=min(exact_hex(r['whole_source'][1][0]) for r in outer)
    require(max(exact_hex(r['z'][0]) for r in outer)==bounds[group_index][0]
            and min(exact_hex(r['z'][1]) for r in outer)==bounds[group_index][1], 'original group z')
    require(outer_v_floor == Fraction(g['v_lower']), 'original V77 v floor')
    require(-1<exact_hex(g['elasticity_hex'][0])<=exact_hex(g['elasticity_hex'][1])<0, 'rate elasticity')
    saha=Fraction(g['saha_over_h_squared_upper'])
    require(0<=saha<=Fraction(rate['saha_over_h_squared_max'])<1, 'Saha')
    current=Fraction(seed['exit_z']) if start_number==first else exact_hex(pairs[start_number-2][0]['z'][1])
    start=current
    covered=[]
    forces=[]
    boxes=[]
    for n in range(start_number,stop_number+1):
        left,right=pairs[n-1]
        high,low=map(exact_hex,left['z'])
        require(high==current and high>low and left['z']==right['z'], f'z join {n}')
        require([r['initial'] for r in (left,right)]==[r['end_source'] for r in pairs[n-2]], f'box join {n}')
        require([i for i,(top,bottom) in enumerate(bounds) if bottom<=low<high<=top]==[group_index], f'unique rate group {n}')
        require(all(r['allowed_branches']==['HMLA'] for r in (left,right)), f'branch masks {n}')
        require(left['H_per_s']==right['H_per_s'], f'common background H {n}')
        hlo,hhi=map(exact_hex,left['H_per_s'])
        require(0<hlo<=hhi, f'positive H {n}')
        boxes.extend([[list(map(exact_hex,box)) for box in r['whole_source']] for r in (left,right)])
        right_h=exact_hex(right['whole_source'][0][0])
        right_v=exact_hex(right['whole_source'][1][0])
        require(right_h>q and right_v<1, f'thermal denominator {n}')
        forces.append((right_h+q)*(1-right_v)/(right_h-q))
        covered.append({'cell':n,'z_ascending':[str(low),str(high)]})
        current=low
    require(all(h[0]<=h[1] and v[0]<=v[1] for h,v in boxes),'valid original boxes')
    h_floor=min(h[0] for h,v in boxes)
    h_cap=max(h[1] for h,v in boxes)
    v_floor=min(v[0] for h,v in boxes)
    v_cap=max(v[1] for h,v in boxes)
    require(q<h_floor<=h_cap<1 and outer_h_floor<=h_floor, 'outer h including changed face')
    require(max(Fraction('.1'),exact_hex('0x1.999999999999ap-4'))<v_floor<=v_cap<1 and outer_v_floor<=v_floor, 'outer v')
    k=sorted([Fraction('8.617343e-5'),exact_hex(float('8.617343e-5').hex())])
    radiation=[t0*(1+current)*k[0],t0*(1+start)*k[1]]
    tr_min=max(Fraction('.004'),exact_hex('0x1.0624dd2f1a9fcp-8'))
    tr_max=min(Fraction('.4'),exact_hex('0x1.999999999999ap-2'))
    require(tr_min<radiation[0]<=radiation[1]<tr_max,'group radiation domain')
    require(max(forces)<=Fraction(rate['thermal_forcing_max'])<Fraction('.99'),'group thermal bound')
    loss=(q-2*b)*h_floor+b*(q-b)
    kappa=((h_floor-q+b)*(h_floor+b))/(h_floor*h_floor)
    require(h_floor*h_floor-loss == kappa*h_floor*h_floor and 0<kappa<1,'positive group kappa')
    margin=(q-2*b)/h_cap
    require(0<margin<1,'positive group margin')
    return {'method':'GROUP_OUTER_BOXES_DIRECT_HEX','status':'PASS','group':group_index,
            'chain_entry':seed['exit_z'],'b':str(b),'start_z':str(start),'reached_z':str(current),
            'records':covered,'original_h_floor':str(outer_h_floor),'original_v_floor':str(outer_v_floor),
            'h_outer':list(map(str,(h_floor,h_cap))),'v_outer':list(map(str,(v_floor,v_cap))),
            'TR_eV':list(map(str,radiation)),'thermal_upper':str(max(forces)),
            'kappa_lower':str(kappa),'normalized_lower':str(margin),'matched_start':list(map(str,starts['L']))}

if __name__=='__main__':
    print(json.dumps(main(int(sys.argv[1]),int(sys.argv[2])),indent=2))
