"""Independent whole-rate-group envelope check, with direct hexadecimal integer parsing."""
from pathlib import Path
from fractions import Fraction
import hashlib
import json

ROOT = Path(__file__).resolve().parent

def load(name):
    return json.loads((ROOT/name).read_bytes())

def exact_hex(text):
    mantissa, exponent = text.lower().split('p')
    sign = -1 if mantissa.startswith('-') else 1
    mantissa = mantissa.lstrip('+-')[2:]
    whole, fractional = mantissa.split('.')
    numerator = sign*int(whole+fractional,16)
    power = int(exponent)-4*len(fractional)
    if power>=0:
        return Fraction(numerator*2**power)
    return Fraction(numerator,2**(-power))

def run():
    for name,pin in load('pins.json').items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==pin['sha256']
    data, rates, task = load('v62.json'),load('v77.json'),load('task90.json')
    q=Fraction(1,1000000)
    paired=list(zip(data['arms']['L']['records'],data['arms']['R']['records']))
    assert len(paired)==1526 and task['cells_one_based']==[246,1526]
    groups=rates['elasticity_blocks']
    assignments={}
    boundary=Fraction(task['domain_z_exact'][1])
    for number,(left,right) in enumerate(paired[245:],246):
        high,low=[exact_hex(s) for s in right['z']]
        assert high==boundary and low<high
        assert right['z']==left['z'] and right['H_per_s']==left['H_per_s']
        assert left['allowed_branches']==right['allowed_branches']==['HMLA']
        assert exact_hex(right['H_per_s'][0])>0
        indices=[i for i,g in enumerate(groups) if Fraction(g['z'][0])>=high and low>=Fraction(g['z'][1])]
        assert len(indices)==1
        assignments.setdefault(indices[0],[]).append(number)
        boundary=low
    assert boundary==50
    checks=[]
    for index,numbers in assignments.items():
        g=groups[index]
        selected=[row for n in numbers for row in paired[n-1]]
        hmin=min(exact_hex(row['whole_source'][0][0]) for row in selected)
        hmax=max(exact_hex(row['whole_source'][0][1]) for row in selected)
        vmin=min(exact_hex(row['whole_source'][1][0]) for row in selected)
        vmax=max(exact_hex(row['whole_source'][1][1]) for row in selected)
        # Aggregate predicates cover all cells without the producer's face intersections.
        assert hmin>q and hmax<1
        assert vmin>Fraction(1,10) and vmax<1 and vmin>=Fraction(g['v_lower'])
        assert -1<exact_hex(g['elasticity_hex'][0])<=exact_hex(g['elasticity_hex'][1])<0
        assert 0<=Fraction(g['saha_over_h_squared_upper'])<1
        # Original V77 groups are 64-cell chunks, with a final short chunk.
        original=[row for pair in paired[index*64:(index+1)*64] for row in pair]
        original_hmin=min(exact_hex(row['whole_source'][0][0]) for row in original)
        original_vmin=min(exact_hex(row['whole_source'][1][0]) for row in original)
        assert original_vmin==Fraction(g['v_lower']) and original_hmin<=hmin
        assert max(exact_hex(row['z'][0]) for row in original)==Fraction(g['z'][0])
        assert min(exact_hex(row['z'][1]) for row in original)==Fraction(g['z'][1])
        forces=[]
        for number in numbers:
            right=paired[number-1][1]
            h=exact_hex(right['whole_source'][0][0])
            v=exact_hex(right['whole_source'][1][0])
            forces.append((h+q)*(1-v)/(h-q))
        assert max(forces)<=Fraction(rates['thermal_forcing_max'])<Fraction(99,100)
        margin=q/hmax
        checks.append({'rate_group_zero_based':index,'cells_one_based':[numbers[0],numbers[-1]],'count':len(numbers),
                       'h_range':[str(hmin),str(hmax)],'v_range':[str(vmin),str(vmax)],
                       'normalized_margin_lower':str(margin),'status':'PASS'})
    assert sum(row['count'] for row in checks)==1281
    floor=min(Fraction(row['normalized_margin_lower']) for row in checks)
    assert floor.numerator>0 and floor.denominator>0
    return {'status':'PASS','method':'Whole-rate-group outer h/v envelopes and exact integer hex decoding',
            'groups':checks,'cells_checked':1281,'normalized_margin_lower':str(floor),'reached_z':'50',
            'shared_premises':'Pinned source, accepted V77 inequalities and V89 positive entry; shared standard-library Fraction arithmetic.'}

if __name__=='__main__':
    print(json.dumps(run(),indent=2))
