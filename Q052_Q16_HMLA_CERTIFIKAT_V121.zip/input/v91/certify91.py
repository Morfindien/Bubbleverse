"""Apply the inherited common-HMLA lower-face lemma to new cells 246–1526."""
from fractions import Fraction as F
from pathlib import Path
from time import monotonic
import hashlib
import json

ROOT = Path(__file__).resolve().parent
Q = F(1, 1000000)

def read(name):
    return json.loads((ROOT / name).read_bytes())

def hx(value):
    return F(float.fromhex(value))

def require(test, message):
    if not test:
        raise ValueError(message)

def run():
    started = monotonic()
    for name, pin in read('pins.json').items():
        require(hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == pin['sha256'], name+' hash')
    task, data, rates = read('task90.json'), read('v62.json'), read('v77.json')
    previous = read('result89.json')
    require(previous['status']=='ALL_TEN_PASS', 'V89 status')
    require(task['current_q']==task['target_q']=='Q052', 'Q identity')
    require(data['case_id']==task['case_id'] and data['conditional'], 'case premises')
    require(task['domain_z_exact']==['50',previous['proven_z'][0]], 'entry identity')
    require(rates['status']=='PASS_UNDER_FROZEN_PREMISES', 'V77 premises')
    require(F(rates['thermal_forcing_max'])<F(rates['thermal_cap'])==F(99,100), 'thermal bound')
    members = read('v19.json')['original_members']
    for name, entry in members.items():
        require(hashlib.sha256(entry['content'].encode()).hexdigest()==entry['sha256'], 'V19 '+name)
    background = json.loads(members['Q052_BACKGROUND_TRANSFER_INPUTS_V18.json']['content'])
    parent = background['parent_v17_inputs']
    context = parent['native_first_cell_context']
    require(context['frozen']['physics_commit']==task['source_commit'], 'physics commit')
    originals = parent['parent_result']['validator_inputs_original']['files']
    capture = json.loads(originals['q048_prefix_config_v1.json']['content'])['cases']['hillipop-ede_n3']
    flags = capture['background']['thermal_flags']
    require(flags=={'has_varconst':0,'has_exotic_injection':0,'has_idm_b':0,'has_idm_g':0,'has_idm_dr':0,'recombination':1}, 'thermal flags')
    require(capture['background']['flags']['has_idm']==capture['background']['flags']['has_idr']==0, 'extra fields')
    reio = F(capture['frozen_reionization']['fixed_reio_start_exact'])
    require(reio<50, 'public electron mapping domain')
    sources = {**context['source_files'], **background['additional_pinned_sources']}
    for name, entry in sources.items():
        require(hashlib.sha256(entry['content'].encode()).hexdigest()==entry['sha256'], 'source '+name)
    for name, length in [('Alpha_inf.dat',16000),('R_inf.dat',100)]:
        table = list(map(F, sources[name]['content'].split()))
        require(len(table)==length and min(table)>0, 'positive log table '+name)
    T0 = hx(capture['thermal_starts'][0]['constants']['Tcmb'])
    constants = capture['thermal_starts'][0]['constants']
    require(T0>0 and hx(constants['nH0_SI'])>0 and hx(constants['fHe_CLASS'])>0, 'positive background constants')
    k_bounds = sorted([F('8.617343e-5'),F(float('8.617343e-5'))])
    trmin = max(F('.004'),F(float('.004')))
    trmax = min(F('.4'),F(float('.4')))
    vmin = max(F('.1'),F(float('.1')))
    arms = [data['arms'][name]['records'] for name in ['L','R']]
    require(len(arms[0])==len(arms[1])==1526, 'cell count')
    current = F(task['interface']['z'])
    inventory = read('next_cells.json')
    require(task['cells_one_based']==[246,1526] and task['cell_count']==1281, 'task cell range')
    require([row['cell_one_based'] for row in inventory]==list(range(246,1527)), 'ordered inventory')
    checked = []
    obstruction = None
    for expected in inventory:
        number = expected['cell_one_based']
        left, right = [arm[number-1] for arm in arms]
        try:
            require(left['z']==right['z'] and left['H_per_s']==right['H_per_s'], 'shared z/H')
            high, low = map(hx,right['z'])
            require(high==current and low<high and expected['z_exact']==[str(low),str(high)], 'contiguity')
            require(left['allowed_branches']==right['allowed_branches']==['HMLA'], 'common HMLA')
            require(hx(right['H_per_s'][0])>0, 'positive H')
            bounds_h = [list(map(hx,row['whole_source'][0])) for row in [left,right]]
            bounds_v = [list(map(hx,row['whole_source'][1])) for row in [left,right]]
            require(all(Q<a<=b<1 for a,b in bounds_h), 'hydrogen domain')
            require(all(vmin<a<=b<1 for a,b in bounds_v), 'temperature ratio domain')
            lo_h = max(bounds_h[1][0],bounds_h[0][0]+Q)
            hi_h = min(bounds_h[1][1],bounds_h[0][1]+Q)
            index = expected['rate_group_zero_based']
            group = rates['elasticity_blocks'][index]
            require(F(group['z'][0])>=high and low>=F(group['z'][1]), 'rate z domain')
            require(min(a for a,b in bounds_v)>=F(group['v_lower']), 'rate v domain')
            require(-1<hx(group['elasticity_hex'][0])<=hx(group['elasticity_hex'][1])<0, 'rate monotonicity')
            require(0<=F(group['saha_over_h_squared_upper'])<1, 'positive net recombination')
            radiation = [T0*(1+low)*k_bounds[0],T0*(1+high)*k_bounds[1]]
            require(trmin<radiation[0]<=radiation[1]<trmax, 'radiation table domain')
            thermal = (bounds_h[1][0]+Q)/(bounds_h[1][0]-Q)*(1-bounds_v[1][0])
            require(thermal<=F(rates['thermal_forcing_max']), 'thermal premise inclusion')
            status = 'EMPTY_FACE' if lo_h>hi_h else 'INWARD'
            margin = None if status=='EMPTY_FACE' else str(Q/hi_h)
            checked.append({'cell':number,'z_exact':[str(low),str(high)],'h_face':list(map(str,[lo_h,hi_h])),
                            'v_bounds':[[str(a),str(b)] for a,b in bounds_v], 'TR_eV':list(map(str,radiation)),
                            'rate_group_zero_based':index,'thermal_forcing_upper':str(thermal),
                            'status':status,'normalized_face_margin':margin})
            current=low
            require(monotonic()-started<300, 'prototype time limit')
        except ValueError as error:
            obstruction={'cell':number,'reason':str(error),'raw_L':left,'raw_R':right}
            break
    done = obstruction is None and len(checked)==1281 and current==50
    margins = [(F(row['normalized_face_margin']),row['cell']) for row in checked if row['normalized_face_margin']]
    minimum, at = min(margins)
    return {'status':'ALL_1281_PASS' if done else 'FIRST_OBSTRUCTION','cells':checked,
            'new_block_z':[str(current),task['interface']['z']],'combined_positive_z':[str(current),'810'],
            'normalized_face_margin_min':str(minimum),'minimum_cell':at,'obstruction':obstruction,
            'end_source_boxes':{a:arms[i][-1]['end_source'] for i,a in enumerate(['L','R'])} if done else None,
            'phase6_interface':{'z':'50','E':'strictly positive by comparison proof','vL_minus_vR':'nonnegative','checked_below_z50':False} if done else None,
            'native_pairs':0,'full_history_integrations':0,'runtime_limit_seconds':300}

if __name__=='__main__':
    print(json.dumps(run(),indent=2))
