# Q052 V121 · En positiv q/16-grænse gennem resten af fase 5

Under den fastlåste fælles baggrund B★, de matchede starttilstande ved
z=810 og de arvede kilde-, eksistens- og baneboksforudsætninger gælder

\[
E(z)=h_L(z)+q-h_R(z)>b=\frac{q}{16}=\frac1{16000000}=6,25\cdot10^{-8}
\]

for hele det lukkede interval

\[
50\le z\le \frac{6045532743931003}{8796093022208}.
\]

Det øvre endepunkt er cirka 687,2975. Dette er den nye del af beviset.
Den møder V119 ved det samme eksakte endepunkt med streng E>b og
uden en kvantificeret ekstra afstand. V117 og V119 samt V111's
stærkere halv-q-resultat giver tilsammen E>b på [50,800] under
de respektive fælles forudsætninger. Den nye slutknude z=50 er
sidste fase-5-knude. En positiv q/16-grænse for fase 6 er ikke
kontrolleret her. Q052's native historik og samlede fejlcertifikat
forbliver åbne.

## Kildegrundlag og domæne

Kilden er CLASS/HyRec fra `mwt5345/class_ede` ved commit
`5a131c91d657dd9a7c6364cc45b038710f8d0d97`. Capture har SHA-256
`2514e250d20c456530be63e790a079176293a87a82c927b1e748d1eec405da9b`.
Det fastlåste fælles baggrunds-ID er
`Q050-COMMON-BACKGROUND-92de319899bf911563aff4d1`.
Se [kildens HMLA-funktion og dispatch](https://github.com/mwt5345/class_ede/blob/5a131c91d657dd9a7c6364cc45b038710f8d0d97/external/HyRec2020/hydrogen.c)
omkring linje 505–541 og 1057–1076.

V62 giver 1.281 par lukkede celler, historiske numre 246–1526.
Maskerne i begge arme tillader alene HMLA på denne blok. Begge
metoder kontrollerede fælles positive H-bokse, identiske z-knuder og
forbindelsen mellem startbokse og foregående slutbokse. V77 giver 21
dækkende rategrupper, negativ α-elasticitet, en temperaturkraft under
0,99 og Saha-lofter beregnet på de oprindelige gruppebokse. Metoderne
rekonstruerede gruppegrænserne fra de fulde oprindelige V62-grupper,
inklusive den forkortede sidste gruppe. De kontrollerede at hver
anvendt T_R-, h- og v-boks ligger i det relevante domæne. Reionisation
begynder under z=50 i den fastlåste konfiguration. Den offentlige
elektronforskel er E på det undersøgte interval.

u=ln[811/(1+z)] vokser, når z falder. Variablerne h, q, E og
v=T_m/T_R er dimensionsløse. H og atomare escape-, beta- og j-rater
er i s⁻¹, n_H i cm⁻³, T_R i eV og rekombinationskoefficienter i
cm³/s. Atomtabeller og konfigurationsbytes er hashkontrolleret.
Begge logratetabellers input er positive. Afhængigheden af arvede
intervalcertifikater betyder, at fejl i en fælles præmis kan berøre
begge metoder.

## Temperaturorden før første kontakt

Størrelsen t=v_L−v_R opfylder den arvede temperaturforskel

\[
t'=-(1+A_L)t+(A_L-A_R)(1-v_R),\qquad
A(X)=\frac{kX}{a+X},\quad a,k>0.
\]

V19 binder matchede h- og temperaturstarter ved z=810. Den allerede
validerede positive historie frem til indgangen og E≥b>0 frem til en
mulig første kontakt giver A_L≥A_R. I det kontrollerede domæne er
v_R<1. Variationen af konstanter giver t≥0 indtil kontakten.
V77's negative rateelasticitet giver derfor α_L,i≤α_R,i og
α_R,i≥α_eq,i>0 i hver kanal i.

## Ændret kontaktflade og det fulde Saha-led

På E=b sættes h=h_R, h_L=h−q+b, X_L=h+b og X_R=h. Det højre
kontaktinterval er skæringen mellem højre h-boks og venstre boks
forskudt med q−b. Alle 1.281 skæringer er ikke-tomme og opfylder
q<h_min≤h_max<1.

\[
P=(h-q+b)(h+b),\qquad
D=h^2-P=(q-2b)h+b(q-b),\qquad
\kappa=1-D/h^2.
\]

Fordi q<h og 0<b<q/2 er P>0 og 0<D<h², så 0<κ<1.
V77's Saha-grænse for det oprindelige gruppeminimum er strengt
under 1. Kontaktfladens h er mindst dette minimum. Med
σ_i=α_eq,i S fås derfor

\[
U_{R,i}=\alpha_{R,i}h^2-\sigma_i(1-h)>0,\qquad
U_{L,i}=\alpha_{L,i}P-\sigma_i(1-h+q-b).
\]

Den eksakte identitet er

\[
\kappa U_{R,i}-U_{L,i}
=(\alpha_{R,i}-\alpha_{L,i})P+
\sigma_i\left[(q-b)+\frac{D(1-h)}{h^2}\right]\ge0.
\]

Dette dækker det fulde Saha-led, også når U_L,i har negativt fortegn.

## HMLA-koefficienterne og indadrettet afledt

Den fælles rå escape er e(h)=L_α H/[n_H(1−h)]. Med positiv fælles
H og n_H er e voksende. På kontaktfladen følger e_L<e_R af
h_L<h_R. De faste ligevægtsrater β_s, β_p, j og Λ er positive, og
den fælles temperatur gør dem ens for begge arme ved samme z.
Sæt G=β_s+Λ+3j og K=Gβ_p+jβ_s. De bogstavelige HMLA-koefficienter
har nævner D_C=(β_s+Λ)(β_p+j)+3jβ_p+Ge og tællere
N_s=Λ(β_p+j)+(Λ+3j)e og N_p=Λj+Ge. Begge C_i=N_i/D_C er positive.
Deres afledte er henholdsvis 3jK/D_C² og GK/D_C². Dermed er
C_L,i≤C_R,i. For U_L,i≥0 kan uligheden ganges direkte med
den positive faktor. For U_L,i<0 er det venstre produkt negativt
og det højre loft positivt. I begge tilfælde gælder

\[
C_{L,i}U_{L,i}\le \kappa C_{R,i}U_{R,i}.
\]

Med f_A=−(n_H/H)Σ_i C_{A,i}U_{A,i} bliver

\[
\frac{E'}{|f_R|}=\frac{f_L-f_R}{|f_R|}
\ge 1-\kappa=\frac{D}{h^2}
\ge \frac{q-2b}{h_{\max}}>0.
\]

Her er f_R<0 i hele kontaktboksen. Den normaliserede margin er
en afledtstørrelse ved kontaktfladen. Den kvantificerer ikke den
opnåede ekstra afstand E−b for en løsning ved udgangen.

## Første kontakt og endepunkter

Den arvede løsning er kontinuert og absolut kontinuert mellem
knuder. Antag en første kontakt med E=b fra E>b. For en indre
knude gælder beviset for begge tilstødende HMLA-felter. Ved
indgangspunktet gælder streng E>b fra V119. For kontakt ved
slutknuden z=50 er det relevante indkommende felt den sidste
fase-5-celle. Før kontakten gør kontinuitet af de anvendte
grenfelter og de strengt indadrettede uligheder E′ positivt i et
tilstrækkeligt lille indkommende nabolag. Integration af den
lokale afledte modsiger en første kontakt fra den indre side.
Cellerne kan derfor sammenføjes fra V119 til og med z=50.
Anvendelsen ved slutknuden kræver kun feltet ind mod knuden.

## Kørsel og kvalitetskontrol

Primærmetoden skar de to ændrede h-bokse cellevis og anvendte
h_max fra skæringen. Mindste margin, i celle 246, er præcis
`1970324836974592/5333500648730140625`.

Kontrollen læste de samme grunddata i en separat proces med
direkte heltalsdekodning af hex-tal. Den genfandt gruppetilhørsforhold
fra z-intervallerne og anvendte h_max fra de ydre bokse for begge
arme i hver gruppe. Den læste ikke primærmetodens skæringer
eller marginer. For gruppens mindste h beregnede den κ med
produktet P/h². Både κ og marginen bestod. Den mindste kontrolmargin,
i gruppe 3, er præcis `1125899906842624/3047714693490328125`.
Begge marginer er større end 0,00036942431 på deres respektive
dækkede kontaktflader. Den uafhængige del er intervalgeometrien,
beregningskoden og dekodningen. De fysiske præmisser er arvet i fællesskab.

Koden startede hver gruppes primære kontrol og derefter den separate
kontrol. Den accepterede kun præfikset med samme eksakte domæne
og positivt fortegn i begge metoder. Alle 42 subprocesser
bestod. De to gennemgange tog tilsammen cirka 8,46 sekunder,
mod kontraktens 300 sekunder. Efterkontrollen genberegnede kun
præcise udsagn fra gemte receipts og verificerede hashes, uden
at køre de to metoder igen. V91's gamle E=0-kørsel blev genbrugt
som præmisgrundlag.

Der er ingen nye native simulationspar, numeriske
historieintegrationer eller optiske evalueringer. Det nye
positive gulv kan indgå i en efterfølgende nedre grænse for
Thomson-integralet, når de samme frosne vægte og cellegrænser er
verificeret. En optisk værdi kræver en særskilt beregning.
Resultatet er det afgrænsede
kildeligningsbevis for E>b.
