"""Check V95 transport and apply signed whole-cell bounds to the V78 inputs."""
import hashlib
import json
import zipfile
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(archive, name):
    return json.loads(archive.read(name))

def checked(path):
    archive = zipfile.ZipFile(path)
    manifest = load(archive, 'manifest.json')['members_sha256']
    assert len(archive.namelist()) == len(manifest) + 1
    assert set(archive.namelist()) == set(manifest) | {'manifest.json'}
    for name, digest in manifest.items():
        assert sha(archive.read(name)) == digest, name
    return archive

def assess(v95_path, v78_path):
    v95, v78 = checked(v95_path), checked(v78_path)
    r, c, prior = [load(v95, n) for n in ('result.json','control.json','result93.json')]
    assert r['status'] == 'ALL_373_PASS' and len(r['cells']) == 373
    assert c['status'] == 'PASS' and len(c['groups']) == 12
    assert r['new_block_z'] == ['0', prior['combined_positive_z'][0]]
    assert prior['combined_positive_z'][1] == '810' and c['endpoint_z'] == '0'
    assert r['combined_positive_z'] == ['0','810']
    verify = load(v95, 'verification.json')
    assert verify['status'] == 'PASS'
    q = F(load(v95, 'v83.json')['global_sup_abs_Delta_Xe'])
    assert q == F(1,10**6) and sha(v95.read('v64.json')) == sha(v78.read('V64_phase6_input.json'))
    transfer = load(v78,'transfer.json')
    old_low, old_high = map(F, transfer['global_sup_abs_delta_tau'])
    assert old_low == F(load(v78,'v71_tau.json')['conditional_source_sup_abs'][0])
    scale = 2**100
    sums = defaultdict(lambda: [0, 0, 0])
    bins = defaultdict(lambda: [0, 0, 0])
    previous = F(0)
    for row in load(v78,'V66_ROUTING_INPUT.json')['source_segments']:
        a,b = map(F,row['z'])
        assert a == previous and a < b
        previous = b
        lo,hi = map(F,row['dx_exact'])
        lo,hi = max(lo,0),min(hi,q)
        wlo,whi = map(F,row['K_over_H_exact'])
        assert 0 <= lo <= hi and 0 < wlo <= whi
        boundaries = [a] + [F(x) for x in range(50,811,50) if a < x < b] + [b]
        for left,right in zip(boundaries,boundaries[1:]):
            mass = ((1+right)**3-(1+left)**3)/3
            lower = (lo*wlo*mass*scale).__floor__()
            upper = (hi*whi*mass*scale).__ceil__()
            start = int(left//50)*50
            for bucket in (sums[row['origin']],bins[f'{start}:{min(start+50,810)}']):
                bucket[0] += lower
                bucket[1] += upper
                bucket[2] += 1
    assert previous == 810
    lower,upper = [F(sum(x[i] for x in sums.values()),scale) for i in (0,1)]
    assert old_low <= upper < old_high
    final_lower = max(old_low,lower)
    return {'coverage':['0','810'],'rows':transfer['whole_cells'],'rounding_step':str(F(1,scale)),
            'cell_only':[str(lower),str(upper)],'with_inherited_V71_lower':[str(final_lower),str(upper)],
            'width':str(upper-final_lower),'V78_prior':[str(old_low),str(old_high)],
            'groups':{k:[str(F(x[0],scale)),str(F(x[1],scale)),x[2]] for k,x in sums.items()},
            'bins':{k:[str(F(x[0],scale)),str(F(x[1],scale)),x[2]] for k,x in bins.items()},
            'dominant_bin':max(bins,key=lambda k:bins[k][1]-bins[k][0])}

if __name__ == '__main__':
    import sys
    print(json.dumps(assess(*map(Path,sys.argv[1:])),indent=2))
