V95 er indtaget én gang. Under den fælles fastholdte baggrund og de matchede starttilstande er elektronforskellen positiv på hele [0,810]. Kildeløsningens akkumulerede Thomson-forskel har derfor sit entydige absolutte maksimum ved z=810.

De 4.990 arkiverede helcellebokse giver 0,00000004583715 ≤ F(810) ≤ 0,00004581137. Grænserne er afrundet udad. Det øvre loft er cirka 20,2 gange lavere end i V78. Q052 er fortsat åben, fordi intervallet er bredt, og den fulde native/kilde-fejl og native-reproducerbarhed mangler.

Matematikmotor 2.3.0 får en pilotopgave på 750 ≤ z ≤ 800. Det interval bidrager mest til bredden blandt de sammenlignede intervaller på 50 i rødforskydning. Pilotmålet er at reducere delintervallets bredde med mindst 25 %. Hele integralets foreløbige målbredde er 4 × 10⁻⁹.

Q052 har nu 12.465 point. Der mangler 535 til næste SoMe-milepæl.

## Beregning og evidens

Med H_B i Mpc⁻¹ er w(z) = (K/H_B(z))(1+z)², hvor K = n_H0 σ_T Mpc_m i den arkiverede V26/V66-konvention. Integralet er dimensionsløst. Den fælles baggrund, konstanterne og de fastholdte reionisations- og startbetingelser følger V95 og de hashbundne V78-inputs. V64-filen i V78 og V95 er byteidentisk. På hver helcelle skærer V96 det arkiverede elektroninterval med [0,10⁻⁶] ved hjælp af V95 og V83. Faktoren K/H_B er strengt positiv. Produktet af de respektive nedre og øvre grænser multipliceres med den eksakte masse ((1+b)³−(1+a)³)/3. Bidrag afrundes udad til et gitter på 2⁻¹⁰⁰. Deling ved bin-grænser bruger stadig forældercellens bokse.

V78's positive nedre grænse fra V71 er bevaret som kontrol. Den nye nedre grænse kommer fra de signerede helceller og er stærkere. De arkiverede intervaller og bevispremisser deles med tidligere beregninger. Kontrollen her er en ny signeret integration og en kontrol af arkividentitet. V95's to beviskontroller er indtaget med deres verificerede resultater og er ikke genkørt i V96.

V71 har en certifikatlæsning for den gemte kurve på cirka 2,42210636 × 10⁻⁵ ved dens valgte snit. Den arvede globale signerede forskelsindhylling i V71 er cirka [−0,0398862, 0,0399331]. Den omfatter den gemte repræsentation med V71's konventioner og er for bred til det foreløbige mål. Forskellen mellem returned og ideal cut i den gemte primitive er cirka −2,26 × 10⁻²¹. Den lille forskel ved koordinatsnittet kan ikke bruges som global fejlgrænse for den native bane. Den native/kilde-sammenligning kræver fælles definition af koordinat, primitive, baggrund og afskæring, kilde- og interpolationsfejl samt dokumentation for native reproducerbarhed.

En optisk bredde på 4 × 10⁻⁹ er under en tiendedel af den nye positive nedre grænse. Det er et foreløbigt præcisionsmål for talrapportering. En eventuel lukning kræver også de frosne Q051-kriterier og en valideret native/kilde-sammenligning. Pilotopgaven kræver mindst 25 % breddereduktion af det største bin. Dermed kan næste motor afgøre, om en bredere indsats er begrundet.

Kør audit96.py med de oprindelige V95- og V78-certifikater som argumenter. V78 er vedlagt i history/.
