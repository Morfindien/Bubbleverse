from pathlib import Path
from hashlib import sha256,sha1
from fractions import Fraction as F
from datetime import datetime,timezone
import json,zipfile,subprocess,ast,io

P=Path(__file__).resolve().parent
ROOT=P.parents[1]
U=ROOT/'upload'
I=P/'in'
C=I/'calc'
O=ROOT/'output/V108'
O.mkdir(parents=True,exist_ok=True)
short,journal,taskfile,cert=names=['Q052_KORT_RESULTAT_V108.md','Q052_INGESTION_OG_SAMLET_JOURNAL_V108.md','Q052_MATEMATIKOPGAVE_V108.json','Q052_INGESTION_CERTIFICATE_V108.zip']
parent='Q052_DELCERTIFIKAT_OG_FEJLDIAGNOSE_V107.zip'
ref=lambda n:cert+'#'+n
sha=lambda b:sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
read=lambda p:json.loads(p.read_bytes())
fp=lambda x:sha(json.dumps({k:v for k,v in x.items() if k!='fingerprint_sha256'},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
blob=lambda b:sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
m=read(I/'manifest.json')
repo=read(P/'repo.json')
assert not repo['truncated'] and not set(names)&repo['paths'].keys()
with zipfile.ZipFile(U/parent) as z:
 assert z.testzip() is None
 assert set(z.namelist())=={'manifest.json'}|{e['path'] for e in m['archive_members']}
 for e in m['archive_members']:
  b=z.read(e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256'] and b==(I/e['path']).read_bytes()
for e in m['external_deliverables']:
 b=(U/e['filename']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256']
for n in [parent]+[e['filename'] for e in m['external_deliverables']]:
 assert blob((U/n).read_bytes())==repo['paths'][n],n
parent_journal=(U/'Q052_MATEMATIK_OG_SAMLET_JOURNAL_V107.md').read_bytes()
assert sha(parent_journal[:m['parent_journal']['bytes']])==m['parent_journal']['sha256']
incoming=read(U/'Q052_RESULTATINDTAG_OPGAVE_V107.json')
old=read(I/'task106.json')
r=read(I/'result107.json')
d=read(I/'diagnosis107.json')
b=read(C/'barrier107.json')
receipt=read(C/'execution107.json')
assert incoming==read(I/'Q052_RESULTATINDTAG_OPGAVE_V107.json')
for t in [incoming,old]: assert fp(t)==t['fingerprint_sha256']
assert sha((I/'result107.json').read_bytes())==incoming['input_result_sha256']==m['result_snapshot_sha256']
for k in ['case_id','current_q','target_q','source_commit','capture_sha256','exact_question']:
 assert incoming[k]==old[k]==r[k]
assert incoming['current_q']=='Q052'
for file,canon,digest in [('Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0-51.md','Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0.md',incoming['engine_prompt_sha256']),('Bubbleverse_Matematikmotor_2.3.0-51.md','Bubbleverse_Matematikmotor_2.3.0.md',old['engine_prompt_sha256'])]:
 body=(U/file).read_bytes();assert sha(body)==digest and blob(body)==repo['paths'][canon]
pins=read(C/'input_pins107.json')
for n,h in pins.items():assert sha((C/n).read_bytes())==h
for n,h in receipt['code_sha256'].items():assert sha((C/n).read_bytes())==h
barrier_hash=sha((C/'barrier107.json').read_bytes())
assert barrier_hash==receipt['output_sha256']['barrier107.json']==d['barrier_control']['barrier_sha256']
assert b['task_fingerprint']==old['fingerprint_sha256'] and b['source_commit']==old['source_commit']
assert b['domain']==['700','750'] and b['strict_interior'] and d['barrier_control']['status']=='PASS_CONDITIONAL'
assert b['electron_interval']==d['barrier_control']['certified_electron_interval']==['1/2000000','1/1000000']
# Read the prior independent check and verify the stored coverage, without replaying the proof.
domains={x['V62_row']:tuple(map(F,reversed(x['z_descending']))) for x in b['source_rows']}
assert set(domains)==set(range(118,220)) and len(b['source_rows'])==102
spans=sorted(domains.values())
assert spans[0][0]==700 and spans[-1][1]==750
assert all(l<h for l,h in spans) and all(x[1]==y[0] for x,y in zip(spans,spans[1:]))
assert sha((C/'capture.json').read_bytes())==incoming['capture_sha256']
assert read(C/'binding.json')['background_dependency_id']==old['frozen']['background_dependency_id']
v97=read(C/'result97.json')
assert v97['source_commit']==incoming['source_commit'] and v97['domain']==['750','800'] and v97['source_electron_interval']==b['electron_interval']
assert v97['barrier']=='d > -q/2; strict interior on [750,800]'
assert r['last_accepted_global_interval']==old['tolerances']['V105_global_interval']==read(C/'result105.json')['optical_result']['new_global_interval']
assert r['new_optical_interval'] is None and r['new_global_interval'] is None
assert receipt['technical_state']=='FAIL' and receipt['new_domain_optical_evaluations']==0
assert 'frontier106.json' in receipt['traceback'] and 'line 119' in receipt['traceback']
corrected=d['counter_correction']
assert [corrected[k] for k in ['diagnosed_attempts_reaching_optical_evaluation','completed_subcells_before_order_gate','accepted_new_optical_results']]==[1,106,0]

frontier=read(C/'frontier106.json')['partition']
assert sha((C/'frontier106.json').read_bytes())==d['input_frontier_sha256']
segments=read(C/'v66.json')['source_segments']
guards=read(C/'guard.json')['evaluators'][0]['rows']
partition=[]
for index,segment in enumerate(segments):
 low,high=map(F,segment['z'])
 for guard_index in range(70,75):
  g=guards[guard_index]
  left=max(F(700),low,F(g['z1']))
  right=min(F(750),high,F(g['z0']))
  if left<right:
   assert segment['origin']=='V62'
   assert sum(l<=left<right<=h for l,h in spans)==1
   partition.append([index,guard_index,str(left),str(right)])
key=lambda row:(F(row[2]),F(row[3]),row[0],row[1])
partition.sort(key=key)
assert len(partition)==len(frontier)==len(set(map(tuple,frontier)))==106
assert partition==sorted(frontier,key=key)==d['ascending_partition']
assert sum(a!=b for a,b in zip(partition,frontier))==8
swaps=[(i,j) for i,j in zip(partition,frontier) if i!=j]
assert all(i[0]==j[0] and abs(i[1]-j[1])==1 for i,j in swaps)
assert {str(F(i[2]) if F(i[2])==F(j[3]) else F(i[3])) for i,j in swaps}=={'710','720','730','740'}
assert partition[0][2]=='700' and partition[-1][3]=='750'
assert all(a[3]==b[2] for a,b in zip(partition,partition[1:]))
assert F(old['tolerances']['block_width_ceiling'])==3*F(old['tolerances']['prior_block_width'])/4

# Prepare a new executable copy. Keep original mathematical inputs and code in V107.
stage=P/'repair'
(stage/'calc').mkdir(parents=True,exist_ok=True)
for n in ['compute107.py','control107.py','run107.py']:
 (stage/'calc'/n).write_bytes((C/n).read_bytes())
subprocess.run(['patch','-s','-p1','-i',str(I/'REPAIR_NOT_EXECUTED.patch')],cwd=stage,check=True)
producer=(stage/'calc/compute107.py').read_text()
start=producer.index(" task=read('task106.json')")
end=producer.index(" bind=read('binding.json')")
producer=producer[:start]+f""" task=read('task106.json')
 recovery=read('Q052_MATEMATIKOPGAVE_V108.json')
 assert recovery['task106_fingerprint']==task['fingerprint_sha256']
 barrier=read('barrier107.json')
 assert hashlib.sha256((P/'barrier107.json').read_bytes()).hexdigest()=='{barrier_hash}'
 assert barrier['status']=='PASS_CONDITIONAL_HALF_Q_EXTENSION'
 assert barrier['task_fingerprint']==task['fingerprint_sha256']
 v62=read('v62.json')
 v62rows=barrier['source_rows']
 anchor=read('result105.json')
"""+producer[end:]
# Gate the archived partition using exact coordinates before entering optical work.
gate=producer.index(" write('attempt_progress107.json'")
producer=producer[:gate]+""" supplied=read('frontier106.json')['partition']
 canonical=read('partition108.json')
 assert len(set(map(tuple,supplied)))==len(supplied)==106
 assert canonical==sorted(supplied,key=lambda x:(F(x[2]),F(x[3]),x[0],x[1]))
 assert canonical[0][2]=='700' and canonical[-1][3]=='750'
 assert all(F(x[2])<F(x[3]) for x in canonical)
 assert all(a[3]==b[2] for a,b in zip(canonical,canonical[1:]))
"""+producer[gate:]
producer=producer.replace(" assert observed==sorted(supplied,key=lambda x:(F(x[2]),F(x[3]),x[0],x[1]))"," assert observed==canonical")
producer=producer.replace("def write(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\\n')","""def write(name, value):
 target=P/name
 pending=target.with_suffix(target.suffix+'.tmp')
 with pending.open('w') as stream:
  stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\\n')
  stream.flush()
  __import__('os').fsync(stream.fileno())
 pending.replace(target)""")
producer=producer.replace('LOCAL-Q052-SWIFT-700-750-CERTIFICATE-V107','LOCAL-Q052-SWIFT-700-750-OPTICAL-RECOVERY').replace("'schema':'Q052_V107_HALF_Q_ANCHORED_BLOCK'","'schema':'Q052_OPTICAL_RECOVERY_BLOCK'")
producer=producer.replace("'task_id':task['task_id'],'task_fingerprint':task['fingerprint_sha256']","'task_id':recovery['task_id'],'task_fingerprint':recovery['fingerprint_sha256']")
control=(stage/'calc/control107.py').read_text()
control=control[:control.index('def barrier_check(')]+control[control.index('def validate('):]
control=control.replace(" domains=barrier_check(deadline);r=load('result_raw107.json');task=load('task106.json');anchor=load('result105.json')",f""" barrier=load('barrier107.json')
 assert hashlib.sha256((P/'barrier107.json').read_bytes()).hexdigest()=='{barrier_hash}'
 domains={{x['V62_row']:tuple(map(R,reversed(x['z_descending']))) for x in barrier['source_rows']}}
 r=load('result_raw107.json');task=load('task106.json');anchor=load('result105.json')
 recovery=load('Q052_MATEMATIKOPGAVE_V108.json')""")
control=control.replace("r['task_fingerprint']==task['fingerprint_sha256']", "r['task_fingerprint']==recovery['fingerprint_sha256'] and r['task_id']==recovery['task_id']")
control=control.replace('reverse source-domain walk, ','reuse of the immutable V107 barrier domain, ')
runner=(stage/'calc/run107.py').read_text()
for original,revised in [('compute107','compute_recovery'),('control107.py','control_recovery.py'),('from control107 ','from control_recovery '),('run107.py','run_recovery.py')]:
 runner=runner.replace(original,revised)
runner=runner.replace("task=json.loads((P/'task106.json').read_text());limit=task['execution_limits']['first_prototype_wall_seconds']",f"""task=json.loads((P/'{taskfile}').read_text())
identity={{k:v for k,v in task.items() if k!='fingerprint_sha256'}}
assert hashlib.sha256(json.dumps(identity,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()==task['fingerprint_sha256']
limit=task['execution_limits']['first_prototype_wall_seconds']
# Atomically reserve this fresh working directory before any optical work.
with (P/'recovery_run.lock').open('x') as lock:
 lock.write(task['fingerprint_sha256']+'\\n')""")
runner=runner.replace("'start_utc':stamp","'task_fingerprint':task['fingerprint_sha256'],'start_utc':stamp")
runner=runner.replace("['barrier107.json','result_raw107.json','control107.json']", "['barrier107.json','attempt_progress107.json','candidate_cells107.json','result_raw107.json','control107.json']")
for token in ['attempt_progress107','candidate_cells107','result_raw107','control107.json','execution107']:
 replacement={'control107.json':'control_recovery.json'}.get(token,token[:-3]+'_recovery')
 producer=producer.replace(token,replacement)
 control=control.replace(token,replacement)
 runner=runner.replace(token,replacement)
assert 'def write(name, value)' in producer and 'barrier_check(' not in producer+control
assert 'assert observed==canonical' in producer and 'from compute_recovery import main' in runner
code={'compute_recovery.py':producer,'control_recovery.py':control,'run_recovery.py':runner}
for name,source in code.items():ast.parse(source,filename=name)
print('PASS archive, provenance, 106-cell partition, patch application and syntax')
prior=read(I/'activity_ledger.json')
assert sum(x['run_points'] for x in prior['entries'])==prior['total_points_after']==13700
assert not prior['pending_packages']
stamp=datetime.now(timezone.utc).isoformat()
run='LOCAL-Q052-V107-PARTIAL-INGESTION-V108'
event='Q052-ACTIVITY-PARTIAL-INGESTION-V108'
events=[x.get('activity_event_id',x['run_id']) for x in prior['entries']]
assert len(set(events))==len(events) and event not in events
breakdown={'provenance_and_certificate_review':15,'exact_partition_and_failure_reconciliation':15,'recovery_code_preparation_and_static_checks':25}
points=sum(breakdown.values())
total=13700+points
remaining=14000-total
basis='Heuristisk vurdering af indtagskontrol, rekonstrueret delcelleorden og klargøring af rettet forsøg. Historisk arbejde og pakning er udeladt.'
ledger={**prior,'entries':prior['entries']+[{'activity_event_id':event,'run_id':run,'run_points':points,'engine':incoming['engine'],'breakdown':breakdown,'basis':basis,'counted_once':True}],
 'previous_ledger_ref':parent+'#activity_ledger.json','previous_total_points':13700,'total_points_after':total,'cycle_progress':total%1000,'points_to_next_publication':remaining,
 'ledger_revision':'V108','parent_ledger_sha256':sha((I/'activity_ledger.json').read_bytes()),'last_updated_utc':stamp,'new_milestones':[],
 'reconciliation':{'prior_total':13700,'new_unique_event_points':points,'current_total':total}}
engine={'path':'Bubbleverse_Matematikmotor_2.3.0.md','sha256':old['engine_prompt_sha256'],'git_blob':repo['paths']['Bubbleverse_Matematikmotor_2.3.0.md']}
task={**old,'task_id':'LOCAL-Q052-V108-OPTICAL-RECOVERY-700-750','state':'PREPARED_NOT_EXECUTED',
 'input_certificate':cert,'ingestion_certificate':cert,'task106_fingerprint':old['fingerprint_sha256'],
 'parent_result_ref':ref('history/'+parent+'#result107.json'),'parent_result_sha256':incoming['input_result_sha256'],
 'recoverable_input_archives':[{'member':'history/'+parent,'sha256':sha((U/parent).read_bytes()),'restore':'Read README.md and invoke prepare_recovery.py in the extracted V108 certificate.'}],
 'objective':'Execute one corrected optical evaluation and independent numerical control on the exact 106-subcell partition of [700,750]. Reuse the admitted V107 half-q certificate.',
 'method':{'entrypoint':'python calc/run_recovery.py after python prepare_recovery.py','inherited_method':old['method'],
 'barrier':'Reuse hashed V107 source-row domains and strict electron enclosure. Do not recompute the barrier or its applicability proof.',
 'ordering':'Gate the same exact unique subcells in ascending rational redshift before entering the optical loop. Check actual traversal against this partition.',
 'persistence':'Reserve the working directory once. Record the attempt before the optical loop and persist the assembled, unvalidated candidate before post-loop gates. Preserve raw results and an independent control receipt.'},
 'source_data':{**old['source_data'],'partition_ref':ref('partition108.json'),'admitted_barrier_sha256':barrier_hash},
 'execution_limits':{**old['execution_limits'],'clock_includes':'Fresh execution preflight, one optical evaluation and one independent control. Extraction excluded.'},
 'recovery_code_sha256':{n:sha(s.encode()) for n,s in code.items()},'canonical_partition_sha256':sha(dump(partition)),
 'stop_condition':'Stop at first corrected controlled result, first unresolved gate, or 300 seconds. Preserve attempted work and distinguish execution, independent control and the 25% method target.',
 'acceptance_criteria':'Exact 106-cell coverage and frozen inputs, valid contained block with independent agreement. Method PASS requires certified width <= 3/4 of frozen prior block width. A wider valid result is separately reported as method FAIL.',
 'no_repeat':incoming['no_repeat']+['V108 order diagnosis and preparation. The next task is a single fresh corrected run, not a repeat of ingestion.'],
 'activity_ledger_ref':ref('activity_ledger.json'),'total_points':total,'next_milestone':14000,'points_to_next_publication':remaining}
task['fingerprint_sha256']=fp(task)
prepare="""from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json,subprocess,sys

base=Path(__file__).resolve().parent
task=json.loads((base/'Q052_MATEMATIKOPGAVE_V108.json').read_bytes())
bundle=task['recoverable_input_archives'][0]
archive=base/bundle['member']
assert sha256(archive.read_bytes()).hexdigest()==bundle['sha256']
work=base/'recovery_work'
work.mkdir(exist_ok=False)
with ZipFile(archive) as saved:
 for name in saved.namelist():
  assert (work/name).resolve().is_relative_to(work.resolve())
 saved.extractall(work)
subprocess.run([sys.executable,str(work/'restore_inputs107.py')],check=True)
for name,digest in task['recovery_code_sha256'].items():
 body=(base/'recovery'/name).read_bytes()
 assert sha256(body).hexdigest()==digest
 (work/'calc'/name).write_bytes(body)
partition=(base/'partition108.json').read_bytes()
assert sha256(partition).hexdigest()==task['canonical_partition_sha256']
(work/'calc/partition108.json').write_bytes(partition)
(work/'calc/Q052_MATEMATIKOPGAVE_V108.json').write_bytes((base/'Q052_MATEMATIKOPGAVE_V108.json').read_bytes())
print('Prepared recovery_work/calc. One execution: python recovery_work/calc/run_recovery.py')
"""
task['method']['entrypoint']='python prepare_recovery.py, then python recovery_work/calc/run_recovery.py'
task['fingerprint_sha256']=fp(task)
memory={'repository_url':'https://github.com/Morfindien/Bubbleverse','base_commit_sha':repo['head'],'branch':'main','source_freshness':'FOUR_V107_BLOBS_AND_BOTH_ENGINES_VERIFIED','sync_status':'USER_UPLOAD_PENDING','commit_sha':None,'pull_request_url':None,
 'proposed_files':[{'path':n,'operation':'ADD','hash_ref':ref('manifest.json')} for n in names],'journal_path':journal,'current_state_path':None,'index_refs':[],'upload_instructions_ref':ref('README.md')}
audit={'run_id':run,'status':'PASS_INTAKE_CONDITIONAL_BARRIER_ONLY','parent_result_sha256':incoming['input_result_sha256'],'input_task_fingerprint':incoming['fingerprint_sha256'],
 'original_receipt_ref':ref('history/'+parent+'#calc/execution107.json'),'original_optical_counter':0,'counter_correction':corrected,
 'accepted_barrier_sha256':barrier_hash,'accepted_barrier_domain':['700','750'],'combined_conditional_domain':['700','800'],'electron_interval':b['electron_interval'],
 'inherited_independent_check':d['barrier_control'],'prior_accepted_optical_state':'V105','last_accepted_global_interval':r['last_accepted_global_interval'],
 'partition_subcells':106,'swapped_pairs':4,'mismatched_positions':8,'guard_cuts':['710','720','730','740'],'recovery_prepared':True,'recovery_executed':False,
 'intake_counts':incoming['execution_limits'],'repository_head':repo['head']}
claims=[{'claim_id':'Q052-V108-C1','scope':'Conditional literal source-real trajectories only','claim':'q/2 < Delta X_e < q on [700,750], with the same strict bound on [700,800] when composed with V97 under the shared premises.','evidence':[ref('audit108.json'),ref('history/'+parent+'#PROOF_V107.md')]},
 {'claim_id':'Q052-V108-C2','claim':'Four adjacent swaps explain the exact set/order discrepancy. V107 processed 106 cells in one failed optical attempt and certified zero new optical results.','evidence':[ref('audit108.json'),ref('partition108.json')]}]
handoff={'schema_id':'bubbleverse.result_ingestion_handoff','schema_version':'3.0.0','prompt_id':'bubbleverse.result_ingestion_routing','prompt_version':'2.3.0','handoff_id':run,'created_at_utc':stamp,
 **{k:incoming[k] for k in ['case_id','current_q','exact_question','target_q']},'evidence_cutoff':{'source_commit':incoming['source_commit'],'input_version':'V107'},'case_lifecycle':'ACTIVE','disposition':'CONTINUE','epistemic_status':'INCONCLUSIVE',
 'ingestion_state':'ACCEPTED_CONDITIONAL_BARRIER_WITH_RECORDED_OPTICAL_FAILURE','new_result_ids':[r['result_id']],'source_state_version':'V107','target_state_version':'V108',
 'selected_next_engine_id':task['engine'],'engine_registry_ref':engine,'execution_profile_ref':ref('README.md'),'journal_ref':journal,'source_register_ref':ref('source_register.json'),
 'claim_evidence_map_ref':ref('claim_map.json'),'result_provenance_ref':ref('audit108.json'),'anomaly_tension_registry_ref':ref('audit108.json'),
 'completed_task_ledger_ref':ref('completed_tasks.json'),'route_history_ref':ref('route.json'),'integrity_manifest_ref':ref('manifest.json'),'closure_snapshot_ref':None,
 'what_changed':['V107 conditional electron bound admitted.','One failed attempt reconciled append-only.','Corrected optical recovery prepared.'],
 'frozen_configuration_refs':[ref('history/'+parent+'#calc/input_pins107.json')],'open_material_uncertainties':r['remaining_uncertainties'],
 'missing_information':['Validated optical value for the new block and native whole-history certificate.'],'next_task':taskfile,'next_task_fingerprint':task['fingerprint_sha256'],
 'success_condition':task['acceptance_criteria'],'failure_or_falsification_condition':'Any failed input, partition or independent control gate blocks promotion.','stop_condition':task['stop_condition'],
 'completion_gate_satisfied':False,'completion_gate_reason':'Native background membership, coordinate alignment and numerical error remain open.',
 'handoff_completeness':'READY_MANUAL_CONTRACT_CHECK','writeback_status':'GITHUB_USER_UPLOAD_PENDING','delivery_status':'FILES_WITH_HANDOFF','operator_gate':'NONE_FOR_LOCAL_PREPARATION',
 'output_file_refs':names,'output_manifest_ref':ref('manifest.json'),'repository_memory':memory,
 'question_activity_points':{'ledger_ref':ref('activity_ledger.json'),'parent_total_pts':13700,'assessed_run_points':points,'assessment_breakdown':breakdown,'activity_event_id':event,'total_pts':total},
 'some_milestones':{'crossed_this_run':[],'pending_milestones':[],'next_threshold_pts':14000,'points_to_next_threshold':remaining,'package_creation_status':'NOT_DUE'}}
summary=f"""# Q052 V108

Den betingede halv-q-grænse fra V107 er optaget på z = 700–750. Sammen med V97 giver den q/2 < ΔXₑ < q på z = 700–800 under det samme kildegrundlag og den samme baggrund.

V107 nåede gennem 106 optiske delceller i ét forsøg. Undersøgelsen fandt fire omvendte par i den leverede liste. Forsøget sluttede uden en certificeret integralværdi, så V105 er fortsat den seneste accepterede optiske grænse.

Matematikmotor 2.3.0 har nu en afgrænset opgave med en rettet kørsel og separat optisk kontrol. Koden genbruger V107-beviset og gemmer et kandidatresultat før de afsluttende kontroller. Rettelsen er statisk kontrolleret. Selve den rettede beregning hører til den nye matematikopgave.

Q052 er åben. Der er {total:,} aktivitetspoint og {remaining} til næste SoMe-milepæl. V107 er verificeret på GitHub. V108 er klar til manuel upload.
""".replace('13,755','13.755')
note=f"""# Q052 V108 · Resultatindtag

{stamp}

> {incoming['exact_question']}

{summary.split(chr(10),2)[2]}

Den oprindelige fejllog er bevaret. Dens nultæller blev opdateret efter retur fra producenten, og rækkefølgekontrollen standsede denne retur. Den supplerende post registrerer ét påbegyndt optisk forsøg, 106 behandlede delceller og nul nye certificerede værdier. Delingen er rekonstrueret fra V66 og guard-rækker 70–74 med eksakte brøker. De otte forskellige listepositioner findes ved z = 710, 720, 730 og 740. Den sorterede liste dækker [700,750] uden huller eller indre overlap.

Indtaget kontrollerede den tidligere uafhængige barrierepost og dens binding til kilde, capture og den fælles baggrund. Det bygger på V107's 102 kontrollerede kilderækker. Native CLASS/P6-reproducerbarhed, koordinatsammenfald og numerisk fejl for hele historien er stadig åbne.

RUN COST: {points} pts
TOTAL WORK POINTS: {total} pts
SOME INTERVAL: 1000 pts
NEWLY CROSSED SOME MILESTONES: []
NEXT SOME MILESTONE: 14000 pts
POINTS TO NEXT SOME MILESTONE: {remaining} pts
SOME PACKAGE STATUS: NOT_DUE
SCIENTIFIC STATUS: ACTIVE / CONTINUE / INCONCLUSIVE
NEXT SCIENTIFIC ENGINE: {task['engine']}

{basis}

Kontrol, opgave, kildefortegnelse og fuld ledger findes i {cert}. Opgavefingerprint: {task['fingerprint_sha256']}.
"""
readme=f"""# V108 · Genoptagelse

Læs {taskfile}. I en ny mappe med hele det udpakkede certifikat køres først `python prepare_recovery.py`. Scriptet genskaber 39 kontrollerede inputfiler via det originale V107-arkiv. Derefter starter `python recovery_work/calc/run_recovery.py` det ene afgrænsede optiske forsøg med maksimalt 300 sekunder inklusive den separate kontrol. Forsøgsmarkør, kandidat, rå resultat og kontrolkvittering ligger i samme mappe. En låsefil beskytter mod dobbeltkørsel i arbejdsmappen.

Bevar V107 som historisk record. Rækkefølge, logføring og lagring af kandidaten er rettet i de tre forberedte recovery-filer. Alle fysiske input, den eksakte deling og 25 %-kriteriet er fastholdt. Kandidaten er først certificeret efter den separate kontrol.

Tilføj de fire V108-filer på GitHub som nye rodfiler. Observeret base er {repo['head']}. Genlæs main før upload. Opdater den eksisterende Q052-pointer, når alle fire filer kan læses. V108 er ikke skrevet til GitHub i denne runde.
"""
(O/short).write_text(summary)
(O/journal).write_bytes(parent_journal+b'\n\n---\n\n'+note.encode())
(O/taskfile).write_bytes(dump(task))
members={'README.md':readme.encode(),'audit108.json':dump(audit),'partition108.json':dump(partition),'handoff108.json':dump(handoff),'activity_ledger.json':dump(ledger),
 'source_register.json':dump({'inherited_register_ref':ref('history/'+parent+'#source_register.json'),'verified_input_pins':pins}),
 'claim_map.json':dump(claims),'github_memory_update.json':dump(memory),'completed_tasks.json':dump({'parent_ref':parent+'#handoff107.json','completed':[incoming['task_id']],'no_repeat':task['no_repeat']}),
 'route.json':dump({'next_engine':task['engine'],'task_fingerprint':task['fingerprint_sha256'],'state':'PREPARED_NOT_RUN'}),
 'prepare_recovery.py':prepare.encode(),'build108.py':Path(__file__).read_bytes(),'repository_snapshot.json':dump(repo),taskfile:dump(task),
 'history/'+parent:(U/parent).read_bytes(),**{'recovery/'+n:s.encode() for n,s in code.items()}}
manifest={'schema':'Q052_V108_OUTPUT_MANIFEST','version':'V108','q':'Q052','case_id':incoming['case_id'],'run_id':run,'base_commit':repo['head'],
 'parent_journal':{'filename':m['external_deliverables'][1]['filename'],'bytes':len(parent_journal),'sha256':sha(parent_journal)},
 'archive_members':[{'path':n,'bytes':len(s),'sha256':sha(s)} for n,s in members.items()],
 'external_deliverables':[{'filename':n,'bytes':(O/n).stat().st_size,'sha256':sha((O/n).read_bytes())} for n in names[:3]],'container':{'filename':cert,'self_hash_omitted':True}}
with zipfile.ZipFile(O/cert,'w',zipfile.ZIP_DEFLATED) as z:
 for n,s in members.items():z.writestr(n,s)
 z.writestr('manifest.json',dump(manifest))
with zipfile.ZipFile(O/cert) as z:
 assert z.testzip() is None
 for item in manifest['archive_members']:assert sha(z.read(item['path']))==item['sha256']
assert (O/journal).read_bytes().startswith(parent_journal)
assert ledger['entries'][:-1]==prior['entries'] and ledger['milestone_records']==prior['milestone_records']
assert fp(read(O/taskfile))==task['fingerprint_sha256']
(P/'upload_request.json').write_bytes(dump({'uploads':[{'local_path':str(O/n),'purpose':'create_library_file','library_artifact_type':'report' if n.endswith('.md') else 'other'} for n in names]}))
print(total,remaining,task['fingerprint_sha256'])
