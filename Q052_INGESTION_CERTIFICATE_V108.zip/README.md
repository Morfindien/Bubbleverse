# V108 · Genoptagelse

Læs Q052_MATEMATIKOPGAVE_V108.json. I en ny mappe med hele det udpakkede certifikat køres først `python prepare_recovery.py`. Scriptet genskaber 39 kontrollerede inputfiler via det originale V107-arkiv. Derefter starter `python recovery_work/calc/run_recovery.py` det ene afgrænsede optiske forsøg med maksimalt 300 sekunder inklusive den separate kontrol. Forsøgsmarkør, kandidat, rå resultat og kontrolkvittering ligger i samme mappe. En låsefil beskytter mod dobbeltkørsel i arbejdsmappen.

Bevar V107 som historisk record. Rækkefølge, logføring og lagring af kandidaten er rettet i de tre forberedte recovery-filer. Alle fysiske input, den eksakte deling og 25 %-kriteriet er fastholdt. Kandidaten er først certificeret efter den separate kontrol.

Tilføj de fire V108-filer på GitHub som nye rodfiler. Observeret base er 980d2b3c6933c2c5e8028b2bee6a9c655341295f. Genlæs main før upload. Opdater den eksisterende Q052-pointer, når alle fire filer kan læses. V108 er ikke skrevet til GitHub i denne runde.
