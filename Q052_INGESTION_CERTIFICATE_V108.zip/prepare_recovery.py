from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json,subprocess,sys

base=Path(__file__).resolve().parent
task=json.loads((base/'Q052_MATEMATIKOPGAVE_V108.json').read_bytes())
bundle=task['recoverable_input_archives'][0]
archive=base/bundle['member']
assert sha256(archive.read_bytes()).hexdigest()==bundle['sha256']
work=base/'recovery_work'
work.mkdir(exist_ok=False)
with ZipFile(archive) as saved:
 for name in saved.namelist():
  assert (work/name).resolve().is_relative_to(work.resolve())
 saved.extractall(work)
subprocess.run([sys.executable,str(work/'restore_inputs107.py')],check=True)
for name,digest in task['recovery_code_sha256'].items():
 body=(base/'recovery'/name).read_bytes()
 assert sha256(body).hexdigest()==digest
 (work/'calc'/name).write_bytes(body)
partition=(base/'partition108.json').read_bytes()
assert sha256(partition).hexdigest()==task['canonical_partition_sha256']
(work/'calc/partition108.json').write_bytes(partition)
(work/'calc/Q052_MATEMATIKOPGAVE_V108.json').write_bytes((base/'Q052_MATEMATIKOPGAVE_V108.json').read_bytes())
print('Prepared recovery_work/calc. One execution: python recovery_work/calc/run_recovery.py')
