"""Restore the math inputs and draft code without scientific execution."""
from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
from hashlib import sha256
import json

root=Path(__file__).resolve().parent
target=root/'calc'
target.mkdir(exist_ok=True)
with ZipFile(root/'history/Q052_BACKEND_FEJLPAKKE_V113.zip') as v113:
    receipt=json.loads(v113.read('calc/execution113.json'))
    names=['produce113.py','control113.py','task112.json','barrier111.json','execution113.json']
    files={name:v113.read('calc/'+name) for name in names}
    for name in names[:2]:
        assert sha256(files[name]).hexdigest()==receipt['code_sha256'][name]
    with ZipFile(BytesIO(v113.read('history/Q052_INGESTION_CERTIFICATE_V112.zip'))) as v112:
        assert v112.read('Q052_MATEMATIKOPGAVE_V112.json')==files['task112.json']
        with ZipFile(BytesIO(v112.read('history/Q052_GRENSKIFT_CERTIFIKAT_V87.zip'))) as v87:
            for name,digest in json.loads(files['task112.json'])['input_sha256'].items():
                data=v87.read(name)
                assert sha256(data).hexdigest()==digest
                files[name]=data
for name,data in files.items():
    path=target/name
    if path.exists():
        assert path.read_bytes()==data
    else:
        path.write_bytes(data)
print(f'PASS: restored {len(files)} files')
