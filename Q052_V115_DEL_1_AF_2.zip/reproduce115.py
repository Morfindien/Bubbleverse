"""Optional explicit replay into a new directory; never rewrites historical output."""
from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,time,hashlib

P=Path(__file__).resolve().parent
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
out=P/('replay115_'+stamp);out.mkdir()
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(P/'runtime')
start=time.monotonic()
receipt={'run_id':'REPLAY-Q052-V115-'+stamp,'original_run_ref':'calc/execution115.json',
         'new_research_points':0,'original_files_changed':False,'commands':[]}
try:
 for cmd in [['python','restore_recovery114.py'],['python','preflight114.py'],
             ['python','calc/produce115.py',str(out/'raw115.json')],
             ['python','calc/control115.py',str(out/'raw115.json'),str(out/'control115.json')]]:
  remaining=300-(time.monotonic()-start)
  if remaining<=0:raise TimeoutError('300 seconds')
  p=subprocess.run(cmd,cwd=P,env=env,capture_output=True,text=True,timeout=remaining)
  receipt['commands'].append({'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
  if p.returncode:raise RuntimeError('Replay command failed; see receipt')
 for n in ['raw115.json','control115.json']:
  a=json.loads((P/'calc'/n).read_bytes());b=json.loads((out/n).read_bytes())
  a.pop('actual_loaded_library',None);b.pop('actual_loaded_library',None)
  assert a==b,n
 receipt['status']='PASS_SAME_NUMERICAL_CONTENT_EXCLUDING_RUNTIME_PATH'
except Exception as exc:
 receipt['status']='FAIL';receipt['error']=repr(exc)
finally:
 receipt['wall_seconds']=time.monotonic()-start
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(out/'receipt.json')
