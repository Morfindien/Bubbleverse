"""Independent literal Gamma-form check at a producer-supplied rational point.
Shares pinned source, rate interpolation and MPFR primitives; no producer import.
Uses original source DAlpha/Dxe expression and archived whole-cell DK.
"""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
import v20 as m
P=Path(__file__).resolve().parent
hx=lambda s:F(float.fromhex(s))
read=lambda n:json.loads((P/n).read_bytes())
def main(result):
 c=m.Context(P/'v19.json');w=result['witness'];q=F(1,1000000)
 mapped={line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if '/libmpfr.so' in line}
 assert mapped=={str((P.parent/'runtime/libmpfr.so.6').resolve())}
 assert hashlib.sha256((P.parent/'runtime/libmpfr.so.6').read_bytes()).hexdigest()=='28c9449d73d97cfe3158dd2c39548f71fb94df9ad300bd08c0fb6ca9331893aa'
 z,hL,hR,vL,vR,H=[F(w[k]) for k in ['z','hL','hR','vL','vR','common_H_per_s']]
 assert hR-hL==q/2 and vL>vR
 L,R=[read('v62.json')['arms'][a]['records'][234] for a in 'LR']
 for row,h,v in [(L,hL,vL),(R,hR,vR)]:
  assert hx(row['z'][1])<z<hx(row['z'][0])
  assert hx(row['whole_source'][0][0])<h<hx(row['whole_source'][0][1])
  assert hx(row['whole_source'][1][0])<v<hx(row['whole_source'][1][1])
  assert hx(row['H_per_s'][0])<H<hx(row['H_per_s'][1])
 assert (hR+q)*(vL-vR)/(q*vL)<F(99,100)
 T,tr,n,_=c.background(m.enc(1+z));assert c.fit_first.hi<T.lo<T.hi<c.fit_last.lo
 t=tr/(10000*c.k)
 B=m.lit('4.309e-13')*t.power(m.lit('-0.6166'))/(1+m.lit('.6703')*t.power(m.lit('.5300')))*c.saha*tr*tr.sqrt()*(-c.EI/(4*tr)).exp()
 dk=m.enc(*map(hx,read('v77.json')['mixed_branch_checks'][0]['DK']))
 assert -1<dk.lo<=float.fromhex(w['DK'][0])<=float.fromhex(w['DK'][1])<=dk.hi<0
 values=[];guards=[];channels=[];coefficients=[]
 for h,v,helium,swift in [(hL,vL,q,True),(hR,vR,F(0),False)]:
  al,eq,_,rate=c.rates(tr,m.enc(v));bs,bp=[m.enc(*map(hx,a['hex'])) for a in rate['beta']];j=m.enc(*map(hx,rate['R2p2s']['hex']))
  e=c.lya*m.enc(H)/(n*m.enc(1-h));guard=B/(3*e+c.lam+B);guards.append(guard.hex())
  assert (guard.lo>m.lit('.01').hi) if swift else (guard.hi<m.lit('.01').lo)
  if swift:e=e/(1+dk)
  gs=bs+3*j+c.lam;gp=bp+j+e
  # Both literal Gamma coefficients increase with positive escape.
  # Their derivative numerators are 3*j*K and gs*K, with K=gs*bp+j*bs>0.
  # Evaluate narrow endpoint boxes instead of repeating the broad DK interval.
  assert gs.lo>0 and (gs*bp+j*bs).lo>0 and e.lo>0
  def literal_C_at(endpoint):
   x=m.I(endpoint);gp=bp+j+x
   den_s=gs-3*j*j/gp;den_p=gp-3*j*j/gs
   assert den_s.lo>0 and den_p.lo>0
   return [(c.lam+3*j*x/gp)/den_s,(x+j*c.lam/gs)/den_p]
  lower=literal_C_at(e.lo);upper=literal_C_at(e.hi)
  C=[m.I(lower[k].lo,upper[k].hi) for k in range(2)]
  s=c.saha*tr*tr.sqrt()*(-c.EI/tr).exp()/n
  dx=m.enc(h)*m.enc(h+helium)-s*m.enc(1-h)
  U=[s*m.enc(1-h)*(al[k]-eq[k])+al[k]*dx for k in range(2)]
  assert all(x.lo>0 for x in U)
  values.append(-n/m.enc(H)*sum((U[k]*C[k] for k in range(2)),m.I(0)));channels.append([x.hex() for x in U]);coefficients.append([x.hex() for x in C])
 d=values[0]-values[1];norm=d/(-values[1])
 primary=list(map(hx,w['dprime']));assert max(primary[0],F(d.lo))<=min(primary[1],F(d.hi))
 return {'status':'PASS_RELAXATION_ONLY' if d.hi<0 else 'INCONCLUSIVE','dprime':d.hex(),'normalized':norm.hex(),'guards':guards,'channels':channels,'C_L_C_R':coefficients,'DK_used':dk.hex(),'actual_loaded_library':list(mapped),'MPFR_version':c.mp.VERSION,'method':'Literal nested Gamma coefficients at monotone escape endpoints and original DAlpha/Dxe expression; broader archived whole-cell DK; independent point-domain and guard checks.','shared_dependencies':'v19/v20 sources, atom tables, MPFR interval primitives, supplied rational witness. No independent physical background admission.','fixed_background_membership':'NOT_VERIFIED','trajectory_counterexample':False}

if __name__=='__main__':
 import sys
 result=main(json.loads(Path(sys.argv[1]).read_bytes()))
 with Path(sys.argv[2]).open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
