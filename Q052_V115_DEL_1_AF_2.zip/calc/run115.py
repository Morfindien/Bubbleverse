"""One producer and one separate control under the V114 300-second contract."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,os,platform,subprocess,time,traceback

P=Path(__file__).resolve().parent
now=lambda:datetime.now(timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda n,x:(P/n).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
run_id='LOCAL-Q052-V115-MIXED-HALF-Q-FACE-RECOVERY'
with (P/'run115.lock').open('x') as lock:lock.write(run_id+'\n')
t=time.monotonic()
r={'run_id':run_id,'started_at_utc':now(),'producer_runs':0,'independent_controls':0,
   'new_optical_evaluations':0,'new_native_pairs':0,'new_scalar_integrations':0,
   'new_full_history_integrations':0,'parameter_searches':0,'point_candidates':1,
   'wall_limit_seconds':300,'python':platform.python_version(),'platform':platform.platform(),
   'code_sha256':{n:sha(P/n) for n in ['produce115.py','control115.py','run115.py']},
   'task_sha256':sha(P.parent/'Q052_MATEMATIKOPGAVE_V114.json'),
   'runtime_preflight_sha256':sha(P.parent/'runtime_check115.json'),
   'technical_state':'INCOMPLETE','scientific_state':'INCONCLUSIVE','output_sha256':{}}
save('execution115.json',r)
env=os.environ.copy();env['LD_LIBRARY_PATH']=str((P.parent/'runtime').resolve())
try:
 assert json.loads((P.parent/'runtime_check115.json').read_bytes())['status']=='PASS'
 for kind,script,args,output in [('producer_runs','produce115.py',['raw115.json'],'raw115.json'),
                                ('independent_controls','control115.py',['raw115.json','control115.json'],'control115.json')]:
  remaining=300-(time.monotonic()-t)
  if remaining<=0:raise TimeoutError('Combined 300-second execution limit')
  r[kind]+=1;save('execution115.json',r)
  print('START',script,now(),flush=True)
  rt=time.monotonic()
  p=subprocess.run(['python',script,*args],cwd=P,env=env,timeout=remaining,capture_output=True,text=True)
  (P/(script+'.log')).write_text(p.stdout+p.stderr)
  r[script]={'seconds':time.monotonic()-rt,'exit_code':p.returncode}
  if p.returncode:raise RuntimeError(script+' failed: '+p.stderr)
  r['output_sha256'][output]=sha(P/output)
  print('DONE',script,json.loads((P/output).read_bytes())['status'],flush=True)
 r['technical_state']='PASS'
except Exception as exc:
 r['technical_state']='FAIL';r['error']=repr(exc);r['traceback']=traceback.format_exc()
finally:
 r['completed_at_utc']=now();r['wall_seconds']=time.monotonic()-t
 save('execution115.json',r)
 print(json.dumps(r,indent=2),flush=True)
