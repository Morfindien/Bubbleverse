"""One frozen mixed-face diagnostic. No trajectory or optical integration."""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib
import v20 as m
P=Path(__file__).resolve().parent
read=lambda n:json.loads((P/n).read_bytes())
hx=lambda x:F(float.fromhex(x))
pair=lambda x:m.enc(*map(hx,x))
Q=F(1,1000000);A=Q/2

def main():
 task=read('../Q052_MATEMATIKOPGAVE_V114.json')
 for n,h in task['input_sha256'].items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h
 c=m.Context(P/'v19.json');arc=read('v62.json');L,R=[arc['arms'][s]['records'][234] for s in 'LR']
 lo,hi=sorted(map(hx,R['z']));assert [str(lo),str(hi)]==task['domain_z']
 assert L['z']==R['z'] and L['H_per_s']==R['H_per_s']
 assert L['allowed_branches']==R['allowed_branches']==['HMLA','SWIFT']
 hmin=max(hx(R['whole_source'][0][0]),hx(L['whole_source'][0][0])+A)
 hmax=min(hx(R['whole_source'][0][1]),hx(L['whole_source'][0][1])+A)
 assert Q<hmin<hmax<1
 v77=read('v77.json');assert v77['status']=='PASS_UNDER_FROZEN_PREMISES'
 assert -1<hx(v77['cold_log_elasticity_hex'][0])<=hx(v77['cold_log_elasticity_hex'][1])<0
 assert 0<F(v77['saha_over_h_squared_max'])<1
 old=v77['mixed_branch_checks'][0];assert old['z']==R['z']
 J=hx(old['relative_C_excess'][1]);common=A*A/(hmax*hmax)
 mixedlo=1-(1+J)*(1-common)
 # One preselected diagnostic point: same relative z as V87 witness; no search.
 z=lo+(hi-lo)/64;h=(hmin+hmax)/2
 v=(max(hx(x['whole_source'][1][0]) for x in [L,R])+min(hx(x['whole_source'][1][1]) for x in [L,R]))/2
 vl=v+Q/100
 assert hx(L['whole_source'][1][0])<vl<hx(L['whole_source'][1][1])
 assert (h+Q)*(vl-v)/(Q*vl)<F(v77['thermal_cap'])
 temp,tr,nh,_=c.background(m.enc(1+z));assert c.fit_first.hi<temp.lo<temp.hi<c.fit_last.lo
 t4=tr/c.k/10000
 B=c.saha*tr*tr.sqrt()*(-c.EI/(4*tr)).exp()*m.lit('4.309e-13')*t4.power(m.lit('-0.6166'))/(1+m.lit('0.6703')*t4.power(m.lit('0.5300')))
 crit=((1/m.lit('.01')-1)*B-c.lam)/3;assert crit.lo>0
 low=F((crit*nh*m.enc(1-h)/c.lya).hi);high=F((crit*nh*m.enc(1-h+A)/c.lya).lo)
 low=max(low,hx(R['H_per_s'][0]));high=min(high,hx(R['H_per_s'][1]));assert low<high
 H=(low+high)/2
 eR=c.lya*m.enc(H)/(nh*m.enc(1-h));eL=c.lya*m.enc(H)/(nh*m.enc(1-h+A))
 PL=B/(3*eL+c.lam+B);PR=B/(3*eR+c.lam+B)
 assert PL.lo>m.lit('.01').hi and PR.hi<m.lit('.01').lo
 ratio=(m.lit('2.7255')/m.enc(c.T0)).power(m.I(3))
 shifts=[m.I(1),(m.I(0,1)-m.lit('.14175'))*ratio,(m.enc(0,F('.03'))-m.lit('.02242')*(1-m.lit('.246738546372')))*ratio,m.enc(F('3.04'),F('3.05'))-m.lit('3.046')]
 fit=[[m.lit(x) for x in line.split()] for line in c.sources['fit_swift.dat']['content'].splitlines() if line.strip()]
 dk=m.hull(sum((s*m.cubic([fit[k][col] for k in range(i-1,i+3)],t) for col,s in enumerate(shifts,1)),m.I(0)) for i,t in m.stencils((temp-c.fit_first)/10,len(fit)))
 assert -1<dk.lo<=dk.hi<0
 aR,eq,_,rates=c.rates(tr,m.enc(v));aL,_,_,_=c.rates(tr,m.enc(vl))
 bs,bp=[pair(x['hex']) for x in rates['beta']];j=pair(rates['R2p2s']['hex']);g=bs+c.lam+3*j
 def C(e):
  D=(bs+c.lam)*(bp+j)+3*j*bp+g*e
  return [(c.lam*(bp+j)+(c.lam+3*j)*e)/D,(c.lam*j+g*e)/D]
 cr=C(eR);cl=C(eL/(1+dk));saha=c.saha*tr*tr.sqrt()*(-c.EI/tr).exp()/nh
 ur=[aR[k]*m.enc(h*h)-eq[k]*saha*m.enc(1-h) for k in range(2)]
 ul=[aL[k]*m.enc(h*h-A*A)-eq[k]*saha*m.enc(1-h+A) for k in range(2)]
 assert all(x.lo>0 for x in ur+ul)
 fR=-nh/m.enc(H)*sum((cr[k]*ur[k] for k in range(2)),m.I(0))
 fL=-nh/m.enc(H)*sum((cl[k]*ul[k] for k in range(2)),m.I(0))
 # Exact cancellation identity, with both channels and Saha subtraction retained.
 D0=(bs+c.lam)*(bp+j)+3*j*bp
 K=g*bp+j*bs
 eS=eL/(1+dk)
 N=[c.lam*(bp+j)+(c.lam+3*j)*eR,c.lam*j+g*eR]
 excess=[(eS-eR)*eta*K/((D0+g*eS)*N[k]) for k,eta in enumerate([3*j,g])]
 deltaU=[(aR[k]-aL[k])*m.enc(h*h)+aL[k]*m.enc(A*A)+eq[k]*saha*m.enc(A) for k in range(2)]
 derivative=nh/m.enc(H)*sum((cr[k]*(deltaU[k]-excess[k]*ul[k]) for k in range(2)),m.I(0))
 normalized=derivative/(-fR)
 # The direct form is retained as a diagnostic, not an extra physical point.
 direct=fL-fR
 assert max(direct.lo,derivative.lo)<=min(direct.hi,derivative.hi)
 seed=read('barrier111.json')
 assert seed['status']=='PASS_CONDITIONAL_HALF_Q_EXTENSION' and seed['strict_interior'] is True
 assert F(seed['domain'][0])==hi and seed['electron_interval'][0]=='1/2000000'
 assert seed['background_dependency_id']==task['frozen_background']
 assert F(v77['phase5_z'][0])<=lo<hi<=F(v77['phase5_z'][1])
 assert c.trmin.hi<tr.lo<=tr.hi<c.trmax.lo and F(1,10)<v<vl<1
 mapped={line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if '/libmpfr.so' in line}
 assert mapped=={str((P.parent/'runtime/libmpfr.so.6').resolve())}
 assert hashlib.sha256((P.parent/'runtime/libmpfr.so.6').read_bytes()).hexdigest()=='28c9449d73d97cfe3158dd2c39548f71fb94df9ad300bd08c0fb6ca9331893aa'
 witness={'z':str(z),'hR':str(h),'hL':str(h-A),'vR':str(v),'vL':str(vl),'common_H_per_s':str(H),'Pion_L':PL.hex(),'Pion_R':PR.hex(),'DK':dk.hex(),'dprime':derivative.hex(),'dprime_normalized':normalized.hex(),'direct_dprime':direct.hex(),'relative_C_excess':[x.hex() for x in excess],'delta_U':[x.hex() for x in deltaU],'C_L':[x.hex() for x in cl],'C_R':[x.hex() for x in cr],'U_L':[x.hex() for x in ul],'U_R':[x.hex() for x in ur]}
 return {'status':'RELAXED_FACE_COUNTEREXAMPLE_PENDING_CONTROL' if derivative.hi<0 else 'INCONCLUSIVE','scientific_state':'INCONCLUSIVE','domain_z':task['domain_z'],'h_face':list(map(str,[hmin,hmax])),'common_branch_normalized_lower':str(common),'mixed_branch_normalized_enclosure':[str(mixedlo),'1'],'witness':witness,'witness_scope':'Shared archived H interval and state/selector/temperature constraints. Membership in the exact fixed B_star H(z) and actual trajectory is NOT VERIFIED. Therefore this is not a fixed-background source counterexample.','new_optical_evaluations':0,'new_native_pairs':0,'new_scalar_integrations':0,'point_candidates':1,'slabs_evaluated':0,'full_cell_mixed_face_covered':False,'seed':'REUSED_AND_IDENTITY_CHECKED_V111','same_branch_pairs':'CONDITIONAL_ANALYTIC_INWARD_BOUND','opposite_mixed_pair':'HMLA/SWIFT_EXCLUDED_BY_RAW_ESCAPE_ORDER','actual_loaded_library':list(mapped),'backend':{'version':c.mp.VERSION,'intermediate_bits':256,'endpoint_format':'binary64 outward; exact rational metadata'},'next_obligation':'Resolve actual common H(z) and tighter joint state/temperature information at the mixed selector, or use a variable lower barrier. Do not repeat unchanged rectangular half-q proof.'}

if __name__=='__main__':
 import sys
 result=main()
 with Path(sys.argv[1]).open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
