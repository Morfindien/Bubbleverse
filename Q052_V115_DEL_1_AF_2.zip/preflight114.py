"""Check the archived MPFR primitives in a process scoped to runtime/."""
from pathlib import Path
from fractions import Fraction
import hashlib, json, platform, importlib.util, tempfile, math

root = Path(__file__).resolve().parent
digest = lambda data: hashlib.sha256(data).hexdigest()
library = root/'runtime/libmpfr.so.6'
source = root/'runtime/mpfr-4.2.1.tar.xz'
assert digest(library.read_bytes()) == '28c9449d73d97cfe3158dd2c39548f71fb94df9ad300bd08c0fb6ca9331893aa'
assert digest(source.read_bytes()) == '277807353a6726978996945af13e52829e3abd7a9a5b7fb2793894e18f1fcbb2'
backend = json.loads((root/'calc/v19.json').read_bytes())['original_members']['q052_scalar_interval_v18.py']['content'].encode()
assert digest(backend) == '558592e20969dbfc063570f2224c36b4e8d7dca37db20009cb5dd2a993e0d160'
with tempfile.TemporaryDirectory() as tmp:
    script = Path(tmp)/'backend.py'
    script.write_bytes(backend)
    spec = importlib.util.spec_from_file_location('pinned_backend', script)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    loaded = {line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if '/libmpfr.so' in line}
    assert loaded == {str(library.resolve())}, loaded
    assert module.VERSION == '4.2.1'
    low, high = (module.rounded('add', 1.0, 2**-53, up=up) for up in (False, True))
    assert low == 1.0 and high == math.nextafter(1.0, math.inf)
    for a,b in [(1.,3.),(-1.,3.)]:
        exact = Fraction(a)/Fraction(b)
        low, high = (module.rounded('div', a, b, up=up) for up in (False, True))
        assert Fraction(low)<exact<Fraction(high)
    low, high = (module.rounded('sqrt', 2.0, up=up) for up in (False, True))
    assert Fraction(low)**2 < 2 < Fraction(high)**2
print(json.dumps({'status':'PASS','version':'4.2.1','platform':platform.platform(),'python':platform.python_version(),'library_sha256':digest(library.read_bytes()),'source_sha256':digest(source.read_bytes()),'backend_sha256':digest(backend),'checks':['loaded path','version','ABI and rounding enum via backend import','binary64 midpoint','signed division','square root'],'scientific_evaluations':0},indent=2))
