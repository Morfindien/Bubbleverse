# Q052 V115 — halvdelsgrænsen ved det blandede grenskift

## Dokumenteret resultat og præcis rækkevidde

V115 finder et strengt udadrettet felt på randen E=q/2 i den arkiverede,
udvidede tilstands- og H-boks for V62-række 234 (historisk celle 235).
En separat kontrol med den oprindelige Gamma-formel bekræfter fortegnet.
Dermed er **uniform indadrettethed på hele denne intervalrelaksation afvist**.
Der er ikke vist et brud på den fastlåste baggrund eller på de matchede baner.
Q052 er fortsat INCONCLUSIVE og åbent.

Det testede interval er z i
[761161663339561/1099511627776, 1523417340748759/2199023255552],
svarende til cirka [692,2725; 692,77]. Der er evalueret ét på forhånd valgt
rationelt punkt, ingen søgning og ingen integration. Hele den blandede flade
er ikke blevet dækket af nye delintervaller. Et negativt punkt er tilstrækkeligt
til at afvise den uniforme påstand på relaksationen, men ikke til at afgøre
den smallere påstand på den bestemte baggrund.

## Ligninger, enheder og kontaktflade

Brug den fremadrettede koordinat u=ln[811/(1+z)], q=1/1000000 og a=q/2.
Sæt h=h_R, h_L=h-a og E=h_L-h_R+q. På E=q/2 er
x_e,R=h og x_e,L=h+a. Det korrekte produkt er derfor

    x_e,L h_L = (h+a)(h-a) = h²-a²,
    x_e,R h_R = h².

Den lineære forbedring fra V87's E=0-flade kan ikke overføres til denne flade.
Temperaturforholdene v=T_m/T_gamma og hydrogenfraktionerne er dimensionsløse.
T_R i raterne er i eV, n_H i cm⁻³, H i s⁻¹ og rekombinationskoefficienterne
alpha i cm³/s. d'=d(h_L-h_R)/du er en fraktion pr. logaritmisk skalafaktor.

Med s=S0 T_R^(3/2) exp(-EI/T_R)/n_H er de to kanalbidrag

    U_R,i = alpha_R,i h² - alpha_eq,i s(1-h),
    U_L,i = alpha_L,i (h²-a²) - alpha_eq,i s(1-h+a),
    f_A = -(n_H/H) sum_i C_A,i U_A,i,  d'=f_L-f_R.

Begge fotoionisationsled, begge atomare kanaler og temperaturafhængigheden
er medtaget. Injektionsleddene er nul under de fastlåste kildeflag.

## Alle mulige grenpar og lighedsgrænser

Den rå escape-rate er e(h)=Lya H/[n_H(1-h)]. Begge arme har samme z,H,n_H
og strålingstemperatur. B er selectorens fælles strålingsafhængige rate,
P=B/(3e+Lambda+B), p=0,01 og c=[(1/p-1)B-Lambda]/3.
HMLA bruges for P<p; SWIFT for P>=p inden for fitdomænet.

På fladen h_L<h_R gælder e_L<e_R og P_L>P_R. HMLA/SWIFT er derfor umulig.
Det blandede par er SWIFT/HMLA, med e_L<=c<e_R. Ved en vurdering af
første kontakt skal begge ensidige felter ved lighed også medtages;
at koden vælger SWIFT ved lighed fjerner ikke det andet grænsefelt.

For HMLA/HMLA og SWIFT/SWIFT er C_L<=C_R. For SWIFT anvendes samme DK
i begge arme, med 1+DK>0. V77's kolde rateelasticitet, Saha-grænse og
temperaturordenen v_L>=v_R giver U_R>0 og

    U_L <= (1-a²/h²) U_R.

Hvis U_L er negativt, er det pågældende bidrag allerede gunstigt. Ellers
kan ovenstående ulighed multipliceres med de positive C-faktorer. Derfor

    d'/|f_R| >= a²/h_max² > 4,2847 × 10^-8

for begge fælles grenpar under de nævnte, nedarvede præmisser. Her er
h_max=5569742253076425/2305843009213693952 fra fladens boksfællesmængde.
Det er et betinget analytisk resultat; det fjerner ikke den blandede gren.

V111's strengt indre start ved cellens øvre endepunkt genbruges med
identitetskontrol. Vi har ikke genberegnet dens tidligere 15 celler.

## Stabil primærberegning

Sæt beta_s,beta_p for fotoionisationsraterne, j=R_2p2s og

    G=beta_s+Lambda+3j,
    D0=(beta_s+Lambda)(beta_p+j)+3j beta_p,
    D(e)=D0+G e,
    K=G beta_p+j beta_s,
    N_s(e)=Lambda(beta_p+j)+(Lambda+3j)e,
    N_p(e)=Lambda j+G e,
    C_i(e)=N_i(e)/D(e).

For t=e_L/(1+DK) og eta_s=3j, eta_p=G er den eksakte identitet

    J_i=C_i(t)/C_i(e_R)-1
       =(t-e_R) eta_i K / [D(t) N_i(e_R)].

Temperatur- og Saha-bidragene samles uden tab af deres lille forskel:

    Delta U_i=(alpha_R,i-alpha_L,i)h²
              +alpha_L,i a²+alpha_eq,i s a,
    d'=(n_H/H) sum_i C_R,i [Delta U_i-J_i U_L,i].

Syv symbolske identitetskontroller giver rest præcis nul:
Gamma/polynomium, positiv afledt og C-ratio i hver kanal samt U-forskellen.
Disse checks tester algebraen; de er ikke nye fysiske punkter.

Det rå direkte interval for f_L-f_R indeholder nul, cirka
[-5,595e-5; 5,390e-5]. Det er en afhængighedseffekt i intervalregningen,
ikke modstridende evidens. Den faktorerede identitet og den separate kontrol
giver begge strengt negative intervaller. Den direkte C_L-indhegning kan
af samme grund have en øvre grænse større end 1; dette er ikke en påstand
om en fysisk C-værdi større end 1.

## Det forudvalgte punkt og resultater

Punktet er valgt efter V113-kladdens faste regel: z_lo+(z_hi-z_lo)/64,
h i midten af fladens boksfællesmængde, v_R i midten af temperaturfællesmængden,
v_L=v_R+q/100 og H i midten af den verificerede selectorkorridor.
Der er ikke efterfølgende søgt efter et mere fordelagtigt punkt.

| Størrelse | Værdi, afrundet til læsning |
|---|---:|
| z | 692,2802734375 |
| h_R | 0,001287624313752069 |
| h_L | 0,001287124313752069 |
| v_R | 0,9849758478562487 |
| v_L-v_R | 10^-8, eksakt |
| H | 3,4073230511991755 × 10^-14 s^-1 |
| P_L | cirka 0,010000001191782 > 0,01 |
| P_R | cirka 0,009999998808218 < 0,01 |

De eksakte rationelle koordinater og udadrettede hex-endepunkter står i
calc/raw115.json. DK er indhegnet fra det fastlåste fit og de nedarvede
parameterbokse; der er ikke foretaget et nyt parameterfit.

Følgende decimalintervaller er afrundet udad og er lidt bredere end de
arkiverede, præcise hex-intervaller:

| Metode | d' | d'/|f_R| |
|---|---:|---:|
| Primær, faktoreret | [-8,952e-7; -2,401e-7] | [-2,752e-4; -7,381e-5] |
| Separat Gamma-kontrol | [-8,864e-7; -2,285e-7] | [-2,725e-4; -7,025e-5] |

Begge kontroller indhegner en negativ afledt. De bruger delvist forskellige
DK-områder, så intervallerne behøver ikke være indlejrede i hinanden.

## Hvad den separate kontrol er uafhængig af

control115.py importerer ikke producenten. Den kontrollerer punktets z,h,v,H,
kontaktfladen, temperaturkorrelationen og de to rå selectorer på ny. Den bruger
den originale indlejrede Gamma-form og DAlpha/Dxe-udtrykket. DK kommer fra
V77's bredere helcelleinterval [-0,033793; -0,008801] (her afrundet udad).

For at undgå gentagne brede escape-intervaller evalueres C ved escape-intervallets
endepunkter. Dette er gyldigt, fordi C_i'(e)=eta_i K/D(e)²>0. De positive
nævnere kontrolleres også numerisk. Kontrollen genbruger således ikke
producentens endelige C-ratio eller faktorerede U-forskel.

Kontrollerne deler kildefiler, atomtabeller, interpolation og MPFR-primitiver.
Det er en separat algebraisk implementation, ikke en uafhængig måling eller
en fuldt uafhængig fysisk model. Begge kørte i separate Python-processer med
MPFR 4.2.1, 256-bit mellemregning og udadrettede binary64-endepunkter.
Det faktisk indlæste bibliotek og dets hash blev kontrolleret i begge processer.

## Grænser for konklusionen

Det valgte H ligger i V62's fælles H-interval. Det er **ikke verificeret**, at
H=H_Bstar(z) ved dette z. Det er heller ikke verificeret, at h- og
temperaturværdierne kan nås samlet fra de matchede starttilstande. Et punkt
i en produktboks er ikke automatisk et punkt på den bestemte bane.

Derfor gælder følgende:

- Den uniforme indadrettede halv-q-test på den afprøvede relaksation fejler.
- Den faktiske halv-q-grænse på den fastlåste bane er fortsat uafgjort.
- V87's E>0-resultat og tidligere gyldige grænser ændres ikke.
- Ingen nye sup|Delta x_e| eller sup|Delta tau_T| er beregnet.
- Der er ikke udført nye native par, optiske beregninger eller historieintegrationer.

Feltet mixed_branch_normalized_enclosure i den rå producentfil er et videreført
groft diagnosticeringsudtryk. Det promoveres ikke til et nyt helcellecertifikat:
den nye flades fulde blandede domæne er ikke gennemgået. Den accepterede nye
evidens er punktresultatet, den separate kontrol og det betingede fællesgrenbevis.

## Næste opgave

Resultatindtag og routing skal optage dette som en valideret begrænsning af
den uniforme randmetode, bevare de tidligere resultater og forberede én ny
matematikopgave. Det konkrete næste valg er at udlede og kontrollere en
svagere positiv eller variabel nedre barriere gennem den samme blandede celle.
Den skal kobles til V111's eksisterende indre start og dække begge ensidige
felter. En konstant kandidat b<q/2 kan designes med den eksakte produktforskel

    h²-(h-q+b)(h+b)=(q-2b)h+b(q-b).

Ingen værdi af b er her certificeret. Genbrug V87's gemte selectoroplysninger
kun efter kontrol af domæneinklusion på den nye flade. En gentagelse af
halv-q-testen på uændrede rektangulære bokse løser ikke den konstaterede fejl.
Den faste baggrund og den native histories identitet forbliver særskilte krav.
For en variabel barriere skal kontaktbetingelsen være E'-b'(u)>0;
E'>0 alene er kun den relevante test for en konstant barriere.

## Kilder og versionsgrænse

1. Vedhæftet Q052_INGESTION_CERTIFICATE_V114.zip og dets manifest: indgang,
   autoritativ journal, V111-start, V112-kontrakt og oprindelig V113-fejl.
2. calc/v19.json og calc/v20.py: fastlåste kildebytes, tabeller og intervalbackend;
   alle angivne inputhashes er kontrolleret under producentkørslen.
3. mwt5345/class_ede@5a131c91d657dd9a7c6364cc45b038710f8d0d97,
   external/HyRec2020/hydrogen.c, linje 429–541 og 1065–1076:
   begge rateformler og selector. SHA-256
   734800ccd69b41d60b519f200003ce27c3b7640f76a70353499424842ba19616.
   Kildebytes findes i V19; ingen nyere fysikkilde er indført.
4. V62, V77, V87 og V111: tidligere boks-, temperatur-, selector- og startresultater,
   genbrugt med præcis angivet rækkevidde. Tidligere point tælles ikke igen.
5. Morfindien/Bubbleverse@fa77297a6808ffd07676e30e5d907a5ad6f921c2:
   V114-journal/opgave og begge motorers identitet verificeret. Se repository115.json.

Kilden beskriver de fastlåste modelligninger; denne runde tilfører ingen ny
observation af universet. Ingen accepteret fysisk model er ændret.

[Fastlåst hydrogen.c](https://github.com/mwt5345/class_ede/blob/5a131c91d657dd9a7c6364cc45b038710f8d0d97/external/HyRec2020/hydrogen.c)
og [verificeret projektversion](https://github.com/Morfindien/Bubbleverse/tree/fa77297a6808ffd07676e30e5d907a5ad6f921c2).
