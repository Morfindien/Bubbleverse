# Q052 V91 · Positiv elektronforskel gennem resten af fase 5

## Dokumenteret delresultat

På det fastholdte fælles B★, med matchede starttilstande ved z = 810 og de arvede kilde- og banepræmisser, gælder

\[
0<\Delta X_e(z)<10^{-6}\quad(50\le z<810),\qquad
\Delta X_e(810)=10^{-6}.
\]

V91 beviser den nye nedre fortegnsgrænse på V62-cellerne 246–1526. Den øvre grænse og startværdien kommer fra de accepterede tidligere resultater. Blokken går fra det eksakte V89-slutpunkt 6045532743931003/8796093022208, cirka 687,2975, ned til 50. Alle 1.281 celler består. Det samlede positive interval er nu [50,810].

Resultatet er et betinget udsagn om løsningerne af de fastlåste kildeligninger. De åbne krav i Q052 om den resterende lave rødforskydning, det globale Thomson-maksimum og den fulde native/kilde-fejl består.

## Variable og kildegrundlag

Venstre arm har det fastholdte heliumbidrag q = 1/1000000, og højre arm har q = 0. Sæt h = h_R, d = h_L − h_R, E = d + q og t = v_L − v_R. v er forholdet mellem stof- og strålingstemperatur. Den fremadrettede variabel er u = ln[811/(1+z)]. Alle disse størrelser er dimensionsløse. Elektronfraktionen er elektroner pr. hydrogenkerne. H og de atomare rater har enheden s⁻¹, n_H er i cm⁻³, og T_R er i eV.

Det fastlagte reionisationsstartpunkt 753585/65536 ligger under 50. Den offentlige elektronforskel er derfor E på hele den nye blok. De to arme bruger samme H og strålingstemperatur ved samme z. De arkiverede H-bokse er identiske celle for celle. Tilstands- og kildekonstanter, flags og kilderevision følger V19/V62/V77 og V90-opgaven.

Den bogstavelige HMLA-kilde er hyrec.c, linje 505–541, ved physics-commit 5a131c91d657dd9a7c6364cc45b038710f8d0d97. Den er indlejret med hash og kilde-URL i v19.json. Dens to kanaler, escape-rate og C-faktorer bruges nedenfor. De positive logtabeller Alpha_inf.dat og R_inf.dat er verificeret i den nye kørsel. Interpolation i lograte efterfulgt af eksponentiering giver positive rater på det arvede tabellære domæne. V77's kontrollerede rateelasticitet giver den nødvendige monotoni i v.

## Sammenligningsargumentet

V89 giver E > 0 ved blokkens begyndelse. Indtil en eventuel første kontakt med E = 0 giver temperaturfeltet

\[
t'=-(1+A_L)t+(A_L-A_R)(1-v_R),\qquad
A(X)=kX/(a+X),\quad a>0,\quad k>0.
\]

På dette tidsinterval er E ≥ 0, A_L ≥ A_R og v_R < 1. Variationen-af-konstanten-formlen sammen med den arvede temperaturorden giver t ≥ 0. Den negative rateelasticitet på det kontrollerede domæne giver dermed α_L,i ≤ α_R,i. Det er samme første-kontakt-lemma som i V85, anvendt på nye celler.

På E = 0 er h_L = h − q og X_L = X_R = h. Begge arme har samme β_i = α_i(1)S. Definér

\[
U_{R,i}=\alpha_{R,i}h^2-\beta_i(1-h),\qquad
U_{L,i}=\alpha_{L,i}(h-q)h-\beta_i(1-h+q).
\]

Da 0 < v_R < 1 og α aftager med v, gælder α_R,i ≥ α_i(1). Den relevante V77-gruppe har S/h_min² < 1. Den nye celles h er mindst gruppens h_min. Dermed er U_R,i > 0. Med κ = 1 − q/h ∈ (0,1) følger

\[
U_{L,i}\le \kappa U_{R,i}-\beta_i q/h\le\kappa U_{R,i}.
\]

Begge armes masker tillader alene HMLA i samtlige nye celler. Escape-raten e = L_Lyα H/[n_H(1−h)] er positiv og voksende med h. På randen er e_L < e_R.

Skriv G = β_s + Λ + 3j, K = Gβ_p + jβ_s og

\[
D(e)=(\beta_s+\Lambda)(\beta_p+j)+3j\beta_p+Ge,
\]

\[
N_s(e)=\Lambda(\beta_p+j)+(\Lambda+3j)e,\qquad
N_p(e)=\Lambda j+Ge.
\]

HMLA-faktorerne er C_i(e)=N_i(e)/D(e). Alle led i nævneren er positive. Deres afledte er

\[
C_s'(e)=3jK/D(e)^2>0,\qquad C_p'(e)=GK/D(e)^2>0.
\]

Derfor er C_L,i ≤ C_R,i. Hvis U_L,i er negativ, bidrager kanalen allerede gunstigt. Ellers kan kanaluligheden multipliceres med C_L,i. I begge tilfælde er C_L,i U_L,i ≤ κ C_R,i U_R,i. Med det fælles positive n_H/H fås

\[
E'=d'=f_L-f_R\ge(q/h)|f_R|>0.
\]

Denne randulighed forhindrer første kontakt fra E > 0. De arvede løsninger er kontinuerte gennem cellegrænserne, og de tilladte ensidige felter opfylder samme argument. Indgangsfeltet fra V89 er allerede dækket af det accepterede blandede-grenbevis. Induktivt nås hver ny slutknude med E > 0.

## Kontrol af de nye domæner

certify91.py læser de hashfastlåste arkiver og går igennem cellerne i faldende z. For hver celle kontrolleres den eksakte knudeidentitet, fælles H, H > 0, de to HMLA-masker, q < h < 1, 0,1 < v < 1 og T_R's tabeldomæne. På randen bruges fællesmængden af højre h-boks og venstre h-boks forskudt med q.

Hver celles v-bokse ligger inden for den relevante V77-rategruppes nedre v-grænse og 1. Gruppens z-interval indeholder hele cellen. Rateelasticiteten ligger mellem −1 og 0, og den arkiverede S/h_min²-grænse er under 1. Den cellevise temperaturkraft er højst V77's eksisterende maksimum, som er under 0,99. Alle 1.281 randbokse er ikke-tomme og giver INWARD.

Den mindste primære normaliserede randmargin findes i celle 246 og er præcis

\[
\mu_{\rm primær}=2251799813685248/5333500648730140625
\simeq0,0004221992199853546.
\]

Det er en nedre grænse for E′/|f_R| på E = 0. Størrelsen af ΔX_e langs den faktiske bane følger ikke af dette tal alene. De eksakte celledata og marginer står i result.json.

## Separat blokkontrol

control91.py læser de samme pin-verificerede input og anvender en separat parser, der omsætter de hexadecimale tal direkte til heltal og potenser af to. Den grupperer de nye celler i de 21 berørte V77-rategrupper. For hver gruppe kontrollerer den ydre h/v-bokse, den oprindelige 64-cellegruppes h- og v-gulv, rategrænserne, temperaturkraften, begge masker og sammenhængen i z.

Kontrollen bruger det største h i begge armes ydre bokse som loft på randens h. Den giver en fælles normaliseret margin på cirka 0,00042219921484962583. Den eksakte brøk står i control.json. Begge metoder giver den sikre strenge grænse

\[
E'/|f_R|>0,00042219
\]

på alle de nye randbokse. Kontrollen læser ingen primærresultater og deler hverken randintersektion eller gruppering med primærkørslen. Metoderne deler de oprindelige kilde- og banepræmisser samt Python-standardbibliotekets rationalregning. V91 kræver kun standardbiblioteket til sine to nye beregninger. De tidligere intervalcertifikater genbruges på deres dokumenterede domæner.

## Optisk konsekvens og slutgrænse

For den signerede Thomson-forskel

\[
F(Z)=\Delta\tau_T(0,Z)=\int_0^Z w(z)\Delta X_e(z)\,dz
\]

er den arvede vægt positiv. Derfor er F′(Z) > 0 på [50,810]. F vokser strengt med den øvre integrationsgrænse Z på dette interval, og maksimum af |F| begrænset til intervallet ligger i et af de to endepunkter. F(50) indeholder bidraget fra z < 50. Dets fortegn og størrelse kræver fortsat kontrol. Et globalt fortegnsbevis ville reducere maksimumsplaceringen yderligere, mens integralets værdi stadig ville kræve en valideret evaluering.

Opgavens slutgrænse er nået ved z = 50. De to armes arkiverede slutbokse er medtaget i result.json som input til næste indtag. Det nye strenge E > 0 og den ikke-negative temperaturforskel ved grænsen kommer fra sammenligningsbeviset. Den rå forskel mellem de brede enkeltarmsbokse kan stadig omfatte nul.

Der er kørt nul nye native simulationspar og nul fulde historieintegrationer. Næste destination er Resultatindtag og routing 2.3.0. Den skal indtage beviset og vælge en afgrænset opgave for fortegnet under z = 50 med korrekte fase- og reionisationsgrænser. V91 stopper ved den aftalte fasegrænse.
