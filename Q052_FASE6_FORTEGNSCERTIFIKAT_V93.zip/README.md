# Q052 V93 — reproduktion

Dette arkiv indeholder de nye rationelle kontroller, deres output, beviset og hashfastlåste historiske præmisser. Sammen med den separat leverede fulde V93-journal udgør det leverancen. Ingen ny native-kørsel eller fuldhistorieintegration.

Kør fra en udpakket mappe med Python 3:

    python3 certify93.py > replay_result.json
    python3 control93.py > replay_control.json

Sammenlign de genererede bytes med result.json og control.json. verification.json dokumenterer en allerede udført frisk-mappe-reproduktion. De to programmer finder inputs relativt til deres egen placering. Ingen tredjepartspakker kræves for de nye kontroller. Historiske rate-/banepræmisser er indlejret og genbruges; gamle MPFR-kørsler genudføres ikke.

Rækkerne er nulbaserede i det opdelte arkiv. Originalfeltet index gentages ved hændelsesopdelinger. prototype_initial.json er den bevarede diagnostik fra den oprindelige for strenge indeksassertion, ikke et modbevis eller det endelige resultat.

result.json og control.json er de aktuelle videnskabelige kontroloutput. return_task.json er forberedt næste indtag, ikke en udført haleanalyse. manifest.json hasher alle medlemmer undtagen sig selv. input92/manifest.json hasher V92-materialet; dets root_outputs leveres eksternt som den historiske journal/brief. GitHub-upload af V93 og offentlig SoMe-postning er ikke udført.
