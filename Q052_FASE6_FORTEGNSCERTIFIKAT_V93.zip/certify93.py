"""V93: signed lower-face continuation through the bounded V92 phase-6 task.
Exact rational checks; inherited outward rate and trajectory enclosures.
No ODE solver, native pair, or new interpolation calculation.
"""
from pathlib import Path
from fractions import Fraction as F
from time import monotonic
import hashlib, json

P = Path(__file__).resolve().parent
Q = F(1, 1000000)
def read(n): return json.loads((P/n).read_bytes())
def hx(s): return F(float.fromhex(s))
def need(t, s):
    if not t: raise ValueError(s)

def run():
    start = monotonic()
    for n, h in read('pins.json').items():
        need(hashlib.sha256((P/n).read_bytes()).hexdigest() == h, 'input hash '+n)
    task = read('input92/Q052_MATEMATIKOPGAVE_V92.json')
    data, v79, v81, v83 = [read('input92/'+n) for n in ['v64.json','v79.json','v81.json','result83.json']]
    prev = read('input91/result.json')
    need(task['current_q'] == task['target_q'] == 'Q052', 'Q boundary')
    need(prev['status'] == 'ALL_1281_PASS' and prev['combined_positive_z'] == ['50','810'], 'positive entry')
    need(all(data['arms'][a]['seed'] == prev['end_source_boxes'][a] for a in 'LR'), 'seed identity')
    need(v79['prefix_cells'] == 236 and v79['late_from_row'] == 2963, 'task bounds')
    need(v83['new_cells'] == 2727 and v83['source_commit'] == task['source_commit'], 'rate continuation')
    original = read('input91/v19.json')['original_members']
    for n, e in original.items(): need(hashlib.sha256(e['content'].encode()).hexdigest() == e['sha256'], 'original '+n)
    bg = json.loads(original['Q052_BACKGROUND_TRANSFER_INPUTS_V18.json']['content'])
    parent = bg['parent_v17_inputs']; context = parent['native_first_cell_context']
    need(context['frozen']['physics_commit'] == task['source_commit'], 'source revision')
    originals = parent['parent_result']['validator_inputs_original']['files']
    cap = json.loads(originals['q048_prefix_config_v1.json']['content'])['cases']['hillipop-ede_n3']
    need(cap['background']['thermal_flags'] == {'has_varconst':0,'has_exotic_injection':0,'has_idm_b':0,'has_idm_g':0,'has_idm_dr':0,'recombination':1}, 'thermal flags')
    need(cap['background']['flags']['has_idm'] == cap['background']['flags']['has_idr'] == 0, 'extra fields')
    need(cap['frozen_reionization'] == data['map_parameters'], 'common reionization')
    sources = {**context['source_files'], **bg['additional_pinned_sources']}
    for n, e in sources.items(): need(hashlib.sha256(e['content'].encode()).hexdigest() == e['sha256'], 'source '+n)
    for n in ['Alpha_inf.dat','R_inf.dat']: need(min(map(F,sources[n]['content'].split()))>0,'positive rate table')
    constants = cap['thermal_starts'][0]['constants']; T0 = hx(constants['Tcmb'])
    need(T0 > 0 and hx(constants['nH0_SI']) > 0 and hx(constants['fHe_CLASS']) > 0, 'background positivity')
    kmin,kmax = sorted([F('8.617343e-5'),F(float('8.617343e-5'))])
    trmin = min(F('.004'), F(float('.004')))
    vm = max(F('.1'), F(float('.1')))
    fit_start = F(sources['fit_swift.dat']['content'].split()[0])
    need(T0*51 < fit_start and T0*51 < 10000, 'no SWIFT; PPB domain')
    upper,lower = map(F,task['domain']['radiation_transition_descending'])
    cut = F(task['domain']['reionization_z'])
    need(list(map(F,data['events'])) == [upper,lower,cut], 'events')
    L,R = [data['arms'][a]['records'] for a in 'LR']
    need(len(L) == len(R) == 3336, 'archive length')
    inv = 1/F(v81['arms']['R']['h50_lower_exact'])
    floors = {a:F(v81['arms'][a]['v50_lower_rounded_down_1e_minus_6']) for a in 'LR'}
    current = F(50); cells = []; failure = None; edges=set(); groups={}
    for i in range(2963):
        l,r=L[i],R[i]
        try:
            need(l['index']==r['index'] and l['z']==r['z'], 'cell identity')
            za,zb = map(F,r['z']); need(za == current and zb < za, 'contiguity')
            need(r['index']==(0 if i==0 else R[i-1]['index']+(0 if za in [upper,lower,cut] else 1)), 'original index with event splits')
            for a,row in [('L',l),('R',r)]:
                need(row['initial'] == (data['arms'][a]['seed'] if i==0 else data['arms'][a]['records'][i-1]['end']), 'state join')
            hboxes=[list(map(hx,k['whole'][0])) for k in [l,r]]
            vboxes=[list(map(hx,k['whole'][1])) for k in [l,r]]
            need(all(Q < a <= b < 1 for a,b in hboxes), 'hydrogen domain')
            need(all(0 < a <= b <= 1 for a,b in vboxes), 'temperature domain')
            increment = hx(r['K'][1])*hx(r['dt'][1]); need(increment>0,'Riccati increment')
            inv += increment
            improved_h = max(1/inv,hboxes[1][0])
            vl = [max(vboxes[j][0],floors[a]*(1+zb)/51) for j,a in enumerate('LR')]
            need(all(vl[j] <= vboxes[j][1] for j in range(2)), 'nonempty refined temperature')
            hlow = hboxes[1][0] if i<236 else improved_h
            branch = 'PEEBLES' if za<=lower else ('HMLA' if zb>=upper else 'COMMON_TRAD_SWITCH')
            if branch != 'PEEBLES': need(min(vl)>vm, 'no separate temperature dispatch')
            if i<236:
                need(l['branches']==r['branches']==['HMLA'] and branch=='HMLA', 'prefix dispatch')
                candidates=[(j,g) for j,g in enumerate(v79['elasticity_blocks']) if F(g['z'][0])>=za and F(g['z'][1])<=zb]
                need(len(candidates)==1,'V79 rate coverage');gi,g=candidates[0]
                lo,hi=map(F,g['z']); rs=[k for arm in [L,R] for k in arm[:236] if F(k['z'][0])<=lo and F(k['z'][1])>=hi]
                gh=min(hx(k['whole'][0][0]) for k in rs)
                need(hlow>=gh and min(vl)>=F(g['min_v']), 'V79 domain inclusion')
                sratio=F(g['S_over_hmin2_bound']);label='V79:'+str(gi)
            else:
                receipt=v83['cells'][i-236]
                need(receipt['row']==i and receipt['z']==r['z'] and receipt['branch']==branch, 'V83 cell identity')
                need(F(receipt['hR_whole_lower'])==improved_h and list(map(F,receipt['v_whole_lower']))==vl, 'V83 refined domain')
                if branch!='PEEBLES':
                    candidates=[(j,g) for j,g in enumerate(v83['HMLA_blocks']) if F(g['z'][0])>=za and F(g['z'][1])<=zb]
                    need(len(candidates)==1,'V83 rate coverage');gi,g=candidates[0]
                    need(min(vl)>=F(g['v_lower']), 'V83 rate temperature coverage')
                    lo,hi=map(F,g['z']);rs=[k for k in v83['cells'] if F(k['z'][0])<=lo and F(k['z'][1])>=hi]
                    need(hlow>=min(F(k['hR_whole_lower']) for k in rs), 'V83 Saha domain')
                    radiation=[max(trmin,T0*(1+zb)*kmin),T0*(1+za)*kmax]
                    need(hx(g['TR_hex'][0])<=radiation[0]<=radiation[1]<=hx(g['TR_hex'][1]), 'V83 radiation inclusion')
                    sratio=F(g['S_over_hR_squared_upper']);label='V83:'+str(gi)
                else:
                    sratio=F(v83['PPB_S_over_hR_squared_upper']);label='PPB'
                    need(hlow>=F(v83['minimum_improved_hR_lower']), 'PPB Saha domain')
            if branch!='PEEBLES':
                need(-1<hx(g['elasticity_hex'][0])<=hx(g['elasticity_hex'][1])<0, 'HMLA decreasing rate')
            if branch!='HMLA':
                need(-1<hx(v83['PPB_elasticity_hex'][0])<=hx(v83['PPB_elasticity_hex'][1])<0, 'PPB decreasing rate')
                need(0<=F(v83['PPB_S_over_hR_squared_upper'])<1,'PPB positive recombination')
            need(0<=sratio<1, 'positive right loss')
            need(l['lambda']==r['lambda'] and l['end_lambda']==r['end_lambda'], 'common map multipliers')
            for key in ['lambda','end_lambda']: need(0<hx(r[key][0])<=hx(r[key][1])<=1,'positive map '+key)
            need((r['reio_interior']=='identity')==(za>cut), 'map dispatch')
            need(l['reio_interior']==r['reio_interior'], 'common map dispatch')
            need(l['right_endpoint_uses_camb']==r['right_endpoint_uses_camb']==(zb<=cut), 'endpoint dispatch')
            need(not zb<cut<za, 'no unsplit reionization')
            face=[max(hlow,hboxes[0][0]+Q),min(hboxes[1][1],hboxes[0][1]+Q)]
            need(Q<face[0]<=face[1]<1,'nonempty lower face')
            margin=Q/face[1]
            cells.append({'row':i,'source_index':r['index'],'z':r['z'],'branch':branch,'map':r['reio_interior'], 'h_face':list(map(str,face)), 'v_lower':list(map(str,vl)), 'rate_group':label, 'lambda_lower':str(min(hx(r[k][0]) for k in ['lambda','end_lambda'])), 'normalized_face_margin':str(margin),'status':'INWARD'})
            groups[label]=groups.get(label,0)+1;edges.update([za,zb]);current=zb
            need(monotonic()-start<300,'prototype time limit')
        except ValueError as e:
            failure={'row':i,'z':r['z'],'predicate':str(e)};break
    done=failure is None and current==F(task['domain']['z_exact'][0]) and len(cells)==2963
    if done: need({upper,lower,cut}<=edges,'all event edges')
    margin,at=min((F(c['normalized_face_margin']),c['row']) for c in cells)
    return {'schema':'Q052_V93_SIGNED_PHASE6','status':'ALL_2963_PASS' if done else 'FIRST_UNCLOSED_PREDICATE', 'source_commit':task['source_commit'], 'conditional_on':'Inherited fixed B_star, source-real configuration and matched z810 lineage; no new native trajectory claim.', 'new_block_z':[str(current),'50'], 'combined_positive_z':[str(current),'810'], 'cells':cells, 'normalized_face_margin_min':str(margin),'minimum_row':at,'lambda_floor':str(min(F(c['lambda_lower']) for c in cells)), 'rate_group_counts':groups,'obstruction':failure, 'end_source_boxes':{a:data['arms'][a]['records'][2962]['end'] for a in 'LR'} if done else None, 'ending_interface':{'z':str(current),'E':'strictly positive','vL_minus_vR':'nonnegative','hR_lower':str(improved_h),'v_lower':list(map(str,vl))} if done else None,'new_native_pairs':0,'new_full_history_integrations':0}

if __name__=='__main__': print(json.dumps(run(),indent=2))
