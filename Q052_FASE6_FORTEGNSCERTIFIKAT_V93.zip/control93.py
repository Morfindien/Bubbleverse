"""Separate grouped enclosure and algebraic control of the V93 lower face.
Does not import certify93 or read its results. Different exact hex parser,
outward rounded reciprocal sums, outer group bounds, analytic PPB derivative.
"""
from pathlib import Path
from fractions import Fraction as F
from math import ceil
from collections import Counter
import json,hashlib
P=Path(__file__).resolve().parent
q=F(1,10**6)
def load(n): return json.loads((P/n).read_text())
def binary(s):
    mantissa,exponent=s.lower().split('p');sign=-1 if mantissa.startswith('-') else 1
    mantissa=mantissa.lstrip('+-')[2:];a,b=mantissa.split('.')
    e=int(exponent)-4*len(b);value=sign*int(a+b,16)
    return F(value*2**e) if e>=0 else F(value,2**(-e))
def run():
    for n,h in load('pins.json').items(): assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h
    task=load('input92/Q052_MATEMATIKOPGAVE_V92.json');d=load('input92/v64.json')
    rate79=load('input92/v79.json');rate83=load('input92/result83.json');temp=load('input92/v81.json')
    parent=load('input91/result.json'); assert parent['combined_positive_z']==['50','810']
    A,B=[d['arms'][a]['records'][:2963] for a in 'LR'];assert len(A)==len(B)==2963
    for a in 'LR':assert d['arms'][a]['seed']==parent['end_source_boxes'][a]
    upper,lower=map(F,task['domain']['radiation_transition_descending']);cut=F(task['domain']['reionization_z'])
    # Each reciprocal increment is rounded UP to an independent decimal grid.
    scale=10**12;inv=F(ceil(scale/F(temp['arms']['R']['h50_lower_exact'])),scale)
    rows=[];edges=set();previous=F(50)
    for i,(a,b) in enumerate(zip(A,B)):
        top,bottom=map(F,b['z']);assert b['z']==a['z'] and top==previous>bottom;previous=bottom
        assert i-sum(top<=e for e in [upper,lower,cut])==a['index']==b['index'];edges.update([top,bottom])
        for arm,row in [('L',a),('R',b)]:assert row['initial']==(d['arms'][arm]['seed'] if i==0 else d['arms'][arm]['records'][i-1]['end'])
        inv+=F(ceil(binary(b['K'][1])*binary(b['dt'][1])*scale),scale)
        rawh=min(binary(x['whole'][0][0]) for x in (a,b));topH=max(binary(x['whole'][0][1]) for x in (a,b))
        hr=max(binary(b['whole'][0][0]),1/inv)
        vv=[max(binary(row['whole'][1][0]),F(temp['arms'][arm]['v50_lower_rounded_down_1e_minus_6'])*(1+bottom)/51) for arm,row in [('L',a),('R',b)]]
        assert q<rawh<=topH<1 and hr>q and all(0<vv[j]<=binary(row['whole'][1][1])<=1 for j,row in enumerate([a,b]))
        kind='PEEBLES' if top<=lower else ('HMLA' if bottom>=upper else 'COMMON_TRAD_SWITCH')
        if kind!='PEEBLES': assert min(vv)>F(3602879701896397,36028797018963968)
        if i<236: assert a['branches']==b['branches']==['HMLA']
        else:assert rate83['cells'][i-236]['z']==b['z'] and rate83['cells'][i-236]['branch']==kind
        assert a['lambda']==b['lambda'] and a['end_lambda']==b['end_lambda']
        lam=min(binary(row[k][0]) for row in [a,b] for k in ['lambda','end_lambda'])
        assert lam>0 and all(binary(row[k][1])<=1 for row in [a,b] for k in ['lambda','end_lambda'])
        assert a['reio_interior']==b['reio_interior']==('identity' if top>cut else 'camb')
        assert a['right_endpoint_uses_camb']==b['right_endpoint_uses_camb']==(bottom<=cut)
        assert not bottom<cut<top
        rows.append(dict(row=i,top=top,bottom=bottom,hR=hr,hRraw=binary(b['whole'][0][0]),hmax=topH,rawh=rawh,v=min(vv),kind=kind,lam=lam))
    assert previous==F(task['domain']['z_exact'][0]) and {upper,lower,cut}<=edges
    coverage=Counter();summaries=[]
    for origin,groups in [('V79',rate79['elasticity_blocks']),('V83',rate83['HMLA_blocks'])]:
        for j,g in enumerate(groups):
            top,bottom=map(F,g['z']);rs=[r for r in rows if bottom<=r['bottom'] and r['top']<=top]
            assert rs and rs[0]['top']==top and rs[-1]['bottom']==bottom
            assert all(r['kind']!='PEEBLES' for r in rs)
            assert -1<binary(g['elasticity_hex'][0])<=binary(g['elasticity_hex'][1])<0
            vmin=F(g['min_v' if origin=='V79' else 'v_lower']);assert min(r['v'] for r in rs)>=vmin
            if origin=='V79':
                # V79 S bound is normalized by minimum h over BOTH raw arms.
                gh=min(r['rawh'] for r in rs);actual=min(r['hRraw'] for r in rs)
                ratio=F(g['S_over_hmin2_bound'])*(gh/actual)**2
            else:
                old=min(F(rate83['cells'][r['row']-236]['hR_whole_lower']) for r in rs)
                actual=min(r['hR'] for r in rs)
                ratio=F(g['S_over_hR_squared_upper'])*(old/actual)**2
                assert actual<=old
            assert 0<=ratio<1
            bound=q/max(r['hmax'] for r in rs)
            for r in rs:coverage[r['row']]+=1
            summaries.append({'group':origin+':'+str(j),'rows':[rs[0]['row'],rs[-1]['row']], 'count':len(rs),'normalized_margin_lower':str(bound),'S_ratio_adjusted':str(ratio)})
    # PPB derivative: -a-b*Y/(1+Y)<0 for a,b,Y>0. With Tm<10000K,
    # Y<c, so the following coarse exact upper bound is also <1.
    hi=lambda x:max(F(x),F(float(x)))
    pp=hi('.6166')+hi('.5300')*hi('.6703')/(1+hi('.6703'));assert pp<1
    rs=[r for r in rows if r['kind']!='HMLA'];assert rs
    old=F(rate83['minimum_improved_hR_lower']);actual=min(r['hR'] for r in rs)
    ratio=F(rate83['PPB_S_over_hR_squared_upper'])*(old/actual)**2;assert 0<=ratio<1
    for r in rs:coverage[r['row']]+=1
    summaries.append({'group':'PPB','rows':[rs[0]['row'],rs[-1]['row']], 'count':len(rs),'normalized_margin_lower':str(q/max(r['hmax'] for r in rs)), 'S_ratio_adjusted':str(ratio)})
    assert all(coverage[r['row']]==(2 if r['kind']=='COMMON_TRAD_SWITCH' else 1) for r in rows)
    # Exact polynomial cross-product identities for dC/de. Exponents are
    # (beta_s,beta_p,Lambda,j); sparse dictionaries avoid sampling.
    def add(*xs):
        out=Counter()
        for x in xs:
            for k,v in x.items():out[k]+=v
        return {k:v for k,v in out.items() if v}
    def mul(a,b):
        out=Counter()
        for x,v in a.items():
            for y,w in b.items():out[tuple(i+j for i,j in zip(x,y))]+=v*w
        return dict(out)
    def neg(a):return {k:-v for k,v in a.items()}
    s,p,l,j=[{tuple(int(i==k) for i in range(4)):1} for k in range(4)]
    j3={k:3*v for k,v in j.items()};G=add(s,l,j3)
    D0=add(mul(add(s,l),add(p,j)),mul(j3,p));K=add(mul(G,p),mul(j,s))
    Cs=add(mul(add(l,j3),D0),neg(mul(mul(l,add(p,j)),G)))
    Cp=add(mul(G,D0),neg(mul(mul(l,j),G)))
    assert Cs==mul(j3,K) and Cp==mul(G,K)
    return {'schema':'Q052_V93_GROUPED_ALGEBRAIC_CONTROL','status':'PASS','cells':2963,'groups':summaries,'branch_counts':dict(Counter(r['kind'] for r in rows)), 'all_events_checked':True,'normalized_face_margin_lower':str(min(F(x['normalized_margin_lower']) for x in summaries)), 'lambda_lower':str(min(r['lam'] for r in rows)), 'PPB_abs_elasticity_upper':str(pp),'C_derivative_polynomial_identities':'PASS: 3jK and GK; Peebles 3 beta/(3R+Lambda+beta)^2>0', 'independence':'Independent hex parser, outward coarsened reciprocal sums and outer group bounds; no V93 producer result read. Shared pinned source, inherited trajectory and rate certificates; no new simulations.'}
if __name__=='__main__':print(json.dumps(run(),indent=2))
