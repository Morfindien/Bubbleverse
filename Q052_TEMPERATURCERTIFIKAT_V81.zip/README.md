# Q052 V81 – reproducerbar temperaturkontrol

Krav: Python 3.10+ og systembiblioteket libmpfr (V20-backend bruger ctypes). Ingen Python-pakker ud over standardbiblioteket kræves. Kør fra en frisk udpakning:

```bash
python3 temperature81.py > replay_result.json
cmp replay_result.json result.json
python3 control81.py > replay_control.json
cmp replay_control.json control.json
```

Kør uden Python -O. Hvert gennemløb stopper, hvis 300 sekunder overskrides. På langsommere hardware er dette en ressourceafbrydelse, ikke et negativt fysisk resultat. Ingen netværksadgang eller CLASS-kørsel er nødvendig.

PROOF_V81.md giver ligninger, scope og uafhængighedsgrænser. result.json indeholder 1.526 koefficient-/tilstandsspor per arm. control.json er den separate decimal/Newton-beregning. activity_ledger.json bevarer historikken; return_task.json er næste motors endnu ikke udførte opgave. De tre historiske ZIP-filer er uændrede afhængigheder. Deres arkiv- og medlemshash er kontrolleret mod den arvede journal. De tidligere beregninger er ikke kørt igen i V81.

manifest.json indeholder medlemskontrolsummer. verification.json dokumenterer genkørsel fra frisk udpakning. GitHub-status: kildejournal og motor verificeret ved den angivne commit; nye filer klar til manuel upload.
