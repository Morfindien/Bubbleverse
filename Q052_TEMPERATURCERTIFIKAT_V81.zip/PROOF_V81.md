# Q052 V81 · Temperaturtesten består på den fastholdte baggrund

**BEREGNET / MODELINFERERET.** For hver af de to kilde-reelle løsninger med samme matchede start ved rødforskydning 810 og samme B★ beviser vi

| Nedre grænse ved z = 50 | L, q = 10⁻⁶ | R, q = 0 |
| --- | ---: | ---: |
| MPFR-kontrol, vist omtrent | 0,3279018866925851 | 0,3278999647334665 |
| Uafhængig decimalkontrol, vist omtrent | 0,3280698812102323 | 0,3280679443527950 |
| Fælles godkendt resultat, rundet ned | **0,327901** | **0,327899** |

Tallene er nedre grænser for v = Tm/Tγ, ikke beregnede ligheder for den faktiske temperatur. De to kontroller må godt give forskellige grænser: de indhyller de samme tabeller med forskellige polynomielle repræsentationer og afrundingsregler. Begge giver den fælles godkendte grænse. Ingen tilpasning af fysiske parametre eller ny CLASS-kørsel indgår.

V80's strenge krav er omtrent 0,2994537464178751 for hver arm. Den mindste margin fra den primære beregning er større end 0,028446. Dermed kan v-tærsklen 0,1 ikke udløse et formelskift i nogen arm mellem 50 og det fælles strålingstemperaturskift omkring z = 16,03101084. På den konservative nedre kant af dette skift er begge v stadig mindst 0,109499. Den mulige adskillelse af formelvalget, som V79 identificerede via v-tærsklen, er således udelukket langs disse kildebaner. Det siger ikke, at alle andre skift eller elektronloftets øvrige betingelser er afgjort.

## Præmisser og afgrænsning

Kilden er commit `5a131c91d657dd9a7c6364cc45b038710f8d0d97`, case `hillipop-ede_n3`. B★ er V73's fastholdte tidlige startværdiproblem. Q048's kvalificerede præfiks, V62's kildeindeslutninger og V77's monotonicitetsbevis arves uændret. De omfatter de erklærede kilde-/grenpræmisser, herunder positiv escape-rate. Det er samme betingede kilde-reelle problem som i V80, ikke en ny binding af alle native runtime-input til B★.

V62 giver de to startbokse ved `1779416633043845/2199023255552` og 1.526 sammenhængende helcellebokse per arm ned til 50. Deres start er allerede afledt af den matchede start ved 810. Vi flytter ikke startværdierne til den gemte native kurve. V62's øvre grænser giver 0 < h < 1 og 0,1 < v < 1 gennem beregningsområdet. Efter 50 bruges V80's allerede dokumenterede positive-opvarmningsulighed og præcise fælles strålingstærskel. Der udføres ingen ny fuld historieintegration.

## Skarpere grænser for H

Sæt p = 1+z. De fastholdte almindelige arter giver

\[
B_0(p)=H_0^2[(\Omega_b+\Omega_c)p^3+(\Omega_\gamma+\Omega_{ur})p^4]
+f_\nu p^3\sum_j q_j^2w_j\sqrt{q_j^2p^2+M^2}.
\]

Alle 11 neutrino-knuder og vægte er positive. Hvert led er derfor voksende i p. De indfangede binary64-parametre behandles som eksakte input, og de skrevne kildekonstanter indhylles sammen med deres binary64-værdier. Den fastholdte baggrund har nul krumning og ingen særskilt kosmologisk konstant i B₀.

Da H² = B₀ + (e+f)/3 og e ≥ 0, følger en nedre grænse fra B₀ ved cellens nedre p og f_min. En øvre grænse bruger B₀ ved øvre p og et loft for e. Fra 810 til 120 bruger vi den seneste godkendte Q048/V12-energirække, hvis venstrekant ligger over eller ved cellens øvre z. Monoton energi gør dens E_input_left gyldig i hele cellen, også hvis cellen krydser en energirækkes kant. Ved z ≤ 120 bruges V73's beviste loft

\[
e(z)<\frac{2}{25}\left(\frac{1+z}{121}\right)^3.
\]

V73-barrierens eksakte numeriske uligheder genkontrolleres. Det kvalificerede præfiks genberegnes ikke. De resulterende H-grænser skæres med V62's allerede gyldige H-grænser og omregnes fra Mpc⁻¹ til s⁻¹ med de indhyldede kildekonstanter c/Mpc.

## Ensidig sammenligning på én celle

Lad a > b være cellens rødforskydningsender, Δu = ln[(1+a)/(1+b)] og u = ln[811/(1+z)]. Antag dokumenterede startgulve h₀ og v₀. Fra

\[
v'=-v+A(1-v),\qquad A>0,\quad 0<v\le1
\]

følger det foreløbige helcellegulv v₀(1+b)/(1+a). Tag maksimum af dette og V62's helcellegulv. V77 beviser ∂log αᵢ/∂log v < 0 på hele den relevante strimmel op til 1; hver anvendt celle kontrolleres mod strimlens præcise domæne. Derfor kan en øvre grænse for begge rekombinationsrater findes ved dette v-gulv og hele strålingstemperaturintervallet. De faktiske stykvist kubiske logtabeller bruges, inklusive randstencils. Der er ingen interpolation mellem gemte native temperaturer.

På begge tilladte HMLA/SWIFT-grene er 0 < Cᵢ ≤ 1, og fotoionisationsleddet er ikke-negativt. Med X = h+q fås

\[
h'\ge -K h(h+q)\ge -K X^2,\qquad
K=\sup_{\rm celle}\frac{n_H}{H_s}\sum_i\alpha_i.
\]

Her er n_H i cm⁻³, αᵢ i cm³/s og H_s i s⁻¹. Den eksakte Riccati-sammenligning giver hele cellen og dens slutpunkt gulvet

\[
h\ge \frac{h_0+q}{1+K(h_0+q)\Delta u}-q.
\]

Gulvet kombineres med den relevante arvede helcelle- eller slutboks. På hele cellen er Compton-koefficienten derfor mindst

\[
A_* = \inf\!\left[\frac{K_C\rho_\gamma}{H_s}
\frac{h_{\rm gulv}+q}{1+f_{He}+h_{\rm gulv}+q}\right]>0.
\]

K_C og ργ følger direkte den fastholdte kildes enheder. Da v ≤ 1, er det konstante felt −v+A_*(1−v) en nedre sammenligning. Dets eksakte løsning giver

\[
v_{\rm slut}\ge \frac{A_*}{1+A_*}+
\left(v_0-\frac{A_*}{1+A_*}\right)e^{-(1+A_*)\Delta u}.
\]

Det nye gulv kombineres med V62's slutgulv og føres videre til næste celle. Induktion over alle 1.526 celler giver det dokumenterede resultat ved 50. Hvert trin er en lukket sammenligningsulighed på en allerede godkendt kildeboks. Der bruges hverken nye native par, en numerisk repræsentationsbane som sand løsning eller en ny fuld ODE-integration.

## To numeriske kontrolspor

`temperature81.py` anvender den uændrede V20-backend med udadrettet MPFR-aritmetik og Lagrange-form for de kubiske logtabeller. `result.json` indeholder alle cellers anvendte koefficienter, startgulve og slutgulve som eksakte brøker eller binary64-hex.

`control81.py` importerer hverken producenten eller dens intervalbackend. Den bruger 50-cifret decimalintervalaritmetik, rettet afrunding af de fire regnearter, korrekt afrundede sqrt/ln/exp udvidet med én hel ulp og Newtons dividerede differenser for kildepolynomierne. Tilstandsgulvene rundes ned til 40 decimaler efter hvert trin. Hele koefficient- og sammenligningsberegningen udføres igen fra kildedata. Kontrolsporet giver selvstændigt en tilstrækkelig nedre temperaturgrænse i begge arme.

Kontrollerne er uafhængige af hinandens aritmetik og polynomielle evalueringsform. De deler de fastholdte input, ligninger og de arvede analytiske præmisser. Dette er ikke to uafhængige observationer af universet. Begge scripts håndhæver en øvre køretidsgrænse på 300 sekunder per gennemløb.

## Konsekvens og næste afgrænsede opgave

V80's temperaturtest er afsluttet med betinget PASS. De gemte native v(50)-værdier minus kildeværdierne er nu højst omtrent 0,037761633 i L og 0,037557856 i R; begge overholder det alternative tilstrækkelige krav 0,065. Dette er ensidige fejlgrænser ved ét slutpunkt, ikke absolutte fejlgrænser for hele historien.

V79's konkrete blandede punkt nær z = 46,452 kræver v omkring 0,1; det er nu uforeneligt med de opnåede kildegulve. Et nyt elektronloft på hele mellemstykket følger ikke alene af dette. De øvrige hydrogen-/temperaturflader og de bogstavelige senere grenskift skal fortsat kontrolleres. V78's øvre Thomson-grænse 0,00092647 er uændret; det realiserede globale maksimum er fortsat uafgjort.

Resultatet afleveres til **Resultatindtag og routing 2.3.0**. Denne motor skal indtage V81 én gang, afgrænse de nu bortfaldne temperaturforhindringer og forberede kontrollen af de resterende flader med de nye temperaturgulve. V81 gennemfører ikke den næste motors opgave. **Q052: ACTIVE / INCONCLUSIVE.**
