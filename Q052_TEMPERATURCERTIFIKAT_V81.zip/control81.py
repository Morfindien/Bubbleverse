"""Independent decimal interval control. No import of the MPFR producer.
Decimal contexts use directed arithmetic, and correctly-rounded transcendentals
are widened by one ulp. Cubic rates use Newton form, not producer Lagrange form.
Shares the archived source data and the V62/V73/V77 analytic premises.
Run: python3 control81.py > control.json
"""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal as D,Context,ROUND_FLOOR,ROUND_CEILING,ROUND_HALF_EVEN
import json,hashlib,time,sys,math
P=50;dn=Context(prec=P,rounding=ROUND_FLOOR);up=Context(prec=P,rounding=ROUND_CEILING);near=Context(prec=P,rounding=ROUND_HALF_EVEN)
ROOT=Path(__file__).resolve().parent
def dec(x,ctx):
 if isinstance(x,D):return x
 x=F(x);return ctx.divide(D(x.numerator),D(x.denominator))
class J:
 def __init__(self,a,b=None):self.lo=dec(a,dn);self.hi=dec(a if b is None else b,up);assert self.lo<=self.hi
 def __add__(self,b):
  b=b if isinstance(b,J) else J(b);return J(dn.add(self.lo,b.lo),up.add(self.hi,b.hi))
 __radd__=__add__
 def __neg__(self):return J(self.hi.copy_negate(),self.lo.copy_negate())
 def __sub__(self,b):return self+(-b if isinstance(b,J) else -J(b))
 def __rsub__(self,b):return J(b)+(-self)
 def __mul__(self,b):
  b=b if isinstance(b,J) else J(b);pairs=[(x,y) for x in [self.lo,self.hi] for y in [b.lo,b.hi]]
  return J(min(dn.multiply(x,y) for x,y in pairs),max(up.multiply(x,y) for x,y in pairs))
 __rmul__=__mul__
 def __truediv__(self,b):
  b=b if isinstance(b,J) else J(b);assert b.lo>0 or b.hi<0
  return self*J(dn.divide(D(1),b.hi),up.divide(D(1),b.lo))
 def __rtruediv__(self,b):return J(b)/self
 def trans(self,name):
  fn=getattr(near,name);a=fn(self.lo);b=fn(self.hi)
  # Correct rounding to nearest has error <= half a last-place unit.
  ea=D(10)**(a.adjusted()-P+1);eb=D(10)**(b.adjusted()-P+1)
  return J(dn.subtract(a,ea),up.add(b,eb))
 def sqrt(self):assert self.lo>0;return self.trans('sqrt')
 def log(self):assert self.lo>0;return self.trans('ln')
 def exp(self):return self.trans('exp')
def literal(s):return J(min(F(s),F(float(s))),max(F(s),F(float(s))))
def hx(s):return F(float.fromhex(s))
def load(n):return json.loads((ROOT/n).read_bytes())
def cubic(y,t):
 # Newton divided differences at nodes 0,1,2,-1.
 a=y[2]-y[1];b=y[3]-2*y[2]+y[1];c=y[3]-3*y[2]+3*y[1]-y[0]
 return y[1]+t*a+t*(t-1)*b/2+t*(t-1)*(t-2)*c/6

def pieces(q,n):
 for j in range(1,n-2):
  lo=q.lo if j==1 else max(q.lo,D(j));hi=q.hi if j==n-3 else min(q.hi,D(j+1))
  if lo<=hi:yield j,J(lo,hi)-j

def run():
 start=time.monotonic();primary=load('result.json')
 for n,expected in primary['input_sha256'].items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==expected
 bundle=load('v19.json')['original_members']
 def checked(item):
  b=item['content'].encode();assert hashlib.sha256(b).hexdigest()==item['sha256'];return item['content']
 for item in bundle.values():checked(item)
 data=json.loads(checked(bundle['Q052_BACKGROUND_TRANSFER_INPUTS_V18.json']))
 parent=data['parent_v17_inputs'];native=parent['native_first_cell_context'];raw=parent['parent_result']['validator_inputs_original']['files']
 sources={**native['source_files'],**data['additional_pinned_sources']}
 for item in list(raw.values())+list(sources.values()):checked(item)
 cap=json.loads(checked(raw['q048_prefix_config_v1.json']))['cases']['hillipop-ede_n3'];g=json.loads(checked(raw['q048_guard_local_v_result_v12.json']))
 f={k:hx(v) for k,v in cap['background']['fields'].items()};cons=cap['thermal_starts'][0]['constants'];T0,n0,he=[hx(cons[k]) for k in ['Tcmb','nH0_SI','fHe_CLASS']]
 rho0=f['Omega0_g']*f['H0']**2;kB=literal('8.617343e-5');conv=literal('2.99792458e8')/literal('3.085677581282e22')
 heat=2*literal('6.6524616e-29')/(literal('9.10938215e-31')*literal('2.99792458e8'))*(J(4)/3)*literal('0.0151730087')
 n=cap['background']['neutrinos'][0];qs,ws=[list(map(hx,n[k])) for k in ['q_ncdm_bg','w_ncdm_bg']];M,fac=[hx(n['fields'][k]) for k in ['M_ncdm','factor_ncdm']]
 assert len(qs)==len(ws)==11 and min(qs+ws+[M,fac])>0 and f['K']==f['Omega0_lambda']==0
 def B0(p):
  p2=p*p;p3=p2*p;p4=p2*p2
  return J(f['H0']**2)*(J(f['Omega0_b']+f['Omega0_cdm'])*p3+J(f['Omega0_g']+f['Omega0_ur'])*p4)+J(fac)*p3*sum((J(q*q*w)*(p2*J(q*q)+J(M*M)).sqrt() for q,w in zip(qs,ws)),J(0))
 vals=sources['Alpha_inf.dat']['content'].split();assert len(vals)==100*40*4
 logs=[[[literal(vals[(i*40+j)*4+l]).log() for i in range(100)] for j in range(40)] for l in range(2)]
 logmin=literal('0.004').log();dlog=(literal('0.4').log()-logmin)/99;vmin=literal('0.1');dv=(1-vmin)/39
 def rates(tr,vl):
  qt=(tr.log()-logmin)/dlog;qv=(J(vl)-vmin)/dv
  out=[[],[]]
  for it,t in pieces(qt,100):
   for iv,s in pieces(qv,40):
    for l in range(2):out[l].append(cubic([cubic(logs[l][j][it-1:it+3],t) for j in range(iv-1,iv+3)],s).exp())
  return [max(x.hi for x in a) for a in out]
 tubes=load('v62.json');v77=load('v77.json');v73=load('v73.json');rows=g['evaluators'][0]['rows'];energy=rows[64:133]
 S=F(2,25);assert v73['S']==str(S);floorlo,floorhi=[F(g['source_intervals'][k]) for k in ['floorlo','floorhi']]
 threshold=F(primary['criterion_exact_strict']['through_common_radiation_switch']);ans={}
 for arm,q in [('L',F(1,1000000)),('R',F(0))]:
  a=tubes['arms'][arm];h,v=[hx(box[0]) for box in a['initial']];stencils=0
  for index,row in enumerate(a['records']):
   za,zb=map(hx,row['z']);pa,pb=za+1,zb+1;p=J(pb,pa);dt=J(pa/pb).log()
   if za>120:E=F([r for r in energy if r['z0']>=za][-1]['E_input_left'])
   else:E=S*(pa/121)**3
   H0=J((B0(J(pb))+J(floorlo)/3).sqrt().lo,(B0(J(pa))+(J(E)+J(floorhi))/3).sqrt().hi)*conv
   H=J(max(H0.lo,dec(hx(row['H_per_s'][0]),dn)),min(H0.hi,dec(hx(row['H_per_s'][1]),up)))
   cold=max(hx(row['whole_source'][1][0]),v*pb/pa)
   blocks=[b for b in v77['elasticity_blocks'] if F(b['z'][0])>=za and F(b['z'][1])<=zb]
   assert blocks and all(cold>=F(b['v_lower']) and hx(b['elasticity_hex'][1])<0 for b in blocks)
   al=rates(J(T0)*p*kB,cold);nH=J(n0)*literal('1e-6')*p*p*p;rho=J(rho0)*p*p*p*p
   K=J((nH*(J(al[0])+J(al[1]))/J(H.lo)).hi)
   hcmp=F((J(h+q)/(1+K*J(h+q)*dt)-J(q)).lo)
   whole=max(hx(row['whole_source'][0][0]),hcmp);h=max(hx(row['end_source'][0][0]),hcmp)
   A=J((heat*J(rho.lo)/J(H.hi)*J((whole+q)/(1+he+whole+q))).lo);eq=A/(1+A)
   v=max(hx(row['end_source'][1][0]),F((eq+(J(v)-eq)*(-(1+A)*dt).exp()).lo))
   # Round lower states down to 40 decimal places to keep rational sizes bounded.
   h=F((h*10**40)//1,10**40);v=F((v*10**40)//1,10**40)
   assert 0<h<=hx(row['end_source'][0][1]) and 0<v<=hx(row['end_source'][1][1])
   if index%500==0:print(arm,index,float(v),'seconds',round(time.monotonic()-start,2),file=sys.stderr,flush=True)
   assert time.monotonic()-start<300,'Bounded independent control exceeded 300 seconds'
  assert zb==50
  ans[arm]={'h50_lower_exact':str(h),'v50_lower_exact':str(v),'v50_lower_display':float(v),'v50_lower_rounded_down_1e_minus_6':str(F(v*1000000//1,1000000)),'strict_threshold_margin':str(v-threshold),'full_selector_criterion_pass':v>threshold}
 assert all(a['full_selector_criterion_pass'] for a in ans.values())
 return {'schema':'Q052_V81_INDEPENDENT_DECIMAL_NEWTON_CONTROL','status':'PASS_CONDITIONAL','arithmetic':'50-digit directed decimal arithmetic; correctly-rounded sqrt/ln/exp widened by a full ulp; lower state truncation at 40 decimal places','interpolation':'Newton divided-difference form on the literal four-node source stencil, including boundary extrapolation; monotone-alpha theorem inherited from V77','cells_per_arm':1526,'arms':ans,'independence_limits':'Independent arithmetic and interpolation representation; shared frozen data, physical equations, and inherited V62/V73/V77 analytic premises. No independent cosmology or observation.','primary_result_sha256':hashlib.sha256((ROOT/'result.json').read_bytes()).hexdigest()}
if __name__=='__main__':print(json.dumps(run(),indent=2)+'\n',end='')
