"""Q052 V81: one-sided analytic cell comparisons; no native or full ODE run.
Run: python3 temperature81.py > result.json
Requires the pinned V20 MPFR interval backend and source bundle, inherited
V62 tubes, V73 fixed-background theorem and V77 rate monotonicity theorem.
"""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys,time
import v20 as m
ROOT=Path(__file__).resolve().parent
PIN={
 'v19.json':'3f3838394c1a85b2fa592dc2fb4c66d7c67e3d6c74a07873b9a060c22aebe89c',
 'v20.py':'d0feecd36359005a55fb91c26aee2381f9ed1652177395acf7ec482ea0e880fa',
 'v62.json':'63480c24d61350c9913ed3072e09c91c097049791165fa964cfa096f7d0d4ca8',
 'task80.json':'d4987bc056099d2e85b5c9b739e19a0d563da28d6ed13f1807ee1b6bb10d8444'}
def digest(b):return hashlib.sha256(b).hexdigest()
def load(n):
 b=(ROOT/n).read_bytes()
 if n in PIN:assert digest(b)==PIN[n],n
 return json.loads(b)
def hx(s):return F(float.fromhex(s))
def out(x):return x.hex()
def run():
 start=time.monotonic()
 assert __debug__
 assert digest((ROOT/'v20.py').read_bytes())==PIN['v20.py']
 c=m.Context(ROOT/'v19.json');I=m.I;enc=m.enc
 d=load('v62.json');v73=load('v73.json');v77=load('v77.json');task=load('task80.json')
 g=json.loads(c.raw['q048_guard_local_v_result_v12.json']['content'])
 assert v73['guard_sha256']==c.raw['q048_guard_local_v_result_v12.json']['sha256']
 assert v73['S']=='2/25' and v77['status']=='PASS_UNDER_FROZEN_PREMISES'
 rows=g['evaluators'][0]['rows'];energy=rows[64:133]
 for i,r in enumerate(energy,64):
  assert r['z0']==810-10*(i-64) and r['z1']==r['z0']-10
  assert r['committed'] and r['whole_cell_qualified'] and F(r['G_lower'])>0
  assert r['E_input_left']==rows[i-1]['E_right']
 fields=c.capture['background']['fields'];f={n:hx(v) for n,v in fields.items()}
 assert f['Omega0_lambda']==f['K']==0 and len(c.capture['background']['neutrinos'])==1
 nn=c.capture['background']['neutrinos'][0]
 qs,ws=[list(map(hx,nn[k])) for k in ['q_ncdm_bg','w_ncdm_bg']]
 M,fac=[hx(nn['fields'][k]) for k in ['M_ncdm','factor_ncdm']]
 assert len(qs)==len(ws)==11 and min(qs+ws+[M,fac])>0
 floorlo,floorhi=[F(g['source_intervals'][k]) for k in ['floorlo','floorhi']]
 def B0(p):
  # p^4 sqrt(q^2+(M/p)^2) = p^3 sqrt((pq)^2+M^2), monotone in p.
  return enc(f['H0']**2)*(enc(f['Omega0_b']+f['Omega0_cdm'])*p*p*p+enc(f['Omega0_g']+f['Omega0_ur'])*p*p*p*p)+enc(fac)*p*p*p*sum((enc(q*q*w)*((p*enc(q))*(p*enc(q))+enc(M*M)).sqrt() for q,w in zip(qs,ws)),I(0))
 conv=m.lit('2.99792458e8')/m.lit('3.085677581282e22')
 # Recheck the exact V73 scalar barrier (prefix remains an inherited premise).
 S=F(2,25);delta=F(1,6);alpha=F(24,23);k=F(90,23);beta=F(1152,529)
 Bup=f['H0']**2*((f['Omega0_b']+f['Omega0_cdm'])*121**3+(f['Omega0_g']+f['Omega0_ur'])*121**4)+fac*121**4*sum(q*q*w*(q+M/121) for q,w in zip(qs,ws))
 C=Bup+(S+floorhi*121**3)/3
 assert str(Bup)==v73['Bstar_upper'] and str(C)==v73['C']
 assert F(rows[132]['E_right'])<S and F(rows[132]['Y_right'])<(1-alpha*delta)*S
 assert 2*C<delta**2*S*F(g['source_intervals']['lamlo'])**2
 assert (k-3)*(1-alpha*delta)>beta*delta
 results={};trace={}
 for arm,q in [('L',F(1,1000000)),('R',F(0))]:
  armdata=d['arms'][arm];h,v=[hx(a[0]) for a in armdata['initial']];trace[arm]=[]
  assert len(armdata['records'])==1526 and armdata['initial']==armdata['records'][0]['initial']
  for index,row in enumerate(armdata['records']):
   za,zb=map(hx,row['z']);pa,pb=za+1,zb+1
   assert za>zb>=50
   if index:assert armdata['records'][index-1]['z'][1]==row['z'][0]
   assert h<=hx(row['initial'][0][1]) and v<=hx(row['initial'][1][1])
   p=enc(pb,pa);dt=enc(pa/pb).log();_,TR,nH,rho=c.background(p)
   if za>120:
    eligible=[r for r in energy if r['z0']>=za]
    er=eligible[-1];E=F(er['E_input_left']);etag='V12:'+str(er['z0'])
   else:E=S*(pa/121)**3;etag='V73:2/25*((1+z_upper)/121)^3'
   Hraw=I((B0(enc(pb))+enc(floorlo)/3).sqrt().lo,(B0(enc(pa))+(enc(E)+enc(floorhi))/3).sqrt().hi)*conv
   H=I(max(Hraw.lo,float.fromhex(row['H_per_s'][0])),min(Hraw.hi,float.fromhex(row['H_per_s'][1])))
   assert 0<H.lo<=H.hi
   cold=max(hx(row['whole_source'][1][0]),v*pb/pa)
   blocks=[b for b in v77['elasticity_blocks'] if F(b['z'][0])>=za and F(b['z'][1])<=zb]
   assert blocks and all(cold>=F(b['v_lower']) and hx(b['elasticity_hex'][1])<0 for b in blocks)
   rates,_,_,_=c.rates(TR,enc(cold))
   # Monotone alpha on [cold,1] gives this whole-state upper rate.
   rate=sum(rates,I(0));K=I((nH*rate/I(H.lo)).hi)
   hi,vi=h,v
   hcmp=((enc(h+q)/(1+K*enc(h+q)*dt))-enc(q)).lo
   hwhole=max(hx(row['whole_source'][0][0]),F(hcmp))
   h=max(hx(row['end_source'][0][0]),F(hcmp))
   assert hwhole>0 and h>0
   A=I((c.K*I(rho.lo)/I(H.hi)*enc((hwhole+q)/(1+c.he+hwhole+q))).lo)
   eq=A/(1+A);vcmp=(eq+(enc(v)-eq)*(-(1+A)*dt).exp()).lo
   v=max(hx(row['end_source'][1][0]),F(vcmp))
   assert v<1 and h<=hx(row['end_source'][0][1]) and v<=hx(row['end_source'][1][1])
   trace[arm].append({'i':index,'z':row['z'],'initial_lower':[str(hi),str(vi)],'dt':out(dt),'E_upper':str(E),'E_rule':etag,'H_per_s':out(H),'cold_whole_lower':str(cold),'alpha_upper':[a.hi.hex() for a in rates],'K_upper':K.hi.hex(),'h_comparison_lower':hcmp.hex(),'h_whole_lower':str(hwhole),'A_lower':A.lo.hex(),'v_comparison_lower':vcmp.hex(),'end_lower':[str(h),str(v)]})
   if index%500==0:print(arm,index,'v >=',float(v),'seconds',round(time.monotonic()-start,2),file=sys.stderr,flush=True)
   assert time.monotonic()-start<300,'Bounded prototype/replay exceeded 300 wall seconds'
  assert zb==50
  threshold=F(task['criterion_exact_strict']['through_common_radiation_switch'])
  saved=F(armdata['z50_saved'][1]);theta=max(F('0.1'),F(float('.1')))
  results[arm]={'h50_lower_exact':str(h),'v50_lower_exact':str(v),'v50_lower_display':float(v),'v50_lower_rounded_down_1e_minus_6':str(F(v*1000000//1,1000000)),'strict_threshold_margin':str(v-threshold),'native_saved_v50_minus_source_v50_upper':str(saved-v),'temperature_guard_z_lower_open':str(51*theta/v-1),'full_selector_criterion_pass':v>threshold,'alternative_065_criterion_pass':saved-v<=F(13,200)}
 return {'schema':'Q052_V81_ONE_SIDED_TEMPERATURE','source_commit':task['source_commit'],'status':'PASS_CONDITIONAL_FULL_TEMPERATURE_GUARD_EXCLUSION' if all(r['full_selector_criterion_pass'] for r in results.values()) else 'PARTIAL','fixed_background':'V73_B_star','inherited_initial_z':str(hx(d['arms']['R']['records'][0]['z'][0])),'matched_z810_lineage':'V62 single-arm endpoint tubes, inherited unchanged; same source-real B_star qualification as V73/V77','input_sha256':{n:digest((ROOT/n).read_bytes()) for n in ['v19.json','v20.py','v62.json','v73.json','v77.json','task80.json']},'criterion_exact_strict':task['criterion_exact_strict'],'arms':results,'whole_cells_per_arm':1526,'new_native_pairs':0,'new_full_history_integrations':0,'method':'Closed Riccati lower comparison for h+q and constant-coefficient linear lower comparison for v on archived cells. No saved thermal samples enter the source bounds.','trace':trace,'scope':'Source-real conditional fixed-background temperature bound only. Q052 global electron and Thomson maxima and native/source consistency remain unresolved.'}
if __name__=='__main__':print(json.dumps(run(),indent=2)+'\n',end='')
