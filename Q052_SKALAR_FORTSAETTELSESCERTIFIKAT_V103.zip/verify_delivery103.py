"""Validate an extracted V103 certificate and available companion files."""
from pathlib import Path
from hashlib import sha256
import json
p=Path(__file__).resolve().parent
m=json.loads((p/'manifest.json').read_bytes())
for x in m['archive_members']:
 b=(p/x['path']).read_bytes()
 assert len(b)==x['bytes'] and sha256(b).hexdigest()==x['sha256'],x['path']
 if x['path'].endswith('.json'):json.loads(b)
for x in m['external_deliverables']:
 f=p/x['filename']
 if f.exists():
  b=f.read_bytes();assert len(b)==x['bytes'] and sha256(b).hexdigest()==x['sha256'],x['filename']
r=json.loads((p/'result103.json').read_bytes());raw=json.loads((p/'result_raw103.json').read_bytes());v=json.loads((p/'verification103.json').read_bytes())
assert r['accepted_new_cells']==raw['accepted_cells']==len(raw['cells'])==179
assert r['checkpoint']['endpoint']==raw['endpoint'] and not raw['target_reached']
assert not v['failures'] and v['status']=='PASS_CONDITIONAL'
l=json.loads((p/'activity_ledger.json').read_bytes());assert sum(e['run_points'] for e in l['entries'])==l['total_points_after']==13300
assert len(set(e.get('activity_event_id',e['run_id']) for e in l['entries']))==len(l['entries'])
print('PASS: manifest, JSON, counts, checkpoint and ledger; scientific scope remains conditional.')
