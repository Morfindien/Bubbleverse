"""Reconstruct only the first unaccepted candidate after the recorded prefix."""
from pathlib import Path
from fractions import Fraction as F
import json,time
P=Path(__file__).resolve().parent
started=time.monotonic()
task=json.loads((P/'task102.json').read_text())
result=json.loads((P/'result_raw103.json').read_text())
streak=0
for cell in result['cells']:
    retried=any(x['a']==cell['a0'] for x in result['rejections'])
    streak=streak+1 if not retried and max(map(F,cell['comparison']['defect']))<=F(1,4*10**8) else 0
    ratio=F(cell['h'])
    if streak>=2:ratio=min(F(1,16),ratio*F(3,2));streak=0
a0=F(result['certified_end_a'])
a1=min(F(1,801),F((a0*(1+ratio)*2**120).__floor__(),2**120))
for reject in result['rejections']:
    if F(reject['a'])==a0:
        assert F(reject['a1'])==a1
        a1=F(((a0+(a1-a0)/2)*2**120).__floor__(),2**120)
source=(P/'continuation103.py').read_text()
source=source.replace('    independent_check(record)\n',"    (P/'last_unaccepted_candidate103.json').write_text(json.dumps(record,indent=2)+'\\n')\n    independent_check(record)\n")
old="    assert all(x.contained(b) for x,b in zip(image,cell['picard_box']))"
new="""    witness=[]
    for j,(x,b) in enumerate(zip(image,cell['picard_box'])):
        witness.append({'component':j,'independent_image':x.saved(),'whole_box':b,'passed':x.contained(b),'lower_gap':str(F(b[0])-x.l),'upper_gap':str(x.h-F(b[1]))})
    (P/'last_picard_witness103.json').write_text(json.dumps(witness,indent=2)+'\\n')
    assert all(x['passed'] for x in witness),'INDEPENDENT_PICARD_NOT_CONTAINED'
"""
assert old in source
source=source.replace(old,new)
ns={'__file__':str(P/'continuation103.py'),'__name__':'diagnostic_only'}
exec(compile(source,str(P/'continuation103.py'),'exec'),ns)
try:
    ns['attempt'](a0,a1,[ns['box'](*map(F,row)) for row in result['endpoint']])
except AssertionError as error:
    output={'status':'REPRODUCED_FIRST_UNACCEPTED_CANDIDATE','a0':str(a0),'a1':str(a1),'z1_display':float(1/a1-1),'error':str(error),'wall_seconds':time.monotonic()-started,'new_accepted_cells':0,'scope':'Diagnostic only; result_raw103.json is preserved.'}
    (P/'last_diagnostic103.json').write_text(json.dumps(output,indent=2)+'\n')
    print(output)
    for w in json.loads((P/'last_picard_witness103.json').read_text()):
        print({**w,'lower_gap':float(F(w['lower_gap'])),'upper_gap':float(F(w['upper_gap']))})
