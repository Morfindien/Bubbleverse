"""Check a justified tighter sine range on the stored first unaccepted cell.
No new polynomial, cells, defect replay or integration; no promotion.
"""
from pathlib import Path
from fractions import Fraction as F
import json,time,hashlib
P=Path(__file__).resolve().parent
start=time.monotonic();rawhash=hashlib.sha256((P/'result_raw103.json').read_bytes()).hexdigest()
source=(P/'continuation103.py').read_text()
old='    if sine.l>0:cosine=R(right_cosine.l,left_cosine.h)'
new='''    if sine.l>0 and cosine.l<=0<=cosine.h:
        # sin > 0 certifies sin'' < 0 throughout, so sine is concave.
        # Its minimum is at an endpoint; its maximum is at most 1.
        sine=R(min(left_sine.l,right_sine.l),F(1))
    if sine.l>0:cosine=R(right_cosine.l,left_cosine.h)'''
assert old in source;source=source.replace(old,new)
ns={'__file__':str(P/'continuation103.py'),'__name__':'stored_candidate_diagnostic'}
exec(compile(source,str(P/'continuation103.py'),'exec'),ns)
cell=json.loads((P/'last_unaccepted_candidate103.json').read_text())
status='PASS_STORED_CANDIDATE_INDEPENDENT_CHECK_ONLY';error=None
try:ns['independent_check'](cell)
except Exception as e:
 import traceback
 status='FAIL';error=traceback.format_exc()
R=ns['R'];arg=R(*cell['picard_box'][0])*ns['LL'];ls,_=R(arg.l).sincos();rs,_=R(arg.h).sincos();sn=R(min(ls.l,rs.l),F(1))
out={'status':status,'error':error,'new_accepted_cells':0,'scope':'Post-stop diagnostic. Original recorded candidate only; Picard, guard, Jacobian and comparison endpoint checks with a corrected sine range. No new scalar steps, no defect recomputation, no checkpoint promotion.','proof':'Original coarse interval has sine.lower > 0 on the whole argument interval. Therefore sine is concave there (sine second derivative = -sine < 0), giving minimum at an endpoint. Upper bound 1 is universal. Endpoint evaluations are outward rational Taylor enclosures.','replacement_source':new,'sine_corrected':sn.saved(),'wall_seconds':time.monotonic()-start,'raw_result_preserved':rawhash==hashlib.sha256((P/'result_raw103.json').read_bytes()).hexdigest()}
(P/'criticalpoint_diagnostic103.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['replacement_source','sine_corrected']},indent=2));print('sine_display',[float(sn.l),float(sn.h)])
