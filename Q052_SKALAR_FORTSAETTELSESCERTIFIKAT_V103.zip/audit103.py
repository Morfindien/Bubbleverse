"""Post-run exact record audit and independent energy/trigonometric diagnostics.
No integration or additional accepted cells. Preserves result_raw103.json.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import json,time,hashlib,sys,platform
import continuation103 as c
P=Path(__file__).resolve().parent
R=c.R
started=time.monotonic()
def read(n):return json.loads((P/n).read_text())
def save(n,x):(P/n).write_text(json.dumps(x,indent=2)+'\n')
def digest(n):return hashlib.sha256((P/n).read_bytes()).hexdigest()
def contained(x,y):return F(y[0])<=F(x[0])<=F(x[1])<=F(y[1])
def val(x):return [float(F(y)) for y in x]
raw_sha=digest('result_raw103.json');raw=read('result_raw103.json');task=read('task102.json')
checks=Counter();failures=[];expansions=[];energies=[]
def check(ok,label,index=None):
 checks[label]+=1
 if not ok:failures.append({'cell':index,'gate':label})
now=F(task['coverage']['a_start']);previous=task['input_checkpoint']['endpoint']
ratio=F(task['input_last_relative_step']);streak=0;ri=0
waypoint=F(task['coverage']['a_waypoint']);target=F(1,801)
for idx,cell in enumerate(raw['cells'],1):
 a0,a1,h=map(F,[cell['a0'],cell['a1'],cell['h']])
 check(a0==now and a1>a0 and h==(a1-a0)/a0,'exact_time_chain',idx)
 check(all(contained(a,b) for a,b in zip(previous,cell['initial'])),'prior_endpoint_contained_in_input',idx)
 if previous!=cell['initial']:expansions.append(idx)
 check(a1<=target and (a1==waypoint or (a1*2**120).denominator==1),'boundary_and_grid',idx)
 proposed=min(waypoint if a0<waypoint else target,F((a0*(1+ratio)*2**120).__floor__(),2**120));retry=0
 while ri<len(raw['rejections']) and F(raw['rejections'][ri]['a'])==a0:
  rej=raw['rejections'][ri];check(F(rej['a1'])==proposed,'controller_rejection_step',idx)
  proposed=F(((a0+(proposed-a0)/2)*2**120).__floor__(),2**120);ri+=1;retry+=1
 check(proposed==a1 and retry<=12 and 0<h<=F(1,16),'accepted_controller_step',idx)
 cr=cell['comparison'];rs=list(map(F,cr['initial_radius']));ds=list(map(F,cr['defect']))
 for j in range(2):
  coeff=list(map(F,cell['polynomial'][j]));lo,hi=map(F,cell['initial'][j])
  check(len(coeff)==13 and coeff[0]==(lo+hi)/2 and rs[j]==(hi-lo)/2,'center_degree_and_radius',idx)
  pv=R(coeff[-1])
  for co in reversed(coeff[:-1]):pv=pv*R(0,h)+co
  check(pv.contained(cell['picard_box'][j]),'rational_polynomial_in_whole_box',idx)
  check(contained(cell['initial'][j],cell['picard_box'][j]) and contained(cell['picard_image'][j],cell['picard_box'][j]),'recorded_input_and_picard_in_box',idx)
  check(contained(cell['endpoint'][j],cell['picard_box'][j]) and contained(cell['endpoint'][j],cell['raw_endpoint'][j]),'endpoint_intersections',idx)
 check(max(ds)<=F(1,10**8) and min(ds)>=0 and max(map(F,cell['defect_80']))<=F(1,10**8),'defect_budget_both_precisions',idx)
 M=[[F(v) for v in row] for row in cr['matrix']];s=F(cr['shift']);beta=F(cr['beta']);k=cr['terms']
 N=[[M[0][0]+s,M[0][1],ds[0]],[M[1][0],M[1][1]+s,ds[1]],[F(0),F(0),s]]
 check(s>=0 and all(x>=0 for row in N for x in row),'nonnegative_augmented_matrix',idx)
 check(beta>=h*max(map(sum,N)) and beta/(k+2)<1,'comparison_norm_and_ratio',idx)
 st=F(1)
 for j in range(1,k+1):st*=beta/j
 tail=st*beta/(k+1)/(1-beta/(k+2))*max(F(1),*rs)
 check(F(cr['tail'])>=tail,'exact_comparison_tail',idx)
 check(cell['higher_precision_replay']=='PASS_WITH_ENCLOSING_UNION' and cell['independent_check']=='PASS_RATIONAL_FIELD_GUARD_JACOBIAN_COMPARISON','recorded_inrun_verification',idx)
 phi,vel=[R(*row) for row in cell['endpoint']]
 ee=vel**2/2+c.AA*(1-(phi*c.LL).monotone_cos())**3
 check(ee.contained(cell['energy']),'independent_endpoint_energy',idx)
 energies.append(ee.saved())
 ratio=h;streak=streak+1 if retry==0 and max(ds)<=F(1,4*10**8) else 0
 if streak>=2:ratio=min(F(1,16),ratio*F(3,2));streak=0
 now=a1;previous=cell['endpoint']
check(now==F(raw['certified_end_a']) and previous==raw['endpoint'],'final_checkpoint')
check(len(raw['cells'])==raw['accepted_cells']==179 and ri==len(raw['rejections'])==33,'counts')
check(raw['energy']==raw['cells'][-1]['energy'],'final_energy_record')
check(raw['waypoint']['passed'] and F(raw['waypoint']['width'])<=F(task['decision_gates']['waypoint_max_energy_width_Mpc_minus_2']),'waypoint_gate')
check(not raw['target_reached'] and now<target and raw['new_weight_evaluations']==0,'no_anchor_no_weight')
check(raw_sha==digest('result_raw103.json'),'raw_preserved')
# Diagnose interval range loss on the recorded, unaccepted candidate only.
cell=read('last_unaccepted_candidate103.json');phi,vel=[R(*row) for row in cell['picard_box']]
arg=phi*c.LL;sn,cs=arg.sincos();ls,lc=R(arg.l).sincos();rs,rc=R(arg.h).sincos()
if cs.h<0:sn=R(rs.l,ls.h)
elif cs.l>0:sn=R(ls.l,rs.h)
if sn.l>0:cs=R(rc.l,lc.h)
elif sn.h<0:cs=R(lc.l,rc.h)
h=F(cell['h']);a0=F(cell['a0']);scale=R(1,1+h);aa=R(a0)*scale
density=R(c.MM)/aa**3+R(c.RR)/aa**4+R(c.factor)/aa**4*sum((R(q*q*w)*(R(q*q)+(aa*c.mass)**2).sqrt() for q,w in zip(c.nodes,c.weights)),R(0))
def image(sine):
 U=c.AA*(1-cs)**3;Up=3*c.AA*c.LL*sine*(1-cs)**2;H=(density+(vel**2/2+U+c.FF)/3).sqrt()
 rhs=[vel/H/scale,(-3*vel-Up/H)/scale]
 return [R(*a)+R(0,h)*b for a,b in zip(cell['initial'],rhs)]
old_im=image(sn);clipped=R(max(F(-1),sn.l),min(F(1),sn.h));new_im=image(clipped)
diag={'scope':'Post-stop diagnostic of stored candidate only. No candidate accepted, no propagation resumed.','argument':arg.saved(),'sine_before':sn.saved(),'sine_after_universal_range_intersection':clipped.saved(),'cosine':cs.saved(),'sine_upper_exceeds_one':sn.h>1,'cosine_sign_uncertain':cs.l<=0<=cs.h,'original_picard_pass':[x.contained(b) for x,b in zip(old_im,cell['picard_box'])],'range_clipped_picard_pass':[x.contained(b) for x,b in zip(new_im,cell['picard_box'])],'range_clipped_picard_image':[x.saved() for x in new_im],'universal_identity':'For real theta, -1 <= sin(theta) <= 1. Intersecting any enclosing sine interval with [-1,1] is valid.','remaining_validation':'Only Picard diagnostic performed for clipped evaluation. Full candidate Jacobian, comparison and other gates remain unaccepted.'}
save('trig_diagnostic103.json',diag)
out={'schema':'Q052_V103_POSTRUN_AUDIT','status':'PASS_CONDITIONAL' if not failures else 'FAIL','accepted_cells':179,'checks':dict(checks),'total_checks':sum(checks.values()),'failures':failures,'input_enlargement_cells':expansions,'independent_energy_all_endpoints':True,'last_energy_independent':energies[-1],'scope':'Exact stored-record audit and independent endpoint-energy evaluation. No new cells. No independent Taylor-defect implementation. In-run rational Picard/Jacobian/comparison checks are retained, not rerun.','raw_result_sha256':raw_sha,'audit_code_sha256':digest('audit103.py'),'wall_seconds':time.monotonic()-started,'python':sys.version,'platform':platform.platform(),'mpmath':__import__('mpmath').__version__}
save('verification103.json',out)
print(json.dumps({k:v for k,v in out.items() if k!='last_energy_independent'},indent=2))
print('TRIG',json.dumps({k:v for k,v in diag.items() if k not in ['argument','sine_before','sine_after_universal_range_intersection','cosine','range_clipped_picard_image']}))
print('TRIG_DISPLAY', {'argument':val(arg.saved()),'sine_before':val(sn.saved()),'sine_clipped':val(clipped.saved()),'energy_last':val(energies[-1])})
