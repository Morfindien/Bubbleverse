"""Replay the first failed candidate for diagnosis only; certify no new step."""
from pathlib import Path
from fractions import Fraction as F
import json, time

P=Path(__file__).resolve().parent
started=time.monotonic()
namespace={'__file__':str(P/'continuation103.py'),'__name__':'diagnostic_only'}
source=(P/'continuation103.py').read_text()
source=source.replace('    independent_check(record)\n',
    "    (P/'failed_candidate103.json').write_text(json.dumps(record,indent=2)+'\\n')\n    independent_check(record)\n")
old='    assert all((J[i][j].h if i==j else max(abs(J[i][j].l),abs(J[i][j].h)))<=M[i][j] for i in range(2) for j in range(2))'
new='''    comparisons=[]
    for i in range(2):
        for j in range(2):
            bound=J[i][j].h if i==j else max(abs(J[i][j].l),abs(J[i][j].h))
            comparisons.append({'i':i,'j':j,'independent_bound':str(bound),'producer_bound':str(M[i][j]),'gap':str(bound-M[i][j]),'gap_display':float(bound-M[i][j]),'passed':bound<=M[i][j]})
    (P/'jacobian_comparison103.json').write_text(json.dumps(comparisons,indent=2)+'\\n')
    assert all(x['passed'] for x in comparisons), 'INDEPENDENT_JACOBIAN_DOMINATION'
'''
assert old in source
source=source.replace(old,new)
exec(compile(source,str(P/'continuation103.py'),'exec'),namespace)
task=json.loads((P/'task102.json').read_text())
a0=F(task['coverage']['a_start'])
h=F(task['input_last_relative_step'])
a1=F((a0*(1+h)*2**120).__floor__(),2**120)
state=[namespace['box'](*map(F,row)) for row in task['input_checkpoint']['endpoint']]
try:
    namespace['attempt'](a0,a1,state)
except AssertionError as error:
    result={'status':'REPRODUCED_FAILED_FIRST_CANDIDATE','error':str(error),'accepted_new_cells':0,'wall_seconds':time.monotonic()-started,'scope':'Diagnostic replay of the same failed candidate; no continuation or promotion.'}
    (P/'diagnostic103.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
    print((P/'jacobian_comparison103.json').read_text())
