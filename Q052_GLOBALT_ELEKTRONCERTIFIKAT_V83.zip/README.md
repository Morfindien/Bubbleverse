# Q052 V83 – dokumentation og genkørsel

Python 3.10+ samt systembiblioteket libmpfr kræves. Kør uden -O:

```bash
python3 certify83.py > replay_result.json
cmp replay_result.json result.json
python3 control83.py > replay_control.json
cmp replay_control.json control.json
```

Hvert kontrolspor har en intern grænse på 300 sekunder. Begge bruger den fastholdte kilde og arvede bokspræmisser. certify83.py viderefører et analytisk invariant område; control83.py bruger rationelle Bernstein-net og en separat konservativ sum for hydrogen. Ingen nye native par eller fulde historieintegrationer udføres.

PROOF_V83.md giver det fulde argument, kilde-/enhedspræmisser og grænser for uafhængighed. result.json indeholder alle nye celler og de signerede flademarginer. Kontrolpakken fra V82 medfølger uændret som historisk afhængighed. verification.json dokumenterer frisk udpakning og genkørsel af V83, ikke gentagelse af tidligere forskning. manifest.json omfatter alle leverede medlemsfiler uden sit eget hash.

De tre nye V83-filer foreslås lagt i Morfindien/Bubbleverse-roden. Tidligere versioner bevares. Opdater eksisterende Q052-navigation efter kontrol af den aktuelle branch. Ingen GitHub-skrivning er gennemført i V83.
