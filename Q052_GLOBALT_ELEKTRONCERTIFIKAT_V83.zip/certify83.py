"""Bounded invariant continuation from V79 prefix into its proven late suffix.
Uses archived coefficient integrals, no new ODE/native integration.
"""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time,sys
import v20 as m
from certify77 import elasticity
P=Path(__file__).resolve().parent
Q=F(1,10**6);B=F(199,200)
def hx(s):return F(float.fromhex(s))
def load(n):return json.loads((P/n).read_bytes())
def run():
 start=time.monotonic()
 for n,h in load('pins.json').items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h
 c=m.Context(P/'v19.json');d=load('v64.json');a=load('v81.json');prior=load('v79.json');task=load('task82.json');g=load('guard80.json');R=d['arms']['R']['records'];L=d['arms']['L']['records']
 first=prior['prefix_cells'];stop=prior['late_from_row'];assert first==236 and stop==2963
 assert F(prior['cone_B'])==B and F(prior['late_max_abs_upper'])<Q
 assert R[first]['z'][0]==prior['prefix_z'][0] and R[stop]['z'][0]==prior['late_z'][1]
 events=sorted(map(F,d['events']),reverse=True);cut=F(d['map_parameters']['fixed_reio_start_exact']);assert cut==events[-1]
 assert d['map_parameters']==c.capture['frozen_reionization']
 inv=1/F(a['arms']['R']['h50_lower_exact']);diagnostics=[];maxJ=F(0);minH=F(1);blocks=[];last=F(50)
 for i,(l,r) in enumerate(zip(L[:stop],R[:stop])):
  assert l['z']==r['z'];za,zb=map(F,r['z']);assert za==last and zb<za;last=zb
  assert l['lambda']==r['lambda'] and 0<=hx(r['lambda'][0])<=hx(r['lambda'][1])<=1
  # V64 K_upper bounds recombination loss on every admissible old state/branch.
  inc=hx(r['K'][1])*hx(r['dt'][1]);assert inc>0;inv+=inc
  hlow=max(1/inv,hx(r['whole'][0][0]));minH=min(minH,hlow)
  vl=[max(hx(k['whole'][1][0]),F(task['temperature_floors'][arm])*(1+zb)/51) for k,arm in [(l,'L'),(r,'R')]]
  assert all(hx(k['whole'][0][0])>2*Q and hx(k['whole'][0][1])<1 and hx(k['whole'][1][1])<=1 for k in [l,r])
  J=(hlow+Q)/(hlow-Q)*(1-vl[1]);maxJ=max(maxJ,J);assert J<B
  if i>=first:
   T,tr,nh,_=c.background(m.enc(1+zb,1+za));assert T.hi<c.fit_first.lo
   if za>=events[1]:assert min(vl)>F(c.vmin.hi)
   assert (r['reio_interior']=='identity')==(za>cut) and r['right_endpoint_uses_camb']==(zb<=cut)
   if za<=events[1]:branch='PEEBLES'
   elif zb>=events[0]:branch='HMLA'
   else:branch='COMMON_TRAD_SWITCH'
   diagnostics.append({'row':i,'z':r['z'],'hR_whole_lower':str(hlow),'v_whole_lower':list(map(str,vl)),'thermal_J_upper':str(J),'branch':branch,'map':r['reio_interior']})
 assert last==F(prior['late_z'][1])
 # HMLA elasticity including the clamped low-TR endpoint, only on active domain.
 hm=[r for r in diagnostics if r['branch']!='PEEBLES']
 for ix in range(0,len(hm),32):
  rs=hm[ix:ix+32];za=F(rs[0]['z'][0]);zb=F(rs[-1]['z'][1]);vl=min(F(x) for r in rs for x in r['v_whole_lower'])
  T,tr,nh,_=c.background(m.enc(1+zb,1+za));tr=m.I(max(tr.lo,c.trmin.lo),tr.hi)
  el=elasticity(c,tr,m.enc(vl,1),12);assert -1<el.lo<=el.hi<0
  S=c.saha*tr*tr.sqrt()*(-c.EI/tr).exp()/nh;hmin=min(F(r['hR_whole_lower']) for r in rs);assert F(S.hi)<hmin*hmin
  blocks.append({'z':[str(za),str(zb)],'v_lower':str(vl),'TR_hex':tr.hex(),'elasticity_hex':el.hex(),'S_over_hR_squared_upper':str(F(S.hi)/hmin**2)})
  assert time.monotonic()-start<300
 # PPB: derivative w.r.t. log(v) = -a-bY/(1+Y), Y=c*(Tm/10000)^b.
 T,tr,nh,_=c.background(m.enc(1+last,51));Y=m.lit('.6703')*(T/10000).power(m.lit('.5300'));pp=-m.lit('.6166')-m.lit('.5300')*Y/(1+Y);assert -1<pp.lo<=pp.hi<0
 S=c.saha*tr*tr.sqrt()*(-c.EI/tr).exp()/nh;assert F(S.hi)<minH**2
 assert all(F(x['thermal_J_upper'])<B for x in diagnostics)
 hmax=max(hx(r['whole'][0][1]) for r in R[first:stop])
 faces={'normalization_hydrogen':'dprime/abs(f_R)','upper_d_zero_upper':str(-(1-B)*Q/hmax),'lower_d_minus_2q_lower':str(2*Q/hmax),'normalization_thermal':'yprime/(A(M(X_L))/v_L)','upper_y_B_upper':str(-(B-maxJ)),'lower_y_minus_B_lower':str(B-maxJ),'hR_upper_used':str(hmax)}
 return {'schema':'Q052_V83_GLOBAL_SOURCE_ELECTRON_CEILING','status':'PASS_UNDER_INHERITED_FIXED_BACKGROUND_PREMISES','source_commit':task['source_commit'],'new_contiguous_z':[str(last),prior['prefix_z'][0]],'new_cells':len(diagnostics),'strict_abs_Delta_Xe_less_than_q_on':'0<=z<810','global_sup_abs_Delta_Xe':'1/1000000','unique_maximum_z':'810','cone_B':str(B),'task_start_clarification':'V77 gives B=0.99 at z50; inherited V79 extension uses B=0.995. This continuation uses the proven 0.995 cap.','max_thermal_forcing_upper':str(maxJ),'minimum_improved_hR_lower':str(minH),'face_bounds':faces,'PPB_elasticity_hex':pp.hex(),'PPB_S_over_hR_squared_upper':str(F(S.hi)/minH**2),'HMLA_blocks':blocks,'cells':diagnostics,'source_events':list(map(str,events)),'late_suffix_reused':{'z':prior['late_z'],'absolute_upper':prior['late_max_abs_upper']},'photon_optical_depth':'V78 upper bound retained; actual global extremum unresolved','native_source_consistency':'Not globally resolved by this theorem','new_native_pairs':0,'new_full_history_integrations':0}
if __name__=='__main__':print(json.dumps(run(),indent=2)+'\n',end='')
