"""Check the four inward faces using archived phase-5 boxes and the pinned MPFR module."""
import hashlib
import json
from fractions import Fraction as F
from pathlib import Path
import v20 as m

BASE = Path(__file__).resolve().parent
Q = F(1,10**6)
B = F(99,100)

def read(name, pin):
    raw = (BASE/name).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == pin
    return json.loads(raw)

def hx(x):
    return F(float.fromhex(x))

def box(row):
    return m.I(*map(float.fromhex,row))

def cubics(c,it,t,iv,channel):
    # Interpolate the forward differences in log(T) before evaluating the ratio derivative.
    triples=[]
    for i in range(it-1,it+3):
        a,b,d,e=[c.alpha[channel][k][i] for k in range(iv-1,iv+3)]
        triples.append((d-b,(e-2*d+b)/2,(e-3*d+3*b-a)/6))
    return [m.cubic(list(term),t) for term in zip(*triples)]

def elasticity(c,tr,v,subdivisions):
    qt=(tr.log()-c.logmin)/c.dlog
    qv=(v-c.vmin)/c.dv
    bounds=[]
    for it,t in m.stencils(qt,100):
        for iv,s in m.stencils(qv,40):
            for channel in [0,1]:
                a,b,d=cubics(c,it,t,iv,channel)
                lo,hi=F(s.lo),F(s.hi)
                for k in range(subdivisions):
                    x=m.enc(lo+(hi-lo)*k/subdivisions,lo+(hi-lo)*(k+1)/subdivisions)
                    bounds.append((c.vmin/c.dv+iv+x)*(a+(2*x-1)*b+(3*x*(x-2)+2)*d))
    return m.hull(bounds)

def jump(c,rows,hs,h,v,zp,shifts,fit):
    T,tr,n,_=c.background(zp)
    fit_index=(T-c.fit_first)/10
    dk=m.hull(sum((u*m.cubic([fit[k][l] for k in range(i-1,i+3)],t)
                   for l,u in enumerate([m.I(1),*shifts],1)),m.I(0))
              for i,t in m.stencils(fit_index,len(fit)))
    assert 0<c.fit_first.hi<T.lo and T.hi<c.fit_last.lo and -1<dk.lo<=dk.hi<0
    e=c.lya*hs/n/(1-h)
    E=e/(1+dk)
    _,_,_,ar=c.rates(tr,v)
    bs,bp=[box(x['hex']) for x in ar['beta']]
    j=box(ar['R2p2s']['hex'])
    g=bs+c.lam+3*j
    D0=(bs+c.lam)*(bp+j)+3*j*bp
    DS=D0+g*E
    K=g*bp+j*bs
    ns=c.lam*(bp+j)+(c.lam+3*j)*e
    np=c.lam*j+g*e
    assert min(DS.lo,K.lo,ns.lo,np.lo,bs.lo,bp.lo,j.lo)>0
    de=(-dk)*e/(1+dk)
    excess=m.hull(y*K*de/(DS*nu) for y,nu in [(3*j,ns),(g,np)])
    # Same h on the two sides of this ratio. The lower-face L hydrogen is smaller.
    assert 0<excess.lo and F(excess.hi)<2*Q/F(h.hi)
    return dict(z=rows[0]['z'],DK=dk.hex(),relative_C_excess=excess.hex(),
                two_q_over_h_upper_state=str(2*Q/F(h.hi)),H_per_s=hs.hex())

def main():
    task=read('task76.json','f1cfdac2e7bd92f4b116cf485e67a0894873628281bd3ff255bb35d96f673917')
    v62=read('v62.json','63480c24d61350c9913ed3072e09c91c097049791165fa964cfa096f7d0d4ca8')
    prev=json.loads((BASE/'v75.json').read_bytes())
    assert task['case_id']==v62['case_id'] and task['target_q']=='Q052'
    assert hashlib.sha256((BASE/'v20.py').read_bytes()).hexdigest()=='d0feecd36359005a55fb91c26aee2381f9ed1652177395acf7ec482ea0e880fa'
    c=m.Context(BASE/'v19.json')
    rr=[v62['arms'][a]['records'] for a in ['L','R']]
    assert len(rr[0])==len(rr[1])==1526 and v62['conditional']
    start=F(task['interface']['z']); end=F(task['domain_z'][0])
    assert end==50 and list(map(F,task['domain_z']))==[end,start]
    slo,shi=map(F,prev['signed_slope_du'])
    delta=list(map(F,task['interface']['Delta_Xe']))
    assert delta==[Q+slo*(810-start)/(1+start),Q+shi*(810-start)/811]
    assert -Q<delta[0]<=delta[1]<Q and prev['source_sup_abs']==[str(Q)]*2
    tmax=max(abs(F(x)) for x in task['interface']['Delta_v'])
    v0=hx(rr[0][0]['whole_source'][1][0]);h0=hx(rr[1][0]['whole_source'][0][1])
    y0=(h0+Q)*tmax/(Q*v0)
    assert y0<B and F(c.capture['frozen_reionization']['fixed_reio_start_exact'])<end
    assert 3.04<float.fromhex(v62['Neff_from_archived_row'][0])<=float.fromhex(v62['Neff_from_archived_row'][1])<3.05
    ratio=(m.lit('2.7255')/m.enc(c.T0)).power(m.I(3))
    shifts=[(m.I(0,1)-m.lit('.14175'))*ratio,
            (m.enc(0,F('.03'))-m.lit('.02242')*(1-m.lit('.246738546372')))*ratio,
            m.enc(F('3.04'),F('3.05'))-m.lit('3.046')]
    fit=[[m.lit(x) for x in line.split()] for line in c.sources['fit_swift.dat']['content'].splitlines() if line.strip()]
    prevz=start; thermal=[]; photo=[]; jumps=[]; blocks=[]; masks={}
    for index,(left,right) in enumerate(zip(*rr)):
        assert left['z']==right['z'] and left['H_per_s']==right['H_per_s']
        za,zb=map(hx,right['z']);assert za==prevz and zb<za
        prevz=zb
        h=m.hull(box(x['whole_source'][0]) for x in [left,right])
        v=m.hull(box(x['whole_source'][1]) for x in [left,right])
        assert F(h.lo)>2*Q and h.hi<1 and c.vmin.hi<v.lo<=v.hi<1
        hr=hx(right['whole_source'][0][0]);vr=hx(right['whole_source'][1][0])
        thermal.append((hr+Q)/(hr-Q)*(1-vr));assert thermal[-1]<B
        mask=right['allowed_branches'];assert mask==left['allowed_branches']
        assert mask in [['SWIFT'],['HMLA','SWIFT'],['HMLA']]
        masks['/'.join(mask)]=masks.get('/'.join(mask),0)+1
        if len(mask)>1:
            jumps.append(jump(c,[left,right],box(right['H_per_s']),h,v,m.enc(1+zb,1+za),shifts,fit))
    assert prevz==end
    for first in range(0,len(rr[0]),64):
        rows=rr[0][first:first+64]+rr[1][first:first+64]
        za=max(hx(r['z'][0]) for r in rows);zb=min(hx(r['z'][1]) for r in rows)
        vmin=min(hx(r['whole_source'][1][0]) for r in rows);hmin=min(hx(r['whole_source'][0][0]) for r in rows)
        _,tr,nh,_=c.background(m.enc(1+zb,1+za))
        assert c.trmin.hi<tr.lo<=tr.hi<c.trmax.lo
        S=c.saha*tr*tr.sqrt()*(-c.EI/tr).exp()/nh
        photo.append(F(S.hi)/hmin**2);assert photo[-1]<1
        vals=elasticity(c,tr,m.enc(vmin,1),8 if zb==end else 1)
        assert -1<vals.lo<=vals.hi<0
        blocks.append(dict(z=list(map(str,[za,zb])),v_lower=str(vmin),elasticity_hex=vals.hex(),
                           saha_over_h_squared_upper=str(photo[-1])))
    return dict(schema='Q052_V77_PHASE5_INVARIANT',status='PASS_UNDER_FROZEN_PREMISES',
                phase5_z=list(map(str,[end,start])),combined_z=['50','810'],
                phase5_abs_difference_upper=str(Q),combined_sup_abs=[str(Q),str(Q)],
                unique_maximum_z='810',interface_abs_y_upper=str(y0),thermal_cap=str(B),
                thermal_forcing_max=str(max(thermal)),saha_over_h_squared_max=str(max(photo)),
                cold_log_elasticity_hex=m.hull(box(x['elasticity_hex']) for x in blocks).hex(),
                source_boxes_per_arm=len(rr[0]),branch_counts=masks,elasticity_blocks=blocks,mixed_branch_checks=jumps,
                global_electron_sup=None,global_optical_depth_sup=None,new_native_pairs=0,new_full_history_integrations=0)
if __name__=='__main__':
    print(json.dumps(main(),indent=2))
