"""Second full-stencil elasticity control using integer arithmetic in the Bernstein basis."""
import hashlib
import json
import math
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from pathlib import Path
import v20 as m

BASE=Path(__file__).resolve().parent
NODES=(-1,0,1,2)
SCALE=2**48

def basis(i,t,derivative=False):
    remaining=[j for j in NODES if j!=i]
    den=math.prod(i-j for j in remaining)
    if derivative:
        return sum(math.prod(t-j for j in remaining if j!=k) for k in remaining)/den
    return math.prod(t-j for j in remaining)/den

def controls(f,a,b):
    p,q,r,s=[f(F(a)+(b-a)*F(k,3)) for k in range(4)]
    x,y=27*q-8*p-s,27*r-p-8*s
    return [p,(2*x-y)/18,(2*y-x)/18,s]

@lru_cache(None)
def weights(iv,sa,offset):
    # Control nets for a bicubic on a unit (t,s) rectangle.
    a=[controls(lambda t:basis(i,t),0,1) for i in NODES]
    b=[controls(lambda s:(offset+iv+s)*basis(i,s,True),sa,sa+1) for i in NODES]
    out=[]
    for u,v in product(range(4),repeat=2):
        w=[a[i][u]*b[j][v] for i,j in product(range(4),repeat=2)]
        den=math.lcm(*(x.denominator for x in w))
        out.append(([int(x*den) for x in w],den))
    return out

def main():
    c=m.Context(BASE/'v19.json')
    src=(BASE/'v62.json').read_bytes()
    assert hashlib.sha256(src).hexdigest()=='63480c24d61350c9913ed3072e09c91c097049791165fa964cfa096f7d0d4ca8'
    d=json.loads(src)
    r=json.loads((BASE/'result.json').read_bytes())
    rr=[d['arms'][a]['records'] for a in 'LR']
    h=lambda s:F(float.fromhex(s))
    off=c.vmin/c.dv
    offsets=[F('4.3333333333'),F('4.3333333334')]
    assert offsets[0]<F(off.lo)<=F(off.hi)<offsets[1]
    tiles=set()
    for idx,block in enumerate(r['elasticity_blocks']):
        rows=rr[0][64*idx:64*(idx+1)]+rr[1][64*idx:64*(idx+1)]
        lo=min(h(row['z'][1]) for row in rows);hi=max(h(row['z'][0]) for row in rows)
        vl=min(h(row['whole_source'][1][0]) for row in rows)
        assert list(map(F,block['z']))==[hi,lo] and F(block['v_lower'])==vl
        _,tr,_,_=c.background(m.enc(1+lo,1+hi))
        qt=(tr.log()-c.logmin)/c.dlog
        assert 1<qt.lo<=qt.hi<97
        qv=(m.enc(vl,1)-c.vmin)/c.dv
        assert qv.lo>0
        for it in range(math.floor(qt.lo),math.floor(qt.hi)+1):
            # Whole cells include the clamped endpoint segments at vmin and 1.
            for j in range(math.floor(qv.lo),39):
                iv=max(1,min(37,j))
                tiles.add((it,iv,j-iv))
    minimum,maximum=F(0),F(-2)
    for it,iv,sa in sorted(tiles):
        for level in [0,1]:
            logs=[c.alpha[level][iv+y][it+x] for x,y in product(NODES,repeat=2)]
            bounds=[(math.floor(F(x.lo)*SCALE),math.ceil(F(x.hi)*SCALE)) for x in logs]
            for offset in offsets:
                for w,den in weights(iv,sa,offset):
                    low=sum(k*(a if k>=0 else b) for k,(a,b) in zip(w,bounds))
                    high=sum(k*(b if k>=0 else a) for k,(a,b) in zip(w,bounds))
                    minimum=min(minimum,F(low,den*SCALE));maximum=max(maximum,F(high,den*SCALE))
    assert -1<minimum<=maximum<0
    q=F(1,10**6);cap=F(99,100)
    forcing=max((h(row['whole_source'][0][0])+q)*(1-h(row['whole_source'][1][0]))/
                (h(row['whole_source'][0][0])-q) for row in rr[1])
    assert forcing==F(r['thermal_forcing_max'])<cap
    mixed=[(l,v) for l,v in zip(*rr) if len(l['allowed_branches'])==2]
    max_jump=F(0)
    for (l,v),proof in zip(mixed,r['mixed_branch_checks']):
        hu=max(h(x['whole_source'][0][1]) for x in (l,v))
        delta=h(proof['relative_C_excess'][1]);assert proof['z']==l['z']==v['z']
        assert h(proof['DK'][1])<0 and (1+delta)*(1-2*q/hu)<1
        max_jump=max(max_jump,delta/(2*q/hu))
    assert len(mixed)==len(r['mixed_branch_checks'])==11
    return dict(status='PASS',full_unit_tiles=len(tiles),bernstein_controls=len(tiles)*2*2*16,
                certified_log_elasticity=list(map(str,[minimum,maximum])),max_thermal_forcing=str(forcing),
                largest_jump_to_allowed_ratio=str(max_jump),shared_inputs='same archived single-arm tubes, outward log-table entries and fitted source; jump magnitudes from producer; separate polynomial and face-margin control')
if __name__=='__main__':
    print(json.dumps(main(),indent=2))
