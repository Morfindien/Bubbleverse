"""Independent Bernstein and coarsened reciprocal-sum control of V83.
Shares source data, inherited premises and outward log-table entries; uses
rational Bernstein nets instead of producer derivative interval evaluation.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from functools import lru_cache
from math import floor,ceil,lcm
import json,time,hashlib
import v20 as m
from control77 import basis,controls,NODES,SCALE
P=Path(__file__).resolve().parent
Q=F(1,10**6);B=F(199,200)
def hx(s):return F(float.fromhex(s))
def load(n):return json.loads((P/n).read_bytes())
@lru_cache(None)
def net(ta,iv,sa,off):
 aa=[controls(lambda t:basis(i,t),ta,ta+1) for i in NODES]
 bb=[controls(lambda s:(off+iv+s)*basis(i,s,True),sa,sa+1) for i in NODES]
 out=[]
 for u,v in product(range(4),repeat=2):
  w=[aa[i][u]*bb[j][v] for i,j in product(range(4),repeat=2)];den=lcm(*(k.denominator for k in w));out.append(([int(k*den) for k in w],den))
 return out

def run():
 start=time.monotonic()
 for n,h in load('pins.json').items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h
 c=m.Context(P/'v19.json');r=load('result.json');d=load('v64.json');v81=load('v81.json');v79=load('v79.json');guard=load('guard80.json')
 R=d['arms']['R']['records'];L=d['arms']['L']['records'];first=v79['prefix_cells'];end=v79['late_from_row'];SCALE_SUM=10**12
 inv=F(ceil((1/F(v81['arms']['R']['h50_lower_exact']))*SCALE_SUM),SCALE_SUM);maxJ=F(0);lowh=F(1);tiles=set();offsets=[F('4.3333333333'),F('4.3333333334')]
 offset=c.vmin/c.dv;assert offsets[0]<F(offset.lo)<=F(offset.hi)<offsets[1]
 upper,lower=sorted(map(F,guard['radiation_transition_enclosure']),reverse=True)
 boundaries=set();branchcounts={};maps=set()
 for i in range(end):
  a,b=L[i],R[i];za,zb=map(F,b['z']);boundaries.update([za,zb]);assert a['z']==b['z'] and a['lambda']==b['lambda']
  inv+=F(ceil(hx(b['K'][1])*hx(b['dt'][1])*SCALE_SUM),SCALE_SUM)
  hf=1/inv;lowh=min(lowh,hf);vr=max(hx(b['whole'][1][0]),F(327899,10**6)*(1+zb)/51)
  J=(hf+Q)*(1-vr)/(hf-Q);assert J<B;maxJ=max(maxJ,J)
  if i<first:continue
  rr=r['cells'][i-first];assert rr['row']==i and rr['z']==b['z'] and hf<=F(rr['hR_whole_lower'])
  assert 0<=hx(b['lambda'][0])<=hx(b['lambda'][1])<=1;maps.add(b['reio_interior'])
  kind='PEEBLES' if za<=lower else ('HMLA' if zb>=upper else 'COMMON_TRAD_SWITCH');assert rr['branch']==kind
  branchcounts[kind]=branchcounts.get(kind,0)+1
  if kind=='PEEBLES':continue
  vl=min(max(hx(k['whole'][1][0]),F(v,10**6)*(1+zb)/51) for k,v in [(a,327901),(b,327899)])
  assert vl>F(c.vmin.hi)
  _,tr,_,_=c.background(m.enc(1+zb,1+za));tr=m.I(max(tr.lo,c.trmin.lo),tr.hi)
  qt=(tr.log()-c.logmin)/c.dlog;qv=(m.enc(vl,1)-c.vmin)/c.dv
  for jt in range(floor(qt.lo),floor(qt.hi)+1):
   it=max(1,min(97,jt))
   for jv in range(floor(qv.lo),39):
    iv=max(1,min(37,jv));tiles.add((it,jt-it,iv,jv-iv))
 lower_el=F(0);upper_el=F(-2);count=0
 for it,ta,iv,sa in sorted(tiles):
  for ch in (0,1):
   logs=[c.alpha[ch][iv+y][it+x] for x,y in product(NODES,repeat=2)]
   bounds=[(floor(F(x.lo)*SCALE),ceil(F(x.hi)*SCALE)) for x in logs]
   for off in offsets:
    for weights,den in net(ta,iv,sa,off):
     lo=sum(w*(a if w>=0 else b) for w,(a,b) in zip(weights,bounds));hi=sum(w*(b if w>=0 else a) for w,(a,b) in zip(weights,bounds));count+=1
     lower_el=min(lower_el,F(lo,den*SCALE));upper_el=max(upper_el,F(hi,den*SCALE))
 assert -1<lower_el<=upper_el<0
 assert set(map(F,d['events']))<=boundaries and maps=={'identity','camb'}
 # Coarse rational PPB bound valid for 0<Tm<=Tgamma<10000 K:
 # exponent b>0 implies Y<=c; maximal |elasticity| <= a_hi+b_hi*c_hi/(1+c_hi).
 hi=lambda s:max(F(s),F(float(s)));lo=lambda s:min(F(s),F(float(s)))
 ppmax=hi('.6166')+hi('.5300')*hi('.6703')/(1+hi('.6703'));assert ppmax<1 and c.T0*51<10000
 assert F(v79['late_max_abs_upper'])<Q and r['global_sup_abs_Delta_Xe']==str(Q)
 hmax=max(hx(row['whole'][0][1]) for row in R[first:end]);faces=r['face_bounds']
 assert F(faces['upper_d_zero_upper'])==-(1-B)*Q/hmax<0
 assert F(faces['lower_d_minus_2q_lower'])==2*Q/hmax>0
 assert F(faces['upper_y_B_upper'])<0<F(faces['lower_y_minus_B_lower'])
 assert B-maxJ>F('.022')
 assert time.monotonic()-start<300
 return {'schema':'Q052_V83_BERNSTEIN_RATIONAL_CONTROL','status':'PASS','new_cells':end-first,'full_unit_tiles':len(tiles),'bernstein_coefficient_intervals':count,'HMLA_log_elasticity':list(map(str,[lower_el,upper_el])),'coarsened_thermal_J_upper':str(maxJ),'coarsened_hR_lower':str(lowh),'PPB_abs_elasticity_upper':str(ppmax),'branch_counts':branchcounts,'map_types':sorted(maps),'all_event_boundaries_checked':True,'global_source_electron_sup':'1/1000000','unique_maximum_z':'810','independence':'Separate polynomial basis and conservative rational reciprocal sum. Shared pinned source, outward logarithms and inherited trajectory premises. No new trajectory integration.'}
if __name__=='__main__':print(json.dumps(run(),indent=2)+'\n',end='')
