"""Exact cell checks for the V94 signed Peebles/CAMB tail task.

Uses the inherited V83 Saha enclosure and proves its extension by monotonicity.
No native runs, trajectory integrations or evaluation of the optical integral.
"""
from fractions import Fraction as F
from pathlib import Path
from time import monotonic
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
Q = F(1, 1000000)

def read(name):
    return json.loads((ROOT/name).read_bytes())

def binary(value):
    return F(float.fromhex(value))

def require(condition, reason):
    if not condition:
        raise ValueError(reason)

def constant_bounds(source, name):
    token = re.search(r'^#define\s+'+name+r'\s+([\d.eE+-]+)', source, re.M).group(1)
    return sorted([F(token), F(float(token))])

def run():
    started = monotonic()
    for name, digest in read('pins.json').items():
        require(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest, 'hash '+name)
    task, data, prior, rates = [read(n) for n in ['task94.json','v64.json','result93.json','v83.json']]
    require(task['current_q']==task['target_q']=='Q052', 'Q identity')
    require(task['domain']['rows_zero_based']==[2963,3335] and task['domain']['cell_count']==373, 'task bounds')
    require(prior['status']=='ALL_2963_PASS' and prior['ending_interface']==task['interface'], 'positive entry')
    start_z = F(task['interface']['z'])
    require(prior['combined_positive_z']==[str(start_z),'810'], 'prior interval')
    require(rates['source_commit']==task['source_commit']==prior['source_commit'], 'physics lineage')
    members = read('v19.json')['original_members']
    for name, entry in members.items():
        require(hashlib.sha256(entry['content'].encode()).hexdigest()==entry['sha256'], 'original '+name)
    background = json.loads(members['Q052_BACKGROUND_TRANSFER_INPUTS_V18.json']['content'])
    parent = background['parent_v17_inputs']
    context = parent['native_first_cell_context']
    originals = parent['parent_result']['validator_inputs_original']['files']
    capture = json.loads(originals['q048_prefix_config_v1.json']['content'])['cases']['hillipop-ede_n3']
    require(context['frozen']['physics_commit']==task['source_commit'], 'source commit')
    require(capture['background']['thermal_flags']=={'has_varconst':0,'has_exotic_injection':0,'has_idm_b':0,'has_idm_g':0,'has_idm_dr':0,'recombination':1}, 'fixed thermal flags')
    require(capture['background']['flags']['has_idm']==capture['background']['flags']['has_idr']==0, 'other thermal fields')
    require(data['map_parameters']==capture['frozen_reionization'], 'common map parameters')
    mapping = data['map_parameters']
    require(mapping['parametrization']=='reio_camb' and F(mapping['fixed_reio_start_exact'])>start_z, 'CAMB domain')
    require(mapping['width']>0 and mapping['helium_width']>0 and mapping['exponent']>0, 'finite map arguments')
    sources = {**context['source_files'], **background['additional_pinned_sources']}
    pins = {item['name']:item['sha256'] for item in data['source_pins']}
    for name, entry in sources.items():
        require(hashlib.sha256(entry['content'].encode()).hexdigest()==entry['sha256'], 'source '+name)
        if name in pins:
            require(entry['sha256']==pins[name], 'V64 source identity '+name)
    constants = capture['thermal_starts'][0]['constants']
    T0 = binary(constants['Tcmb'])
    n0 = binary(constants['nH0_SI'])/1000000
    helium = binary(constants['fHe_CLASS'])
    require(T0>0 and n0>0 and helium>0 and 0<binary(constants['YHe'])<1, 'positive common constants')
    header = sources['hydrogen.h']['content']
    ionization = constant_bounds(header, 'EI')
    boltzmann = constant_bounds(header, 'kBoltz')
    threshold = constant_bounds(header, 'TR_MIN')
    radiation_upper = T0*(1+start_z)*boltzmann[1]
    require(0<radiation_upper<threshold[0], 'common Peebles radiation dispatch')
    monotonicity = ionization[0]/radiation_upper-F(3,2)
    require(monotonicity>0, 'Saha increasing with redshift')
    require(rates['new_contiguous_z'][0]==str(start_z), 'Saha boundary coverage')
    saha_upper = F(rates['PPB_S_over_hR_squared_upper'])*F(rates['minimum_improved_hR_lower'])**2
    require(saha_upper>0, 'positive inherited Saha upper bound')
    require('pow(t4,-0.6166)' in sources['hyrec.c']['content'] and 'pow(t4,0.5300)' in sources['hyrec.c']['content'], 'PPB formula binding')
    alpha_exponents = {value:sorted([F(value),F(float(value))]) for value in ['.6166','.5300','.6703']}
    require(all(bounds[0]>0 for bounds in alpha_exponents.values()), 'strictly decreasing PPB alpha')
    left,right = [data['arms'][arm]['records'] for arm in 'LR']
    for arm,rows in [('L',left),('R',right)]:
        require(rows[2963]['initial']==prior['end_source_boxes'][arm]==task['end_source_boxes_V93'][arm], 'entry boxes '+arm)
    cursor = start_z
    cells = []
    obstruction = None
    for index in range(2963,3336):
        l,r = left[index],right[index]
        try:
            require(l['z']==r['z'] and l['index']==r['index']==index-3, 'row identity')
            high,low = map(F,r['z'])
            require(high==cursor and 0<=low<high, 'contiguity')
            require(l['initial']==left[index-1]['end'] and r['initial']==right[index-1]['end'], 'state joins')
            require(l['branches']==r['branches']==['PEEBLES'], 'common branch')
            require(l['reio_interior']==r['reio_interior']=='camb', 'common CAMB map')
            require(l['right_endpoint_uses_camb'] and r['right_endpoint_uses_camb'], 'endpoint map')
            h = [list(map(binary,row['whole'][0])) for row in [l,r]]
            v = [list(map(binary,row['whole'][1])) for row in [l,r]]
            require(all(Q<a<=b<1 for a,b in h), 'hydrogen domain')
            require(all(0<a<=b<=1 for a,b in v), 'temperature domain')
            for row in [l,r]:
                for coordinate in range(2):
                    a,b=map(binary,row['whole'][coordinate])
                    for key in ['initial','end']:
                        x,y=map(binary,row[key][coordinate])
                        require(a<=x<=y<=b, 'whole-cell contains endpoints')
            ratio = saha_upper/h[1][0]**2
            require(0<ratio<1, 'positive right hydrogen loss')
            face_low=max(h[1][0],h[0][0]+Q)
            face_high=min(h[1][1],h[0][1]+Q)
            require(Q<face_low<=face_high<1, 'nonempty physical contact face')
            for key in ['lambda','end_lambda']:
                require(l[key]==r[key], 'common '+key)
                a,b=map(binary,r[key])
                require(0<a<=b<=1, 'positive '+key)
            cells.append({'row':index,'source_index':r['index'],'z':r['z'],'h_face':list(map(str,[face_low,face_high])), 'temperature_boxes':[[str(a),str(b)] for a,b in v], 'S_over_hR_squared_upper':str(ratio),'normalized_face_margin':str(Q/face_high),'lambda_lower':str(min(binary(r[key][0]) for key in ['lambda','end_lambda'])),'status':'INWARD'})
            cursor=low
            require(monotonic()-started<300, 'prototype runtime limit')
        except ValueError as error:
            obstruction={'row':index,'z':r['z'],'predicate':str(error)}
            break
    done=obstruction is None and len(cells)==373 and cursor==0
    return {'schema':'Q052_V95_SIGNED_PEEBLES_TAIL','status':'ALL_373_PASS' if done else 'FIRST_UNCLOSED_PREDICATE','source_commit':task['source_commit'],'conditional_on':prior['conditional_on'],'new_block_z':[str(cursor),str(start_z)],'combined_positive_z':[str(cursor),'810'],'cells':cells,'normalized_face_margin_min':str(min(F(c['normalized_face_margin']) for c in cells)),'lambda_floor':str(min(F(c['lambda_lower']) for c in cells)),'saha_bound':{'method':'V83 boundary enclosure and exact monotonicity extension','S_upper':str(saha_upper),'dlogS_dlog1pz_lower':str(monotonicity),'tail_ratio_max':str(max(F(c['S_over_hR_squared_upper']) for c in cells))},'obstruction':obstruction,'end_source_boxes':{a:data['arms'][a]['records'][-1]['end'] for a in 'LR'} if done else None,'ending_interface':{'z':'0','E':'strictly positive','vL_minus_vR':'nonnegative','public_Delta_Xe':'strictly positive'} if done else None,'optical_consequence':{'observable':'F(Z)=Delta_tau_T(0,Z)=integral_0^Z w(z) Delta_Xe(z) dz','positive_weight':'Inherited fixed-background Thomson weight','global_abs_maximum_location':'810' if done else 'UNRESOLVED','unique_location':done,'maximum_value':'UNEVALUATED','native_output_maximum':'UNRESOLVED'},'new_native_pairs':0,'new_full_history_integrations':0}

if __name__=='__main__':
    print(json.dumps(run(),indent=2))
