# Q052 V95 — reproduktion

De to nye kontroller kræver Python 3 med standardbiblioteket. Kør i den udpakkede mappe:

    python3 certify95.py > replay_result.json
    python3 control95.py > replay_control.json

Sammenlign outputbytes med result.json og control.json. verification.json dokumenterer allerede gennemført genkørsel i en frisk mappe. Programfilerne finder inputs relativt til deres egen placering. Alle inputs i pins.json er inkluderet.

Primærkontrollen bruger det arvede V83-Saha-loft med en ny monotonicitetsudledning. Den separate kontrol bruger en direkte analytisk eksponentialgrænse og læser hverken V83-raterne eller V95's primæroutput. Det globale fortegn og den optiske følge udledes i PROOF_V95.md. De arvede banebokse og kildepræmisser fremgår af input_receipt.json og det uændrede V94-arkiv i history/.

manifest.json hasher alle nye pakkemedlemmer undtagen sig selv. Historiske manifests henviser til deres oprindelige pakker og eksterne journaler. Den fulde opdaterede journal leveres separat. V95 bestemmer maksimumstedet for F(Z)=Delta_tau_T(0,Z). Det realiserede tal F(810) og den fulde native/kilde-fejl står åbne.

return_task.json beskriver et forberedt indtag og en kommende afgrænsning af kvadraturarbejdet. GitHub-upload af de tre nye V95-filer afventer Jim.
