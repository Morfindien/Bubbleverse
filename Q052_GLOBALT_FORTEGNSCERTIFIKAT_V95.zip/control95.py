"""Separate grouped rational check with a direct analytic Saha bound.

Does not read result.json or the inherited V83 rate certificate. The Saha
estimate uses exp(-x)<2^-1000 for x>1000 and exact coarse source constants.
"""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parent
F=Fraction

def load(name):
    return json.loads((ROOT/name).read_text())

def hex_fraction(text):
    mantissa,exponent=text.lower().split('p')
    sign=-1 if mantissa.startswith('-') else 1
    whole,decimal=mantissa.lstrip('+-')[2:].split('.')
    integer=sign*int(whole+decimal,16)
    power=int(exponent)-4*len(decimal)
    return F(integer*2**power) if power>=0 else F(integer,2**(-power))

def run():
    pins=load('pins.json')
    for name in ['v64.json','v19.json','task94.json','result93.json']:
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==pins[name]
    data=load('v64.json')
    task=load('task94.json')
    previous=load('result93.json')
    assert previous['status']=='ALL_2963_PASS' and previous['ending_interface']==task['interface']
    archive=load('v19.json')['original_members']
    background=json.loads(archive['Q052_BACKGROUND_TRANSFER_INPUTS_V18.json']['content'])
    parent=background['parent_v17_inputs']
    context=parent['native_first_cell_context']
    capture=json.loads(parent['parent_result']['validator_inputs_original']['files']['q048_prefix_config_v1.json']['content'])['cases']['hillipop-ede_n3']
    sources={**context['source_files'],**background['additional_pinned_sources']}
    assert context['frozen']['physics_commit']==task['source_commit']
    for name in ['hydrogen.h','hyrec.c','thermo.c','wrap_hyrec.c']:
        entry=sources[name]
        assert hashlib.sha256(entry['content'].encode()).hexdigest()==entry['sha256']
    constants=capture['thermal_starts'][0]['constants']
    T0=hex_fraction(constants['Tcmb'])
    density=hex_fraction(constants['nH0_SI'])/1000000
    helium=hex_fraction(constants['fHe_CLASS'])
    assert 0<T0<3 and density>F(1,10**7) and helium>0
    header=sources['hydrogen.h']['content']
    def bounds(name):
        token=re.search(r'^#define\s+'+name+r'\s+([\d.eE+-]+)',header,re.M).group(1)
        exact=F(token)
        binary=hex_fraction(float(token).hex())
        return min(exact,binary),max(exact,binary)
    assert bounds('EI')[0]>13 and 0<bounds('kBoltz')[0]<=bounds('kBoltz')[1]<F(9,100000)
    assert bounds('TR_MIN')[0]>F(1,500)
    coefficient=re.search(r'return\s+([\d.eE+]+)\s*\* cube\(fsR\*meR\)',sources['hyrec.c']['content']).group(1)
    assert max(F(coefficient),hex_fraction(float(coefficient).hex()))<4*10**21
    assert capture['background']['thermal_flags']=={'has_varconst':0,'has_exotic_injection':0,'has_idm_b':0,'has_idm_g':0,'has_idm_dr':0,'recombination':1}
    mapping=capture['frozen_reionization']
    assert mapping==data['map_parameters'] and mapping['parametrization']=='reio_camb'
    start=F(task['domain']['z_exact'][1])
    assert 0<start<6<F(mapping['fixed_reio_start_exact'])
    assert mapping['width']>0 and mapping['helium_width']>0 and mapping['exponent']>0
    # TR < 3*7*9e-5 < 1/500, so EI/TR > 6500 > 1000.
    assert 3*7*F(9,100000)<F(1,500)
    assert 13/F(1,500)>1000
    saha_upper=F(4*10**28,2**1000)
    ratio_upper=saha_upper/F(1,100000)**2
    assert ratio_upper<F(1,10**260)<1
    # Positive fit coefficients give decreasing alpha at every v>0.
    # Tm<=Tgamma<21K<10000K also gives a coarse elasticity bound.
    for token,lo,hi in [('.6166',F('.61'),F('.62')),('.5300',F('.52'),F('.54')),('.6703',F('.66'),F('.68'))]:
        assert lo<min(F(token),hex_fraction(float(token).hex()))
        assert max(F(token),hex_fraction(float(token).hex()))<hi
    abs_elasticity_upper=F('.62')+F('.54')*F('.68')/(1+F('.68'))
    assert abs_elasticity_upper<1
    arms={a:data['arms'][a]['records'] for a in 'LR'}
    for a,rows in arms.items():
        assert len(rows)==3336 and rows[2963]['initial']==previous['end_source_boxes'][a]
    summaries=[]
    cursor=start
    for first in range(2963,3336,32):
        stop=min(first+32,3336)
        allrows=[arms[a][i] for a in 'LR' for i in range(first,stop)]
        h_lower=min(hex_fraction(r['whole'][0][0]) for r in allrows)
        h_upper=max(hex_fraction(r['whole'][0][1]) for r in allrows)
        v_lower=min(hex_fraction(r['whole'][1][0]) for r in allrows)
        v_upper=max(hex_fraction(r['whole'][1][1]) for r in allrows)
        assert F(1,100000)<h_lower<=h_upper<F(1,500)
        assert F(1,1000)<v_lower<=v_upper<F(1,2)
        lambdas=[]
        for i in range(first,stop):
            l,r=arms['L'][i],arms['R'][i]
            high,low=map(F,r['z'])
            assert l['z']==r['z'] and high==cursor>low>=0
            assert l['index']==r['index']==i-3
            assert l['branches']==r['branches']==['PEEBLES']
            assert l['reio_interior']==r['reio_interior']=='camb'
            for arm in 'LR':
                row=arms[arm][i]
                assert row['initial']==arms[arm][i-1]['end'] and row['right_endpoint_uses_camb']
                for key in ['initial','end']:
                    assert h_lower<=hex_fraction(row[key][0][0])<=hex_fraction(row[key][0][1])<=h_upper
                    assert v_lower<=hex_fraction(row[key][1][0])<=hex_fraction(row[key][1][1])<=v_upper
            for key in ['lambda','end_lambda']:
                assert l[key]==r[key]
                a,b=map(hex_fraction,r[key])
                assert F(1,10**10)<a<=b<=1
                lambdas.append(a)
            cursor=low
        summaries.append({'rows':[first,stop-1],'count':stop-first,'z':[arms['R'][first]['z'][0],str(cursor)],'outer_h':[str(h_lower),str(h_upper)],'outer_v':[str(v_lower),str(v_upper)],'normalized_face_margin_lower':str(F(1,1000000)/h_upper),'lambda_lower':str(min(lambdas))})
    assert cursor==0 and sum(g['count'] for g in summaries)==373
    return {'schema':'Q052_V95_DIRECT_SAHA_GROUP_CONTROL','status':'PASS','groups':summaries,'cells':373,'direct_Saha_upper':str(saha_upper),'S_over_hR_squared_coarse_upper':str(ratio_upper),'S_ratio_display_bound':'<1e-260','PPB_abs_log_elasticity_upper':str(abs_elasticity_upper),'normalized_face_margin_lower':str(min(F(g['normalized_face_margin_lower']) for g in summaries)),'coarse_normalized_margin_strict_lower':'1/2000','lambda_lower':str(min(F(g['lambda_lower']) for g in summaries)),'independence':'Independent exact hex parser and 12 outer-box groups; direct analytic exponential bound without V83 rates or V95 producer results. Shared pinned source and inherited V64 trajectory enclosures, V93 positive entry and fixed-background premises.','endpoint_z':'0'}

if __name__=='__main__':
    print(json.dumps(run(),indent=2))
