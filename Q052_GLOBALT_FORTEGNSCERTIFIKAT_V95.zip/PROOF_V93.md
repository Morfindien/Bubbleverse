# Q052 V93 · Positiv elektronforskel gennem fase 6 til z_B

## Dokumenteret resultat og afgrænsning

Under samme fastlagte kildekonfiguration, fælles baggrund B★ og matchede start ved z = 810 som i V91–V92 er

\[
0<\Delta X_e(z)<10^{-6}\quad(z_B\le z<810),\qquad
\Delta X_e(810)=10^{-6},
\]

hvor z_B = 787504997847845/140737488355328 ≈ 5,595560. V93 beviser den nye strenge nedre grænse på [z_B,50]. Den øvre grænse på hele historien er det tidligere V83-resultat og genberegnes ikke. Alle 2.963 nye helceller består. Dette er et betinget bevis for løsningerne af kildeligningerne, ikke en observation og ikke en ny fejlcertificering af den gemte CLASS-kurve. Q052 forbliver åbent.

## Kilde og variable

Case: hillipop-ede_n3. Physics-commit: 5a131c91d657dd9a7c6364cc45b038710f8d0d97. q = 1/1000000 i venstre arm, q = 0 i højre. Brug u = ln[811/(1+z)], v = T_m/T_γ, h = h_R, t = v_L−v_R og E = h_L−h_R+q. Disse størrelser er dimensionsløse; elektronfraktion måles i elektroner pr. hydrogenkerne. H er i s⁻¹, n_H i cm⁻³, T_γ i K og T_R i eV i HyRec. Der er ingen eksotisk energiinjektion, variable fundamentalkonstanter eller ekstra mørk-sektor-temperaturled i den fastlagte konfiguration.

Den bogstavelige kode bruger interne X_L=h_L+q og X_R=h_R i hydrogenfeltet, men det fælles reionisationskort M_z(X)=λ(z)X+b(z) i temperaturfeltet og den offentlige elektronfraktion. λ og b er fælles, b≥0. Derfor er ΔX_e=λE. Begge armes positive H og n_H følger det samme arvede B★; V64 har ikke et nyt særskilt H-felt i hver række, og V93 påstår ikke en ny baggrundsintegration.

Kildepassagerne er [HyRec hydrogen.c](https://github.com/mwt5345/class_ede/blob/5a131c91d657dd9a7c6364cc45b038710f8d0d97/external/HyRec2020/hydrogen.c), funktionerne alphaB_PPB, rec_TLA_dxHIIdlna, interpolate_rates, rec_HMLA_dxHIIdlna og rec_dxHIIdlna; [wrap_hyrec.c](https://github.com/mwt5345/class_ede/blob/5a131c91d657dd9a7c6364cc45b038710f8d0d97/external/HyRec2020/wrap_hyrec.c), hyrec_dx_H_dz; samt [thermodynamics.c](https://github.com/mwt5345/class_ede/blob/5a131c91d657dd9a7c6364cc45b038710f8d0d97/source/thermodynamics.c), temperatur- og reionisationsfunktionerne. Hashkontrollerede tekstkopier ligger indlejret i input91/v19.json. De er genbrugt og inspiceret i V93; det er ikke en ny fysisk datakilde.

## Temperaturordenen før første kontakt

V91 giver E>0 og t≥0 ved 50, og dens slutbokse er nøjagtigt V64's startbokse. Temperaturfeltet er

\[
v'=-v+A(M_z(X))(1-v),\qquad A(x)=kx/(a+x),\quad a=1+f_{He}>0,\ k>0.
\]

Indtil en eventuel første kontakt med E=0 er M_z(X_L)≥M_z(X_R) og dermed A_L≥A_R. Direkte subtraktion giver

\[
t'=-(1+A_L)t+(A_L-A_R)(1-v_R).
\]

Alle relevante bokse har 0<v_R≤1. Variationen-af-konstanten-formlen bevarer t≥0. Argumentet holder også når M skifter: t er kontinuert, og begge ensidige felter har samme ordensbevarende egenskab. På en kontaktflade har vi derfor v_L≥v_R.

## Hydrogenfeltet på E=0

På randen er h_L=h−q og X_L=X_R=h. For hver aktiv kanal sættes γ_i=α_i(1)S, hvor S er det fælles Saha-led, og

\[
U_{R,i}=\alpha_i(v_R)h^2-\gamma_i(1-h),\qquad
U_{L,i}=\alpha_i(v_L)(h-q)h-\gamma_i(1-h+q).
\]

γ_i er grundtilstandens fotoionisationsled; det må ikke forveksles med de exciterede tilstandes β_s,β_p i C-faktorerne nedenfor. Hydrogenfeltet er f=−(n_H/H)Σ_i C_iU_i.

De genbrugte ratecertifikater giver en negativ loghældning i v på hvert nødvendigt HMLA-domæne, helt op til v=1. Derfor α_L≤α_R og α_R≥α(1). Den kontrollerede S/h_min²<1 og h<1 giver U_R>0 i hver kanal. For Peebles er PPB-raten proportional med T_m^(−a)/(1+cT_m^b), med a,b,c>0, så den samme monotoni følger analytisk. Dens Saha-grænse er også kontrolleret.

Sæt κ=1−q/h, hvor 0<κ<1 på alle randbokse. Så

\[
U_L\le \kappa U_R-\gamma q/h\le\kappa U_R.
\]

Escape-raten e er proportional med H/[n_H(1−h)] og er strengt voksende med h. På randen er e_L<e_R. For HMLA sættes

\[
G=\beta_s+\Lambda+3j,\quad K=G\beta_p+j\beta_s,
\]

\[
D(e)=(\beta_s+\Lambda)(\beta_p+j)+3j\beta_p+Ge,
\]

\[
N_s(e)=\Lambda(\beta_p+j)+(\Lambda+3j)e,\quad
N_p(e)=\Lambda j+Ge.
\]

De positive faktorer C_i=N_i/D opfylder C_s′=3jK/D²>0 og C_p′=GK/D²>0. control93.py verificerer tællernes polynomielle identiteter med eksakte heltalskoefficienter, uden sampling. Peebles har C=(3e+Λ)/(3e+Λ+B_β), B_β>0, og dC/de=3B_β/(3e+Λ+B_β)²>0. Altså C_L≤C_R på begge fælles grene.

Når U_L≥0 kan kanaluligheden multipliceres med C_L og derefter sammenlignes med C_R. Når U_L<0 er venstre bidrag allerede negativt og højre positivt. I begge tilfælde C_LU_L≤κC_RU_R. Dermed

\[
E'=f_L-f_R\ge(q/h)|f_R|>0\qquad\text{på } E=0.
\]

En første kontakt fra E>0 ville kræve et ikke-positivt indadgående tidsforløb ved kontakten. Det strengt positive randfelt og lokal kontinuitet på hver aktiv gren giver det modsatte. Ved et fælles grenskift gælder argumentet for begge ensidige felter. Induktivt bevares E>0 gennem hele blokken.

## Helceller, grene og kort

| Nye celler | Dækning |
| --- | --- |
| Række 0–235 | V79's otte kontrollerede HMLA-rategrupper. |
| Række 236–2264 | V83's forbedrede temperatur- og hydrogengulve; fælles HMLA. |
| Række 2265 | Fælles strålingstærskel; både HMLA/HMLA og Peebles/Peebles kontrolleres. |
| Række 2266–2962 | Fælles Peebles, inklusive reionisationsgrænsen. |

Tallene er nulbaserede rækkenumre i det opdelte V64-arkiv. Feltet `index` i arkivet er den oprindelige celles indeks og gentages ved indskudte hændelsesgrænser. Den første prototype forvekslede de to og stoppede ved række 2265. Prototypens output bevares som diagnostics. Den endelige kontrol binder rækkerne til eksakte z-grænser, matchende armtilstande og det oprindelige indeks med de tre dokumenterede opdelinger. Ingen historiske data eller matematiske præmisser blev ændret.

V81 giver de nedre temperaturstarter b_L=0,327901 og b_R=0,327899. Helcellegulvet er maksimum af V64's gulv og b_i(1+z_low)/51. Før og gennem strålingstærsklens indhylling er begge arme strengt over v=0,1. Der kan derfor ikke opstå et særskilt temperaturudløst blandet grenskift dér. For en fast fælles kildekonstant er T_R fælles, så strålingsovergangen er samtidig. Den meget smalle indhylling tillader begge fælles felter, ikke uafhængige grenvalg i de to arme. Ingen af cellerne når SWIFT-fittemperaturen.

V83's forbedrede h_R-gulv rekonstrueres fra h_R(50) og de arvede K_jΔu_j-lofter:

\[
h_R\ge\max\left(h_{R,\mathrm{V64,low}},\left[h_{R,50,low}^{-1}+\sum_{k\le j}K_{k,up}\Delta u_{k,up}\right]^{-1}\right).
\]

Det er en skalar sammenligningsgrænse; der køres ingen ny ODE-integration. Alle rekonstruerede V83-gulve matcher de gemte værdier præcist. De nye randbokse bruger h_R-boksen skåret med venstre h-boks forskudt med q. Ratedomænernes z-, v- og Saha-forudsætninger kontrolleres over hele celler, ikke kun i knuder.

Reionisationsgrænsen er z=753585/65536. Arkivet deler ved grænsen; præcis ved grænsen bruges CAMB-endepunktskortet. Begge armes λ og end_lambda er ens. Alle relevante indre og endepunktsværdier har det fælles positive gulv

\[
\lambda\ge7095185298635785/9223372036854775808>0.
\]

E>0 giver derfor den strenge offentlige elektronforskel også ved dette endepunkt. M kan skifte uden at h eller v springer. Den sammenføjede elektronfunktion behøver ikke at være kontinuert i selve kildekonventionens kortskift; den påståede positivitet kræver ikke denne kontinuitet.

## Separat kontrol og margin

Primærkontrollen giver E′/|f_R|≥72057594037927936/93936667015211265625 på kontaktfladen. Det svageste loft kommer fra række 0. Den separate kontrol bruger en anden parser for hexadecimale intervalendepunkter, reciprok-summens led rundet op til 12 decimaler og ydre hydrogengrænser pr. rategruppe. Saha-ratioerne justeres konservativt til de lidt svagere kontrolgulve. Den læser ikke primærresultatet og giver

\[
E'/|f_R|\ge72057594037927936/93936667644127296875>0,00076708.
\]

Der er 73 kontrolgrupper: otte fra V79, 64 fra V83 og én PPB-gruppe. Tærskelcellen dækkes af begge relevante grupper. Begge spor deler de hashfastlåste kilde-, bane- og ratepræmisser og rationalregningens standardbibliotek. De er separate kontroller af denne nye anvendelse, ikke uafhængige observationer eller nye ratecertifikater.

Tallet 0,00076708 er en normaliseret randafledt. Det er **ikke** en nedre grænse for elektronforskellens amplitude på banen. Dette bevis fastslår et strengt fortegn uden at bestemme en ny numerisk minimumsamplitude.

## Optisk følge og næste videnskabelige opgave

For F(Z)=Δτ_T(0,Z)=∫₀ᶻw(z)ΔX_e(z)dz med den arvede positive vægt w er F strengt voksende med den øvre integrationsgrænse på [z_B,810]. Afledningsudsagnet gælder på de åbne glatte stykker og næsten overalt gennem kortskiftet. F er kontinuert som integral; derfor ligger maksimum af |F| begrænset til dette interval i et af de to endepunkter. Det ukendte bidrag F(z_B) fra den lave ende er stadig relevant.

V93 når den udtrykkelige V92-slutgrænse. De sidste 373 arkivceller på [0,z_B) er en særskilt opgave. Det arvede absolutte elektronloft dér afgør ikke deres fortegn. Næste indtag skal fastholde den nye indgang E>0, t≥0 ved z_B og forberede et afgrænset Peebles-/CAMB-fortegnsbevis ned til nul med dækning af nye rate-/Saha-domæner og positive kortfaktorer. Et eventuelt globalt fortegnsbevis ville bestemme maksimumstedet for den signerede optiske akkumulering; selve integralværdien og den fulde native/kilde-fejl kræver fortsat validering.

Nul nye native simulationspar. Nul nye fuldhistorieintegrationer. Ingen udvidelse til nyt Q eller ændring af accepted model.
