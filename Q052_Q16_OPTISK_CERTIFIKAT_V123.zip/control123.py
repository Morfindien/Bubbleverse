"""Separate reverse construction. Does not read primary code/output or V122 geometry."""
import sys,json
from pathlib import Path
from fractions import Fraction
sys.set_int_max_str_digits(0)
Q=Fraction
folder=Path(__file__).resolve().parent/'input'
allowed={'weights66.json','v62.json','result121.json','result119.json','result117.json','audit112.json','result111.json'}
opened=[]
def guard(event,args):
    if event=='open' and isinstance(args[0],(str,bytes)):
        name=Path(args[0]).resolve();mode=args[1]
        if isinstance(mode,str) and 'r' in mode:
            assert name.parent==folder and name.name in allowed, str(name)
            opened.append(name.name)
sys.addaudithook(guard)
def get(name): return json.loads((folder/name).read_text())
source=get('weights66.json')['source_segments'];pair=get('v62.json')['pair_records']
one=get('result121.json');two=get('result119.json');three=get('result117.json');prior=get('audit112.json');bridge=get('result111.json')
assert one['technical_state']==two['technical_state']==three['technical_state']==prior['technical_state']=='PASS'
assert one['b']==two['constant_b']==three['b']=='1/16000000'
areas=[(tuple(map(Q,one['exact_z_ascending'])),one['claim_id']),(tuple(map(Q,two['domain_z_ascending'])),two['claim_id']),(tuple(map(Q,three['domain_z_ascending'])),three['claim_id'])]
assert areas[0][0][1]==areas[1][0][0] and areas[1][0][1]==areas[2][0][0]
domain=(areas[0][0][0],areas[2][0][1]);assert domain[0]==50
old=prior['current_bins'];opt=bridge['optical_result'];assert old==opt['current_bins']
shield=[Q(bridge['conditional_electron_domain'][0]),Q(700)]
assert domain[1]==shield[0] and shield[0]<shield[1]
bound=Q(one['b']);scale=2**100
def fromhex(s):
    sign=-1 if s.startswith('-') else 1;s=s.lstrip('+-');mant,exp=s.split('p');whole,frac=mant[2:].split('.');n=int(whole+frac,16)*sign;e=int(exp)-4*len(frac)
    return Q(n*2**e) if e>=0 else Q(n,2**(-e))
lookup={tuple(reversed(tuple(fromhex(x) for x in r['z']))):j for j,r in enumerate(pair)}
segments=list(old.items());p=Q(0);baseline=[Q(0),Q(0)]
for name,values in segments:
    a,c=map(Q,name.split(':'));assert a==p and c>a;p=c
    baseline[0]+=Q(values[0]);baseline[1]+=Q(values[1])
assert p==810 and list(map(str,baseline))==prior['global_interval']
rows=[];aggregates={k:[0,Q(0),Q(0)] for k in old}
for i in range(len(source)-1,-1,-1):
    item=source[i];l,r=map(Q,item['z'])
    if r<=domain[0] or l>=domain[1]:continue
    assert item['origin']=='V62';mapped=lookup[(l,r)]
    for (fl,fr),claim in reversed(areas):
        for name,values in reversed(segments):
            bl,br=map(Q,name.split(':'));a=max(l,fl,bl,domain[0]);c=min(r,fr,br,domain[1])
            if a>=c:continue
            assert c<=shield[0]
            lower,upper=map(Q,item['K_over_H_exact']);assert 0<lower<=upper
            x,y=1+a,1+c;mass=(c-a)*(x*x+x*y+y*y)/3
            exact=bound*lower*mass
            n,rem=divmod(exact.numerator*scale,exact.denominator);safe=Q(n,scale)
            assert safe>0 and 0<=rem<exact.denominator and safe<=exact<safe+Q(1,scale)
            rows.append({'V66_row':i,'V62_row':mapped,'z_ascending':[str(a),str(c)],'bin':name,'floor_claim':claim,'weight_lower':str(lower),'mass':str(mass),'unrounded_lower':str(exact),'rounded_lower':str(safe)})
            aggregates[name][0]+=1;aggregates[name][1]+=exact;aggregates[name][2]+=safe
assert len(rows)==1304 and len({r['V66_row'] for r in rows})==1292
rows.sort(key=lambda r:Q(r['z_ascending'][0]))
p=domain[0]
for row in rows:
    a,c=map(Q,row['z_ascending']);assert a==p<c;p=c
assert p==domain[1]
total=Q(0);exact_total=Q(0);new={};diff={}
for name,values in reversed(segments):
    count,ex,low=aggregates[name];total+=low;exact_total+=ex
    a=Q(values[0])+low;c=Q(values[1]);assert a<=c
    new[name]=[str(a),values[1],values[2]];diff[name]={'pieces':count,'unrounded_gain':str(ex),'rounded_gain':str(low),'rounding_loss':str(ex-low)}
assert sum(v['pieces']>0 for v in diff.values())==13
for name in ['0:50','700:750','750:800','800:810']:assert new[name]==old[name]
lo=baseline[0]+total;hi=baseline[1];assert total>0 and lo==sum(Q(v[0]) for v in new.values())
assert hi==sum(Q(v[1]) for v in new.values())
width=hi-lo;before=baseline[1]-baseline[0];goal=Q(1,250000000)
result={'status':'PASS','rows':rows,'current_bins':new,'bin_changes':diff,'protected_support':list(map(str,shield)),'protected_lower_preserved':opt['new_lower'],'new_support':list(map(str,domain)),'gain':str(total),'unrounded_gain':str(exact_total),'rounding_loss':str(exact_total-total),'rounding_loss_strict_upper':str(Q(len(rows),scale)),'prior_global_interval':list(map(str,baseline)),'new_global_interval':[str(lo),str(hi)],'prior_global_width':str(before),'global_width':str(width),'global_width_reduction_fraction':str(total/before),'global_width_goal_ratio':str(width/goal),'provisional_width_goal':str(goal),'baseline_partition_coverage':['0','810'],'upper_endpoints_unchanged':True,'support_overlap':'SHARED_ENDPOINT_ONLY','baseline_counts_meaning':'Inherited enclosing-bin segmentation counts; new lower-piece counts are in bin_changes.'}
Path(sys.argv[1]).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
Path(sys.argv[2]).write_text(json.dumps({'status':'PASS','input_files_opened':opened,'producer_code_or_receipt_read':False,'V122_geometry_read':False,'method':'Independent proof endpoints, reverse V66 traversal, independent hex parser, factorized mass, integer divmod; same Python Fraction backend and archived premises.'},indent=2)+'\n')
