"""Recreate redundant extracted inputs from the preserved V122 archive."""
from pathlib import Path
from zipfile import ZipFile
import json,hashlib,io
R=Path(__file__).resolve().parent;dest=R/'input';dest.mkdir(exist_ok=True)
z=ZipFile(R/'history/Q052_INGESTION_CERTIFICATE_V122.zip')
names=['baseline122.json','geometry122.json','activity_ledger122.json','audit122.json','input/V121/result121.json','input/V119/result119.json','input/V119/input/v117/result117.json','input/V112/audit112.json','input/V111/result111.json','input/V111/calc/control111.json','input/V95/v95.json']
data={Path(n).name:z.read(n) for n in names};data['task122.json']=z.read('Q052_MATEMATIKOPGAVE_V122.json')
w=ZipFile(io.BytesIO(z.read('history/Q052_THOMSON_CERTIFICATE_V66.zip')));data['weights66.json']=w.read('receipt.json')
v=ZipFile(io.BytesIO(z.read('history/Q052_Q16_HMLA_CERTIFIKAT_V121.zip')));data['v62.json']=v.read('input/v91/v62.json')
freeze=json.loads((R/'freeze123.json').read_text())
for n,b in data.items():
    assert hashlib.sha256(b).hexdigest()==freeze['files']['input/'+n],n
    p=dest/n
    if p.exists():assert p.read_bytes()==b,n
    else:p.write_bytes(b)
print(json.dumps({'status':'PASS','restored_or_verified_inputs':len(data),'new_optical_evaluations':0}))
