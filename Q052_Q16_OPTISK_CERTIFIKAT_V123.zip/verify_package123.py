"""Stored-file verification only: no primary/control replay or new optical integral."""
from pathlib import Path
from fractions import Fraction as F
from zipfile import ZipFile
import json,hashlib,sys
sys.set_int_max_str_digits(0)
R=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((R/'manifest123.json').read_text())
for x in m['members']:
    b=(R/x['path']).read_bytes();assert len(b)==x['size_bytes'] and sha(b)==x['sha256'],x['path']
a=json.loads((R/'primary123.json').read_text());b=json.loads((R/'control123.json').read_text());assert a==b
assert len(a['rows'])==1304
assert sum((F(r['rounded_lower']) for r in a['rows']),F(0))==F(a['gain'])
assert sum((F(r['unrounded_lower']) for r in a['rows']),F(0))==F(a['unrounded_gain'])
assert F(a['unrounded_gain'])-F(a['gain'])==F(a['rounding_loss'])
assert 0<=F(a['rounding_loss'])<F(a['rounding_loss_strict_upper'])
lo,hi=map(F,a['new_global_interval']);assert hi-lo==F(a['global_width'])
assert [sum((F(v[i]) for v in a['current_bins'].values()),F(0)) for i in [0,1]]==[lo,hi]
z=ZipFile(R/'history/Q052_INGESTION_CERTIFICATE_V122.zip')
prefix=z.read('Q052_INGESTION_OG_SAMLET_JOURNAL_V122.md');append=(R/'journal_append123.md').read_bytes()
assert (R/'Q052_MATEMATIK_OG_SAMLET_JOURNAL_V123.md').read_bytes()==prefix+append
assert sha(prefix)==m['parent_journal_sha256'] and sha(append)==m['append_sha256']
t=json.loads((R/'Q052_RESULTATINDTAG_OPGAVE_V123.json').read_text());fp=t.pop('fingerprint_sha256')
assert sha(json.dumps(t,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==fp
for n,h in t['input_refs'].items():assert sha((R/n).read_bytes())==h,n
ledger=json.loads((R/'activity_ledger123.json').read_text());old=json.loads(z.read('activity_ledger122.json'))
assert ledger['entries'][:-1]==old['entries'] and sum(x['run_points'] for x in ledger['entries'])==14880
print(json.dumps({'status':'PASS','members':len(m['members']),'stored_rows':1304,'journal_prefix_bytes':len(prefix),'new_optical_evaluations':0,'new_primary_or_control_runs':0}))
