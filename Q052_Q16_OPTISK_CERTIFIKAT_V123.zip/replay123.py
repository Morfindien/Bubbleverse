"""Optional explicit independent replay into a new directory; never overwrites history."""
from pathlib import Path
import sys,shutil,subprocess,json,hashlib
R=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('Usage: python replay123.py /absolute/new/directory')
dest=Path(sys.argv[1]).resolve()
if dest.exists():raise SystemExit('Destination must not exist. Historical run will not be overwritten.')
subprocess.run([sys.executable,str(R/'restore_inputs123.py')],check=True)
freeze=json.loads((R/'freeze123.json').read_text())
for n,h in freeze['files'].items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h,n
dest.mkdir(parents=True)
for n in freeze['files']:
    p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,p)
subprocess.run([sys.executable,str(dest/'run123.py')],check=True)
for n in ['primary123.json','control123.json']:
    assert json.loads((dest/n).read_text())==json.loads((R/n).read_text()),n
print('Replay matches stored outputs. This is a new technical execution, not new research credit.')
