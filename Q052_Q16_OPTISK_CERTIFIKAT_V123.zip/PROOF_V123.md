# Q052 V123 — eksakt optisk q/16-bidrag

## Udsagn og forudsætninger

Claim `LOCAL-Q052-V123-C1`. Under den samme frosne hillipop-ede_n3-kilde,
fælles B★ og matchede z810-starter giver den betingede kilde-reelle
akkumulation F(810) intervallet

`381845896508367207321097/79228162514264337593543950336` ≤ F(810) ≤ `28908876046131453968421139/633825300114114700748351602688`.

De viste decimaler er tilnærmelser; brøkerne i receipts er autoritative.
F er den signerede Thomson-forskel fra 0 til Z. V95's arvede
positive offentlige elektronforskel og positive vægt giver
max₀≤Z≤810 |F(Z)| = F(810). Det er et deterministisk betinget interval,
ikke et statistisk konfidensinterval eller en observation.

På det nye domæne [50, 1523417340748759/2199023255552] ligger vi over
reionisationskortets aktive område. Her er den offentlige ΔX_e lig
E=h_L+q−h_R. Ved lavere z bruger den arvede globale baseline den
offentlige forskel inklusive sit reionisationskort; V123 udvider
ikke rå E's q/16-udsagn ned under z=50.

## Ligning, dimensioner og undergrænse

F(Z)=∫₀ᶻ W(z)(1+z)² ΔX_e(z) dz, W=K/H_B,
K=n_H0 σ_T Mpc_m. Den oprindelige V66-konvention anvender n_H0
i m⁻³, σ_T i m², Mpc_m som meter pr. Mpc og H_B i Mpc⁻¹. K og H_B har
begge Mpc⁻¹; W, z, ΔX_e og F er dimensionsløse.

V121, V119 og V117 leverer E>b=1/16000000 på deres præcise,
sammenhængende domæner. På et barn [a,c] af en V66-række gælder
W≥W_l>0. Derfor er det eksakte lokale nedre bidrag

ℓ=b W_l M, hvor M=((1+c)³−(1+a)³)/3.

Vi anvender L=floor(2¹⁰⁰ℓ)/2¹⁰⁰, så 0≤ℓ−L<2⁻¹⁰⁰.
Polynomiemassen integreres eksakt. Kvadraturrest for denne
indhylling er nul; løshedsfejl fra W- og E-indhyllinger er stadig
indeholdt i det globale interval. De er ikke afrundingsfejl.

De 1.304 delintervaller dækker hele det nye domæne uden huller
eller overlap af positiv længde. De ligger i 1.292 V66-forældre
og 13 baseline-bins. V111's beskyttede strimmel begynder præcis
ved 1523417340748759/2199023255552 og slutter ved 700.
Ét fælles endepunkt har integralmasse nul. Derfor må de nye
bidrag lægges til de gamle nedre bin-endepunkter. Der tælles
intet tidligere bidrag igen. Alle øvre grænser bevares.

## Målt forbedring

Nyt nedre tillæg: `1052022321077674135187859/1267650600228229401496703205376` ≈ 8.298992805180e-07.
Globalt nedre endepunkt: 3.989673512674e-06
→ 4.819572793192e-06. Øvre endepunkt: 4.561016425335e-05, uændret.
Global bredde: 4.162049074067e-05 → 4.079059146015e-05.
Relativ breddereduktion: 1.993968032931 %.
Det er ændringen i intervallets bredde, ikke i den fysiske optiske dybde.

Samlet nedadrettet afrundingstab ≈ 5.169872405954e-28,
strengt mindre end 1304·2⁻¹⁰⁰ = 1.028674620408e-27.
Det eksakte tab og de uafrundede summer står i begge receipts.
Afrundingen er altså langt mindre end den resterende indhyllingsbredde.
Bredden er 10197.64786504 gange det foreløbige mål 4×10⁻⁹.
Målet er ikke opfyldt og er ikke alene Q052's afslutningskriterium.

| z-bin | Nyt nedre endepunkt (≈) | Bevaret øvre endepunkt (≈) | Nye nedre delstykker |
|---|---:|---:|---:|
| 0:50 | 0.000000000000e+00 | 7.043392760568e-07 | 0 |
| 50:100 | 2.247490882881e-09 | 1.321804614364e-06 | 101 |
| 100:150 | 6.040671618764e-09 | 1.703562157119e-06 | 102 |
| 150:200 | 1.171166460013e-08 | 2.013275740947e-06 | 101 |
| 200:250 | 1.926046982699e-08 | 2.281098218363e-06 | 102 |
| 250:300 | 2.868708729933e-08 | 2.520482330350e-06 | 101 |
| 300:350 | 3.999151701716e-08 | 2.739000831524e-06 | 102 |
| 350:400 | 5.317375898047e-08 | 2.941272307933e-06 | 101 |
| 400:450 | 6.823381318928e-08 | 3.130509025110e-06 | 102 |
| 450:500 | 8.517167964356e-08 | 3.308905374111e-06 | 101 |
| 500:550 | 1.039873583433e-07 | 3.478178230207e-06 | 102 |
| 550:600 | 1.246808492886e-07 | 3.639560009282e-06 | 101 |
| 600:650 | 1.472521524793e-07 | 3.794099639080e-06 | 102 |
| 650:700 | 3.313767252201e-07 | 3.703678803428e-06 | 86 |
| 700:750 | 1.849590008120e-06 | 3.716040711905e-06 | 0 |
| 750:800 | 1.902330387653e-06 | 3.819211958293e-06 | 0 |
| 800:810 | 4.583715902963e-08 | 7.951450252741e-07 | 0 |

Baseline-tredjefeltet i JSON-bins er det arvede antal
indhyllingsstykker; de nye bidragsantal ligger i `bin_changes`.
Det største resterende bin er 600:650. Området 0:50 står for
cirka 1.726720 % af den samlede bredde.
Dette er en rangering af gemte intervaller, ikke en ny integration
eller en dokumenteret fejlfordeling mellem vægt og elektronhistorie.

## Uafhængig kontrol og fælles begrænsninger

Primærmetoden læser den frosne V122-geometri. Kontrollen læser
hverken denne geometri, producentkode eller producentreceipt.
Den rekonstruerer selv partitionen fra de fulde V66-rækker,
V121/V119/V117's faktiske endepunkter, V112-bin-grænser og V111's
beskyttede strimmel. Den traverserer baglæns, parser hex-tal med
heltalsaritmetik og bruger den faktoriserede masse
(c−a)((1+a)²+(1+a)(1+c)+(1+c)²)/3 samt divmod til afrunding.

To separate subprocesser sluttede med exit 0. Kombineret wall-tid
1.070418499 sekunder, under 120-sekundersgrænsen.
Alle 1.304 geometrier, vægte, masser, uafrundede bidrag, afrundede
bidrag, binændringer og globale summer er eksakt ens.
Forskellig nøgleorden giver forskellige filhashes, men de parsede
JSON-objekter er identiske. Kode- og inputhashes blev frosset før
execution og er uændrede efter execution.

Uafhængigheden gælder implementation, partition, traversal,
hex-dekodning og algebraisk udtryk. Begge metoder deler de
arkiverede fysikforudsætninger og Python Fraction. R3 gælder
denne lokale aritmetiske deltest; ingen ekstern reproduktion,
ny empirisk baggrundstest eller native certificering hævdes.

## Falsifikatorer og næste krav

Forkert W-konvention, et gulv anvendt uden for sit certificerede
domæne, dobbeltregning, inputidentitetsbrud eller ulukket
kontrolmismatch ville ugyldiggøre denne opdatering. Ingen af
disse fejl blev fundet i de afgrænsede checks.

Q052 forbliver INCONCLUSIVE. De faktiske native baner, baggrundens
admission, koordinat-/banekonsistens, reproducerbarhed og samlet
numerisk fejl kræver særskilt evidens. Den fælles kildeberegnings
optiske intervalbredde er fortsat væsentlig. Der er nul nye
vægtberegninger, dynamiske integrationer, native par eller
parametersøgninger i V123. Næste motor skal indtage det nye
resultat og fryse én ændret test, begrundet i restbredden.
