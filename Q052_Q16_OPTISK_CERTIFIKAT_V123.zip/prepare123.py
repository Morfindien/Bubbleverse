from pathlib import Path
from fractions import Fraction as F
import json, hashlib, zipfile, io, shutil, datetime

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent.parent
def sha(b): return hashlib.sha256(b).hexdigest()
def js(b): return json.loads(b)
def put(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')

def main():
    task=js((BASE/'upload/Q052_MATEMATIKOPGAVE_V122.json').read_bytes())
    f=dict(task); fp=f.pop('fingerprint_sha256')
    assert sha(json.dumps(f,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==fp
    assert task['target_q']=='Q052' and task['source_state_version']=='V122'
    assert sha((BASE/'upload/Bubbleverse_Matematikmotor_2.3.0-54.md').read_bytes())==task['engine_prompt_sha256']
    repo=js((ROOT/'repository123.json').read_bytes()); repo_matches={}
    mapping={'Bubbleverse_Matematikmotor_2.3.0.md':'Bubbleverse_Matematikmotor_2.3.0-54.md'}
    for e in repo['entries']:
        p=BASE/'upload'/mapping.get(e['path'],e['path'])
        if not p.is_file(): continue
        b=p.read_bytes(); blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        assert blob==e['sha'] and len(b)==e['size'], e['path']
        repo_matches[e['path']]={'git_blob':blob,'sha256':sha(b),'size_bytes':len(b)}
    assert len(repo_matches)==5
    z=zipfile.ZipFile(BASE/'upload'/task['input_archive']); assert z.testzip() is None
    manifest=js(z.read('manifest122.json'))
    for m in manifest['members']:
        b=z.read(m['path']); assert len(b)==m['size_bytes'] and sha(b)==m['sha256']
    assert z.read('Q052_MATEMATIKOPGAVE_V122.json')==(BASE/'upload/Q052_MATEMATIKOPGAVE_V122.json').read_bytes()
    journal=(BASE/'upload/Q052_INGESTION_OG_SAMLET_JOURNAL_V122-1.md').read_bytes()
    assert journal==z.read('Q052_INGESTION_OG_SAMLET_JOURNAL_V122.md')
    v121=zipfile.ZipFile(io.BytesIO(z.read('history/Q052_Q16_HMLA_CERTIFIKAT_V121.zip')))
    old=v121.read('Q052_MATEMATIK_OG_SAMLET_JOURNAL_V121.md')
    assert journal==old+z.read('journal_append122.md')
    assert sha(old)==manifest['parent_journal_sha256']
    for n,h in task['input_refs'].items(): assert sha(z.read(n))==h,n
    dest=ROOT/'input';dest.mkdir(exist_ok=True)
    names=['baseline122.json','geometry122.json','activity_ledger122.json','audit122.json','input/V121/result121.json','input/V119/result119.json','input/V119/input/v117/result117.json','input/V112/audit112.json','input/V111/result111.json','input/V111/calc/control111.json','input/V95/v95.json']
    for n in names: (dest/Path(n).name).write_bytes(z.read(n))
    (dest/'task122.json').write_bytes(z.read('Q052_MATEMATIKOPGAVE_V122.json'))
    weights=zipfile.ZipFile(io.BytesIO(z.read(task['frozen']['weight_archive'])))
    b=weights.read('receipt.json'); assert sha(b)==task['frozen']['weight_receipt_sha256']
    assert js(weights.read('control.json'))['status']=='PASS'
    (dest/'weights66.json').write_bytes(b)
    (dest/'v62.json').write_bytes(v121.read('input/v91/v62.json'))
    d=js(b); assert len(d['source_segments'])==4990
    rows=d['source_segments']; assert rows[0]['z'][0]=='0' and rows[-1]['z'][1]=='810'
    for i,r in enumerate(rows):
        a,c=map(F,r['z']); wl,wu=map(F,r['K_over_H_exact']); assert a<c and 0<wl<=wu
        if i: assert F(rows[i-1]['z'][1])==a
    baseline=js((dest/'baseline122.json').read_bytes()); a112=js((dest/'audit112.json').read_bytes()); o=js((dest/'result111.json').read_bytes())['optical_result']; c111=js((dest/'control111.json').read_bytes())
    assert a112['technical_state']=='PASS' and a112['ingestion_state']=='ACCEPTED_CONDITIONAL_SOURCE_REAL'
    assert baseline['current_bins']==a112['current_bins']==o['current_bins']
    assert baseline['global_interval']==a112['global_interval']==o['new_global_interval']
    assert baseline['global_width']==a112['global_width']==o['global_width']
    assert c111['status']=='PASS' and c111['new_lower']==o['new_lower']==baseline['credited_V111_lower']
    for k in ['source_commit','capture_sha256']:
        assert a112[k]==task[k] and js((dest/'result121.json').read_bytes())[k]==task[k]
    assert js((dest/'result121.json').read_bytes())['background_dependency_id']==task['background_dependency_id']
    last=None
    for ((a,c),claim),n,key,bkey in zip(task['target']['floor_chain'],['result121.json','result119.json','result117.json'],['exact_z_ascending','domain_z_ascending','domain_z_ascending'],['b','constant_b','b']):
        r=js((dest/n).read_bytes()); assert r[key]==[a,c] and r['claim_id']==claim and r[bkey]==task['target']['floor'] and r['q']==task['target']['Q']
        assert r['technical_state']=='PASS'
        if last: assert a==last
        last=c
    assert last==baseline['credited_V111_support'][0]==task['target']['domain_z_ascending'][1]
    assert task['target']['floor_chain'][0][0][0]=='50'
    sign=js((dest/'v95.json').read_bytes());assert sign['status']=='ALL_373_PASS' and sign['combined_positive_z']==['0','810'] and sign['source_commit']==task['source_commit']
    bins=baseline['current_bins']; end=F(0); sums=[F(0),F(0)]
    for label,val in bins.items():
        a,c=map(F,label.split(':'));assert a==end and a<c;end=c
        lo,hi=map(F,val[:2]); assert 0<=lo<=hi;sums[0]+=lo;sums[1]+=hi
        if 50<=a<650: assert lo==0
    assert end==810 and list(map(str,sums))==baseline['global_interval']
    assert str(sums[1]-sums[0])==baseline['global_width']
    ledger=js((dest/'activity_ledger122.json').read_bytes());assert sum(x['run_points'] for x in ledger['entries'])==ledger['total_points_after']==task['total_points']==14780
    checks={'status':'PASS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repository_commit':repo['commit'],'repository_files':repo_matches,'task_fingerprint':fp,'V122_manifest_members':len(manifest['members']),'journal_prefix':'BYTE_IDENTICAL','journal_sha256':sha(journal),'journal_bytes':len(journal),'baseline_bins':len(bins),'global_positivity':'INHERITED_V95_CONDITIONAL_SOURCE_REAL','floor_chain':task['target']['floor_chain'],'all_input_refs_verified':True,'weight_source_segments':len(rows),'new_optical_evaluations':0,'ledger_total':14780,'ledger_auxiliary_note':'Parent reconciliation field refers to historical V118; current total is independently summed from immutable entries. V123 will refresh only its own auxiliary reconciliation.'}
    put(ROOT/'input_check123.json',checks)
    print(json.dumps({k:v for k,v in checks.items() if k not in ['repository_files','floor_chain']}))

if __name__=='__main__': main()
