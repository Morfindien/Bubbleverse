from pathlib import Path
import json,sys,hashlib,subprocess,time,datetime,platform,os
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,x):(R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert not (R/'freeze123.json').exists(), 'Frozen run exists; no replay in this directory.'
assert json.loads((R/'input_check123.json').read_text())['status']=='PASS'
files=[R/n for n in ['primary123.py','control123.py','run123.py','prepare123.py','input_check123.json','repository123.json']]+sorted((R/'input').glob('*.json'))
freeze={'created_utc':now(),'run_id':'LOCAL-Q052-V123-Q16-SIGNED-OPTICAL-LOWER-50-TO-BRIDGE','wall_seconds_combined_limit':120,'planned_primary':1,'planned_controls':1,'files':{str(p.relative_to(R)):sha(p) for p in files},'python':sys.version,'platform':platform.platform(),'parameters':{'grid':'2^-100','b':'1/16000000','pieces':1304,'new_weights':0,'new_dynamics':0,'new_native_pairs':0}}
put('freeze123.json',freeze)
fd=os.open(R/'run123.lock',os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.write(fd,now().encode());os.close(fd)
execution={'status':'RUNNING','started_utc':now(),'freeze_sha256':sha(R/'freeze123.json'),'subprocesses':[]};put('execution123.json',execution)
total=0.0
try:
    for program,args in [('primary123.py',['primary123.json']),('control123.py',['control123.json','control_access123.json'])]:
        for n,h in freeze['files'].items():assert sha(R/n)==h,n
        cmd=[sys.executable,str(R/program)]+[str(R/a) for a in args];started=now();t=time.monotonic()
        run=subprocess.run(cmd,capture_output=True,text=True,timeout=120-total)
        wall=time.monotonic()-t;total+=wall
        log=program.replace('.py','.log');(R/log).write_text(run.stdout+run.stderr)
        execution['subprocesses'].append({'command':cmd,'started_utc':started,'ended_utc':now(),'wall_seconds':wall,'returncode':run.returncode,'log':log});put('execution123.json',execution)
        assert run.returncode==0,run.stderr
        assert total<=120
    a=json.loads((R/'primary123.json').read_text());b=json.loads((R/'control123.json').read_text())
    assert a==b,'Exact output mismatch; no interval promotion.'
    check={'status':'PASS','piece_count':len(a['rows']),'all_rows_exactly_equal':True,'all_bin_changes_exactly_equal':True,'all_rounded_unrounded_sums_exactly_equal':True,'upper_endpoints_unchanged':a['upper_endpoints_unchanged'],'support_overlap':a['support_overlap'],'first_inconsistent_row_or_bin':None,'primary_sha256':sha(R/'primary123.json'),'control_sha256':sha(R/'control123.json'),'code_and_inputs_unchanged_after_run':all(sha(R/n)==h for n,h in freeze['files'].items())}
    assert check['code_and_inputs_unchanged_after_run'];put('validation123.json',check)
    execution['status']='PASS'
except Exception as e:
    execution['status']='FAIL_OR_INCOMPLETE';execution['error']=repr(e);raise
finally:
    execution['ended_utc']=now();execution['wall_seconds_combined']=total;execution['actual_primary_evaluations']=sum('primary123.py' in x['command'][1] for x in execution['subprocesses']);execution['actual_independent_controls']=sum('control123.py' in x['command'][1] for x in execution['subprocesses']);put('execution123.json',execution)
print(json.dumps({'execution':execution['status'],'combined_seconds':total,'validation':'validation123.json'}))
