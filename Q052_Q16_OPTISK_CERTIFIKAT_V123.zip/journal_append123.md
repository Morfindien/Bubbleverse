

---

# Q052 V123 — q/16-gulvet giver et nyt optisk nedre bidrag

UTC 2026-11-16T16:48:29.778725+00:00. Run `LOCAL-Q052-V123-Q16-SIGNED-OPTICAL-LOWER-50-TO-BRIDGE`. Claim `LOCAL-Q052-V123-C1`.
BUBBLEVERSE.MATHEMATICS 2.3.0. Evidensgrænse Q052 til og med V123.
WORKFLOW_STATE READY_FOR_HANDOFF · TECHNICAL_STATE PASS · SCIENTIFIC_STATE INCONCLUSIVE.

## Oprindeligt spørgsmål

Under the pinned hillipop-ede_n3 source/configuration, the same fixed admitted common background and matched validated z=810 start state used by Q051, does the actual native CLASS/P6 low-z implementation produce q=xHeII=10^-6 versus q=0 electron-fraction and Thomson-optical-depth histories that are reproducible, trajectory-consistent with the literal source-real dynamics, and contained within Q051's uniform analytic bounds; and what are the realized sup|Delta x_e| and sup|Delta tau_T| with a validated numerical error certificate?

## Nyt dokumenteret resultat

Under det frosne kilde-, baggrunds-, start- og banedomæne er den
samlede signerede kilde-reelle Thomson-forskel F(810) indeholdt i
`381845896508367207321097/79228162514264337593543950336` til
`28908876046131453968421139/633825300114114700748351602688`.
Det er cirka [4.819572793192e-06, 4.561016425335e-05], dimensionsløst.
V95's arvede fortegn bestemmer maksimumstedet for denne definerede
kildeakkumulation ved z810. Det er ikke et native fejlcertifikat.

Det nye nedre bidrag er `1052022321077674135187859/1267650600228229401496703205376` ≈ 8.298992805180e-07.
Global bredde falder fra 4.162049074067e-05 til 4.079059146015e-05,
svarende til 1.993968032931 %.
Bredden er fortsat 10197.64786504 gange det foreløbige mål 4×10⁻⁹.
Ingen ændring i den fysiske optiske dybde udledes af breddereduktionen.

## Metode og kontrol

1.304 delintervaller fra 1.292 oprindelige V66-rækker dækker
[50, 1523417340748759/2199023255552] over 13 bins. Hver bruger den
oprindelige positive W-undergrænse og den nye E>q/16-dækning.
Eksakt masse M=((1+c)³−(1+a)³)/3 og nedrunding på 2⁻¹⁰⁰-gitter
giver et samlet afrundingstab cirka 5.169872405954e-28.
Det er mindre end 1.028674620408e-27.

Den separate kontrol konstruerer partitionen direkte fra de fulde
V66-rækker, faktiske bevisendepunkter og baseline. Den læser ikke
V122-geometrien eller producentens kode/receipt. Omvendt traversal,
heltalsbaseret hex-dekodning, faktoriseret masse og divmod giver
præcis samme geometri, lokale bidrag, bins og globale summer.
To subprocesser sluttede med exit 0 efter samlet
1.070418499 sekunder. Frosne input- og kodehashes
er uændrede. Ingen anden primær eller separat kørsel udført.

Det gamle V111-bidrag på [1523417340748759/2199023255552,700]
bevares én gang. Områderne deler kun endepunkt. Alle 17 øvre
bin-endepunkter og de fire uberørte binintervaller er uændrede.
Der er nul nye vægte, feltberegninger, skalare/fulde
historieintegrationer, native par eller parametersøgninger.

## Proveniens, afgrænsning og næste opgave

GitHub-main `3a588f12b301237f9566a1f6dfeaec38ca98026b` matcher alle fem aktuelle vedhæftede inputs,
inklusive Matematikmotor 2.3.0. V122-arkivets 40 manifestmedlemmer
og dets historiske præfiks er verificeret. Det fulde V122-journalpræfiks
på 9623732 bytes bevares identisk i denne fil.
Fysikkilden er `5a131c91d657dd9a7c6364cc45b038710f8d0d97`; capture er
`2514e250d20c456530be63e790a079176293a87a82c927b1e748d1eec405da9b`; baggrund er `Q050-COMMON-BACKGROUND-92de319899bf911563aff4d1`.
Kildehenvisninger, hashkæde og alle forudsætninger følger certifikatet.

G1 og de lokale G2–G5 består under de frosne antagelser. G6 er
åben: global kildeoptisk præcision samt native admission,
koordinat-/banekonsistens, reproducerbarhed og numerisk fejl.
G7 består med uændret historisk præfiks. MODEL_DIFF NONE.
Reproducerbarhed R3 gælder kun denne aritmetiske deltest og to
separate implementationer med fælles arkiver/Python Fraction.
Ingen ekstern reproduktion eller empirisk bekræftelse hævdes.

Næste motor er `BUBBLEVERSE.RESULT_INGESTION_ROUTING 2.3.0`. Opgaven `Q052_RESULTATINDTAG_OPGAVE_V123.json`
er PREPARED_NOT_EXECUTED med fingeraftryk
`10e7304f3365230e84d52cd7b215ba1ac45dab8e7af347a03f063903001d1d4a`. Den skal optage det nye interval
uden genkørsel og forberede én ændret præcisionstest med konkret
starttilstand og dæknings-/fejlkrav. Størst restbredde ligger i
600:650; 0:50 udgør kun cirka 1.726720 %.
Det fulde resterende budget står i `width_budget123.json`.
CONTINUE_SAME_Q true. De fire nye filer er klar til manuel upload
efter den eksisterende rodstruktur. GitHub-write er ikke udført.

## Point og udgivelse

POINTS_EVENT RESEARCH_RUN. EVENT_ID `Q052-ACTIVITY-Q16-SIGNED-OPTICAL-V123`.
PREVIOUS_POINTS_ENTRY `Q052-ACTIVITY-Q16-PHASE5-OPTICAL-INTAKE-V122`.
Analyse 35, beregning 25, kildesporing 5, validering 35.
RUN POINTS 100 · TOTAL POINTS 14880 · CYCLE PROGRESS 880/1000.
NEXT SOME MILESTONE 15000 · POINTS TO NEXT PUBLICATION 120.
POINTS_STATE VERIFIED · PUBLICATION_STATE NOT_DUE.
Ingen ny milepæl eller udestående pakke. M001–M014 videreføres som leveret.

Redaktionelt skøn: bevis for additiv opdatering uden overlap, én eksakt 1304-stykkers sum og én separat omvendt konstruktion, GitHub/inputidentitet samt eksakt sammenligning af bidrag, bins, bevarede grænser og afrunding. Ingen nye point for V121-feltbevis, V122-geometriforberedelse, historiske integralbidrag, arkivpakning eller genlevering.

V122-ledgerens hjælpefelt reconciliation refererede stadig til V118;
de historiske entries og totalsummen var korrekte. Kun V123's eget
hjælpefelt opdateres til den aktuelle, kontrolsummerede bevægelse.
Historiske filer og poster omskrives ikke, og der tilføjes ingen
korrektionspoint for dette administrative felt.
