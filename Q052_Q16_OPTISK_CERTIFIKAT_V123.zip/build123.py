from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from zipfile import ZipFile,ZIP_DEFLATED,ZIP_STORED
import hashlib,json,sys,shutil,subprocess,ast
sys.set_int_max_str_digits(0)
R=Path(__file__).resolve().parent;BASE=R.parent.parent;OUT=BASE/'output/V123';OUT.mkdir(parents=True,exist_ok=True)
ZIP='Q052_Q16_OPTISK_CERTIFIKAT_V123.zip';SHORT='Q052_KORT_RESULTAT_V123.md';JOURNAL='Q052_MATEMATIK_OG_SAMLET_JOURNAL_V123.md';NEXT='Q052_RESULTATINDTAG_OPGAVE_V123.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
enc=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def read(n):return json.loads((R/n).read_bytes())
def put(n,x):(R/n).write_bytes(enc(x))
def fingerprint(x):return sha(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
now=datetime.now(timezone.utc).isoformat();task=read('input/task122.json');p=read('primary123.json');control=read('control123.json');ex=read('execution123.json');val=read('validation123.json');pre=read('input_check123.json')
assert p==control and ex['status']==val['status']==pre['status']=='PASS'
rid=task['task_id'];claim='LOCAL-Q052-V123-C1';event='Q052-ACTIVITY-Q16-SIGNED-OPTICAL-V123'
priorledger=(R/'input/activity_ledger122.json').read_bytes();ledger=json.loads(priorledger);previous_event=ledger['entries'][-1]['activity_event_id']
breakdown={'analysis_points':35,'computation_points':25,'search_points':5,'validation_points':35};points=sum(breakdown.values());total=ledger['total_points_after']+points
basis='Redaktionelt skøn: bevis for additiv opdatering uden overlap, én eksakt 1304-stykkers sum og én separat omvendt konstruktion, GitHub/inputidentitet samt eksakt sammenligning af bidrag, bins, bevarede grænser og afrunding. Ingen nye point for V121-feltbevis, V122-geometriforberedelse, historiske integralbidrag, arkivpakning eller genlevering.'
assert total==14880 and not ledger['pending_packages'];assert not any(e['run_id']==rid for e in ledger['entries'])
ledger['entries'].append({'run_id':rid,'activity_event_id':event,'engine':task['engine'],'run_points':points,'breakdown':breakdown,'basis':basis,'counted_once':True})
ledger.update({'previous_ledger_ref':'history/Q052_INGESTION_CERTIFICATE_V122.zip!activity_ledger122.json','previous_total_points':14780,'parent_ledger_sha256':sha(priorledger),'total_points_after':total,'cycle_progress':880,'next_publication_at':15000,'points_to_next_publication':120,'ledger_revision':'V123','last_updated_utc':now,'new_milestones':[],'pending_packages':[],'scientific_state':'INCONCLUSIVE','workflow_state':'READY_FOR_HANDOFF','point_state':'VERIFIED','reconciliation':{'prior_total':14780,'new_unique_event_points':100,'current_total':14880,'old_entries_preserved':True},'note':'V123 adds one research event. Prior entries and M001–M014 delivery records preserved. Auxiliary reconciliation refreshed; the parent V122 field still referred to V118, while its entries and total were correct.'})
assert sum(x['run_points'] for x in ledger['entries'])==total
put('activity_ledger123.json',ledger)
width=F(p['global_width']);oldwidth=F(p['prior_global_width']);gain=F(p['gain']);goal=F(p['provisional_width_goal']);lo,hi=map(F,p['new_global_interval'])
rank=[]
for name,v in p['current_bins'].items():
    w=F(v[1])-F(v[0]);rank.append({'bin':name,'width':str(w),'share':str(w/width),'lower':v[0],'upper':v[1],'new_pieces':p['bin_changes'][name]['pieces'],'new_lower_gain':p['bin_changes'][name]['rounded_gain']})
rank.sort(key=lambda x:F(x['width']),reverse=True)
budget={'status':'STORED_ARITHMETIC_ONLY','global_width':str(width),'provisional_width_goal':str(goal),'ratio_to_goal':p['global_width_goal_ratio'],'ranked_bins':rank,'largest_bin':rank[0]['bin'],'phase6_bin':'0:50','phase6_width_share':next(x['share'] for x in rank if x['bin']=='0:50'),'new_optical_evaluations':0,'meaning':'Ranks deterministic enclosure widths, not physical effect sizes or measured uncertainties. No new integration, fitted model or field evaluation.'}
put('width_budget123.json',budget)
result={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','version':'V123','target_q':'Q052','run_id':rid,'claim_id':claim,'created_utc':now,'exact_question':task['exact_question'],'workflow_state':'READY_FOR_HANDOFF','technical_state':'PASS','scientific_state':'INCONCLUSIVE','local_scientific_state':'SUPPORTED_WITHIN_TESTED_DOMAIN','claim':'Conditional source-real accumulated Thomson maximum F(810) is contained in the exact updated interval; no native numerical-error certificate is inferred.','observable':'F(Z)=integral_0^Z W(z)(1+z)^2 DeltaX_e(z) dz; source-real signed public-electron accumulation','observable_unit':'dimensionless','observable_domain':['0','810'],'new_lower_support':p['new_support'],'new_support_electron_floor':'1/16000000','new_support_public_equals_raw_electron_difference':True,'floor_proof_chain':task['target']['floor_chain'],'global_positive_premise':'V95, reused under inherited conditions','conditional_maximum_location':'810','source_commit':task['source_commit'],'capture_sha256':task['capture_sha256'],'background_dependency_id':task['background_dependency_id'],'input_task_fingerprint':task['fingerprint_sha256'],'pieces':1304,'distinct_V66_rows':1292,'affected_bins':13,'grid':'2^-100','new_global_interval':p['new_global_interval'],'prior_global_interval':p['prior_global_interval'],'gain':p['gain'],'unrounded_gain':p['unrounded_gain'],'rounding_loss':p['rounding_loss'],'rounding_loss_strict_upper':p['rounding_loss_strict_upper'],'global_width':p['global_width'],'global_width_reduction_fraction':p['global_width_reduction_fraction'],'global_width_goal_ratio':p['global_width_goal_ratio'],'provisional_width_goal':p['provisional_width_goal'],'provisional_precision_target_met':False,'current_bins':p['current_bins'],'protected_V111_support':p['protected_support'],'protected_V111_lower':p['protected_lower_preserved'],'support_overlap':p['support_overlap'],'upper_endpoints_unchanged':True,'knowledge_type':['BEREGNET','MODELINFERERET'],'new_primary_optical_sums':1,'independent_controls':1,'new_weight_evaluations':0,'new_scalar_integrations':0,'new_full_history_integrations':0,'new_native_pairs':0,'parameter_searches':0,'execution_wall_seconds_combined':ex['wall_seconds_combined'],'execution_ref':'execution123.json','validation_ref':'validation123.json','proof_ref':'PROOF_V123.md','primary_ref':'primary123.json','control_ref':'control123.json','inherited_assumptions':['Frozen hillipop-ede_n3 source/configuration and the same fixed admitted common background.','Matched validated z=810 starting states and inherited continuous source-real trajectory boxes.','V121/V119/V117 q/16 floors on precisely their verified domains; V111/V109/V105 prior credited optical contributions.','V66 positive W enclosures in the original unit convention; V95 positivity for the public electron difference throughout the source history.'],'not_claimed':['Native CLASS/P6 trajectory identity, reproducibility or validated whole-history error.','A new point estimate or empirical observation of optical depth.','A q/16 proof below z=50, a stronger barrier or changed background.','Q052 closure or an accepted physical-model promotion.'],'run_points':points,'total_points':total,'points_to_next_publication':120,'next_milestone':15000,'publication_state':'NOT_DUE'}
put('result123.json',result)
refs={n:sha((R/n).read_bytes()) for n in ['result123.json','primary123.json','control123.json','validation123.json','execution123.json','freeze123.json','input_check123.json','control_access123.json','width_budget123.json','activity_ledger123.json']}
nexttask={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','state':'PREPARED_NOT_EXECUTED','task_id':'LOCAL-Q052-V124-SIGNED-OPTICAL-UPDATE-INTAKE-AND-PRECISION-ROUTING','engine':task['return_engine'],'case_id':task['case_id'],'current_q':'Q052','target_q':'Q052','continue_same_q':True,'exact_question':task['exact_question'],'source_state_version':'V123','evidence_boundary':'Q052 through V123','journal_ref':JOURNAL,'input_archive':ZIP,'input_refs':refs,'source_commit':task['source_commit'],'capture_sha256':task['capture_sha256'],'background_dependency_id':task['background_dependency_id'],'objective':'Admit the one new conditional source-optical interval after stored-evidence audit, then prepare one materially changed precision-reduction test from the residual width budget.','claim_to_ingest':claim,'expected_exact_interval':p['new_global_interval'],'expected_gain':p['gain'],'expected_width':p['global_width'],'provisional_width_goal':str(goal),'steps':['Verify all manifest members, task fingerprint, unchanged V122 journal prefix, frozen source/configuration and original V66 ancestry in the embedded V122 archive.','Audit the two stored receipts: 1304 exact piece identities, exact and rounded sums, 13 changed lower bins, 1292 V66 parents, no positive-length overlap with V111, and all 17 preserved upper endpoints. Do not rerun either optical implementation.','Admit LOCAL-Q052-V123-C1 only as a conditional source-real bound. Record the 1.993968 percent relative width decrease and the approximately 10197.65 width-goal ratio. Keep actual native trajectory and error obligations open.','Verify and rank the 17 stored residual bin widths. The current largest bin is 600:650. Distinguish electron-enclosure slack from original weight-enclosure slack using archived V62/V66 and the proof dependencies; do not evaluate new weights or dynamics during ingestion.','Prepare one changed-method or changed-input mathematics contract addressing a quantitatively justified dominant source-optical uncertainty. Start the feasibility audit at 600:650. Identify an applicable certified starting state, actual coordinate convention, whole-bin coverage, a meaningful precision criterion, an independent control and a finite stop rule. If these cannot be established, record the concrete missing certificate and prepare its recovery instead of an unexecutable integration order.','The 0:50 bin contributes only about 1.72672 percent of the current width. Do not prioritize phase-6 q/16 continuation merely because it is the next redshift segment. Any such choice must document why it resolves a material main-question obligation.','Carry forward the point ledger exactly once and keep the original Q052 scope. Produce one bounded next task, not alternative simultaneously executed branches.'],'acceptance_criteria':'All stored arithmetic, provenance and support checks pass; the new interval is admitted under explicit source-real conditions, and one actionable changed scientific test is prepared with verified dependencies.','rejection_criteria':'Verified hash/source/domain mismatch, any duplicated positive-length optical support, inconsistent exact sums or a new lower endpoint exceeding its preserved upper endpoint. Preserve the V112 baseline if V123 cannot be admitted.','inconclusive_criteria':'Missing mandatory ancestry, missing independent agreement or insufficient starting-state/method applicability prevents the affected claim or next execution contract from being promoted.','execution_limits':{'new_optical_evaluations':0,'new_weight_evaluations':0,'new_field_evaluations':0,'new_scalar_integrations':0,'new_full_history_integrations':0,'new_native_pairs':0,'parameter_searches':0,'stored_arithmetic_audit':True},'stop_condition':'One result intake and one bounded next scientific task, or the first unresolved mandatory evidence gate.','expected_output':'V124 intake certificate, unchanged-prefix journal, current residual-width rationale and one frozen next task.','no_repeat':task['no_repeat']+['V123 primary 1304-piece optical sum and independent reverse control on unchanged inputs.','V123 stored arithmetic, packaging or optional technical replay must not be credited as another optical result.','V111 protected-strip lower contribution may not be added a second time.','A maximum-location search is already settled for the defined conditional source accumulation.','Unchanged q/16 floors and unchanged V66 weights cannot yield a different exact V123 sum. A new numerical attempt requires a concrete changed method/input or validation defect.'],'activity_ledger_ref':'activity_ledger123.json','total_points':total,'next_milestone':15000,'points_to_next_publication':120,'publication_state':'NOT_DUE','max_deliverable_bytes':25000000}
nexttask['fingerprint_sha256']=fingerprint(nexttask);(OUT/NEXT).write_bytes(enc(nexttask))
repo=pre['repository_commit'];files=[SHORT,JOURNAL,NEXT,ZIP]
memory={'repository':'Morfindien/Bubbleverse','branch':'main','verified_base':repo,'github_read_state':'VERIFIED','github_write_state':'READY_FOR_MANUAL_UPLOAD','sync_status':'USER_UPLOAD_PENDING','prompt_id':'BUBBLEVERSE.MATHEMATICS','prompt_version':'2.3.0','target_q':'Q052','exact_question':task['exact_question'],'workflow_state':'READY_FOR_HANDOFF','scientific_state':'INCONCLUSIVE','technical_state':'PASS','claim_id':claim,'new_result_ref':'result123.json','journal_ref':JOURNAL,'next_engine':task['return_engine'],'next_task':NEXT,'input_archive':'history/Q052_INGESTION_CERTIFICATE_V122.zip','completed_test_no_repeat':rid,'upload_new_root_files':files,'proposed_root_paths':{n:n for n in files},'proposed_index_updates':{'case':'Q052 ACTIVE / INCONCLUSIVE','journal':JOURNAL,'claim':claim,'conditional_source_optical_interval':p['new_global_interval'],'task':NEXT,'total_points':total,'publication_state':'NOT_DUE'},'instructions':'Upload the four new V123 root files without replacing historical versions. Update only current Q052 index references; no physical-model promotion. No GitHub upload was performed in this run.','points':{'run_points':points,'total_points':total,'event_id':event,'ledger_ref':'activity_ledger123.json','next_milestone':15000,'points_to_next_publication':120,'new_milestones':[]},'remaining_obligations':['Global source-optical interval precision','Actual native background admission, coordinate/trajectory consistency, reproducibility and whole-history numerical error'],'manifest_ref':'manifest123.json','hash_convention':'Final hashes of non-archive deliverables are in manifest123.json. Archive hash is recorded in the separate delivery receipt; no circular hash.'}
put('github_memory_update123.json',memory)
source={'target_q':'Q052','evidence_boundary':'Q052 through V123','repository_base':repo,'input_identity_ref':'input_check123.json','source_commit':task['source_commit'],'capture_sha256':task['capture_sha256'],'background_dependency_id':task['background_dependency_id'],'sources':[{'id':'K1','role':'Authoritative V122 state and immutable journal','reference':'history/Q052_INGESTION_CERTIFICATE_V122.zip','repository_url':'https://github.com/Morfindien/Bubbleverse/tree/'+repo,'verification':'Five attached/root Git blobs and archive members verified.'},{'id':'K2','role':'Positive original Thomson weight enclosures','reference':'history/Q052_INGESTION_CERTIFICATE_V122.zip!history/Q052_THOMSON_CERTIFICATE_V66.zip!receipt.json','sha256':task['frozen']['weight_receipt_sha256'],'verification':'Pinned raw bytes and prior PASS; no weight reevaluation.'},{'id':'K3','role':'q/16 floor chain','references':['input/result121.json','input/result119.json','input/result117.json'],'verification':'Pinned result identities, exact joins and applicable closed domains; dynamical proofs inherited.'},{'id':'K4','role':'Frozen signed optical baseline and protected V111 strip','references':['input/audit112.json','input/result111.json','input/control111.json'],'verification':'All 17 bins and prior totals reconciled.'},{'id':'K5','role':'Global positivity and source maximum at z810','reference':'input/v95.json','verification':'Pinned ALL_373_PASS and [0,810] public-electron positivity; inherited source-real conditions.'}],'claim_evidence_map':{claim:['PROOF_V123.md','primary123.json','control123.json','validation123.json','execution123.json','result123.json']},'external_new_physical_data':'NONE','limitations':'Shared archived physics, source assumptions and Python Fraction backend. Separate implementations do not provide independent empirical validation.'}
put('source_register123.json',source)
bins_table='\n'.join(f"| {k} | {float(F(v[0])):.12e} | {float(F(v[1])):.12e} | {p['bin_changes'][k]['pieces']} |" for k,v in p['current_bins'].items())
proof=f'''# Q052 V123 — eksakt optisk q/16-bidrag

## Udsagn og forudsætninger

Claim `{claim}`. Under den samme frosne hillipop-ede_n3-kilde,
fælles B★ og matchede z810-starter giver den betingede kilde-reelle
akkumulation F(810) intervallet

`{p['new_global_interval'][0]}` ≤ F(810) ≤ `{p['new_global_interval'][1]}`.

De viste decimaler er tilnærmelser; brøkerne i receipts er autoritative.
F er den signerede Thomson-forskel fra 0 til Z. V95's arvede
positive offentlige elektronforskel og positive vægt giver
max₀≤Z≤810 |F(Z)| = F(810). Det er et deterministisk betinget interval,
ikke et statistisk konfidensinterval eller en observation.

På det nye domæne [50, {p['new_support'][1]}] ligger vi over
reionisationskortets aktive område. Her er den offentlige ΔX_e lig
E=h_L+q−h_R. Ved lavere z bruger den arvede globale baseline den
offentlige forskel inklusive sit reionisationskort; V123 udvider
ikke rå E's q/16-udsagn ned under z=50.

## Ligning, dimensioner og undergrænse

F(Z)=∫₀ᶻ W(z)(1+z)² ΔX_e(z) dz, W=K/H_B,
K=n_H0 σ_T Mpc_m. Den oprindelige V66-konvention anvender n_H0
i m⁻³, σ_T i m², Mpc_m som meter pr. Mpc og H_B i Mpc⁻¹. K og H_B har
begge Mpc⁻¹; W, z, ΔX_e og F er dimensionsløse.

V121, V119 og V117 leverer E>b=1/16000000 på deres præcise,
sammenhængende domæner. På et barn [a,c] af en V66-række gælder
W≥W_l>0. Derfor er det eksakte lokale nedre bidrag

ℓ=b W_l M, hvor M=((1+c)³−(1+a)³)/3.

Vi anvender L=floor(2¹⁰⁰ℓ)/2¹⁰⁰, så 0≤ℓ−L<2⁻¹⁰⁰.
Polynomiemassen integreres eksakt. Kvadraturrest for denne
indhylling er nul; løshedsfejl fra W- og E-indhyllinger er stadig
indeholdt i det globale interval. De er ikke afrundingsfejl.

De 1.304 delintervaller dækker hele det nye domæne uden huller
eller overlap af positiv længde. De ligger i 1.292 V66-forældre
og 13 baseline-bins. V111's beskyttede strimmel begynder præcis
ved {p['protected_support'][0]} og slutter ved 700.
Ét fælles endepunkt har integralmasse nul. Derfor må de nye
bidrag lægges til de gamle nedre bin-endepunkter. Der tælles
intet tidligere bidrag igen. Alle øvre grænser bevares.

## Målt forbedring

Nyt nedre tillæg: `{p['gain']}` ≈ {float(gain):.12e}.
Globalt nedre endepunkt: {float(F(p['prior_global_interval'][0])):.12e}
→ {float(lo):.12e}. Øvre endepunkt: {float(hi):.12e}, uændret.
Global bredde: {float(oldwidth):.12e} → {float(width):.12e}.
Relativ breddereduktion: {float(F(p['global_width_reduction_fraction']))*100:.12f} %.
Det er ændringen i intervallets bredde, ikke i den fysiske optiske dybde.

Samlet nedadrettet afrundingstab ≈ {float(F(p['rounding_loss'])):.12e},
strengt mindre end 1304·2⁻¹⁰⁰ = {float(F(p['rounding_loss_strict_upper'])):.12e}.
Det eksakte tab og de uafrundede summer står i begge receipts.
Afrundingen er altså langt mindre end den resterende indhyllingsbredde.
Bredden er {float(width/goal):.8f} gange det foreløbige mål 4×10⁻⁹.
Målet er ikke opfyldt og er ikke alene Q052's afslutningskriterium.

| z-bin | Nyt nedre endepunkt (≈) | Bevaret øvre endepunkt (≈) | Nye nedre delstykker |
|---|---:|---:|---:|
{bins_table}

Baseline-tredjefeltet i JSON-bins er det arvede antal
indhyllingsstykker; de nye bidragsantal ligger i `bin_changes`.
Det største resterende bin er 600:650. Området 0:50 står for
cirka {100*float(F(budget['phase6_width_share'])):.6f} % af den samlede bredde.
Dette er en rangering af gemte intervaller, ikke en ny integration
eller en dokumenteret fejlfordeling mellem vægt og elektronhistorie.

## Uafhængig kontrol og fælles begrænsninger

Primærmetoden læser den frosne V122-geometri. Kontrollen læser
hverken denne geometri, producentkode eller producentreceipt.
Den rekonstruerer selv partitionen fra de fulde V66-rækker,
V121/V119/V117's faktiske endepunkter, V112-bin-grænser og V111's
beskyttede strimmel. Den traverserer baglæns, parser hex-tal med
heltalsaritmetik og bruger den faktoriserede masse
(c−a)((1+a)²+(1+a)(1+c)+(1+c)²)/3 samt divmod til afrunding.

To separate subprocesser sluttede med exit 0. Kombineret wall-tid
{ex['wall_seconds_combined']:.9f} sekunder, under 120-sekundersgrænsen.
Alle 1.304 geometrier, vægte, masser, uafrundede bidrag, afrundede
bidrag, binændringer og globale summer er eksakt ens.
Forskellig nøgleorden giver forskellige filhashes, men de parsede
JSON-objekter er identiske. Kode- og inputhashes blev frosset før
execution og er uændrede efter execution.

Uafhængigheden gælder implementation, partition, traversal,
hex-dekodning og algebraisk udtryk. Begge metoder deler de
arkiverede fysikforudsætninger og Python Fraction. R3 gælder
denne lokale aritmetiske deltest; ingen ekstern reproduktion,
ny empirisk baggrundstest eller native certificering hævdes.

## Falsifikatorer og næste krav

Forkert W-konvention, et gulv anvendt uden for sit certificerede
domæne, dobbeltregning, inputidentitetsbrud eller ulukket
kontrolmismatch ville ugyldiggøre denne opdatering. Ingen af
disse fejl blev fundet i de afgrænsede checks.

Q052 forbliver INCONCLUSIVE. De faktiske native baner, baggrundens
admission, koordinat-/banekonsistens, reproducerbarhed og samlet
numerisk fejl kræver særskilt evidens. Den fælles kildeberegnings
optiske intervalbredde er fortsat væsentlig. Der er nul nye
vægtberegninger, dynamiske integrationer, native par eller
parametersøgninger i V123. Næste motor skal indtage det nye
resultat og fryse én ændret test, begrundet i restbredden.
'''
(R/'PROOF_V123.md').write_text(proof)
setup={'current':'Codex in ChatGPT Work Mode; local Python and file execution observed','mode':'Default','model_or_reasoning_tier':'Exact runtime model label and reasoning tier not exposed','recommended':'Same available local Python standard-library setup for one stored-result intake','availability':'VERIFIED_AVAILABLE','capability_classes':['H','C','A'],'reason':'Exact finite rational sum and archive/provenance checks fit the present runtime. No HPC required for intake.','fallback':'Read-only stored evidence review and precise blocker if mandatory input cannot be verified.','upgrade_trigger':'A subsequent changed native/trajectory test needs actual runtime, source build or certified arithmetic unavailable here.','downgrade_trigger':'Once mathematical inputs are frozen, bookkeeping uses standard-library arithmetic only.','tools':{'local_files':'VERIFIED_AVAILABLE','python_fraction_subprocess_zip_hash':'VERIFIED_AVAILABLE','github_read':'VERIFIED_AVAILABLE','github_write':'NOT_USED_MANUAL_HANDOFF','new_external_physics_research':'NOT_NEEDED_FOR_FROZEN_SUM','subagents':'NOT_USED'}}
handoff={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','prompt_id':'BUBBLEVERSE.MATHEMATICS','prompt_version':'2.3.0','run_id':rid,'created_utc':now,'target_q':'Q052','authorized_q_range':['Q052','Q052'],'evidence_boundary':'Q052 through V123','exact_question':task['exact_question'],'journal_ref':JOURNAL,'journal_completeness':'Complete supplied V122 journal preserved byte-for-byte, with one V123 append.','workflow_state':'READY_FOR_HANDOFF','scientific_state':'INCONCLUSIVE','technical_state':'PASS','local_scientific_state':'SUPPORTED_WITHIN_TESTED_DOMAIN','result_ref':'result123.json','claim_refs':[claim],'completed_tests':['One primary exact sum on 1304 new pieces','One independent reverse-partition sum with exact full-output agreement'],'new_information':'Positive lower gain and 1.993968032931 percent smaller conditional source-optical interval.','blocker_id':'LOCAL-Q052-SOURCE-OPTICAL-PRECISION-AND-NATIVE-CERTIFICATE','blocker_description':'Global source-optical width remains approximately 4.07906e-5; native coordinate/trajectory, reproducibility and validated error obligations remain open.','next_engine':task['return_engine'],'next_task':NEXT,'next_task_fingerprint':nexttask['fingerprint_sha256'],'input_refs':refs,'source_refs':['source_register123.json'],'equations_ref':'PROOF_V123.md','units':'Dimensionless F, z, DeltaX_e and W','uncertainty':'Conditional deterministic enclosure, not a confidence interval','acceptance_criteria':nexttask['acceptance_criteria'],'rejection_criteria':nexttask['rejection_criteria'],'inconclusive_criteria':nexttask['inconclusive_criteria'],'expected_output_artifact':nexttask['expected_output'],'no_repeat_constraints':nexttask['no_repeat'],'resume_condition':'The delivered V123 package and stored receipts are available to the Result Ingestion engine. No new permission or points allocation required.','run_manifest_ref':'manifest123.json','setup_assessment':setup,'points':{'run_points':points,'total_points':total,'cycle_progress':880,'next_milestone':15000,'points_to_next_publication':120,'new_milestones':[],'event_id':event,'previous_points_entry':previous_event,'breakdown':breakdown,'basis':basis,'state':'VERIFIED'},'publication_state':'NOT_DUE','pending_packages':[],'delivered_milestone_ids':ledger['delivered_milestone_ids'],'delivery_files':files,'github_memory_update_ref':'github_memory_update123.json','github_read_state':'VERIFIED','github_write_state':'READY_FOR_MANUAL_UPLOAD','contract_validation':'Required local fields, references, exact question and task fingerprint checked; no external formal schema claimed.','termination_gates':{'G1':'PASS_EXACT_Q_AND_DOMAIN','G2':'PASS_FOR_LOCAL_CONDITIONAL_BOUND_ONLY','G3':'PASS_LOCAL_ARITHMETIC; GLOBAL_OPTICAL_PRECISION_OPEN','G4':'PASS_WITHIN_FROZEN_ASSUMPTIONS_ONLY','G5':'PASS_SEPARATE_IMPLEMENTATION_CONTROL','G6':'OPEN_NATIVE_AND_SOURCE_PRECISION_OBLIGATIONS','G7':'PASS_IMMUTABLE_PREFIX_AND_SINGLE_APPEND'},'model_diff':'NONE; no accepted physical model changed.'}
put('handoff123.json',handoff)
append=f'''

---

# Q052 V123 — q/16-gulvet giver et nyt optisk nedre bidrag

UTC {now}. Run `{rid}`. Claim `{claim}`.
BUBBLEVERSE.MATHEMATICS 2.3.0. Evidensgrænse Q052 til og med V123.
WORKFLOW_STATE READY_FOR_HANDOFF · TECHNICAL_STATE PASS · SCIENTIFIC_STATE INCONCLUSIVE.

## Oprindeligt spørgsmål

{task['exact_question']}

## Nyt dokumenteret resultat

Under det frosne kilde-, baggrunds-, start- og banedomæne er den
samlede signerede kilde-reelle Thomson-forskel F(810) indeholdt i
`{p['new_global_interval'][0]}` til
`{p['new_global_interval'][1]}`.
Det er cirka [{float(lo):.12e}, {float(hi):.12e}], dimensionsløst.
V95's arvede fortegn bestemmer maksimumstedet for denne definerede
kildeakkumulation ved z810. Det er ikke et native fejlcertifikat.

Det nye nedre bidrag er `{p['gain']}` ≈ {float(gain):.12e}.
Global bredde falder fra {float(oldwidth):.12e} til {float(width):.12e},
svarende til {100*float(F(p['global_width_reduction_fraction'])):.12f} %.
Bredden er fortsat {float(width/goal):.8f} gange det foreløbige mål 4×10⁻⁹.
Ingen ændring i den fysiske optiske dybde udledes af breddereduktionen.

## Metode og kontrol

1.304 delintervaller fra 1.292 oprindelige V66-rækker dækker
[50, {p['new_support'][1]}] over 13 bins. Hver bruger den
oprindelige positive W-undergrænse og den nye E>q/16-dækning.
Eksakt masse M=((1+c)³−(1+a)³)/3 og nedrunding på 2⁻¹⁰⁰-gitter
giver et samlet afrundingstab cirka {float(F(p['rounding_loss'])):.12e}.
Det er mindre end {float(F(p['rounding_loss_strict_upper'])):.12e}.

Den separate kontrol konstruerer partitionen direkte fra de fulde
V66-rækker, faktiske bevisendepunkter og baseline. Den læser ikke
V122-geometrien eller producentens kode/receipt. Omvendt traversal,
heltalsbaseret hex-dekodning, faktoriseret masse og divmod giver
præcis samme geometri, lokale bidrag, bins og globale summer.
To subprocesser sluttede med exit 0 efter samlet
{ex['wall_seconds_combined']:.9f} sekunder. Frosne input- og kodehashes
er uændrede. Ingen anden primær eller separat kørsel udført.

Det gamle V111-bidrag på [{p['protected_support'][0]},700]
bevares én gang. Områderne deler kun endepunkt. Alle 17 øvre
bin-endepunkter og de fire uberørte binintervaller er uændrede.
Der er nul nye vægte, feltberegninger, skalare/fulde
historieintegrationer, native par eller parametersøgninger.

## Proveniens, afgrænsning og næste opgave

GitHub-main `{repo}` matcher alle fem aktuelle vedhæftede inputs,
inklusive Matematikmotor 2.3.0. V122-arkivets 40 manifestmedlemmer
og dets historiske præfiks er verificeret. Det fulde V122-journalpræfiks
på {pre['journal_bytes']} bytes bevares identisk i denne fil.
Fysikkilden er `{task['source_commit']}`; capture er
`{task['capture_sha256']}`; baggrund er `{task['background_dependency_id']}`.
Kildehenvisninger, hashkæde og alle forudsætninger følger certifikatet.

G1 og de lokale G2–G5 består under de frosne antagelser. G6 er
åben: global kildeoptisk præcision samt native admission,
koordinat-/banekonsistens, reproducerbarhed og numerisk fejl.
G7 består med uændret historisk præfiks. MODEL_DIFF NONE.
Reproducerbarhed R3 gælder kun denne aritmetiske deltest og to
separate implementationer med fælles arkiver/Python Fraction.
Ingen ekstern reproduktion eller empirisk bekræftelse hævdes.

Næste motor er `{task['return_engine']}`. Opgaven `{NEXT}`
er PREPARED_NOT_EXECUTED med fingeraftryk
`{nexttask['fingerprint_sha256']}`. Den skal optage det nye interval
uden genkørsel og forberede én ændret præcisionstest med konkret
starttilstand og dæknings-/fejlkrav. Størst restbredde ligger i
600:650; 0:50 udgør kun cirka {100*float(F(budget['phase6_width_share'])):.6f} %.
Det fulde resterende budget står i `width_budget123.json`.
CONTINUE_SAME_Q true. De fire nye filer er klar til manuel upload
efter den eksisterende rodstruktur. GitHub-write er ikke udført.

## Point og udgivelse

POINTS_EVENT RESEARCH_RUN. EVENT_ID `{event}`.
PREVIOUS_POINTS_ENTRY `{previous_event}`.
Analyse 35, beregning 25, kildesporing 5, validering 35.
RUN POINTS 100 · TOTAL POINTS 14880 · CYCLE PROGRESS 880/1000.
NEXT SOME MILESTONE 15000 · POINTS TO NEXT PUBLICATION 120.
POINTS_STATE VERIFIED · PUBLICATION_STATE NOT_DUE.
Ingen ny milepæl eller udestående pakke. M001–M014 videreføres som leveret.

{basis}

V122-ledgerens hjælpefelt reconciliation refererede stadig til V118;
de historiske entries og totalsummen var korrekte. Kun V123's eget
hjælpefelt opdateres til den aktuelle, kontrolsummerede bevægelse.
Historiske filer og poster omskrives ikke, og der tilføjes ingen
korrektionspoint for dette administrative felt.
'''
(R/'journal_append123.md').write_text(append)
prefix=(BASE/'upload/Q052_INGESTION_OG_SAMLET_JOURNAL_V122-1.md').read_bytes();assert sha(prefix)==pre['journal_sha256']
(OUT/JOURNAL).write_bytes(prefix+append.encode())
report=f'''# BUBBLEVERSE — OVERLEVERING

**V123 består: Det betingede optiske interval er 1,994 % smallere. Q052 er fortsat åbent.**

STATUS: FORTSÆTTER. WORKFLOW_STATE: READY_FOR_HANDOFF.
SCIENTIFIC_STATE: INCONCLUSIVE. TECHNICAL_STATE: PASS.
TARGET_Q: Q052. AUTHORIZED_Q_RANGE: Q052. EVIDENCE_BOUNDARY: Q052 gennem V123.
PROMPT_ID: BUBBLEVERSE.MATHEMATICS. PROMPT_VERSION: 2.3.0.
VALGT NÆSTE MOTOR: BUBBLEVERSE.RESULT_INGESTION_ROUTING 2.3.0.

## Dokumenteret svar

Begge beregningsmetoder er eksakt enige om 1.304 nye bidrag.
Det samlede betingede kilde-reelle Thomson-interval er nu cirka
**[4,81957×10⁻⁶; 4,56102×10⁻⁵]**. Alle størrelser er dimensionsløse.
Den nedre grænse stiger med cirka 8,29899×10⁻⁷. Den øvre er uændret.

Intervalbredden falder fra cirka 4,16205×10⁻⁵ til 4,07906×10⁻⁵:
en reduktion på **1,993968 %**. Den er stadig cirka **10.197,65 gange**
det foreløbige breddekrav 4×10⁻⁹. Det krav er ikke opfyldt.
Reduktionen beskriver vores indhyllingsinterval, ikke en målt ændring
i universet eller selve den fysiske optiske dybde.

Det oprindelige hovedspørgsmål er stadig:

{task['exact_question']}

V123 besvarer kun den afgrænsede kildeoptiske deltest. De faktiske
native CLASS/P6-baner, deres sammenhæng med kildebanerne og deres
samlede validerede numeriske fejl er fortsat åbne afslutningskrav.

## Beregning, input og kontrol

På [50; 1523417340748759/2199023255552] anvendes de tidligere
certificerede E>q/16-grænser fra V121/V119/V117, q=10⁻⁶ og
de originale positive V66-vægte. Hvert bidrag er
L=floor(2¹⁰⁰·W_l·q/16·((1+c)³−(1+a)³)/3)/2¹⁰⁰.
1.292 vægtrækker bliver til 1.304 delstykker fordelt over 13 bins.
V111's gamle strimmel berøres kun i ét fælles endepunkt og tælles
ikke igen. Alle øvre grænser og fire uberørte bins er bevaret.

Den separate kontrol bygger selv partitionen, traverserer baglæns
og bruger et faktoriseret masseudtryk med heltalsafrunding.
Alle geometrier, uafrundede/afrundede bidrag og globale summer matcher.
Kørslernes samlede wall-tid er {ex['wall_seconds_combined']:.6f} sekunder.
Samlet afrundingstab er cirka 5,17×10⁻²⁸; den resterende bredde
skyldes indhyllingerne, ikke dette afrundingstab.

Resultatet er betinget af samme kilde, fælles baggrund B★,
matchede z810-starter og arvede banebeviser. Der er ingen nye
vægtberegninger, dynamiske integrationer eller native par.
R3 dækker den lokale aritmetiske deltest med to implementationer;
fælles arkivforudsætninger og Python Fraction er ikke uafhængig
empirisk evidens. G1 og de lokale G2–G5/G7 er opfyldt; G6 er åben.
MODEL_DIFF: NONE.

## Aktuel overlevering

BLOCKER_ID: LOCAL-Q052-SOURCE-OPTICAL-PRECISION-AND-NATIVE-CERTIFICATE.
Næste motor skal optage dette nye resultat og forberede én ændret
matematiktest ud fra den resterende intervalbredde. Største bin er
z=600–650. Den næste kontrakt skal skelne mellem vægtindhyllingens
og elektronindhyllingens bidrag og fastlægge en gyldig starttilstand,
metode, kontrol, dækningskrav og stopgrænse før ny beregning.

Opgaven står i `{NEXT}`. Accept kræver konsistente hashes,
eksakte receipts, uændret præfiks og korrekt støtte uden overlap.
Et domænebrud, dobbeltregning eller uforenelig sum afviser den
berørte opdatering. Manglende nødvendige input giver INCONCLUSIVE
eller en konkret blokering. Ingen af de gennemførte V123-metoder
skal genkøres på uændrede inputs. Genoptagelse kræver blot denne
pakke i Resultatindtagsmotoren. Næste opgave er forberedt, ikke udført.

## Samlet journal og proveniens

`{JOURNAL}` indeholder hele den leverede V122-journal i uændrede
bytes og én ny V123-post. ZIP-filen indeholder beviset `PROOF_V123.md`,
kode, begge receipts, execution, validator, frosne inputhashes,
ledger, kildeoversigt og den originale V122-pakke.

GitHub-base: `{repo}`. Alle fem vedhæftede inputs matcher
repositoryets bytes. Fysikkilde: `{task['source_commit']}`.
Capture: `{task['capture_sha256']}`.
Baggrund: `{task['background_dependency_id']}`.
Kilder K1–K5 og claim-evidens står i `source_register123.json`.
GITHUB_READ_STATE: VERIFIED. GITHUB_WRITE_STATE: READY_FOR_MANUAL_UPLOAD.
Upload de fire nye V123-filer til roden efter den eksisterende
navngivning; tidligere versioner bevares. Ingen GitHub-upload er udført her.

## ChatGPT-setupvurdering

AKTUELT SETUP: Codex i Work Mode, Default, lokal Python-standardpakke,
filer og verificeret GitHub-læsning. Det præcise modelnavn og
reasoning-niveau er ikke eksponeret. ANBEFALET PRIMÆRT SETUP:
samme tilgængelige runtime til indtag. KAPABILITETSKLASSE: H/C/A.
Begrundelse: endelig rationalaritmetik og arkivkontrol kan udføres her.
Fallback: gemt evidenskontrol og konkret inputblokering.
Upgrade-trigger: en næste native/banetest kræver en faktisk build-
eller valideringskapabilitet, der mangler. Downgrade-trigger:
frosne inputs kan behandles med almindelig standardbibliotekskode.
Ingen agenter, modelskift eller HPC er anvendt. Kontraktfelter og
referencer er lokalt kontrolleret; ingen ekstern schema-validation hævdes.

## Point og udgivelse

RUN_ID: `{rid}`. PREVIOUS_POINTS_ENTRY: `{previous_event}`.
RUN POINTS: **100** (analyse 35, beregning 25, kildesporing 5, validering 35).
TOTAL POINTS: **14.880**. CYCLE PROGRESS: 880/1000.
NEXT SOME MILESTONE: 15.000. POINTS TO NEXT PUBLICATION: **120**.
POINTS_STATE: VERIFIED. PUBLICATION_STATE: NOT_DUE.
NEW MILESTONES: NONE. PENDING SOME PACKAGES: NONE.
M001–M014 er videreført som leveret. Point er en redaktionel tæller,
ikke et mål for bevisstyrke eller procentvis færdiggørelse.

{basis}
'''
(OUT/SHORT).write_text(report)
readme=f'''Q052 V123 — dokumenteret optisk delresultat

Start med {SHORT}. Fuld historik: {JOURNAL}.
Næste motor: BUBBLEVERSE.RESULT_INGESTION_ROUTING 2.3.0.
Indlæs {NEXT} sammen med denne pakke.

Alle leverede filer er under 25.000.000 bytes. ZIP bruger almindelig
Deflate og kan udpakkes uden splitarkiv eller særskilte volumener.

Efter udpakning: python verify_package123.py
Dette kontrollerer gemte hashes, summer og journalpræfiks uden ny optisk beregning.

De store afledte inputkopier er udeladt for at holde pakken lille.
De originale bytes ligger i history/Q052_INGESTION_CERTIFICATE_V122.zip.
python restore_inputs123.py genskaber alle 14 inputfiler og kontrollerer
dem mod de frosne SHA-256-værdier. Dette er kun filgendannelse.

Valgfri reproduktion, kun ved eksplicit behov:
python replay123.py /absolut/sti/til/ny_mappe
Mappen må ikke eksistere. Originale receipts og journal overskrives aldrig.
Den portable reproduktionswrapper er syntakskontrolleret, ikke kørt i V123.
De oprindelige to metodekørsler er udført og bestået i execution123.json.
En teknisk reproduktion tæller ikke som ny forskning eller ny pointpost.

GitHub: de fire nye V123-leverancer lægges i repositoryets rod;
se github_memory_update123.json. Upload er ikke udført her.
'''
(R/'LAES_MIG_V123.txt').write_text(readme)
for code in R.glob('*.py'):ast.parse(code.read_text(),filename=str(code))
stage=R/'package';stage.mkdir(exist_ok=True);(stage/'history').mkdir(exist_ok=True)
included=['prepare123.py','primary123.py','control123.py','run123.py','build123.py','verify_package123.py','restore_inputs123.py','replay123.py','repository123.json','input_check123.json','freeze123.json','run123.lock','execution123.json','primary123.log','control123.log','primary123.json','control123.json','control_access123.json','validation123.json','result123.json','width_budget123.json','PROOF_V123.md','source_register123.json','activity_ledger123.json','handoff123.json','github_memory_update123.json','journal_append123.md','LAES_MIG_V123.txt']
for n in included:shutil.copyfile(R/n,stage/n)
for n in [SHORT,JOURNAL,NEXT]:shutil.copyfile(OUT/n,stage/n)
shutil.copyfile(BASE/'upload/Q052_INGESTION_CERTIFICATE_V122.zip',stage/'history/Q052_INGESTION_CERTIFICATE_V122.zip')
members=[]
for f in sorted(stage.rglob('*')):
    if f.is_file() and f.name!='manifest123.json':members.append({'path':str(f.relative_to(stage)),'size_bytes':f.stat().st_size,'sha256':sha(f.read_bytes())})
manifest={'version':'V123','target_q':'Q052','run_id':rid,'created_utc':now,'parent_journal_sha256':sha(prefix),'parent_prefix_bytes':len(prefix),'append_sha256':sha(append.encode()),'task_fingerprint':nexttask['fingerprint_sha256'],'max_deliverable_bytes':25000000,'input_storage':'Derived input/ files recreated byte-identically by restore_inputs123.py from nested original V122 archive. Frozen hashes in freeze123.json.','schema_validation':'Local required-field/reference/integrity checks only','self_hash_convention':'Manifest excluded from its own member hashes; archive hash stored separately.','github_memory_update':memory,'members':members}
(stage/'manifest123.json').write_bytes(enc(manifest))
with ZipFile(OUT/ZIP,'w',compression=ZIP_DEFLATED,compresslevel=9,allowZip64=False) as z:
    for f in sorted(stage.rglob('*')):
        if f.is_file():z.write(f,str(f.relative_to(stage)),compress_type=ZIP_STORED if f.suffix=='.zip' else ZIP_DEFLATED)
assert all((OUT/n).stat().st_size<25000000 for n in files)
with ZipFile(OUT/ZIP) as z:
    assert z.testzip() is None
    for m in members:assert sha(z.read(m['path']))==m['sha256'] and len(z.read(m['path']))==m['size_bytes']
    for n in z.namelist():
        if n.endswith('.json'):json.loads(z.read(n))
verification=subprocess.run([sys.executable,str(stage/'verify_package123.py')],capture_output=True,text=True,check=True)
delivery={'status':'PASS','created_utc':now,'files':[{'name':n,'path':str(OUT/n),'size_bytes':(OUT/n).stat().st_size,'sha256':sha((OUT/n).read_bytes())} for n in files],'zip_crc':'PASS','zip_member_hashes':'PASS','all_json_parse':'PASS','all_files_under_25000000_bytes':True,'stored_only_verification':json.loads(verification.stdout),'portable_replay':'SYNTAX_CHECKED_NOT_EXECUTED','new_optical_replays':0}
put('delivery123.json',delivery)
print(json.dumps(delivery,indent=2))
