"""One frozen exact lower sum. No dynamical or weight evaluation."""
from pathlib import Path
from fractions import Fraction as F
import json,sys
sys.set_int_max_str_digits(0)
P=Path(__file__).resolve().parent/'input'
def read(n): return json.loads((P/n).read_text())
task=read('task122.json'); base=read('baseline122.json'); geo=read('geometry122.json')
weights=read('weights66.json')['source_segments']; v62=read('v62.json')['pair_records']
assert len(geo)==task['target']['pieces']==1304
floor=F(task['target']['floor']); grid=1<<100
claims={c:tuple(map(F,z)) for z,c in task['target']['floor_chain']}
start,stop=map(F,task['target']['domain_z_ascending']);protected=list(map(F,base['credited_V111_support']))
assert stop==protected[0] and start<stop<protected[1]
rows=[];prev=start;parts={k:[] for k in base['current_bins']};seen=set()
for g in geo:
    i=g['V66_row']; a,c=map(F,g['z_ascending']);w=weights[i];pa,pc=map(F,w['z'])
    ba,bc=map(F,g['bin'].split(':'));ca,cc=claims[g['floor_claim']]
    assert prev==a<c and pa<=a<c<=pc and ba<=a<c<=bc and ca<=a<c<=cc
    assert c<=protected[0] and a>=start and c<=stop
    vr=list(map(lambda x:F(float.fromhex(x)),v62[g['V62_row']]['z']))
    assert vr==[pc,pa] and w['origin']=='V62'
    key=(i,a,c,g['bin'],g['floor_claim']);assert key not in seen;seen.add(key)
    wl,wu=map(F,w['K_over_H_exact']);assert 0<wl<=wu
    mass=((1+c)**3-(1+a)**3)/3
    exact=floor*wl*mass
    scaled=exact*grid;rounded=F(scaled.numerator//scaled.denominator,grid)
    assert 0<=exact-rounded<F(1,grid) and rounded>0
    row={**g,'weight_lower':str(wl),'mass':str(mass),'unrounded_lower':str(exact),'rounded_lower':str(rounded)}
    rows.append(row);parts[g['bin']].append(row);prev=c
assert prev==stop and len(set(r['V66_row'] for r in rows))==1292
bins={};changes={};sumexact=F(0);sumgrid=F(0)
for label,old in base['current_bins'].items():
    ex=sum((F(r['unrounded_lower']) for r in parts[label]),F(0));lo=sum((F(r['rounded_lower']) for r in parts[label]),F(0))
    left=F(old[0])+lo;right=F(old[1]);assert left<=right
    bins[label]=[str(left),old[1],old[2]]
    changes[label]={'pieces':len(parts[label]),'unrounded_gain':str(ex),'rounded_gain':str(lo),'rounding_loss':str(ex-lo)}
    sumexact+=ex;sumgrid+=lo
assert sum(1 for x in changes.values() if x['pieces'])==13
for label in ['0:50','700:750','750:800','800:810']: assert bins[label]==base['current_bins'][label]
oldlo,oldhi=map(F,base['global_interval']);newlo=sum((F(b[0]) for b in bins.values()),F(0));newhi=sum((F(b[1]) for b in bins.values()),F(0))
assert newlo==oldlo+sumgrid and newhi==oldhi and sumgrid>0
width=newhi-newlo;oldwidth=oldhi-oldlo;goal=F(base['provisional_width_goal'])
out={'status':'PASS','rows':rows,'current_bins':bins,'bin_changes':changes,'protected_support':base['credited_V111_support'],'protected_lower_preserved':base['credited_V111_lower'],'new_support':list(map(str,[start,stop])),'gain':str(sumgrid),'unrounded_gain':str(sumexact),'rounding_loss':str(sumexact-sumgrid),'rounding_loss_strict_upper':str(F(len(rows),grid)),'prior_global_interval':base['global_interval'],'new_global_interval':[str(newlo),str(newhi)],'prior_global_width':str(oldwidth),'global_width':str(width),'global_width_reduction_fraction':str(sumgrid/oldwidth),'global_width_goal_ratio':str(width/goal),'provisional_width_goal':str(goal),'baseline_partition_coverage':['0','810'],'upper_endpoints_unchanged':True,'support_overlap':'SHARED_ENDPOINT_ONLY','baseline_counts_meaning':'Inherited enclosing-bin segmentation counts; new lower-piece counts are in bin_changes.'}
Path(sys.argv[1]).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
