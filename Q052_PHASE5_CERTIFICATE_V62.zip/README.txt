Reproduce the phase-5 certificate on Linux with Python 3 and libmpfr.so.6. The V61 journal contains the hash-pinned V19 input capsule, V20 interval backend and V23/V24 terminal state certificate. The V60 raw JSON can be recovered from its four original parts. The V37 archive is q052-native-pair-v36-41171153649.zip, SHA256 548d38abefcc530d312e59dc15522b0b01535db063833489adeed10c3b303e54 (project input ID libfile_0d81d1ba16b481918f6ca8c17e97f564). The archived first background row supplies the frozen-fit parameter check. The propagation itself uses envelopes for the fixed admitted common background. It does not interpolate the native table as a substitute for this assumption.

Example commands in a working directory containing these inputs:
python recover_raw.py reconstructed60.json Q052_FULL_HISTORY_RAW_V60_PART_*OF_4*.json
python certify62.py Q052_INGESTION_OG_SAMLET_JOURNAL_V61.md reconstructed60.json q052-native-pair-v36-41171153649.zip rerun.json
python verify62.py rerun.json reconstructed60.json
python branchcheck62.py rerun.json reconstructed60.json

Expected rerun.json SHA256: 63480c24d61350c9913ed3072e09c91c097049791165fa964cfa096f7d0d4ca8. Assertions must be enabled. phase5_receipt.json contains binary64 outward endpoints in hexadecimal; z decreases. Intervals are deterministic enclosures. Inspect terminal_pair in [Delta xe, Delta v] order and arms.L/arms.R.terminal in [h,v] order. signed_source_minus_ref is source minus linear reconstruction; residual_ref_minus_field is reconstruction derivative minus the source field per unit u. See the V62 journal for the proof, handoff and limits. No native solver is required for replay.
