from pathlib import Path
from bisect import bisect_left
import sys,json
from collections import Counter
r=json.loads(Path(sys.argv[1]).read_bytes());raw=json.loads(Path(sys.argv[2]).read_bytes());out={}
for a in 'LR':
    rows=r['arms'][a]['records'];f=float.fromhex;edges=[-f(p['z'][0]) for p in rows]+[-f(rows[-1]['z'][1])];counts=Counter()
    fs=raw['arms'][a];rhs=[json.loads(line) for line in fs['fullstate_trace.jsonl'].splitlines() if '"tag":"RHS"' in line];guards=list(map(json.loads,fs['hyrec_guard_trace.jsonl'].splitlines()));assert len(rhs)==len(guards)
    for t,g in zip(rhs,guards):
        assert g['z']==t['z'] and g['xHII']==t['y'][t['indices']['x_H']];s=-f(t['z']);
        if t['phase']!=5 or s<edges[0]:continue
        j=bisect_left(edges,s);indices=[j-1] if j else [];indices+=([j] if j<len(rows) and edges[j]==s else []);assert indices
        actual=[k for k,v in g['observed_child_calls'].items() if v];assert len(actual)==1
        for i in indices:
            assert edges[i]<=s<=edges[i+1] and actual[0] in rows[i]['allowed_branches'];counts['branch_checks']+=1
        counts['eligible_RHS']+=1
    recorded=[p for p in rows if len(p['allowed_branches'])==1];min_margin=min(min(abs(f(t)) for t in p['guard_margin']) for p in recorded);assert min_margin>0.09
    counts['smallest_abs_unique_mask_margin']=min_margin;out[a]=dict(counts)
print(json.dumps(out,indent=2))
