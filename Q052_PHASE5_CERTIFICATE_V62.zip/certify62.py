"""Phase-5 conditional comparison and residual certificate. Python 3 + pinned V20 MPFR backend."""
import json,hashlib,base64,zlib,re,zipfile,sys,math
from pathlib import Path
from fractions import Fraction as Q
from functools import lru_cache
from collections import Counter
from tempfile import TemporaryDirectory
import importlib.util
H=lambda b:hashlib.sha256(b).hexdigest()
qhex=lambda s:Q.from_float(float.fromhex(s))
pack=lambda x:x.hex()

def main(journal,raw_path,archive,output):
    parent=Path(journal).read_bytes(); rawb=Path(raw_path).read_bytes();raw=json.loads(rawb)
    assert H(parent)=='41e8283caf91f3d48d21e5c0293ef7fb67a4b95f12d0d9eb702f8e5d7a868ce5' and H(rawb)=='e683333446b1ea3d889cd837520f8f475a8926c1bad4cdc4459150dffb11bfcb'
    blocks=lambda lang:re.findall(rb'^```'+lang+rb'\n(.*?)^```',parent,re.M|re.S)
    tmp=TemporaryDirectory();w=Path(tmp.name)
    module=next(b for b in blocks(b'python') if H(b)=='d0feecd36359005a55fb91c26aee2381f9ed1652177395acf7ec482ea0e880fa');(w/'v20.py').write_bytes(module)
    spec=importlib.util.spec_from_file_location('bound62',w/'v20.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    def unpack(s,expected):
        b=zlib.decompress(base64.b64decode(s,validate=True));assert H(b)==expected;return b
    (w/'v19').write_bytes(unpack(json.loads(blocks(b'q052-inputs')[0])['v19.json'],m.BUNDLE_SHA))
    c=m.Context(w/'v19');I=m.I;enc=m.enc;lit=m.lit
    cap=json.loads(blocks(b'q052-inputs-v53')[0])['files'];data,cert=[json.loads(unpack(cap[k]['data'],h)) for k,h in [('Q052_SECOND_CELL_DATA_V23.json','4749411ad719803c9fd0c489a4f6103049ae4b1d960a18f8bce16123fcd8c1af'),('Q052_SECOND_CELL_RECEIPT_V24.json','863b0664140bce242bcbf05848ec840e43d809681a71feeb1e1b864c1f7f2bf8')]]
    assert H(Path(archive).read_bytes())=='548d38abefcc530d312e59dc15522b0b01535db063833489adeed10c3b303e54'
    with zipfile.ZipFile(archive) as ar:
        rows=[]
        for arm in 'LR':
            with ar.open(arm+'/background_table_hex.jsonl') as f:
                header=json.loads(f.readline());assert header['bg_size_normal']==23 and header['index_bg_H']==1
                row=json.loads(f.readline());assert row['i']==0;rows.append(row['background'])
        assert rows[0]==rows[1];rad,crit,gamma=[enc(qhex(rows[0][k])) for k in [22,23,3]]
    neff=(rad*crit-gamma)/(enc(Q(7,8))*enc(Q(4,11)).power(enc(Q(4,3)))*gamma)
    assert 3.04<neff.lo<=neff.hi<3.05
    # Broad parameter intervals include conversion/roundoff and the optional massive-neutrino selection.
    # Positive flat constituents: 0<=Omega_nfsm<=1, little h<1 and omega_b<0.03.
    fields=c.capture['background']['fields'];H0=enc(qhex(fields['H0']));ob=enc(qhex(fields['Omega0_b']));oc=enc(qhex(fields['Omega0_cdm']));little_h=H0*lit('2.99792458e5')/100
    assert little_h.hi<1 and (ob*little_h*little_h).hi<0.03
    temp_ratio=(lit('2.7255')/enc(c.T0)).power(I(3));diff=[(I(0,1)-lit('0.14175'))*temp_ratio,(enc(0,Q(3,100))-lit('0.02242')*(1-lit('0.246738546372')))*temp_ratio,enc(Q('3.04'),Q('3.05'))-lit('3.046')]
    fit=[[lit(x) for x in line.split()] for line in c.sources['fit_swift.dat']['content'].splitlines() if line.strip()];topT=c.T0*811
    # General clamped 4-point interpolation, subdivided for interval width; only T where SWIFT is allowed.
    dk_values=[]
    for j in range(math.ceil(float((topT-1775)/10))):
        ix=max(1,min(j,len(fit)-3));
        for panel in range(8):
            lo=Q(j)+Q(panel,8);hi=min(Q(j)+Q(panel+1,8),(topT-1775)/10)
            if lo>hi:continue
            t=enc(lo-ix,hi-ix);ys=[m.cubic([fit[k][l] for k in range(ix-1,ix+3)],t) for l in range(1,5)]
            dk_values.append(1+ys[0]+sum((a*b for a,b in zip(ys[1:],diff)),I(0)))
    dk=m.hull(dk_values);assert dk.lo>0
    ratesrc=c.sources['hyrec.c']['content'];assert 'Pion < PION_MAX' in ratesrc and 'TR/kBoltz/cosmo->fsR/cosmo->fsR/cosmo->meR < fit->swift_func[0][0]' in ratesrc
    hconv=lit('2.99792458e8')/lit('3.085677581282e22');bgrows=[(Q(x['z'][0]),Q(x['z'][1]),list(map(Q,x['H']))) for x in c.binding['cells']]
    def background(za,zb,zp):
        # Friedmann matter floor, and monotone H fixed at or before the segment.
        floor=(H0*((ob+oc)*zp*zp*zp).sqrt()).lo
        candidates=[hi[1] for a,b,hi in bgrows if a>=za];assert candidates
        lower=max([Q(floor)]+[hi[0] for a,b,hi in bgrows if a>=za and zb>=b]);upper=min(candidates)
        return enc(lower,upper)*hconv
    @lru_cache(None)
    def coeff_table(zbin):
        # Each bin contains its complete five-unit redshift band. Cold ratio range is padded on the low side.
        zp=enc(1+5*zbin,1+5*(zbin+1));_,tr,_,_=c.background(zp);assert tr.lo>c.trmin.hi and tr.hi<c.trmax.lo
        qt=(tr.log()-c.logmin)/c.dlog; qv=(enc(Q('0.09999'),1)-c.vmin)/c.dv
        als=[[],[]];eqs=[[],[]];rs=[]
        for it,t in m.stencils(qt,100):
            rs.append(m.cubic(c.R[it-1:it+3],t).exp())
            for l in [0,1]:
                eqs[l].append(m.cubic(c.alpha[l][-1][it-1:it+3],t).exp())
                for iv,s in m.stencils(qv,40):
                    yt=[m.cubic(c.alpha[l][j][it-1:it+3],t) for j in range(iv-1,iv+3)]
                    als[l].append(m.cubic(yt,s).exp())
        return [m.hull(a) for a in als],[m.hull(e) for e in eqs],m.hull(rs)
    def ppb(T):
        t4=T/10000
        return lit('4.309e-13')*t4.power(lit('-0.6166'))/(1+lit('0.6703')*t4.power(lit('0.5300')))
    def k_bounds(za,zb,zp,ratio_lo,hs,q,h_cap):
        _,tr,nh,rho=c.background(zp); bins=[coeff_table(i) for i in range(int(zb//5),int(za//5)+1)]
        alpha=[m.hull(t[0][l] for t in bins) for l in [0,1]];ae=[m.hull(t[1][l] for t in bins) for l in [0,1]];r=m.hull(t[2] for t in bins)
        bn=c.saha*tr*tr.sqrt()*(-c.EI/(4*tr)).exp();bs,bp=ae[0]*bn,ae[1]*bn/3
        # At zero escape the C lower bounds are precisely lambda*(bp+r)/denom and lambda*r/denom.
        den=(bs+c.lam)*(bp+r)+3*r*bp;cs=c.lam*(bp+r)/den;cp=c.lam*r/den
        low=alpha[0]*cs+alpha[1]*cp;high=sum(alpha,I(0));eqhigh=sum(ae,I(0));assert min(low.lo,den.lo)>0
        # Guard computed over all h in [0,h_cap]; one hull covers either branch even at equality.
        B=bn*ppb(enc(c.T0)*zp);R=c.lya*hs/nh/(1-enc(0,h_cap));guard=99*B-c.lam-3*R
        T=enc(c.T0)*zp
        branches=[]
        if guard.lo<0 or T.lo<c.fit_first.hi: branches.append('HMLA')
        if guard.hi>=0 and T.hi>=c.fit_first.lo: branches.append('SWIFT')
        if ratio_lo<=Q('0.100001') or tr.lo<=c.trmin.hi:
            at=ppb(enc(ratio_lo,1)*T);at0=ppb(T);ct=c.lam/(c.lam+bn*at0)
            low=I(min(low.lo,(at*ct).lo));high=I(max(high.hi,at.hi));eqhigh=I(max(eqhigh.hi,at0.hi));branches.append('PEEBLES')
        assert branches
        k=nh/hs*I(low.lo,high.hi);photo=eqhigh/hs*c.saha*tr*tr.sqrt()*(-c.EI/tr).exp()
        return k,photo,rho,guard,branches
    def endpoint(coupling,initial,dt):
        eq=coupling/(1+coupling);return eq+(initial-eq)*(-(1+coupling)*dt).exp()
    def make_nodes(a):
        fs=raw['arms'][a];rr=[json.loads(l) for l in fs['fullstate_trace.jsonl'].splitlines()];rhs={(r['phase'],r['mz'],tuple(r['y']),tuple(r['dy'])) for r in rr if r['tag']=='RHS'}
        outs=[r for r in rr if r['tag']=='OUTPUT' and r['phase']==5];assert len(outs)==1528
        assert all((r['phase'],r['mz'],tuple(r['y']),tuple(r['dy'])) in rhs for r in outs)
        join=next(r for r in rr if r['tag']=='OUTPUT' and r['phase']==6 and qhex(r['z'])==50);assert all(join[k]==outs[-1][k] for k in ['z','y','dy','workspace'])
        nodes=[(qhex(r['z']),qhex(r['y'][r['indices']['x_H']]),qhex(r['y'][r['indices']['D_Tmat']])) for r in outs];return nodes[1:]
    result={'schema':'Q052_PHASE5_ENCLOSURE_V62','v61_sha256':H(parent),'raw_sha256':H(rawb),'archive_sha256':H(Path(archive).read_bytes()),'source_pins':c.pins,'Neff_from_archived_row':pack(neff),'archived_first_row_hex':[rows[0][i] for i in [22,23,3]],'one_plus_DK_range':pack(dk),'case_id':cert['case_id'],'conditional':True,'arms':{}}
    for a in 'LR':
        nodes=make_nodes(a);d=data['arms'][a];z0,h0,D0=nodes[0];assert nodes[-1][0]==50 and z0==Q(d['z_exact'][-1]) and h0==Q(d['bernstein_exact']['h'][-1]) and D0==Q(d['bernstein_exact']['D'][-1]);assert all(x[0]>y[0] for x,y in zip(nodes,nodes[1:]))
        q=Q(d['q_exact']);eh,ev=map(qhex,cert['arms'][a]['certified_terminal_error_upper_hex']);h=enc(h0-eh,h0+eh);v0=1+D0/(c.T0*(1+z0));v=enc(v0-ev,v0+ev);initial=[pack(h),pack(v)];records=[]
        for (za,ha,Da),(zb,hb,Db) in zip(nodes,nodes[1:]):
            zp=enc(1+zb,1+za);hs=background(za,zb,zp);dt=enc((1+za)/(1+zb)).log();assert dt.lo>0
            refh=enc(min(ha,hb),max(ha,hb));refv=1+enc(min(Da,Db),max(Da,Db))/(enc(c.T0)*zp)
            vl=min(Q(v.lo)*(1+zb)/(1+za),Q(refv.lo));assert 0<vl and refv.hi<=1 and q>=0
            hcap=Q(1,100);k,p,rho,guard,branches=k_bounds(za,zb,zp,vl,hs,q,hcap);assert p.lo>=0 and k.lo>0
            hwholehi=(I(h.hi)+I(p.hi)*dt).hi;assert hwholehi<0.01 and refh.hi<0.01
            lower=(I(h.lo)+enc(q))/(1+I(k.hi)*(I(h.lo)+enc(q))*dt)-enc(q)
            upper=I(h.hi)/(1+I(k.lo)*I(h.hi)*dt)+I(p.hi)*dt
            h1=I(lower.lo,upper.hi);wh=I(lower.lo,hwholehi);assert wh.lo>0 and wh.hi<0.01
            X=wh+enc(q);scale=c.K*rho/hs;A=scale*X/(1+enc(c.he)+X)
            # This natural interval includes dependency in numerator/denominator.
            vlo=endpoint(I(A.lo),I(v.lo),dt);vhi=endpoint(I(A.hi),I(v.hi),dt);v1=I(vlo.lo,vhi.hi);wv=I(min(v.lo,v1.lo),min(1.,max(v.hi,v1.hi)));assert v1.lo>0 and v1.hi<=1
            # Pointwise error by subtracting reference ranges from the propagated source boxes.
            hdiff=wh-refh;vdiff=wv-refv
            # Residual of the independent piecewise-linear h,D reconstruction in u=ln(811/(1+z)).
            rX=refh+enc(q);rA=scale*rX/(1+enc(c.he)+rX)
            f=-k*refh*rX+I(0,p.hi);g=-refv+rA*(1-refv)
            dh=zp*enc((hb-ha)/(za-zb));dv=enc((Db-Da)/(za-zb)/c.T0)+refv-1
            records.append({'z':[float(za).hex(),float(zb).hex()],'initial':[pack(h),pack(v)],'ref_h_D':[[str(ha),str(Da)],[str(hb),str(Db)]],'u_width':pack(dt),'H_per_s':pack(hs),'K':pack(k),'Pmax':p.hi.hex(),'A':pack(A),'guard_margin':pack(guard),'allowed_branches':branches,'whole_source':[pack(wh),pack(wv)],'end_source':[pack(h1),pack(v1)],'signed_source_minus_ref':[pack(hdiff),pack(vdiff)],'residual_ref_minus_field':[pack(dh-f),pack(dv-g)]})
            h,v=h1,v1
        result['arms'][a]={'nodes':len(nodes),'interval_count':len(records),'initial':initial,'terminal':[pack(h),pack(v)],'z50_saved':[str(nodes[-1][1]),str(1+nodes[-1][2]/(c.T0*51))],'terminal_signed_source_minus_output':[pack(h-enc(nodes[-1][1])),pack(v-enc(1+nodes[-1][2]/(c.T0*51)))],'branch_masks':dict(Counter('|'.join(r['allowed_branches']) for r in records)),'records':records}
    l,r=[result['arms'][a]['records'] for a in 'LR'];assert len(l)==len(r)==1526
    def diff(x,y):return I(*map(float.fromhex,x))-I(*map(float.fromhex,y))
    result['pair_records']=[{'z':x['z'],'whole_dh':pack(diff(x['whole_source'][0],y['whole_source'][0])),'whole_dxe':pack(diff(x['whole_source'][0],y['whole_source'][0])+enc(Q(1,10**6))),'whole_dv':pack(diff(x['whole_source'][1],y['whole_source'][1]))} for x,y in zip(l,r) if x['z']==y['z']];assert len(result['pair_records'])==1526
    result['terminal_pair']=[pack(diff(l[-1]['end_source'][i],r[-1]['end_source'][i])+(enc(Q(1,10**6)) if i==0 else I(0))) for i in [0,1]]
    Path(output).write_text(json.dumps(result,separators=(',',':'),allow_nan=False)+'\n');print({a:{k:v for k,v in d.items() if k!='records'} for a,d in result['arms'].items()});print('DK',pack(dk),'terminal_pair',result['terminal_pair'])
if __name__=='__main__':main(*sys.argv[1:])
