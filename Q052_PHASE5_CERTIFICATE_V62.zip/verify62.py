"""Independent scalar transfer checks with Decimal log/exp and exact rational algebra."""
import json,sys,hashlib
from decimal import Decimal as D,localcontext
from fractions import Fraction as F
from collections import Counter
from pathlib import Path

def hx(x):return F.from_float(float.fromhex(x))
def readpair(pair):return tuple(map(hx,pair))
def included(pair,x):return pair[0]<=x<=pair[1]
def contains(big,small):return big[0]<=small[0]<=small[1]<=big[1]
def dec(x):return D(x.numerator)/D(x.denominator)

def verify(receipt,raw_path):
    receipt_bytes=Path(receipt).read_bytes();r=json.loads(receipt_bytes);raw=json.loads(Path(raw_path).read_bytes());stats=Counter();bad=[]
    T=hx(json.loads(raw['arms']['L']['effective_identity.json'])['fields']['T_cmb']);paired=r['pair_records']
    with localcontext() as ctx:
        ctx.prec=100
        for a in 'LR':
            arm=r['arms'][a];q=F(1,10**6) if a=='L' else F(0)
            tr=[json.loads(l) for l in raw['arms'][a]['fullstate_trace.jsonl'].splitlines()];out={hx(x['z']):x for x in tr if x['tag']=='OUTPUT' and x['phase']==5}
            prev=arm['initial'];lastz=hx(arm['records'][0]['z'][0]);assert lastz==F(1779416633043845,2199023255552)
            for i,row in enumerate(arm['records']):
                za,zb=readpair(row['z']);assert row['initial']==prev and za==lastz and za>zb;prev=row['end_source'];lastz=zb
                h0,v0=map(readpair,row['initial']);h1,v1=map(readpair,prev);hw,vw=map(readpair,row['whole_source']);assert contains(hw,h0) and contains(hw,h1) and contains(vw,v0) and contains(vw,v1)
                assert hw[0]>0 and hw[1]<F(1,100) and 0<vw[0]<=vw[1]<=1
                dt=(dec(1+za)/dec(1+zb)).ln();dts=readpair(row['u_width']);assert dec(dts[0])<=dt-D('1e-91')<=dt+D('1e-91')<=dec(dts[1])
                kl,ku=readpair(row['K']);pl=hx(row['Pmax']);al,au=readpair(row['A']);assert 0<kl<=ku and pl>=0 and 0<al<=au
                # Check the lower/upper ideal rational comparison at both outward bounds on delta-u.
                low=(h0[0]+q)/(1+ku*(h0[0]+q)*dts[1])-q;high=h0[1]/(1+kl*h0[1]*dts[0])+pl*dts[1]
                assert h1[0]<=low and high<=h1[1] and hw[1]>=h0[1]+pl*dts[1]
                for side,A in enumerate((al,au)):
                    eq=A/(1+A);val=dec(eq)+(dec(v0[side])-dec(eq))*(-(1+dec(A))*dt).exp()
                    assert (dec(v1[0])<=val-D('1e-88') if side==0 else dec(v1[1])>=val+D('1e-88'))
                derivs=list(map(readpair,row['residual_ref_minus_field']));errs=list(map(readpair,row['signed_source_minus_ref']));points=[list(map(F,p)) for p in row['ref_h_D']]
                for j,z in enumerate([za,zb]):
                    rec=out[z];hi=rec['indices']['x_H'];di=rec['indices']['D_Tmat'];hh,dd=points[j];assert (hh,dd)==(hx(rec['y'][hi]),hx(rec['y'][di]))
                    vv=1+dd/(T*(1+z));assert contains(errs[0],(hw[0]-hh,hw[1]-hh)) and contains(errs[1],(vw[0]-vv,vw[1]-vv))
                    dh=(1+z)*(points[1][0]-points[0][0])/(za-zb);dv=(points[1][1]-points[0][1])/((za-zb)*T)+vv-1
                    ndh=(1+z)*hx(rec['dy'][hi]);ndv=hx(rec['dy'][di])/T+vv-1
                    for tag,bound,dv0 in [('h',derivs[0],dh-ndh),('v',derivs[1],dv-ndv)]:
                        stats['sampled_residual_checks']+=1
                        if not included(bound,dv0):bad.append((a,i,j,tag,float(dv0),list(map(float,bound))))
                stats['decimal_thermal_endpoint_checks']+=2;stats['rational_h_comparisons']+=2;stats['validated_contiguous_arm_segments']+=1
            assert lastz==50 and prev==arm['terminal']
        for l,rr,p in zip(r['arms']['L']['records'],r['arms']['R']['records'],paired):
            assert l['z']==rr['z']==p['z'];lx,lv=map(readpair,l['whole_source']);rx,rv=map(readpair,rr['whole_source']);assert contains(readpair(p['whole_dxe']),(lx[0]-rx[1]+F(1,10**6),lx[1]-rx[0]+F(1,10**6)));stats['paired_xe_checks']+=1
    result={'schema':'Q052_V62_INDEPENDENT_TRANSFER_CONTROL','receipt_sha256':hashlib.sha256(receipt_bytes).hexdigest(),'checks':dict(stats),'sampled_residual_outside_count':len(bad),'sampled_residual_outside_first':bad[:6],'scope':'Independent arithmetic/continuity and finite native derivative cross-check; coefficient envelopes and primary source assumptions shared.'}
    print(json.dumps(result,indent=2));return result
if __name__=='__main__':verify(sys.argv[1],sys.argv[2])
