from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from hashlib import sha256, sha1
from fractions import Fraction as F
from datetime import datetime, timezone
import json, subprocess, sys, tempfile

p=Path(__file__).resolve().parent
root=p.parents[1]
u=root/'upload'
out=root/'output/V110'
out.mkdir(parents=True,exist_ok=True)
archive='Q052_OPTISK_RECOVERYCERTIFIKAT_V109.zip'
oldtask='Q052_RESULTATINDTAG_OPGAVE_V109.json'
oldjournal='Q052_MATEMATIK_OG_SAMLET_JOURNAL_V109.md'
oldshort='Q052_KORT_RESULTAT_V109.md'
short,journal,taskfile,bundle=names=['Q052_KORT_RESULTAT_V110.md','Q052_INGESTION_OG_SAMLET_JOURNAL_V110.md','Q052_MATEMATIKOPGAVE_V110.json','Q052_INGESTION_CERTIFICATE_V110.zip']
read=lambda f:json.loads(f.read_bytes())
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
sha=lambda x:sha256(x).hexdigest()
blob=lambda x:sha1(f'blob {len(x)}\0'.encode()+x).hexdigest()
fp=lambda x:sha(json.dumps({k:v for k,v in x.items() if k!='fingerprint_sha256'},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
ref=lambda member:bundle+'#'+member
hist=lambda member:ref('history/'+archive+'#'+member)
repo=read(p/'repository_snapshot.json')
assert not repo['truncated'] and not set(names)&repo['paths'].keys()
a=read(u/oldtask)
engine=(u/'Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0-55.md').read_bytes()
assert sha(engine)==a['engine_prompt_sha256'] and blob(engine)==repo['paths']['Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0.md']
for n in [archive,oldtask,oldjournal,oldshort]:
 assert blob((u/n).read_bytes())==repo['paths'][n],n

with tempfile.TemporaryDirectory(dir=p) as tmp:
 stage=Path(tmp)
 with ZipFile(u/archive) as z:
  for n in z.namelist():assert (stage/n).resolve().is_relative_to(stage)
  z.extractall(stage)
  for n in [oldtask,oldjournal,oldshort]:assert z.read(n)==(u/n).read_bytes()
 verified=json.loads(subprocess.check_output([sys.executable,str(stage/'verify109.py'),str(u/archive)],text=True))
 restore=subprocess.check_output([sys.executable,'restore_inputs109.py'],cwd=stage,text=True)
 assert json.loads(restore.splitlines()[-1])['scientific_evaluations']==0
 r=read(stage/'result109.json')
 prior=read(stage/'activity_ledger.json')
 w=read(stage/'width_budget109.json')
 c=stage/'calc'
 execution=read(c/'execution_recovery.json')
 pins=read(c/'input_pins107.json')
 for n,h in pins.items():assert sha((c/n).read_bytes())==h
 assert sha((stage/'result109.json').read_bytes())==a['input_result_sha256']
 assert sha((c/'capture.json').read_bytes())==a['capture_sha256']
 assert fp(a)==a['fingerprint_sha256'] and r['input_task_fingerprint']==a['input_task_fingerprint']==execution['task_fingerprint']
 assert all(r[k]==a[k] for k in ['case_id','current_q','target_q','exact_question','source_commit','capture_sha256'])
 assert r['technical_state']==r['independent_control_status']==r['method_target']=='PASS' and r['attempts']==1
 assert read(c/'attempt_progress_recovery.json')['evaluations_started']==1
 raw=read(c/'result_raw_recovery.json')
 old=read(c/'budget106.json')['current_bins']
 assert raw['current_bins']==w['current_bins'] and raw['new_global_interval']==w['global_interval']
 assert all(raw['current_bins'][k]==v for k,v in old.items() if k!='700:750')
 assert raw['block_interval']==raw['current_bins']['700:750'][:2]
 assert [x['bin'] for x in w['ranked_widths'][:2]]==['600:650','650:700']
 v62=read(c/'v62.json')
 v77=read(c/'v77.json')
 hx=lambda s:F(float.fromhex(s))
 q=F(1,10**6)
 assert -1<hx(v77['cold_log_elasticity_hex'][0])<=hx(v77['cold_log_elasticity_hex'][1])<0
 assert F(v77['saha_over_h_squared_max'])<1 and v77['status']=='PASS_UNDER_FROZEN_PREMISES'
 assert hx(v62['one_plus_DK_range'][0])>0
 assert read(c/'v95.json')['combined_positive_z']==['0','810']
 assert read(c/'v83.json')['global_sup_abs_Delta_Xe']==str(q)
 barrier=read(c/'barrier107.json')
 assert barrier['strict_interior'] and barrier['domain']==['700','750'] and barrier['electron_interval']==[str(q/2),str(q)]
 cfg=read(c/'q048_prefix_config_v1.json')['cases']['hillipop-ede_n3']
 phase_floor=max(F(v77['phase5_z'][0]),F(cfg['frozen_reionization']['fixed_reio_start_exact']))
 assert F(v77['phase5_z'][1])>=700
 L,R=(v62['arms'][name]['records'] for name in ('L','R'))
 cursor=F(700)
 screened=[]
 for i,(left,right) in enumerate(zip(L,R)):
  hi,lo=map(hx,right['z'])
  if lo>=cursor:continue
  assert hi>=cursor>lo and lo>phase_floor
  checks={'shared_H_z':left['z']==right['z'] and left['H_per_s']==right['H_per_s'] and hx(right['H_per_s'][0])>0}
  for name,arm,rows in [('L',left,L),('R',right,R)]:
   h,v=arm['whole_source']
   checks[name+'_SWIFT_only']=arm['allowed_branches']==['SWIFT']
   checks[name+'_whole_box']=q<hx(h[0])<hx(h[1])<1 and 0<hx(v[0])<=hx(v[1])<1
   checks[name+'_continuity']=arm['initial']==rows[i-1]['end_source']
  cell={'row_v62':i,'upper':str(cursor),'lower':str(lo),'checks':checks,
        'allowed_branches':[left['allowed_branches'],right['allowed_branches']]}
  if not all(checks.values()):
   obstruction=cell
   break
  screened.append(cell)
  cursor=lo
 assert [x['row_v62'] for x in screened]==list(range(219,234)) and obstruction['row_v62']==234
 assert [k for k,v in obstruction['checks'].items() if not v]==['L_SWIFT_only','R_SWIFT_only']
 v66=read(c/'v66.json')
 partition=[]
 cover=[]
 for i,s in enumerate(v66['source_segments']):
  lo,hi=map(F,s['z'])
  if lo<700 and hi>650:
   cover.append(i)
   if hi>cursor:
    l,h=max(lo,cursor),min(hi,F(700))
    matches=[x['row_v62'] for x in screened if F(x['lower'])<=l<h<=F(x['upper'])]
    assert len(matches)==1 and s['origin']=='V62'
    assert 0<F(s['K_over_H_exact'][0])<=F(s['K_over_H_exact'][1])
    assert F(s['dx_exact'][0])<=q/2 and F(s['dx_exact'][1])>=q
    partition.append([i,matches[0],str(l),str(h)])
 assert cover==list(range(4542,4643)) and len(partition)==15
 assert partition[0][2]==str(cursor) and partition[-1][3]=='700'
 assert all(a_[3]==b_[2] for a_,b_ in zip(partition,partition[1:]))
 assert all(F(v66['source_segments'][i]['z'][0])>=cursor for i,_,_,_ in partition)
 math=(stage/'prompts/Bubbleverse_Matematikmotor_2.3.0.md').read_bytes()
 assert blob(math)==repo['paths']['Bubbleverse_Matematikmotor_2.3.0.md']
 dep=read(c/'binding.json')['background_dependency_id']
 input_pins={n:sha((c/n).read_bytes()) for n in ['v62.json','v66.json','v77.json','v83.json','v95.json','capture.json','binding.json','q048_prefix_config_v1.json','barrier107.json','result_raw_recovery.json']}

run='LOCAL-Q052-V109-OPTICAL-INTAKE-V110'
event='Q052-ACTIVITY-OPTICAL-INTAKE-V110'
stamp=datetime.now(timezone.utc).isoformat()
base=13825
points=55
total=base+points
remain=14000-total
assert sum(x['run_points'] for x in prior['entries'])==prior['total_points_after']==base
assert event not in [x.get('activity_event_id') for x in prior['entries']] and not prior['pending_packages']
basis='Heuristisk: 20 for kilde- og certifikatkontrol, 25 for arkivscreening af præmisser og den første blandede celle, 10 for eksakt afgrænsning og metode til næste opgave. Beregning af nyt optisk bidrag og pakning giver ingen point i denne runde.'
entry={'activity_event_id':event,'run_id':run,'engine':a['engine'],'run_points':points,'breakdown':{'provenance':20,'premise_screen':25,'task_design':10},'basis':basis,'counted_once':True}
ledger={**prior,'entries':prior['entries']+[entry],'previous_ledger_ref':hist('activity_ledger.json'),'previous_total_points':base,'total_points_after':total,'cycle_progress':total%1000,'points_to_next_publication':remain,'new_milestones':[],'ledger_revision':'V110','last_updated_utc':stamp,'note':basis,'parent_ledger_sha256':sha(dump(prior)),'reconciliation':{'prior_total':base,'new_unique_event_points':points,'current_total':total}}
screen={'classification':'STORED_PREMISE_SCREEN_ONLY','seed':'700','candidate_domain':[str(cursor),'700'],'passing_rows_descending':screened,'first_obstruction':obstruction,'partition_v66_v62_lo_hi':partition,'background_dependency_id':dep,'precision':'exact binary64 coordinates represented as rational numbers','new_optical_evaluations':0}
targetkeys=['case_id','current_q','target_q','exact_question','source_commit','capture_sha256']
task={**{k:a[k] for k in targetkeys},'schema_version':'UNVALIDATED_LOCAL_CONTRACT','task_id':'LOCAL-Q052-V110-SWIFT-BRIDGE-TO-FIRST-MIXED-CELL','engine':'BUBBLEVERSE.MATHEMATICS 2.3.0','engine_prompt_sha256':sha(math),'state':'PREPARED_NOT_EXECUTED','input_certificate':bundle,
 'objective':'Verify the inherited strict half-q first-contact premises on the fixed pure-SWIFT bridge from z=700 to the first mixed archived cell, then certify one positive lower endpoint improvement in the parent [650,700] optical bin using its frozen weights.',
 'domain_z':[str(cursor),'700'],'unresolved_complement_z':['650',str(cursor)],'source_rows_v62_zero_based':[219,233],'source_rows_v66_zero_based':[4628,4642],'first_obstruction':obstruction,'partition_ref':ref('frontier110.json'),'input_sha256':input_pins,
 'frozen':{'q_pair':['1/1000000','0'],'background_dependency_id':dep,'seed_ref':hist('calc/barrier107.json'),'seed_z':'700','optical_definition':'F(Z)=integral_0^Z K*(1+z)^2*Delta_Xe(z)/H_B(z) dz','parent_bin':'650:700','prior_parent_bin':w['current_bins']['650:700'],'prior_global_interval':w['global_interval'],'current_bins_ref':hist('width_budget109.json')},
 'method':['Restore hashed inputs via the archived V109 restore script and use the pinned V107/V97 first-contact proof. Independently verify connected V62 rows, both exclusive SWIFT branches, whole-cell h and v bounds, matching H and endpoints, V77 cold slopes and Saha domination, V95 positivity, fixed pre-reionization and shared background. Stop at any failed premise. Treat row 234 as an obstruction in the archived enclosures.',
 'Bind the 15 clipped V66 rows to the 15 V62 rows by exact endpoints. Use inherited positive V66 K/H endpoints and q/2 as lower electron bound only on this domain. For each subcell take mass ((1+b)^3-(1+a)^3)/3 and round each product downward to the 2^-100 grid. The rest of the [650,700] bin retains zero lower bound from V95 positivity. Reconcile the existing parent upper from all 101 clipped rows using the existing q upper and upward rounding to 2^-100. Preserve that endpoint; do not replace other bins.',
 'Perform one separate control traversing rows in reverse with integer-hex parsing, independently reconstructing row correspondence and masses via (b-a)*((1+b)^2+(1+b)*(1+a)+(1+a)^2)/3. Check the lower sums and old upper exactly, and recompute the global sum from all bins. No fresh K/H, density or scalar evaluation is required.'],
 'acceptance_criteria':'Complete 15-cell exact cover with independent agreement, strict V97 barrier premises inherited and verified on the new connected domain, conserved parent upper, strictly positive certified parent lower, exact global endpoint addition and unchanged remaining bins.',
 'tolerances':{'increment_grid_bits':100,'minimum_improvement':'strictly positive exact sum','domain_and_control_agreement':'exact rational equality','prior_provisional_global_width_goal':'1/250000000'},
 'execution_limits':{'wall_seconds':300,'new_optical_evaluations_at_most':1,'independent_controls_at_most':1,'new_weight_evaluations':0,'new_scalar_integrations':0,'new_native_pairs':0,'new_full_history_integrations':0,'parameter_or_grid_searches':0},
 'rejection_criteria':'Any conflict in identities, contiguity, barrier premises, bin reconciliation or independent control blocks promotion. Preserve original inputs and report first concrete mismatch.',
 'stop_condition':'Stop after one checked result, at first failed gate or after 300 seconds. Do not extend into the HMLA/SWIFT mixed cell under the SWIFT-only proof.',
 'expected_artifacts':['exact barrier/application record','15 rational increments','independent control receipt','updated parent interval and global width budget','execution log'],
 'no_repeat':a['no_repeat']+['V110 archived frontier screen is preparation, not an optical run. Reuse the verified V109 [700,750] and V105 [750,800] outputs.'],
 'return_engine':a['engine'],'continue_same_q':True,'total_points':total,'next_milestone':14000,'points_to_next_publication':remain,'activity_ledger_ref':ref('activity_ledger.json')}
task['fingerprint_sha256']=fp(task)
audit={'status':'ACCEPTED_CONDITIONAL_SOURCE_REAL','result_ref':hist('result109.json'),'result_sha256':a['input_result_sha256'],'verification':verified,'input_restore':restore.splitlines(),'V109_verified_GitHub_commit':repo['head'],'optical_result':r['optical_result'],'scope_warning':r['scope_warning'],'remaining_uncertainties':r['remaining_uncertainties'],'historical_failure_preserved':hist('result109.json'),'new_optical_evaluations':0,'first_obstruction':obstruction}
summary=f"""# Q052 V110 · BUBBLEVERSE — CONTINUATION HANDOFF

V109 er optaget som et betinget resultat for kildeligningerne. Det optiske delinterval for z=700–750 blev 51,04 % smallere. Det samlede betingede interval er ca. [3,79776·10⁻⁶, 4,56102·10⁻⁵], og dets bredde faldt 4,45 %. Den separate kontrol bestod for alle 106 delceller.

Den sammenhængende SWIFT-dækning fra z=700 når ned til z≈692,77. I næste arkivcelle, V62-række 234, tillader begge beregningsgrene HMLA og SWIFT. Det er en begrænsning i arkivets indhylling. Det præcise fysiske grenskift er stadig åbent.

Matematikmotor 2.3.0 får én afgrænset opgave på de 15 delceller frem til denne grænse. Den skal kontrollere, at halv-q-beviset kan overføres, og bruge de eksisterende vægte til at teste, om den nedre grænse i [650,700] kan hæves. Der er endnu ingen ny optisk værdi fra dette område.

Q052 er fortsat åbent. Der mangler et fejlcertifikat for det fulde CLASS/P6-forløb og væsentlig optisk præcision. V109 er verificeret på GitHub. V110 er klar til manuel upload.

**13.880 aktivitetspoint. 120 til næste SoMe-milepæl.**
"""
append=f"""\n\n---\n\n# Q052 V110 · Resultatindtag\n\n{stamp}\n\n> {a['exact_question']}\n\n{summary}\n
Eksakt nedre afgrænsning for den næste opgave: z={cursor}. V62-række 219 genbruges kun på sit stykke under z=700. Rækker 219–233 dækker den nye strimmel kontinuerligt. Række 234 dækker fra grænsen ned til z={obstruction['lower']}. Manglende eksklusiv SWIFT er den første registrerede præmisfejl i begge arme.

[600,650] er det største resterende breddebidrag og [650,700] det næststørste. Det sammenhængende SWIFT-bevis kan ikke forbinde de to med den nuværende arkivindhylling. Opgaven bruger derfor kun strimlen med sammenhængende præmisser og bevarer resten af [650,700] uden en ny nedre elektronindhylling.

V109's globale bredde er ca. 4,18124·10⁻⁵, omtrent 10.453 gange det foreløbige mål 4·10⁻⁹. Alle øvrige optiske blokke, inklusive V105-piloten, stemmer med deres forrige tal. Original V107-fejl og V108-rettelse bevares i det indlejrede V109-arkiv.

RUN POINTS: {points}
TOTAL WORK POINTS: {total}
NEXT SOME MILESTONE: 14000
POINTS TO NEXT SOME MILESTONE: {remain}
NEWLY CROSSED SOME MILESTONES: []
WORKFLOW: ACTIVE / CONTINUE / INCONCLUSIVE
NEXT ENGINE: {task['engine']}
TASK FINGERPRINT: {task['fingerprint_sha256']}

{basis}

Kontrol, data, ledgers og næste opgave fremgår af {bundle}.
"""
memory={'repository_url':'https://github.com/Morfindien/Bubbleverse','base_commit_sha':repo['head'],'branch':'main','source_freshness':'VERIFIED_V109_AND_BOTH_ENGINE_BLOBS','sync_status':'USER_UPLOAD_PENDING','journal_path':journal,'proposed_files':names,'index_updates':'Add a V110 research pointer to README after verifying the uploaded files. Preserve the executable program registry.','upload_instructions_ref':ref('README.md'),'commit_sha':None}
claims=[{'id':'Q052-V110-C1','claim':'V109 conditional source-optical enclosure accepted and non-target bins preserved.','evidence':[ref('audit110.json'),hist('calc/control_recovery.json')]},{'id':'Q052-V110-C2','claim':'Stored exclusive SWIFT coverage extends from z=700 to the upper edge of V62 row 234. Its two arm boxes allow HMLA and SWIFT.','evidence':[ref('frontier110.json')]}]
handoff={**{k:a[k] for k in targetkeys},'schema_id':'bubbleverse.result_ingestion_handoff','schema_version':'3.0.0','prompt_id':'bubbleverse.result_ingestion_routing','prompt_version':'2.3.0','handoff_id':run,'created_at_utc':stamp,'case_lifecycle':'ACTIVE','disposition':'CONTINUE','epistemic_status':'INCONCLUSIVE','ingestion_state':'ACCEPTED_CONDITIONAL_SOURCE_REAL','source_state_version':'V109','target_state_version':'V110','evidence_cutoff':{'source_commit':a['source_commit'],'result_version':'V109'},'new_result_ids':[r['result_id']],'selected_next_engine_id':task['engine'],'engine_registry_ref':{'file':'Bubbleverse_Matematikmotor_2.3.0.md','sha256':sha(math)},'execution_profile_ref':taskfile,'journal_ref':journal,'source_register_ref':ref('source_register.json'),'claim_evidence_map_ref':ref('claim_map.json'),'result_provenance_ref':ref('audit110.json'),'anomaly_tension_registry_ref':ref('frontier110.json'),'completed_task_ledger_ref':ref('completed_tasks.json'),'route_history_ref':ref('route.json'),'integrity_manifest_ref':ref('manifest.json'),'closure_snapshot_ref':None,'what_changed':[x['claim'] for x in claims],'frozen_configuration_refs':[hist('calc/input_pins107.json')],'open_material_uncertainties':r['remaining_uncertainties'],'missing_information':['Native whole-history certificate','Applicability of a mixed-branch extension at row 234'],'next_task':taskfile,'success_condition':task['acceptance_criteria'],'failure_or_falsification_condition':task['rejection_criteria'],'stop_condition':task['stop_condition'],'completion_gate_satisfied':False,'completion_gate_reason':'Native validation and global optical precision remain open.','handoff_completeness':'READY_LOCAL_CONTRACT','writeback_status':'USER_UPLOAD_PENDING','delivery_status':'FILES_PREPARED','operator_gate':'NONE_FOR_LOCAL_MATHEMATICS','output_file_refs':names,'output_manifest_ref':ref('manifest.json'),'repository_memory':memory,'question_activity_points':{'policy_id':'bubbleverse.question_activity_some_milestones','policy_version':'2.0.0','ledger_ref':ref('activity_ledger.json'),'parent_ledger_version':'V109','ledger_version':'V110','run_id':run,'activity_event_id':event,'parent_total_pts':base,'assessed_run_points':points,'assessment_breakdown':entry['breakdown'],'assessment_basis':basis,'total_pts':total,'status':'VERIFIED_LEDGER_HEURISTIC_POINTS'},'some_milestones':{'interval_pts':1000,'highest_threshold_reached_pts':13000,'crossed_this_run':[],'ready_package_ids':prior['ready_milestone_ids'],'pending_milestones':[],'next_threshold_pts':14000,'points_to_next_threshold':remain,'milestone_ledger_ref':ref('activity_ledger.json'),'package_creation_status':'NOT_DUE','scientific_route_changed_by_points':False}}
readme=f"""# Q052 V110

Læs {short} og {taskfile}. ZIP indeholder begge samt hele V110-journalen og det uændrede V109-certifikat under history/. Udpak V109 i en ny mappe. Kør V109's restore_inputs109.py dér for at genskabe de arkiverede beregningsinput. Læs så V110-opgaven med dens præcise koordinater, inputhashes, kontrol og stopbetingelse. V110 er resultatindtag og præmisscreening. Den optiske opgave er forberedt til Matematikmotor 2.3.0.

Tilføj de fire ydre filer som nye rodfiler i Morfindien/Bubbleverse. Verificeret base {repo['head']}. Genlæs main før upload. Efter verificeret upload kan README få en henvisning til den aktuelle Q052-journal. GITHUB SYNC: USER_UPLOAD_PENDING.
"""
(out/short).write_text(summary)
(out/journal).write_bytes((u/oldjournal).read_bytes()+append.encode())
(out/taskfile).write_bytes(dump(task))
members={'README.md':readme.encode(),'history/'+archive:(u/archive).read_bytes(),'audit110.json':dump(audit),'frontier110.json':dump(screen),'handoff110.json':dump(handoff),'activity_ledger.json':dump(ledger),'github_memory_update.json':dump(memory),'repository_snapshot.json':dump(repo),'width_budget110.json':dump(w),'claim_map.json':dump(claims),'source_register.json':dump({'inherited':hist('source_register.json'),'new_screen_inputs_sha256':input_pins,'actual_engine_sha256':sha(engine)}),'completed_tasks.json':dump({'completed':[a['task_id']],'no_repeat':task['no_repeat']}),'route.json':dump({'from':a['engine'],'next':task['engine'],'task':taskfile,'state':'PREPARED_NOT_EXECUTED'}),'build110.py':Path(__file__).read_bytes()}
for n in names[:3]:members[n]=(out/n).read_bytes()
manifest={'schema':'Q052_V110_OUTPUT_MANIFEST','q':'Q052','version':'V110','run_id':run,'base_commit':repo['head'],'parent_journal':{'filename':oldjournal,'bytes':(u/oldjournal).stat().st_size,'sha256':sha((u/oldjournal).read_bytes())},'archive_members':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in members.items()],'external_deliverables':[{'filename':n,'target_path':n,'bytes':len(members[n]),'sha256':sha(members[n])} for n in names[:3]],'container':{'filename':bundle,'target_path':bundle,'self_hash_omitted':True}}
with ZipFile(out/bundle,'w',ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in members.items(): z.writestr(n,b)
 z.writestr('manifest.json',dump(manifest))
with ZipFile(out/bundle) as z:
 assert z.testzip() is None
 for record in manifest['archive_members']:
  content=z.read(record['path'])
  assert len(content)==record['bytes'] and sha(content)==record['sha256']
  if record['path'].endswith('.json'):json.loads(content)
 assert z.read(journal).startswith((u/oldjournal).read_bytes())
 assert fp(json.loads(z.read(taskfile)))==task['fingerprint_sha256']
assert ledger['entries'][:-1]==prior['entries'] and ledger['milestone_records']==prior['milestone_records']
(p/'upload_request.json').write_bytes(dump({'uploads':[{'local_path':str(out/n),'purpose':'create_library_file','library_artifact_type':'report' if n.endswith('.md') else 'other'} for n in names]}))
print('PASS',len(members),str(cursor),total,remain,task['fingerprint_sha256'])
