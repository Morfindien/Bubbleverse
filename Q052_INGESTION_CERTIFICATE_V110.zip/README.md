# Q052 V110

Læs Q052_KORT_RESULTAT_V110.md og Q052_MATEMATIKOPGAVE_V110.json. ZIP indeholder begge samt hele V110-journalen og det uændrede V109-certifikat under history/. Udpak V109 i en ny mappe. Kør V109's restore_inputs109.py dér for at genskabe de arkiverede beregningsinput. Læs så V110-opgaven med dens præcise koordinater, inputhashes, kontrol og stopbetingelse. V110 er resultatindtag og præmisscreening. Den optiske opgave er forberedt til Matematikmotor 2.3.0.

Tilføj de fire ydre filer som nye rodfiler i Morfindien/Bubbleverse. Verificeret base 90e40b5a0a299f61733924be7008dc0c20c4cde9. Genlæs main før upload. Efter verificeret upload kan README få en henvisning til den aktuelle Q052-journal. GITHUB SYNC: USER_UPLOAD_PENDING.
