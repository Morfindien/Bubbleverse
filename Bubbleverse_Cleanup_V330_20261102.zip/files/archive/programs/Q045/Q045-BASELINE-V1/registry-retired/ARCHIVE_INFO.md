# Q045-BASELINE-V1

**ARCHIVED — NOT FOR ROUTINE EXECUTION**

This bundle contains only the retired workflow, not the source program or scientific evidence.

- Original path: `.github/workflows/q045-native-baseline-v1.yml`
- Payload: [workflow](payload/.github/workflows/q045-native-baseline-v1.yml)
- Source commit: `f689c9ca4a4917909104ea34b0428f46059e4c07`
- SHA256: `ab96a3d0844f78ed991f81298e40603932908746b290f2d707721d818fe6218b`
- Completion: https://github.com/Morfindien/Bubbleverse/actions/runs/38021982095 (`completed/failure`)
- Retirement: canonical registry replaces `Q045-BASELINE-V1` with `Q045-BASELINE-V2`.
- Source program retained: `q045_native_baseline_v1.py`.
- Original retrieval: `git show f689c9ca4a4917909104ea34b0428f46059e4c07:.github/workflows/q045-native-baseline-v1.yml`.

Historical manifests retain their original text. Shared code, tests, inputs, outputs and journals remain at their original locations. Restoration is a separate decision. No scientific rerun was performed.
