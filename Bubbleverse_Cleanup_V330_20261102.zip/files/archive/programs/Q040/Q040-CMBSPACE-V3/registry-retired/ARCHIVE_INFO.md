# Q040-CMBSPACE-V3

**ARCHIVED — NOT FOR ROUTINE EXECUTION**

This bundle contains only the retired workflow, not the source program or scientific evidence.

- Original path: `.github/workflows/q040-cmbspace-coupled-bridge-v3.yml`
- Payload: [workflow](payload/.github/workflows/q040-cmbspace-coupled-bridge-v3.yml)
- Source commit: `f689c9ca4a4917909104ea34b0428f46059e4c07`
- SHA256: `1e0bdacdff3105138378c4ce78b64a11ba35bec7c176431ebde330e996b8c08d`
- Completion: https://github.com/Morfindien/Bubbleverse/actions/runs/34209404762 (`completed/failure`)
- Retirement: canonical registry replaces `Q040-CMBSPACE-V3` with `Q040-CMBSPACE-V4`.
- Source program retained: `q040_cmbspace_coupled_bridge_v3.py`.
- Original retrieval: `git show f689c9ca4a4917909104ea34b0428f46059e4c07:.github/workflows/q040-cmbspace-coupled-bridge-v3.yml`.

Historical manifests retain their original text. Shared code, tests, inputs, outputs and journals remain at their original locations. Restoration is a separate decision. No scientific rerun was performed.
