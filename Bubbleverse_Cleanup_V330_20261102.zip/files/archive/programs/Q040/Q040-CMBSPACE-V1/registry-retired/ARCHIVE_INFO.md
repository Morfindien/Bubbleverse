# Q040-CMBSPACE-V1

**ARCHIVED — NOT FOR ROUTINE EXECUTION**

This bundle contains only the retired workflow, not the source program or scientific evidence.

- Original path: `.github/workflows/q040-cmbspace-coupled-bridge-v1.yml`
- Payload: [workflow](payload/.github/workflows/q040-cmbspace-coupled-bridge-v1.yml)
- Source commit: `f689c9ca4a4917909104ea34b0428f46059e4c07`
- SHA256: `70012a66b9b3fe691c3d1a7eb4040d7b1ba6e36d6259cce9a44d54d2d7861d8c`
- Completion: https://github.com/Morfindien/Bubbleverse/actions/runs/34199777865 (`completed/failure`)
- Retirement: canonical registry replaces `Q040-CMBSPACE-V1` with `Q040-CMBSPACE-V2`.
- Source program retained: `q040_cmbspace_coupled_bridge_v1.py`.
- Original retrieval: `git show f689c9ca4a4917909104ea34b0428f46059e4c07:.github/workflows/q040-cmbspace-coupled-bridge-v1.yml`.

Historical manifests retain their original text. Shared code, tests, inputs, outputs and journals remain at their original locations. Restoration is a separate decision. No scientific rerun was performed.
