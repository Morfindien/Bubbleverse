# Q040-RQMC-V2

**ARCHIVED — NOT FOR ROUTINE EXECUTION**

This bundle contains only the retired workflow, not the source program or scientific evidence.

- Original path: `.github/workflows/q040-defensive-rqmc-v2.yml`
- Payload: [workflow](payload/.github/workflows/q040-defensive-rqmc-v2.yml)
- Source commit: `f689c9ca4a4917909104ea34b0428f46059e4c07`
- SHA256: `079905dfeb8055cd4483b60431b55492da37169184d8e32450b2f207fdca839f`
- Completion: https://github.com/Morfindien/Bubbleverse/actions/runs/34247581888 (`completed/failure`)
- Retirement: canonical registry replaces `Q040-RQMC-V2` with `Q040-RQMC-V3`.
- Source program retained: `q040_defensive_rqmc_v2.py`.
- Original retrieval: `git show f689c9ca4a4917909104ea34b0428f46059e4c07:.github/workflows/q040-defensive-rqmc-v2.yml`.

Historical manifests retain their original text. Shared code, tests, inputs, outputs and journals remain at their original locations. Restoration is a separate decision. No scientific rerun was performed.
