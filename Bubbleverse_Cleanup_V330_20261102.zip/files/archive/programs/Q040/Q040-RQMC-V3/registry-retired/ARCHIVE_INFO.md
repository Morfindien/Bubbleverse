# Q040-RQMC-V3

**ARCHIVED — NOT FOR ROUTINE EXECUTION**

This bundle contains only the retired workflow, not the source program or scientific evidence.

- Original path: `.github/workflows/q040-defensive-rqmc-v3.yml`
- Payload: [workflow](payload/.github/workflows/q040-defensive-rqmc-v3.yml)
- Source commit: `f689c9ca4a4917909104ea34b0428f46059e4c07`
- SHA256: `db89aba3f7b04e13dd066cab1f44c503dc35af54c2e50fbdb2feb63e3991a6cf`
- Completion: https://github.com/Morfindien/Bubbleverse/actions/runs/34256042442 (`completed/failure`)
- Retirement: canonical registry replaces `Q040-RQMC-V3` with `Q040-RQMC-V4`.
- Source program retained: `q040_defensive_rqmc_v3.py`.
- Original retrieval: `git show f689c9ca4a4917909104ea34b0428f46059e4c07:.github/workflows/q040-defensive-rqmc-v3.yml`.

Historical manifests retain their original text. Shared code, tests, inputs, outputs and journals remain at their original locations. Restoration is a separate decision. No scientific rerun was performed.
