# Q040-CMBSPACE-V2

**ARCHIVED — NOT FOR ROUTINE EXECUTION**

This bundle contains only the retired workflow, not the source program or scientific evidence.

- Original path: `.github/workflows/q040-cmbspace-coupled-bridge-v2.yml`
- Payload: [workflow](payload/.github/workflows/q040-cmbspace-coupled-bridge-v2.yml)
- Source commit: `f689c9ca4a4917909104ea34b0428f46059e4c07`
- SHA256: `3cedb3e6781d91a7c4f70bf7643d1ac9300e0c76f728d77dfa6c3ba3ae29b90a`
- Completion: https://github.com/Morfindien/Bubbleverse/actions/runs/34203696897 (`completed/failure`)
- Retirement: canonical registry replaces `Q040-CMBSPACE-V2` with `Q040-CMBSPACE-V3`.
- Source program retained: `q040_cmbspace_coupled_bridge_v2.py`.
- Original retrieval: `git show f689c9ca4a4917909104ea34b0428f46059e4c07:.github/workflows/q040-cmbspace-coupled-bridge-v2.yml`.

Historical manifests retain their original text. Shared code, tests, inputs, outputs and journals remain at their original locations. Restoration is a separate decision. No scientific rerun was performed.
