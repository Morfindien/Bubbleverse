# Q040-RQMC-V1

**ARCHIVED — NOT FOR ROUTINE EXECUTION**

This bundle contains only the retired workflow, not the source program or scientific evidence.

- Original path: `.github/workflows/q040-defensive-rqmc-v1.yml`
- Payload: [workflow](payload/.github/workflows/q040-defensive-rqmc-v1.yml)
- Source commit: `f689c9ca4a4917909104ea34b0428f46059e4c07`
- SHA256: `2018927177476bac8c86d4aaedf323d024fd6d24b540910aa3651f6ae257f146`
- Completion: https://github.com/Morfindien/Bubbleverse/actions/runs/34244197767 (`completed/failure`)
- Retirement: canonical registry replaces `Q040-RQMC-V1` with `Q040-RQMC-V2`.
- Source program retained: `q040_defensive_rqmc_v1.py`.
- Original retrieval: `git show f689c9ca4a4917909104ea34b0428f46059e4c07:.github/workflows/q040-defensive-rqmc-v1.yml`.

Historical manifests retain their original text. Shared code, tests, inputs, outputs and journals remain at their original locations. Restoration is a separate decision. No scientific rerun was performed.
