# START_CODES

Launch navigation derived from the source checkout. No scientific campaign or remote dispatch was executed. Registry lifecycle and verification are separate.

Use the existing permanent launcher only for a canonical registry ID currently marked ACTIVE. Inspect its configuration before dispatch.

```bash
gh workflow run 00-bubbleverse-start.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_ACTIVE_ID
```

Replace the visibly marked value with an exact ACTIVE ID from `bubbleverse_program_registry.json`. This command is reference-only and NOT_RUN. It can consume production compute.

## Detailed command records

[All 3805 workflow run blocks, working directories, env names, inputs and exclusions](docs/maintenance/cleanup/20261102T124152Z-f689c9ca4a49-scoped-v330/ENTRYPOINT_REGISTRY.json).

Commands containing GitHub expressions depend on the original runner context and are not standalone local commands. Unknown outputs/resume and costs remain explicitly unknown. Historical journal/notebook commands are not exhaustively normalized.

## Canonical registry entries

### Q036-GEOMETRY-V1
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q036_endpoint_geometry_portability_v1.py`.
- Workflow: [q036-endpoint-geometry-portability-v3.yml](.github/workflows/q036-endpoint-geometry-portability-v3.yml).

```bash
gh workflow run q036-endpoint-geometry-portability-v3.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Internal PROGRAM_ID propagated by BUBBLEVERSE START", "required": true, "type": "string"}}`.

### Q036-GEOMETRY-V2
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q036_endpoint_geometry_portability_v1.py`.
- Workflow: [q036-endpoint-geometry-portability-v3.yml](.github/workflows/q036-endpoint-geometry-portability-v3.yml).

```bash
gh workflow run q036-endpoint-geometry-portability-v3.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Internal PROGRAM_ID propagated by BUBBLEVERSE START", "required": true, "type": "string"}}`.

### Q036-GEOMETRY-V3
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q036_endpoint_geometry_portability_v1.py`.
- Workflow: [q036-endpoint-geometry-portability-v3.yml](.github/workflows/q036-endpoint-geometry-portability-v3.yml).

```bash
gh workflow run q036-endpoint-geometry-portability-v3.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Internal PROGRAM_ID propagated by BUBBLEVERSE START", "required": true, "type": "string"}}`.

### Q038-COORDLOC-V1
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q038_coordinate_localization_v1.py`.
- Workflow: [q038-coordinate-localization-v1.yml](.github/workflows/q038-coordinate-localization-v1.yml).

```bash
gh workflow run q038-coordinate-localization-v1.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Internal PROGRAM_ID propagated by BUBBLEVERSE START", "required": true, "type": "string"}}`.

### Q039-FGPROFILE-V1
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q039_native_foreground_profile_v1.py`.
- Workflow: [q039-native-foreground-profile-v1.yml](.github/workflows/q039-native-foreground-profile-v1.yml).

```bash
gh workflow run q039-native-foreground-profile-v1.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": false, "default": "Q039-FGPROFILE-V1", "type": "string"}}`.

### Q039-IMPLBLOCK-V1
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q039_implementation_block_intervention_v1.py`.
- Workflow path absent or unspecified: BLOCKED; no command invented.

### Q040-CMBSPACE-V1
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q040_cmbspace_coupled_bridge_v1.py`.
- **ARCHIVED workflow, reference only:** [q040-cmbspace-coupled-bridge-v1.yml](archive/programs/Q040/Q040-CMBSPACE-V1/registry-retired/payload/.github/workflows/q040-cmbspace-coupled-bridge-v1.yml).

### Q040-CMBSPACE-V2
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q040_cmbspace_coupled_bridge_v2.py`.
- **ARCHIVED workflow, reference only:** [q040-cmbspace-coupled-bridge-v2.yml](archive/programs/Q040/Q040-CMBSPACE-V2/registry-retired/payload/.github/workflows/q040-cmbspace-coupled-bridge-v2.yml).

### Q040-CMBSPACE-V3
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q040_cmbspace_coupled_bridge_v3.py`.
- **ARCHIVED workflow, reference only:** [q040-cmbspace-coupled-bridge-v3.yml](archive/programs/Q040/Q040-CMBSPACE-V3/registry-retired/payload/.github/workflows/q040-cmbspace-coupled-bridge-v3.yml).

### Q040-CMBSPACE-V4
- Scientific registry status: `SUPERSEDED`; command verification: `NOT_RUN`.
- Source program: `q040_cmbspace_coupled_bridge_v4.py`.
- Workflow: [q040-cmbspace-coupled-bridge-v4.yml](.github/workflows/q040-cmbspace-coupled-bridge-v4.yml).

```bash
gh workflow run q040-cmbspace-coupled-bridge-v4.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": false, "default": "Q040-CMBSPACE-V4", "type": "string"}}`.

### Q040-CMBSPACE-V5
- Scientific registry status: `SUPERSEDED`; command verification: `NOT_RUN`.
- Source program: `q040_cmbspace_coupled_bridge_v5.py`.
- Workflow: [q040-cmbspace-compression-seal-v5.yml](.github/workflows/q040-cmbspace-compression-seal-v5.yml).

### Q040-RQMC-V1
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q040_defensive_rqmc_v1.py`.
- **ARCHIVED workflow, reference only:** [q040-defensive-rqmc-v1.yml](archive/programs/Q040/Q040-RQMC-V1/registry-retired/payload/.github/workflows/q040-defensive-rqmc-v1.yml).

### Q040-RQMC-V2
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q040_defensive_rqmc_v2.py`.
- **ARCHIVED workflow, reference only:** [q040-defensive-rqmc-v2.yml](archive/programs/Q040/Q040-RQMC-V2/registry-retired/payload/.github/workflows/q040-defensive-rqmc-v2.yml).

### Q040-RQMC-V3
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q040_defensive_rqmc_v3.py`.
- **ARCHIVED workflow, reference only:** [q040-defensive-rqmc-v3.yml](archive/programs/Q040/Q040-RQMC-V3/registry-retired/payload/.github/workflows/q040-defensive-rqmc-v3.yml).

### Q040-RQMC-V4
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q040_defensive_rqmc_v4.py`.
- Workflow: [q040-defensive-rqmc-v4.yml](.github/workflows/q040-defensive-rqmc-v4.yml).

```bash
gh workflow run q040-defensive-rqmc-v4.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": false, "default": "Q040-RQMC-V4", "type": "string"}}`.

### Q041-PLANCKPORT-V1
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v1.py`.
- Workflow: [q041-planck-portability-v1.yml](.github/workflows/q041-planck-portability-v1.yml).

```bash
gh workflow run q041-planck-portability-v1.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V10
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v10.py`.
- Workflow: [q041-planck-portability-v10.yml](.github/workflows/q041-planck-portability-v10.yml).

```bash
gh workflow run q041-planck-portability-v10.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V11
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v11.py`.
- Workflow: [q041-planck-portability-v11.yml](.github/workflows/q041-planck-portability-v11.yml).

```bash
gh workflow run q041-planck-portability-v11.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V12
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v12.py`.
- Workflow: [q041-planck-portability-v12.yml](.github/workflows/q041-planck-portability-v12.yml).

```bash
gh workflow run q041-planck-portability-v12.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V13
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v13.py`.
- Workflow: [q041-planck-portability-v13.yml](.github/workflows/q041-planck-portability-v13.yml).

```bash
gh workflow run q041-planck-portability-v13.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V14
- Scientific registry status: `SUPERSEDED`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v14.py`.
- Workflow: [q041-planck-portability-v14.yml](.github/workflows/q041-planck-portability-v14.yml).

```bash
gh workflow run q041-planck-portability-v14.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}, "segment": {"description": "Internal MCMC continuation segment", "required": false, "default": "1", "type": "string"}}`.

### Q041-PLANCKPORT-V15
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v15.py`.
- Workflow: [q041-planck-portability-v15.yml](.github/workflows/q041-planck-portability-v15.yml).

```bash
gh workflow run q041-planck-portability-v15.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}, "segment": {"description": "Internal MCMC continuation segment", "required": false, "default": "1", "type": "string"}}`.

### Q041-PLANCKPORT-V16
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v16.py`.
- Workflow: [q041-planck-portability-v16.yml](.github/workflows/q041-planck-portability-v16.yml).

```bash
gh workflow run q041-planck-portability-v16.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}, "segment": {"description": "Internal MCMC continuation segment", "required": false, "default": "1", "type": "string"}, "series_id": {"description": "Internal V16 continuation lineage; leave blank on segment 1", "required": false, "default": "", "type": "string"}}`.

### Q041-PLANCKPORT-V17
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v17.py`.
- Workflow: [q041-planck-portability-v17.yml](.github/workflows/q041-planck-portability-v17.yml).

```bash
gh workflow run q041-planck-portability-v17.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}, "segment": {"description": "Internal V17 continuation round after locked V16 state migration", "required": false, "default": "1", "type": "string"}, "series_id": {"description": "Internal V17 continuation lineage; leave blank on segment 1", "required": false, "default": "", "type": "string"}}`.

### Q041-PLANCKPORT-V18
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v18.py`.
- Workflow: [q041-planck-portability-v18.yml](.github/workflows/q041-planck-portability-v18.yml).

```bash
gh workflow run q041-planck-portability-v18.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V19
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v19.py`.
- Workflow: [q041-planck-portability-v19.yml](.github/workflows/q041-planck-portability-v19.yml).

```bash
gh workflow run q041-planck-portability-v19.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V2
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v2.py`.
- Workflow: [q041-planck-portability-v2.yml](.github/workflows/q041-planck-portability-v2.yml).

```bash
gh workflow run q041-planck-portability-v2.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V3
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v3.py`.
- Workflow: [q041-planck-portability-v3.yml](.github/workflows/q041-planck-portability-v3.yml).

```bash
gh workflow run q041-planck-portability-v3.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V4
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v4.py`.
- Workflow: [q041-planck-portability-v4.yml](.github/workflows/q041-planck-portability-v4.yml).

```bash
gh workflow run q041-planck-portability-v4.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V5
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v5.py`.
- Workflow: [q041-planck-portability-v5.yml](.github/workflows/q041-planck-portability-v5.yml).

```bash
gh workflow run q041-planck-portability-v5.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V6
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v6.py`.
- Workflow: [q041-planck-portability-v6.yml](.github/workflows/q041-planck-portability-v6.yml).

```bash
gh workflow run q041-planck-portability-v6.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V7
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v7.py`.
- Workflow: [q041-planck-portability-v7.yml](.github/workflows/q041-planck-portability-v7.yml).

```bash
gh workflow run q041-planck-portability-v7.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V8
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v8.py`.
- Workflow: [q041-planck-portability-v8.yml](.github/workflows/q041-planck-portability-v8.yml).

```bash
gh workflow run q041-planck-portability-v8.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q041-PLANCKPORT-V9
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `q041_planck_portability_v9.py`.
- Workflow: [q041-planck-portability-v9.yml](.github/workflows/q041-planck-portability-v9.yml).

```bash
gh workflow run q041-planck-portability-v9.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered Bubbleverse PROGRAM_ID", "required": true, "type": "string"}}`.

### Q042-STOCKDIAG-V20
- Scientific registry status: `BROKEN`; command verification: `NOT_RUN`.
- Source program: `UNKNOWN`.
- Workflow path absent or unspecified: BLOCKED; no command invented.

### Q042-STOCKDIAG-V21
- Scientific registry status: `SUPERSEDED`; command verification: `NOT_RUN`.
- Source program: `UNKNOWN`.
- Workflow path absent or unspecified: BLOCKED; no command invented.

### Q042-DURABLE-V22
- Scientific registry status: `COMPLETED`; command verification: `NOT_RUN`.
- Source program: `UNKNOWN`.
- Workflow path absent or unspecified: BLOCKED; no command invented.

### Q042-CLASSCAUSE-V23
- Scientific registry status: `COMPLETED`; command verification: `NOT_RUN`.
- Source program: `UNKNOWN`.
- Workflow path absent or unspecified: BLOCKED; no command invented.

### Q042-CLASSORIGIN-V24
- Scientific registry status: `COMPLETED`; command verification: `NOT_RUN`.
- Source program: `UNKNOWN`.
- Workflow path absent or unspecified: BLOCKED; no command invented.

### Q042-CLASSNAN-V25
- Scientific registry status: `COMPLETED`; command verification: `NOT_RUN`.
- Source program: `UNKNOWN`.
- Workflow path absent or unspecified: BLOCKED; no command invented.

### Q042-REFACQ-V26
- Scientific registry status: `COMPLETED`; command verification: `NOT_RUN`.
- Source program: `q042_reference_acquisition_v26.py`.
- Workflow: [q042-reference-acquisition-v26.yml](.github/workflows/q042-reference-acquisition-v26.yml).

```bash
gh workflow run q042-reference-acquisition-v26.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q042-SWITCHPROBE-V27
- Scientific registry status: `COMPLETED`; command verification: `NOT_RUN`.
- Source program: `q042_switch_probe_v27.py`.
- Workflow: [q042-switch-probe-v27.yml](.github/workflows/q042-switch-probe-v27.yml).

```bash
gh workflow run q042-switch-probe-v27.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q042-EVENTCELL-V28
- Scientific registry status: `COMPLETED`; command verification: `NOT_RUN`.
- Source program: `q042_event_cell_v28.py`.
- Workflow: [q042-event-cell-v28.yml](.github/workflows/q042-event-cell-v28.yml).

```bash
gh workflow run q042-event-cell-v28.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q042-CONTEXT-V29
- Scientific registry status: `COMPLETED`; command verification: `NOT_RUN`.
- Source program: `q042_context_v29.py`.
- Workflow: [q042-context-v29.yml](.github/workflows/q042-context-v29.yml).

```bash
gh workflow run q042-context-v29.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q045-BASELINE-V1
- Scientific registry status: `SUPERSEDED`; command verification: `NOT_RUN`.
- Source program: `q045_native_baseline_v1.py`.
- **ARCHIVED workflow, reference only:** [q045-native-baseline-v1.yml](archive/programs/Q045/Q045-BASELINE-V1/registry-retired/payload/.github/workflows/q045-native-baseline-v1.yml).

### Q045-BASELINE-V2
- Scientific registry status: `COMPLETED`; command verification: `NOT_RUN`.
- Source program: `q045_native_baseline_v2.py`.
- Workflow: [q045-native-baseline-v2.yml](.github/workflows/q045-native-baseline-v2.yml).

```bash
gh workflow run q045-native-baseline-v2.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q045-OPTICAL-AUDIT-V1
- Scientific registry status: `FAILED`; command verification: `NOT_RUN`.
- Source program: `q045_optical_audit_v1.py`.
- Workflow: [q045-optical-audit-v1.yml](.github/workflows/q045-optical-audit-v1.yml).

```bash
gh workflow run q045-optical-audit-v1.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q045-OPTICAL-AUDIT-V2
- Scientific registry status: `FAILED`; command verification: `NOT_RUN`.
- Source program: `q045_optical_audit_v2.py`.
- Workflow: [q045-optical-audit-v2.yml](.github/workflows/q045-optical-audit-v2.yml).

```bash
gh workflow run q045-optical-audit-v2.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q045-OPTICAL-AUDIT-V3
- Scientific registry status: `COMPLETED`; command verification: `NOT_RUN`.
- Source program: `q045_optical_audit_v3.py`.
- Workflow: [q045-optical-audit-v3.yml](.github/workflows/q045-optical-audit-v3.yml).

```bash
gh workflow run q045-optical-audit-v3.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q045-REFHIST-V1
- Scientific registry status: `COMPLETED_WITH_POSTPROCESSING_FAILURE`; command verification: `NOT_RUN`.
- Source program: `q045_reference_history_v1.py`.
- Workflow: [q045-reference-history-v1.yml](.github/workflows/q045-reference-history-v1.yml).

```bash
gh workflow run q045-reference-history-v1.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q045-REFHIST-V2
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q045_reference_history_v2.py`.
- Workflow: [q045-reference-history-v2.yml](.github/workflows/q045-reference-history-v2.yml).

```bash
gh workflow run q045-reference-history-v2.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q047-CERTCHECK-V1
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q047_certificate_v1.py`.
- Workflow: [q047-certificate-check-v1.yml](.github/workflows/q047-certificate-check-v1.yml).

```bash
gh workflow run q047-certificate-check-v1.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q047-PRECURSORCHECK-V1
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q047_precursor_check_v1.py`.
- Workflow: [q047-precursor-check-v1.yml](.github/workflows/q047-precursor-check-v1.yml).

```bash
gh workflow run q047-precursor-check-v1.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Exact registered PROGRAM_ID", "required": true, "type": "string"}}`.

### Q047-COLLECTION-PREFLIGHT-V1
- Scientific registry status: `COMPLETED_HISTORICAL`; command verification: `NOT_RUN`.
- Source program: `q047_execution_v1.py`.
- Workflow: [q047-collection-preflight-v1.yml](.github/workflows/q047-collection-preflight-v1.yml).

```bash
gh workflow run q047-collection-preflight-v1.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q047-RECONSTRUCTION-V1
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q047_reconstruction_v1.py`.
- Workflow: [q047-reconstruction-v1.yml](.github/workflows/q047-reconstruction-v1.yml).

```bash
gh workflow run q047-reconstruction-v1.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q048-INPUTCHECK-V1
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q048_inputcheck_v1.py`.
- Workflow: [q048-input-check-v1.yml](.github/workflows/q048-input-check-v1.yml).

```bash
gh workflow run q048-input-check-v1.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Exact registered target", "type": "string", "required": true, "default": "Q048-INPUTCHECK-V1"}}`.

### Q048-PREFIX-V1
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q048_prefix_v1.py`.
- Workflow: [q048-prefix-v1.yml](.github/workflows/q048-prefix-v1.yml).

```bash
gh workflow run q048-prefix-v1.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Exact registered program identifier", "required": true, "type": "string", "default": "Q048-PREFIX-V1"}}`.

### Q048-RESUME-V2
- Scientific registry status: `SUPERSEDED`; command verification: `NOT_RUN`.
- Source program: `q048_resume_v2.py`.
- Workflow: [q048-resume-v2.yml](.github/workflows/q048-resume-v2.yml).

```bash
gh workflow run q048-resume-v2.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered continuation identifier", "required": true, "type": "string", "default": "Q048-RESUME-V2"}}`.

### Q048-RESUME-V3
- Scientific registry status: `SUPERSEDED`; command verification: `NOT_RUN`.
- Source program: `q048_resume_v3.py`.
- Workflow: [q048-resume-v3.yml](.github/workflows/q048-resume-v3.yml).

```bash
gh workflow run q048-resume-v3.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered continuation identifier", "required": true, "type": "string", "default": "Q048-RESUME-V3"}}`.

### Q048-RESUME-V4
- Scientific registry status: `SUPERSEDED`; command verification: `NOT_RUN`.
- Source program: `q048_resume_v4.py`.
- Workflow: [q048-resume-v4.yml](.github/workflows/q048-resume-v4.yml).

```bash
gh workflow run q048-resume-v4.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered continuation identifier", "required": true, "type": "string", "default": "Q048-RESUME-V4"}}`.

### Q048-RESUME-V5
- Scientific registry status: `SUPERSEDED`; command verification: `NOT_RUN`.
- Source program: `q048_resume_v5.py`.
- Workflow: [q048-resume-v5.yml](.github/workflows/q048-resume-v5.yml).

```bash
gh workflow run q048-resume-v5.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered continuation identifier", "required": true, "type": "string", "default": "Q048-RESUME-V5"}}`.

### Q048-STRUCTURAL-V6
- Scientific registry status: `SUPERSEDED`; command verification: `NOT_RUN`.
- Source program: `q048_structural_runner_v6.py`.
- Workflow: [q048-structural-v6.yml](.github/workflows/q048-structural-v6.yml).

```bash
gh workflow run q048-structural-v6.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered one-pass structural extension identifier", "required": true, "type": "string", "default": "Q048-STRUCTURAL-V6"}}`.

### Q048-GUARDCONT-V7
- Scientific registry status: `SUPERSEDED`; command verification: `NOT_RUN`.
- Source program: `q048_guard_runner_v7.py`.
- Workflow: [q048-guard-continuation-v7.yml](.github/workflows/q048-guard-continuation-v7.yml).

```bash
gh workflow run q048-guard-continuation-v7.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered finite Q048 V7 proof identifier", "required": true, "type": "string", "default": "Q048-GUARDCONT-V7"}}`.

### Q048-PHASETURN-V8
- Scientific registry status: `SUPERSEDED`; command verification: `NOT_RUN`.
- Source program: `q048_phase_turn_runner_v8.py`.
- Workflow: [q048-phase-turn-v8.yml](.github/workflows/q048-phase-turn-v8.yml).

```bash
gh workflow run q048-phase-turn-v8.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered bounded Q048 V8 proof identifier", "required": true, "type": "string", "default": "Q048-PHASETURN-V8"}}`.

### Q048-THRESHOLD-V9
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q048_threshold_anchor_runner_v9.py`.
- Workflow: [q048-threshold-anchor-v9.yml](.github/workflows/q048-threshold-anchor-v9.yml).

```bash
gh workflow run q048-threshold-anchor-v9.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Registered bounded Q048 V9 proof identifier", "required": true, "type": "string", "default": "Q048-THRESHOLD-V9"}}`.

### Q052-NATIVEPAIR-V2
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q052_native_pair_v2.py + q052_native_pair_v2.c`.
- Workflow: [q052-native-pair-v2.yml](.github/workflows/q052-native-pair-v2.yml).

```bash
gh workflow run q052-native-pair-v2.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"required": true, "type": "string"}}`.

### Q052-VALIDATEDDIAG-V3
- Scientific registry status: `ACTIVE`; command verification: `NOT_RUN`.
- Source program: `q052_validated_diag_v3.py + generated q052_validated_diag_v3.c`.
- Workflow: [q052-validated-diagnostics-v3.yml](.github/workflows/q052-validated-diagnostics-v3.yml).

```bash
gh workflow run q052-validated-diagnostics-v3.yml --repo Morfindien/Bubbleverse --ref f689c9ca4a4917909104ea34b0428f46059e4c07 -f program_id=REPLACE_WITH_PROGRAM_ID
```

Inputs and permitted values: `{"program_id": {"description": "Exact registered Bubbleverse program ID", "required": true, "default": "Q052-VALIDATEDDIAG-V3"}}`.

## Other discovered workflow definitions

- [00-bubbleverse-start-add-only-v2.yml](.github/workflows/00-bubbleverse-start-add-only-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [00-bubbleverse-start-segmented-v5.yml](.github/workflows/00-bubbleverse-start-segmented-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [00-bubbleverse-start-verified-v4.yml](.github/workflows/00-bubbleverse-start-verified-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [00-bubbleverse-start.yml](.github/workflows/00-bubbleverse-start.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [apply-bubbleverse-cleanup-current-v2.yml](.github/workflows/apply-bubbleverse-cleanup-current-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [apply-bubbleverse-cleanup-current.yml](.github/workflows/apply-bubbleverse-cleanup-current.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [apply-bubbleverse-cleanup-v330.yml](.github/workflows/apply-bubbleverse-cleanup-v330.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [apply-bubbleverse-cleanup.yml](.github/workflows/apply-bubbleverse-cleanup.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q005-hpc-v11.yml](.github/workflows/q005-hpc-v11.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q005-hpc-v12.yml](.github/workflows/q005-hpc-v12.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q005-hpc-v13.yml](.github/workflows/q005-hpc-v13.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q005-hpc-v14-globality-recovery.yml](.github/workflows/q005-hpc-v14-globality-recovery.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q005-hpc-v14.yml](.github/workflows/q005-hpc-v14.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q005-hpc-v5.yml](.github/workflows/q005-hpc-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q005-hpc-v6.yml](.github/workflows/q005-hpc-v6.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q005-hpc-v7.yml](.github/workflows/q005-hpc-v7.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q005-hpc-v8.yml](.github/workflows/q005-hpc-v8.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q005-hpc-v9.yml](.github/workflows/q005-hpc-v9.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q006-likelihood-attribution-v1.yml](.github/workflows/q006-likelihood-attribution-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q007-act-observable-attribution-v1.yml](.github/workflows/q007-act-observable-attribution-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q007-act-observable-attribution-v2.yml](.github/workflows/q007-act-observable-attribution-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q008-globality-validation-v1.yml](.github/workflows/q008-globality-validation-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q009-act-corrected-minima-attribution-v1.yml](.github/workflows/q009-act-corrected-minima-attribution-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q009-act-corrected-minima-attribution-v2.yml](.github/workflows/q009-act-corrected-minima-attribution-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q009-act-corrected-minima-attribution-v3.yml](.github/workflows/q009-act-corrected-minima-attribution-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q009-act-corrected-minima-attribution-v4.yml](.github/workflows/q009-act-corrected-minima-attribution-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q009-act-corrected-minima-attribution-v5.yml](.github/workflows/q009-act-corrected-minima-attribution-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q009-act-corrected-minima-attribution-v6.yml](.github/workflows/q009-act-corrected-minima-attribution-v6.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q009-act-corrected-minima-attribution-v7.yml](.github/workflows/q009-act-corrected-minima-attribution-v7.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q009-act-corrected-minima-attribution-v8.yml](.github/workflows/q009-act-corrected-minima-attribution-v8.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q010-nonact-likelihood-attribution-v1.yml](.github/workflows/q010-nonact-likelihood-attribution-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q010-nonact-likelihood-attribution-v2.yml](.github/workflows/q010-nonact-likelihood-attribution-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q010-nonact-likelihood-attribution-v3.yml](.github/workflows/q010-nonact-likelihood-attribution-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q011-ede-globality-certification-v1.yml](.github/workflows/q011-ede-globality-certification-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q011-ede-globality-certification-v2.yml](.github/workflows/q011-ede-globality-certification-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q011-ede-globality-certification-v3.yml](.github/workflows/q011-ede-globality-certification-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q011-ede-globality-certification-v4.yml](.github/workflows/q011-ede-globality-certification-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q012-likelihood-attribution-v1.yml](.github/workflows/q012-likelihood-attribution-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q014-external-viability-v1.yml](.github/workflows/q014-external-viability-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q014-external-viability-v10.yml](.github/workflows/q014-external-viability-v10.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q014-external-viability-v11.yml](.github/workflows/q014-external-viability-v11.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q014-external-viability-v12.yml](.github/workflows/q014-external-viability-v12.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q014-external-viability-v2.yml](.github/workflows/q014-external-viability-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q014-external-viability-v3.yml](.github/workflows/q014-external-viability-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q014-external-viability-v4.yml](.github/workflows/q014-external-viability-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q014-external-viability-v5.yml](.github/workflows/q014-external-viability-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q014-external-viability-v6.yml](.github/workflows/q014-external-viability-v6.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q014-external-viability-v7.yml](.github/workflows/q014-external-viability-v7.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q014-external-viability-v8.yml](.github/workflows/q014-external-viability-v8.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q014-external-viability-v9.yml](.github/workflows/q014-external-viability-v9.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q015-cmb-attribution-v1.yml](.github/workflows/q015-cmb-attribution-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q015-cmb-attribution-v2.yml](.github/workflows/q015-cmb-attribution-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q015-cmb-attribution-v3.yml](.github/workflows/q015-cmb-attribution-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-cmb-mechanism-v1.yml](.github/workflows/q016-cmb-mechanism-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-cmb-mechanism-v2.yml](.github/workflows/q016-cmb-mechanism-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-cmb-mechanism-v3.yml](.github/workflows/q016-cmb-mechanism-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-cmb-mechanism-v4.yml](.github/workflows/q016-cmb-mechanism-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v1.yml](.github/workflows/q016-matched-cmb-surface-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v10.yml](.github/workflows/q016-matched-cmb-surface-v10.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v11.yml](.github/workflows/q016-matched-cmb-surface-v11.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v12.yml](.github/workflows/q016-matched-cmb-surface-v12.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v14.yml](.github/workflows/q016-matched-cmb-surface-v14.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v15.yml](.github/workflows/q016-matched-cmb-surface-v15.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v16.yml](.github/workflows/q016-matched-cmb-surface-v16.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v2.yml](.github/workflows/q016-matched-cmb-surface-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v3.yml](.github/workflows/q016-matched-cmb-surface-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v4.yml](.github/workflows/q016-matched-cmb-surface-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v5.yml](.github/workflows/q016-matched-cmb-surface-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v6.yml](.github/workflows/q016-matched-cmb-surface-v6.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v7.yml](.github/workflows/q016-matched-cmb-surface-v7.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v8.yml](.github/workflows/q016-matched-cmb-surface-v8.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q016-matched-cmb-surface-v9.yml](.github/workflows/q016-matched-cmb-surface-v9.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q017-planck-direction-localization-v1.yml](.github/workflows/q017-planck-direction-localization-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q017-planck-direction-localization-v2.yml](.github/workflows/q017-planck-direction-localization-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q017-planck-direction-localization-v3.yml](.github/workflows/q017-planck-direction-localization-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q018-planck-likelihood-bridge-v1.yml](.github/workflows/q018-planck-likelihood-bridge-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q018-planck-likelihood-bridge-v2.yml](.github/workflows/q018-planck-likelihood-bridge-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q018-planck-likelihood-bridge-v3.yml](.github/workflows/q018-planck-likelihood-bridge-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q019-planck-cosmology-reprofile-v1.yml](.github/workflows/q019-planck-cosmology-reprofile-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q019-planck-globality-repair-v2.yml](.github/workflows/q019-planck-globality-repair-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q019-planck-globality-repair-v3.yml](.github/workflows/q019-planck-globality-repair-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q020-cross-profile-gate-repair-v2.yml](.github/workflows/q020-cross-profile-gate-repair-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q020-planck-cross-profile-direction-v1.yml](.github/workflows/q020-planck-cross-profile-direction-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q021-coherent-restart-gate-repair-v2.yml](.github/workflows/q021-coherent-restart-gate-repair-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q021-primordial-internal-structure-v1.yml](.github/workflows/q021-primordial-internal-structure-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q022-optimizer-basin-continuation-v2.yml](.github/workflows/q022-optimizer-basin-continuation-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q022-optimizer-basin-diagnostic-v1.yml](.github/workflows/q022-optimizer-basin-diagnostic-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q023-read-only-basin-directions-v1.yml](.github/workflows/q023-read-only-basin-directions-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q023-read-only-basin-directions-v2.yml](.github/workflows/q023-read-only-basin-directions-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q024-read-only-basin-matching-v1.yml](.github/workflows/q024-read-only-basin-matching-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q025-fullmf-component-attribution-v1.yml](.github/workflows/q025-fullmf-component-attribution-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q025-fullmf-component-attribution-v2.yml](.github/workflows/q025-fullmf-component-attribution-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q026-mask6-nuisance-localization-v1.yml](.github/workflows/q026-mask6-nuisance-localization-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q027-residual-covariance-bridge-v1.yml](.github/workflows/q027-residual-covariance-bridge-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q028-common-support-counterfactual-v1.yml](.github/workflows/q028-common-support-counterfactual-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q028-common-support-counterfactual-v2.yml](.github/workflows/q028-common-support-counterfactual-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q028-common-support-counterfactual-v3.yml](.github/workflows/q028-common-support-counterfactual-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q028-common-support-counterfactual-v4.yml](.github/workflows/q028-common-support-counterfactual-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q028-common-support-counterfactual-v5.yml](.github/workflows/q028-common-support-counterfactual-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q028-common-support-counterfactual-v6.yml](.github/workflows/q028-common-support-counterfactual-v6.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q028-common-support-counterfactual-v7.yml](.github/workflows/q028-common-support-counterfactual-v7.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q028-common-support-counterfactual-v8.yml](.github/workflows/q028-common-support-counterfactual-v8.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q030-interaction-preserving-decomposition-v1.yml](.github/workflows/q030-interaction-preserving-decomposition-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q030-interaction-preserving-decomposition-v2.yml](.github/workflows/q030-interaction-preserving-decomposition-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q030-original-gate-audit-finalization-r1.yml](.github/workflows/q030-original-gate-audit-finalization-r1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q030-original-gate-precision-audit-v1.yml](.github/workflows/q030-original-gate-precision-audit-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q030-validation-repair-v3.yml](.github/workflows/q030-validation-repair-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q031-planck-portability-v1.yml](.github/workflows/q031-planck-portability-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q031-planck-portability-v2.yml](.github/workflows/q031-planck-portability-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q031-planck-portability-v3.yml](.github/workflows/q031-planck-portability-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q031-planck-portability-v4.yml](.github/workflows/q031-planck-portability-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q032-camspec-addback-v3.yml](.github/workflows/q032-camspec-addback-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q032-exact-start-addback-v4.yml](.github/workflows/q032-exact-start-addback-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q032-planck-tt3pair-bridge-v1.yml](.github/workflows/q032-planck-tt3pair-bridge-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q032-planck-tt3pair-bridge-v2.yml](.github/workflows/q032-planck-tt3pair-bridge-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q033-launch-semantics-matched-ab-v1.yml](.github/workflows/q033-launch-semantics-matched-ab-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q033-launch-semantics-protocol-audit-v2.yml](.github/workflows/q033-launch-semantics-protocol-audit-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q034-primordial-freeze-isolation-v1.yml](.github/workflows/q034-primordial-freeze-isolation-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q035-classifier-harmonization-v1.yml](.github/workflows/q035-classifier-harmonization-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q035-classifier-harmonization-v2.yml](.github/workflows/q035-classifier-harmonization-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q036-endpoint-geometry-portability-v1_REPLACE.yml](.github/workflows/q036-endpoint-geometry-portability-v1_REPLACE.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q036-endpoint-geometry-portability-v2.yml](.github/workflows/q036-endpoint-geometry-portability-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q036-endpoint-geometry-portability-v3.yml](.github/workflows/q036-endpoint-geometry-portability-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q036-endpoint-geometry-portability-v4.yml](.github/workflows/q036-endpoint-geometry-portability-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q036-endpoint-geometry-portability-v5.yml](.github/workflows/q036-endpoint-geometry-portability-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q037-common-support-endpoint-geometry-v1.yml](.github/workflows/q037-common-support-endpoint-geometry-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q038-coordinate-localization-v1.yml](.github/workflows/q038-coordinate-localization-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q039-implementation-block-intervention-v1-fixed.yml](.github/workflows/q039-implementation-block-intervention-v1-fixed.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q039-implementation-block-intervention-v2.yml](.github/workflows/q039-implementation-block-intervention-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q039-implementation-block-intervention-v3.yml](.github/workflows/q039-implementation-block-intervention-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q039-implementation-block-intervention-v5.yml](.github/workflows/q039-implementation-block-intervention-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q039-native-foreground-profile-v1.yml](.github/workflows/q039-native-foreground-profile-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q040-cmbspace-compression-seal-v5.yml](.github/workflows/q040-cmbspace-compression-seal-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q040-cmbspace-coupled-bridge-v4.yml](.github/workflows/q040-cmbspace-coupled-bridge-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q040-defensive-rqmc-v4.yml](.github/workflows/q040-defensive-rqmc-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v1.yml](.github/workflows/q041-planck-portability-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v10.yml](.github/workflows/q041-planck-portability-v10.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v11.yml](.github/workflows/q041-planck-portability-v11.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v12.yml](.github/workflows/q041-planck-portability-v12.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v13.yml](.github/workflows/q041-planck-portability-v13.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v14.yml](.github/workflows/q041-planck-portability-v14.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v15.yml](.github/workflows/q041-planck-portability-v15.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v16.yml](.github/workflows/q041-planck-portability-v16.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v17.yml](.github/workflows/q041-planck-portability-v17.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v18.yml](.github/workflows/q041-planck-portability-v18.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v19.yml](.github/workflows/q041-planck-portability-v19.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v2.yml](.github/workflows/q041-planck-portability-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v3.yml](.github/workflows/q041-planck-portability-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v4.yml](.github/workflows/q041-planck-portability-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v5.yml](.github/workflows/q041-planck-portability-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v6.yml](.github/workflows/q041-planck-portability-v6.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v7.yml](.github/workflows/q041-planck-portability-v7.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v8.yml](.github/workflows/q041-planck-portability-v8.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q041-planck-portability-v9.yml](.github/workflows/q041-planck-portability-v9.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-class-cause-v23.yml](.github/workflows/q042-class-cause-v23.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-class-nan-v25.yml](.github/workflows/q042-class-nan-v25.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-class-origin-v24.yml](.github/workflows/q042-class-origin-v24.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-context-v29.yml](.github/workflows/q042-context-v29.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-durable-v22.yml](.github/workflows/q042-durable-v22.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-event-cell-v28.yml](.github/workflows/q042-event-cell-v28.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-execution-mechanism-v1.yml](.github/workflows/q042-execution-mechanism-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-planck-portability-v10.yml](.github/workflows/q042-planck-portability-v10.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-planck-portability-v11.yml](.github/workflows/q042-planck-portability-v11.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-planck-portability-v2.yml](.github/workflows/q042-planck-portability-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-planck-portability-v3.yml](.github/workflows/q042-planck-portability-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-planck-portability-v4.yml](.github/workflows/q042-planck-portability-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-planck-portability-v5.yml](.github/workflows/q042-planck-portability-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-planck-portability-v6.yml](.github/workflows/q042-planck-portability-v6.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-planck-portability-v7.yml](.github/workflows/q042-planck-portability-v7.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-planck-portability-v9.yml](.github/workflows/q042-planck-portability-v9.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v1.yml](.github/workflows/q042-production-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v11.yml](.github/workflows/q042-production-v11.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v12.yml](.github/workflows/q042-production-v12.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v13.yml](.github/workflows/q042-production-v13.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v15.yml](.github/workflows/q042-production-v15.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v16.yml](.github/workflows/q042-production-v16.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v17.yml](.github/workflows/q042-production-v17.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v18.yml](.github/workflows/q042-production-v18.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v19.yml](.github/workflows/q042-production-v19.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v2.yml](.github/workflows/q042-production-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v3.yml](.github/workflows/q042-production-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v4.yml](.github/workflows/q042-production-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v5.yml](.github/workflows/q042-production-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v6.yml](.github/workflows/q042-production-v6.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v7.yml](.github/workflows/q042-production-v7.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v8.yml](.github/workflows/q042-production-v8.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-production-v9.yml](.github/workflows/q042-production-v9.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-reference-acquisition-v26.yml](.github/workflows/q042-reference-acquisition-v26.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-stock-diagnostic-v20.yml](.github/workflows/q042-stock-diagnostic-v20.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-stock-diagnostic-v21.yml](.github/workflows/q042-stock-diagnostic-v21.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q042-switch-probe-v27.yml](.github/workflows/q042-switch-probe-v27.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q045-native-baseline-v2.yml](.github/workflows/q045-native-baseline-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q045-optical-audit-v1.yml](.github/workflows/q045-optical-audit-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q045-optical-audit-v2.yml](.github/workflows/q045-optical-audit-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q045-optical-audit-v3.yml](.github/workflows/q045-optical-audit-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q045-reference-history-v1.yml](.github/workflows/q045-reference-history-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q045-reference-history-v2.yml](.github/workflows/q045-reference-history-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q047-certificate-check-v1.yml](.github/workflows/q047-certificate-check-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q047-collection-preflight-v1.yml](.github/workflows/q047-collection-preflight-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q047-precursor-check-v1.yml](.github/workflows/q047-precursor-check-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q047-reconstruction-v1.yml](.github/workflows/q047-reconstruction-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q048-guard-continuation-v7.yml](.github/workflows/q048-guard-continuation-v7.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q048-input-check-v1.yml](.github/workflows/q048-input-check-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q048-install-threshold-v9.yml](.github/workflows/q048-install-threshold-v9.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q048-phase-turn-v8.yml](.github/workflows/q048-phase-turn-v8.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q048-prefix-v1.yml](.github/workflows/q048-prefix-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q048-resume-v2.yml](.github/workflows/q048-resume-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q048-resume-v3.yml](.github/workflows/q048-resume-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q048-resume-v4.yml](.github/workflows/q048-resume-v4.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q048-resume-v5.yml](.github/workflows/q048-resume-v5.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q048-structural-v6.yml](.github/workflows/q048-structural-v6.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q048-threshold-anchor-v9.yml](.github/workflows/q048-threshold-anchor-v9.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q050-clean-v6-literal-normal.yml](.github/workflows/q050-clean-v6-literal-normal.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q050-v4-pion-surface.yml](.github/workflows/q050-v4-pion-surface.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q050-v8-execute.yml](.github/workflows/q050-v8-execute.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q050-v8-pion-normal-certificate.yml](.github/workflows/q050-v8-pion-normal-certificate.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q050-v8r1-execute.yml](.github/workflows/q050-v8r1-execute.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q052-background-dump-v30.yml](.github/workflows/q052-background-dump-v30.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q052-install-nativepair-v2.yml](.github/workflows/q052-install-nativepair-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q052-install-validated-diag-v3.yml](.github/workflows/q052-install-validated-diag-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q052-native-pair-v1.yml](.github/workflows/q052-native-pair-v1.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q052-native-pair-v2.yml](.github/workflows/q052-native-pair-v2.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q052-native-pair-v36.yml](.github/workflows/q052-native-pair-v36.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q052-validated-diagnostics-v3.yml](.github/workflows/q052-validated-diagnostics-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
- [q052-validateddiag-collect-recovery-v3.yml](.github/workflows/q052-validateddiag-collect-recovery-v3.yml) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.
