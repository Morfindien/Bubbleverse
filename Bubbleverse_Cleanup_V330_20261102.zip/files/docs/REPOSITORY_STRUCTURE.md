# Repository structure

Prepared from `f689c9ca4a4917909104ea34b0428f46059e4c07`. This describes the delivered local tree; remote installation is pending.

- Root: README.md, START_CODES.md and canonical program registry; 4580 other original root records remain protected/contract-bound.
- `.github/workflows/`: existing active-discovery workflows, minus seven archived definitions. A present workflow is not necessarily an ACTIVE scientific target.
- `tools/maintenance/`: existing maintenance engine retained unchanged.
- `cleanup-installation/`: existing installation snapshots retained unchanged.
- `archive/programs/`: seven retired workflow-only bundles with exact frozen payloads.
- `docs/indexes/`: navigation to original journals and engine prompts; no payload copies.
- `docs/maintenance/cleanup/20261102T124152Z-f689c9ca4a49-scoped-v330/`: this run’s inventory, schema, decisions and evidence.

[Launch navigation](../START_CODES.md) · [Cleanup history](maintenance/cleanup/INDEX.md) · [Journals](indexes/journals.md) · [Engine prompts](indexes/engine-prompts.md).

Root files before: 4582; after: 4583. No root scientific record was moved. Every baseline path has an individual placement decision and byte/mode inventory. Ambiguous content is protected pending lifecycle/consumer evidence. Existing case-folding collisions are recorded rather than renamed.
