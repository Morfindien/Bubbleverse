# Cleanup execution design

Run the supplied v3.3.0 contract against an isolated checkout at f689c9ca4a4917909104ea34b0428f46059e4c07. Preserve scientific payloads, source snapshots, input/output paths and untracked files. Inspect all tracked bytes and entrypoint syntax. Archive only retired workflow definitions with explicit registry replacement, completed run evidence and no live source caller; retain uncertain code/support dependencies. Add source retrieval maps, root launch documentation, protected navigation and a current maintenance record. Preserve the README content below a new navigation block. No remote mutation or scientific execution.

Acceptance: every tracked path inventoried with a placement reason; archive bytes/mode and original Git retrieval verified; current ACTIVE registry targets retained; launcher rejects retired IDs; no new scientific result; bounded syntax/link/schema/integrity checks pass; exact-base patch plus complete changed files and rollback instructions delivered. Broad retirement and end-to-end campaigns remain explicitly unverified.

Alternatives: running the existing cleanup engine is rejected because preview mutates, retirement lacks active-job checks and generated commands omit inputs. A navigation-only result is insufficient where a retired workflow can safely move. Full case migration is outside the supplied historical policy.
