import os,json,hashlib,subprocess,re,stat,ast,zipfile,collections
from pathlib import Path
root=Path.cwd();base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();files=subprocess.check_output(['git','ls-files','-z']).decode().split('\0')[:-1]
p=json.loads(Path('bubbleverse_program_registry.json').read_text())['programs'];cands={v.get('workflow_path'):k for k,v in p.items() if v.get('superseded_by') and v.get('failed_run_id')};cands.pop(None,None)
inv=[];references={x:[] for x in cands};commands=[];python_entries=[];syntax=[];yaml_errors=[]
import yaml
for i,f in enumerate(files):
 b=Path(f).read_bytes();st=Path(f).lstat();text=None
 if b'\0' not in b[:8192]:
  try:text=b.decode('utf-8')
  except UnicodeError:pass
 content='binary payload'
 if text is not None:
  content='text; historical/support association unresolved'
  sample=text[:32000].lower()
  if any(x in sample for x in ['journal','sha256','sha-256','provenance','run_id','run id','frozen','result_id','certificate','checkpoint','handoff']):content='content contains scientific/history/provenance binding'
  if f.endswith('.py'):
   content='executable snapshot; runtime/provenance consumers inspected'
   for target in cands:
    if target in text or Path(target).name in text:references[target].append(f)
   try:
    tree=ast.parse(text,filename=f)
    if any(isinstance(n,ast.If) and '__name__' in ast.unparse(n.test) for n in tree.body):python_entries.append(f)
   except SyntaxError as e:syntax.append({'path':f,'line':e.lineno,'error':e.msg})
  elif f.startswith('.github/workflows/') and f.endswith(('.yml','.yaml')):
   content='GitHub-discovered workflow interface'
   for target in cands:
    if target in text or Path(target).name in text:references[target].append(f)
   try:
    d=yaml.safe_load(text);on=d.get('on',d.get(True,{}));inputs=(on.get('workflow_dispatch') or {}).get('inputs',{}) if isinstance(on,dict) else {}
    for job,j in (d.get('jobs') or {}).items():
     for ix,s in enumerate(j.get('steps',[])):
      if 'run' in s:commands.append({'path':f,'job':job,'step':ix,'name':s.get('name'),'command':s['run'],'shell':s.get('shell',j.get('defaults',{}).get('run',{}).get('shell','runner default')),'working_directory':s.get('working-directory',j.get('defaults',{}).get('run',{}).get('working-directory','.')),'env_names':sorted(set((j.get('env') or {}))|set((s.get('env') or {}))),'workflow_inputs':inputs,'execution':'NOT_RUN','reason':'May dispatch production, install or mutate remote state; command text extracted, not executed'})
   except Exception as e:yaml_errors.append({'path':f,'error':str(e)[:200]})
  elif f.endswith(('.json','.sh','.toml','.cfg','.ini','.yaml','.yml')):
   for target in cands:
    if target in text or Path(target).name in text:references[target].append(f)
 inv.append({'record_id':'F-'+hashlib.sha256(f.encode()).hexdigest()[:16],'path':f,'sha256':hashlib.sha256(b).hexdigest(),'size':len(b),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'mode':oct(stat.S_IMODE(st.st_mode)),'symlink_target':os.readlink(f) if Path(f).is_symlink() else None,'content_assessment':content,'source_available':True,'classification':'KEEP_REQUIRED_ROOT' if f in ['README.md','START_CODES.md','bubbleverse_program_registry.json'] else 'KEEP_CORRECT_LOCATION' if f.startswith('.github/workflows/') and f.endswith(('.yml','.yaml')) or f.startswith('tools/maintenance/') else 'KEEP_PROTECTED','reason':'Existing live root interface' if f in ['README.md','START_CODES.md','bubbleverse_program_registry.json'] else 'Platform/maintenance location' if f.startswith('.github/workflows/') and f.endswith(('.yml','.yaml')) or f.startswith('tools/maintenance/') else 'Frozen evidence or unresolved historical/runtime dependency; preserve original bytes and source access'})
 print('',end='',flush=True)
out={'base':base,'inventory':inv,'candidate_workflow_refs':references,'workflow_commands':commands,'python_main_entries':python_entries,'baseline_python_syntax_errors':syntax,'baseline_yaml_errors':yaml_errors,'candidate_records':{x:p[k] for x,k in cands.items()}}
Path('../cleanup_baseline.json').write_text(json.dumps(out,indent=2));print(json.dumps({'files':len(inv),'commands':len(commands),'python_entrypoints':len(python_entries),'python_errors':len(syntax),'yaml_errors':len(yaml_errors),'candidate_refs':references},indent=2))
