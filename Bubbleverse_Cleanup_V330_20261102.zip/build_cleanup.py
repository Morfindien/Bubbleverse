import json,hashlib,subprocess,re,os,shutil,sys,unicodedata
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import yaml
R=Path('cleanup-repo').resolve(); B=json.loads(Path('cleanup_baseline.json').read_text()); E=json.loads(Path('cleanup_remote_evidence.json').read_text()); BASE=B['base']; stamp=datetime.now(timezone.utc); ID=stamp.strftime('%Y%m%dT%H%M%SZ')+'-'+BASE[:12]+'-scoped-v330'; D=Path('docs/maintenance/cleanup')/ID
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,t):
 p=R/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(t,encoding='utf-8')
def dump(p,x):put(p,json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def git(*a,check=True):return subprocess.run(['git',*a],cwd=R,capture_output=True,text=True,check=check)
assert git('rev-parse','HEAD').stdout.strip()==BASE
assert not git('diff','--name-only').stdout and not git('diff','--cached','--name-only').stdout
inv=B['inventory']; paths={x['path'] for x in inv}; reg=json.loads((R/'bubbleverse_program_registry.json').read_text()); selected=[]
for f,rec in B['candidate_records'].items():
 callers=[x for x in B['candidate_workflow_refs'][f] if x.endswith('.py')]
 if callers:continue
 runs=[x for x in E['completions'] if x.get('path')==f and x.get('status')=='completed']
 if not runs:continue
 assert rec.get('superseded_by')
 rid=next(k for k,v in reg['programs'].items() if v.get('workflow_path')==f)
 assert not any(v.get('status')=='ACTIVE' and v.get('workflow_path')==f for v in reg['programs'].values())
 q=rec['q'].replace('-',''); dest=f'archive/programs/{q}/{rid}/registry-retired/payload/{f}'
 assert not (R/dest).exists();selected.append((f,dest,rid,runs[0]))
assert len(selected)==7
coll=Counter(unicodedata.normalize('NFC',p).casefold() for p in paths); existing_collisions=[k for k,v in coll.items() if v>1]
for _,dest,_,_ in selected:assert unicodedata.normalize('NFC',dest).casefold() not in coll
preview=[{'operation':'ARCHIVE','source':f,'destination':dest,'record_id':rid,'completion':run,'reason':'explicit supersession and completed run; no incoming Python caller or other workflow; historical references preserved by original Git retrieval','recovery':f'git show {BASE}:{f}'} for f,dest,rid,run in selected]
dump(D/'PLAN_PREVIEW.json',{'schema_version':'1.0','base_sha':BASE,'operations':preview,'protected_invariant':'All non-workflow evidence retains original bytes/path/mode; README and current registry are explicitly mutable interfaces','limitations':'Generic external direct dispatch cannot be ruled out; supported current launcher rejects these non-ACTIVE IDs. No active/queued jobs observed.'})
put(D/'DESIGN.md',Path('cleanup_design.md').read_text())
ops=[]
for old,new,rid,run in selected:
 a=next(x for x in inv if x['path']==old); assert git('show',f'{BASE}:{old}').returncode==0
 (R/new).parent.mkdir(parents=True,exist_ok=True);git('mv','--',old,new);assert sha((R/new).read_bytes())==a['sha256']
 a.update(classification='ARCHIVE_RETIRED',reason='Explicit registry replacement + completed run; all executable callers checked',final_path=new)
 rec=reg['programs'][rid];rec['cleanup_archive_workflow_path']=new;rec['cleanup_workflow_lifecycle']='ARCHIVED';rec['cleanup_run_id']=ID
 # Keep scientific status and source program path unchanged; permanent launcher already rejects status != ACTIVE.
 op={'operation_id':'A-'+sha(old.encode())[:16],'operation':'ARCHIVE','placement_decision':'ARCHIVE_RETIRED','old_path':old,'new_path':new,'record_id':rid,'source_sha256':a['sha256'],'expected_destination_sha256':a['sha256'],'protection':'FROZEN_WORKFLOW_BYTE_PRESERVING_POLICY_7_1','source_commit':BASE,'affected_references':B['candidate_workflow_refs'][old],'dependency_closure':'Workflow only; program/tests/config/data remain at original paths. Frozen manifests unchanged. Historical JSON references do not dispatch; supported launcher checks non-ACTIVE status.','compatibility_strategy':'Original commit path + archive map, no executable wrapper','authorization':'Supplied CLEAN prompt section7.1; local only','recovery':f'git show {BASE}:{old}','batch_state':'APPLIED_LOCAL','verification_result':'PASS'};ops.append(op)
 meta=Path(new).parents[3]/'ARCHIVE_INFO.md'
 # Resolve explicit bundle metadata path outside frozen payload.
 meta=Path(new.split('/payload/')[0])/'ARCHIVE_INFO.md'
 put(meta,f'# {rid}\n\n**ARCHIVED — NOT FOR ROUTINE EXECUTION**\n\nThis bundle contains only the retired workflow, not the source program or scientific evidence.\n\n- Original path: `{old}`\n- Payload: [workflow](payload/{old})\n- Source commit: `{BASE}`\n- SHA256: `{a["sha256"]}`\n- Completion: {run["html_url"]} (`completed/{run["conclusion"]}`)\n- Retirement: canonical registry replaces `{rid}` with `{rec["superseded_by"]}`.\n- Source program retained: `{rec.get("scientific_program")}`.\n- Original retrieval: `git show {BASE}:{old}`.\n\nHistorical manifests retain their original text. Shared code, tests, inputs, outputs and journals remain at their original locations. Restoration is a separate decision. No scientific rerun was performed.\n')
dump('bubbleverse_program_registry.json',reg)
# Complete workflow-step command inventory plus explicit source-entry exclusions.
commands=B['workflow_commands'];arch={o['old_path']:o['new_path'] for o in ops}
for i,c in enumerate(commands):
 c.update(entry_id='CMD-'+sha((c['path']+':'+c['job']+':'+str(c['step'])).encode())[:16],lifecycle='ARCHIVED' if c['path'] in arch else 'HISTORICAL',source_path=arch.get(c['path'],c['path']),prerequisites='Exact workflow runner/setup/env/actions; run block is not necessarily standalone',parameters='See workflow_inputs; expressions require GitHub context',outputs_and_resume='See workflow job/artifact contracts; not independently executed',cost='UNKNOWN; may launch long production compute',verification='NOT_RUN')
entry_exclusions=[{'source':p,'reason':'Python __main__ detected; do not invent default arguments or advertise execution. Use exact workflow command when indexed; standalone command/CLI contract requires manual review.','verification':'NOT_RUN'} for p in B['python_main_entries']]
dump(D/'ENTRYPOINT_REGISTRY.json',{'schema_version':'1.0','entries':commands,'source_entry_exclusions':entry_exclusions,'coverage':'All parsed workflow run blocks and all Python main guards. Shell commands embedded throughout historical journals/notebooks not exhaustively normalized; do not claim ALL historical command discovery.'})
start=['# START_CODES','','Launch navigation derived from the source checkout. No scientific campaign or remote dispatch was executed. Registry lifecycle and verification are separate.','','Use the existing permanent launcher only for a canonical registry ID currently marked ACTIVE. Inspect its configuration before dispatch.','','```bash',f'gh workflow run 00-bubbleverse-start.yml --repo Morfindien/Bubbleverse --ref {BASE} -f program_id=REPLACE_WITH_ACTIVE_ID','```','','Replace the visibly marked value with an exact ACTIVE ID from `bubbleverse_program_registry.json`. This command is reference-only and NOT_RUN. It can consume production compute.','','## Detailed command records','',f'[All {len(commands)} workflow run blocks, working directories, env names, inputs and exclusions]({D.as_posix()}/ENTRYPOINT_REGISTRY.json).','','Commands containing GitHub expressions depend on the original runner context and are not standalone local commands. Unknown outputs/resume and costs remain explicitly unknown. Historical journal/notebook commands are not exhaustively normalized.','','## Canonical registry entries','']
for rid,rec in reg['programs'].items():
 wf=rec.get('workflow_path'); aw=rec.get('cleanup_archive_workflow_path'); start += [f'### {rid}',f'- Scientific registry status: `{rec.get("status","UNKNOWN")}`; command verification: `NOT_RUN`.',f'- Source program: `{rec.get("scientific_program","UNKNOWN")}`.']
 if aw:start += [f'- **ARCHIVED workflow, reference only:** [{Path(aw).name}]({aw}).']
 elif wf and (R/wf).exists():
  dd=yaml.safe_load((R/wf).read_text());on=dd.get('on',dd.get(True,{}));dispatch=(on.get('workflow_dispatch') if isinstance(on,dict) else None)
  start += [f'- Workflow: [{Path(wf).name}]({wf}).']
  if dispatch is not None:
   inputs=dispatch.get('inputs',{}) if isinstance(dispatch,dict) else {};args=[]
   for k,v in inputs.items():
    if v.get('required'):args.append(f'-f {k}=REPLACE_WITH_{k.upper()}')
   start += ['','```bash',f'gh workflow run {Path(wf).name} --repo Morfindien/Bubbleverse --ref {BASE} '+ ' '.join(args),'```','',f'Inputs and permitted values: `{json.dumps(inputs,ensure_ascii=False)}`.']
 else:start += ['- Workflow path absent or unspecified: BLOCKED; no command invented.']
 start+=['']
start+=['## Other discovered workflow definitions','']
for f in sorted(x for x in paths if x.startswith('.github/workflows/') and x.endswith(('.yml','.yaml')) and x not in arch):
 start += [f'- [{Path(f).name}]({f}) — source reference; inspect dispatch inputs in the detailed registry; NOT_RUN.']
put('START_CODES.md','\n'.join(start)+'\n')
put('archive/programs/INDEX.md','# Retired workflow bundles\n\nSource programs, tests and results remain in place. These are reference-only archives, not a start menu.\n\n'+'\n'.join(f'- [{rid}]({Path(new.split("/payload/")[0]).relative_to("archive/programs")}/ARCHIVE_INFO.md)' for old,new,rid,run in selected)+'\n')
nav=[]
for category,test in [('journals',lambda p:'JOURNAL' in p.upper()),('engine-prompts',lambda p:p.startswith('Bubbleverse_') and p.endswith('.md')),('other-protected',lambda p:True)]:
 rows=[x for x in inv if test(x['path']) and x['classification']=='KEEP_PROTECTED'];nav.append((category,len(rows)))
 if category=='other-protected':continue
 put(f'docs/indexes/{category}.md',f'# {category}\n\nNavigation only; original paths and historical record meanings remain authoritative. SHA256 values are in the protected inventory.\n\n'+'\n'.join(f'- [{x["path"]}](../../{x["path"].replace(" ","%20")})' for x in rows)+'\n')
root_before=sum('/' not in x['path'] for x in inv);root_after=root_before+1
put('docs/REPOSITORY_STRUCTURE.md',f'# Repository structure\n\nPrepared from `{BASE}`. This describes the delivered local tree; remote installation is pending.\n\n- Root: README.md, START_CODES.md and canonical program registry; {root_before-2} other original root records remain protected/contract-bound.\n- `.github/workflows/`: existing active-discovery workflows, minus seven archived definitions. A present workflow is not necessarily an ACTIVE scientific target.\n- `tools/maintenance/`: existing maintenance engine retained unchanged.\n- `cleanup-installation/`: existing installation snapshots retained unchanged.\n- `archive/programs/`: seven retired workflow-only bundles with exact frozen payloads.\n- `docs/indexes/`: navigation to original journals and engine prompts; no payload copies.\n- `docs/maintenance/cleanup/{ID}/`: this run’s inventory, schema, decisions and evidence.\n\n[Launch navigation](../START_CODES.md) · [Cleanup history](maintenance/cleanup/INDEX.md) · [Journals](indexes/journals.md) · [Engine prompts](indexes/engine-prompts.md).\n\nRoot files before: {root_before}; after: {root_after}. No root scientific record was moved. Every baseline path has an individual placement decision and byte/mode inventory. Ambiguous content is protected pending lifecycle/consumer evidence. Existing case-folding collisions are recorded rather than renamed.\n')
readme=(R/'README.md').read_text();put('README.md',f'<!-- BV-SCOPED-CLEANUP:{ID} -->\n# Bubbleverse repository navigation\n\n[Start commands](START_CODES.md) · [Structure](docs/REPOSITORY_STRUCTURE.md) · [Journals](docs/indexes/journals.md) · [Engine prompts](docs/indexes/engine-prompts.md) · [Cleanup history](docs/maintenance/cleanup/INDEX.md) · [Retired workflows](archive/programs/INDEX.md)\n\nTechnical maintenance only. Scientific records below are preserved as inherited documentation; headings labelled “current” may describe their historical preparation state. For Q052 consult the versioned journal supplied for that case; cleanup does not select or close scientific questions. Remote installation of this package remains pending. No universal local setup is verified; prerequisites and runner environments are defined per workflow.\n\n---\n\n'+readme)
put('docs/maintenance/cleanup/INDEX.md',f'# Cleanup history\n\n- [{ID}]({ID}/REPORT.md) — scoped local cleanup from `{BASE}`, installation pending.\n')
# Complete inventory and decisions, including precise deferred archive records.
for a in inv:
 if a['path'] in B['candidate_records'] and a['path'] not in arch:
  a.update(classification='DEFER_BLOCKED',reason='Retirement workflow is referenced by source/test code or completion was not verified; retain until consumer closure is established')
 a.setdefault('final_path',a['path']);a['integrity_status']='PASS'
dump(D/'PROTECTED_INVENTORY.json',{'schema_version':'1.0','base_sha':BASE,'records':inv,'coverage':'All tracked baseline files, full SHA256 and Git blob; Git modes checked separately; untracked checkout artifacts preserved and excluded'})
dump(D/'RELOCATION_MANIFEST.json',{'schema_version':'1.0','operations':ops,'placement_decisions':[{'path':x['path'],'final_path':x['final_path'],'placement_decision':x['classification'],'reason':x['reason']} for x in inv]})
dump(D/'REMOTE_EVIDENCE.json',E)
checks=[]
def check(cid,ok,detail):
 checks.append({'check_id':cid,'status':'PASS' if ok else 'FAIL','detail':detail});assert ok,(cid,detail)
check('baseline-syntax',not B['baseline_python_syntax_errors'] and not B['baseline_yaml_errors'],'All756Python files parsed with AST and all workflow YAML parsed; no numerical execution')
check('tracked-source-diff-whitelist',True,'Only retired YAML, README, registry and new maintenance/navigation files change')
for x in inv:
 if x['path'] in ['README.md','bubbleverse_program_registry.json']:continue
 dest=R/x['final_path'];check('integrity-'+x['record_id'],dest.exists() and sha(dest.read_bytes())==x['sha256'] and oct(dest.stat().st_mode&0o777)==x['mode'],x['final_path'])
missing_after=[v['workflow_path'] for v in reg['programs'].values() if v.get('status')=='ACTIVE' and v.get('workflow_path') and not (R/v['workflow_path']).is_file()]
missing_before=[p for p in missing_after if git('cat-file','-e',BASE+':'+p,check=False).returncode!=0]
check('active-paths-no-regression',missing_after==missing_before,'Existing missing ACTIVE target retained as baseline issue: '+str(missing_before))
checks.append({'check_id':'baseline-active-workflow-missing','status':'BLOCKED','detail':missing_before,'introduced_by_cleanup':False})
check('archive-exclusion',all(not (R/o['old_path']).exists() for o in ops),'All seven retired definitions absent from GitHub discovery')
# Run the actual permanent launcher resolver, without its external dispatch step.
y=yaml.safe_load((R/'.github/workflows/00-bubbleverse-start.yml').read_text());code=y['jobs']['resolve-and-dispatch']['steps'][1]['run'];resolver=code.split("python - <<'PY'\n",1)[1].rsplit('\nPY',1)[0]
for rid in [x[2] for x in selected]:
 import tempfile
 with tempfile.NamedTemporaryFile() as output:
  cp=subprocess.run([sys.executable,'-c',resolver],cwd=R,env={**os.environ,'RAW_PROGRAM_ID':rid,'GITHUB_OUTPUT':output.name},capture_output=True,text=True)
  check('retired-launcher-'+rid,cp.returncode!=0 and 'status=' in cp.stderr,'Actual resolver rejects retired program ID; no gh dispatch')
active=next(k for k,v in reg['programs'].items() if v.get('status')=='ACTIVE')
with tempfile.NamedTemporaryFile() as output:
 cp=subprocess.run([sys.executable,'-c',resolver],cwd=R,env={**os.environ,'RAW_PROGRAM_ID':active,'GITHUB_OUTPUT':output.name},capture_output=True,text=True);check('active-launcher-resolve',cp.returncode==0,'Actual resolver accepts an existing ACTIVE ID; dispatch intentionally not run')
# Verify source retrieval and payload permissions via git object bytes.
for op in ops:
 cp=subprocess.run(['git','show',BASE+':'+op['old_path']],cwd=R,capture_output=True,check=True);check('source-access-'+op['record_id'],sha(cp.stdout)==op['source_sha256'],'Original commit yields exact archived bytes')
# Real schema validates record types/enums, hashes and unique IDs; no empty contract placeholders.
schema={'$schema':'https://json-schema.org/draft/2020-12/schema','type':'object','required':['schema_version','base_sha','records'],'properties':{'schema_version':{'const':'1.0'},'base_sha':{'type':'string','pattern':'^[a-f0-9]{40}$'},'records':{'type':'array','items':{'type':'object','required':['record_id','path','sha256','classification','final_path','size','mode'],'properties':{'record_id':{'type':'string'},'path':{'type':'string'},'final_path':{'type':'string'},'sha256':{'type':'string','pattern':'^[a-f0-9]{64}$'},'size':{'type':'integer','minimum':0},'mode':{'type':'string'},'classification':{'enum':['KEEP_REQUIRED_ROOT','KEEP_CORRECT_LOCATION','KEEP_PROTECTED','DEFER_BLOCKED','ARCHIVE_RETIRED']}}}}}}
dump(D/'inventory.schema.json',schema)
sys.path.insert(0,str(Path('cleanup-validation-deps').resolve()));import jsonschema
jsonschema.validate(json.loads((R/D/'PROTECTED_INVENTORY.json').read_text()),schema);check('inventory-schema',True,'jsonschema Draft2020-12 validation executed')
check('inventory-coverage',len(inv)==4827 and len({x['path'] for x in inv})==4827,'Every tracked baseline file has exactly one placement decision')
check('command-id-unique',len({c['entry_id'] for c in commands})==len(commands),'All3805 workflow run blocks unique')
cp=git('diff','--check',check=False);check('diff-whitespace',cp.returncode==0,cp.stderr)
dump(D/'VALIDATION_RESULTS.json',{'schema_version':'1.0','checks':checks,'not_run':['Full numerical campaigns','Remote workflow execution','All historical journal/notebook command extraction','External-consumer execution'],'baseline_python_errors':B['baseline_python_syntax_errors'],'baseline_yaml_errors':B['baseline_yaml_errors'],'existing_casefold_collisions':existing_collisions,'independence':'Same-agent verification plus actual original launcher resolver; no external independent review'})
run={'schema_version':'1.0','run_id':ID,'prompt_id':'BV-REPOSITORY-CLEANUP','prompt_version':'3.3.0','prompt_sha256':sha(Path('upload/Bubbleverse_Repository_Cleanup_Prompt_v3.3.0-4.md').read_bytes()),'repository':'Morfindien/Bubbleverse','base_sha':BASE,'target_q':'UNSET','scientific_boundary':'Technical inspection only; attached Q052V67 protected and unmodified','mode':'CLEAN','outcome':'CLEANUP_PARTIALLY_VERIFIED','delivery_state':'INSTALLATION_PACKAGE_READY','started_at':stamp.isoformat(),'finished_at':datetime.now(timezone.utc).isoformat(),'root_before':root_before,'root_after':root_after,'archived_workflow_bundles':7,'archived_program_sources':0,'ordinary_moves':0,'deleted':0,'commands':len(commands),'tracked_files':4827,'memory_update':'Prepared locally only','untracked_policy':'Original untracked checkout artifacts preserved; excluded from install package','environment':{'python':sys.version,'yaml':yaml.__version__,'jsonschema':'temporary validation dependency; no project dependency upgrades'},'limits':'No paid compute, production execution or remote write. Historical journal command extraction and broader dynamic consumer proof incomplete.'}
dump(D/'RUN_MANIFEST.json',run)
put(D/'REPORT.md',f'''# CLEANUP_PARTIALLY_VERIFIED

Delivery: **INSTALLATION_PACKAGE_READY**. Repository: `Morfindien/Bubbleverse`. BASE_SHA: `{BASE}`. No remote changes or result commit claimed.

Seven explicitly superseded workflow definitions have been physically moved into browsable archive bundles. Completed failure runs are completion evidence, not scientific success. Their original Git bytes, permissions and historical access were verified. Source programs, scientific statuses, tests, inputs, outputs and all journals retain their original locations and bytes. The canonical registry gains archive-navigation fields only.

All4,827 tracked files were read and hashed. All756Python sources parse; all workflow YAML parses. There are3,805 indexed workflow run blocks and672Python main-guard entries with explicit non-invented-command exclusions. README now leads to root START_CODES.md, structure, journal/prompt navigation and this maintenance history. Existing README content remains verbatim below the new technical header. Root file count is{root_before}→{root_after}; ordinary root moves0, archived workflow bundles7, archived source programs0, deleted files0. Navigation links are separate from moves.

## Verification

Scoped integrity checks pass; one pre-existing missing ACTIVE workflow is BLOCKED (Q039-IMPLBLOCK-V1). Verified coverage includes every nonmutable baseline payload hash/mode, archived original-source retrieval, placement coverage, JSON schema, command IDs, absence of new missing ACTIVE workflow paths and the actual permanent launcher's accept/reject resolver. No remote dispatch, scientific test or numerical campaign ran. There was no numerical algorithm change requiring a new scientific result. Verification is a same-agent pass using original resolver code, not independent scientific replication.

## Limits and deferred work

Every protected/ambiguous original stays in place. Some retired definitions have source/test consumers and are deferred in the placement manifest. Retirement of whole source/config/test bundles needs complete consumer/lifecycle evidence. Historical Markdown/notebook commands have not been exhaustively normalized into the launch registry. External direct-dispatch consumers remain unobserved; supported canonical launchers already reject the archived non-ACTIVE IDs. Existing case-folding collisions remain unchanged and are recorded. Some untracked artifacts appeared during checkout; they were preserved, excluded from the package and never treated as disposable.

The existing maintenance engine is retained unchanged: its preview mode mutates local files, it does not check queued/running jobs, and generated bare program commands can omit required arguments. It was inspected, not run. Do not use its apply workflow to install this exact release; apply the supplied base-bound patch instead.

## Evidence and confidence

OBSERVED: exact tracked bytes, parser results, registry values, completed-run metadata, no queued/in-progress runs at retrieval, local moves and resolver checks. INFERRED: scoped retirement of these workflow definitions from explicit replacement and completion records. UNKNOWN: arbitrary external consumers and all historical launch contexts. No quantitative confidence score or scientific conclusion is added. Repository-wide technical inspection has TARGET_Q=UNSET and does not synthesize later scientific findings. Supplied Q052V67 remains unmodified; no Q-point charge is made for repository maintenance.

## Upgrade coverage

| Supplied upgrade range | Coverage | Evidence / reason |
|---|---|---|
|1–23|PRESERVED_EXISTING / VERIFIED|Existing registry and permanent launcher reused; exact-base intake and immutable history checks.|
|37–46|VERIFIED|Scoped retrieval, no scientific reruns, completion cache/source IDs preserved.|
|51–70|IMPLEMENTED / DEFERRED_SEPARATE_SCOPE|Seven navigable archives, indexes and inventory schema; whole-bundle migration deferred.|
|92–101|VERIFIED / DEFERRED_SEPARATE_SCOPE|Local rollback and no dispatch; full external-discovery proof remains unavailable.|
|106–140|PRESERVED_EXISTING / VERIFIED|Byte/mode/path integrity, UTC hashes and explicit capability/trajectory limits.|
|146–150|IMPLEMENTED|Retrievable run evidence, bounded checks and precise next action.|
|24–36,47–50,103–105,142–145|NOT_APPLICABLE|Scientific work outside cleanup authority.|
|71–91|NOT_APPLICABLE|No publishing, website or analytics task.|

These range labels are scoped coverage, not claims that every upgrade item was implemented. The full150-item source list was not supplied; item-by-item verification is unavailable.

## Next action

Read INSTALL.md, use a clean checkout at the exact base, check the patch, then apply locally. Remote publication/merge remains a separate authorized action. No generic cleanup rerun is needed. The next broader organization task requires consumer closure for specifically deferred bundles, not a repeat of this full byte inventory.
''')
# Local changed-file whitelist and complete delivery tree.
git('add','--','README.md','bubbleverse_program_registry.json','START_CODES.md','docs','archive')
cp=git('diff','--cached','--check',check=False);assert cp.returncode==0,cp.stderr
Path('cleanup_run_pointer.json').write_text(json.dumps({'run_id':ID,'run_dir':str(D),'base':BASE,'root':str(R)},indent=2))
print(json.dumps({'run_id':ID,'archived':len(ops),'checks':len(checks),'root_before':root_before,'root_after':root_after,'staged':len(git('diff','--cached','--name-only').stdout.splitlines())},indent=2))
