# Intervalbevis og næste beregning

På den gemte kandidat gav den grove evaluering sin(θ) i cirka [0,94074201; 1,05676874]. Skæring med [−1; 1] alene gav fortsat fejl i X-komponentens Picard-inklusion. Den grove nedre grænse beviser dog sin(θ)>0 på hele argumentintervallet. Da sin″=−sin, er sinus konkav der. Minimum opnås derfor ved et endepunkt, som kan evalueres med udadrettet rationel afrunding. Sammen med det universelle maksimum 1 giver det cirka [0,99418327; 1].

Ved genkontrollen bestod den gemte kandidat den separate Picard-, guard-, Jacobi- og sammenligningskontrol med denne grænse. For at acceptere cellen skal Matematikmotoren beregne den igen fra det eksakte checkpoint og køre samtlige valideringskrav, herunder frisk defektberegning. Den separate evaluator skal også håndtere senere intervaller, hvor monotoni eller fortegn er uafklaret. Den maskinlæsbare opgave angiver gyldige tilbagefald.

Brug det afprøvede lokale Python-miljø med mpmath og rationel intervalregning. Kontrollér trigonometriske intervaller ved endepunkter og vendepunkter før fremføring. Hold højst én ny prototype inden for den angivne tidsgrænse og brug det frosne energikriterium og den optiske test, hvis det eksakte anker nås.
