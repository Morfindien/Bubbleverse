from pathlib import Path
from hashlib import sha256, sha1
from fractions import Fraction
from datetime import datetime, timezone
import json
from zipfile import ZipFile, ZIP_DEFLATED

work = Path(__file__).resolve().parent
root = work.parents[1]
source = root / 'upload'
data = work / 'input'
out = root / 'output/V104'
out.mkdir(parents=True, exist_ok=True)
def read(path):
    return json.loads(path.read_bytes())
def digest(value):
    return sha256(value).hexdigest()
def blob(value):
    return sha1(f'blob {len(value)}\0'.encode() + value).hexdigest()
def dump(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
def fingerprint(value):
    return digest(json.dumps({k:v for k,v in value.items() if k != 'fingerprint_sha256'}, ensure_ascii=False, sort_keys=True, separators=(',',':')).encode())

short = 'Q052_KORT_RESULTAT_V104.md'
journal = 'Q052_INGESTION_OG_SAMLET_JOURNAL_V104.md'
taskfile = 'Q052_MATEMATIKOPGAVE_V104.json'
cert = 'Q052_INGESTION_CERTIFICATE_V104.zip'
names = [short, journal, taskfile, cert]
previous_journal = 'Q052_MATEMATIK_OG_SAMLET_JOURNAL_V103.md'
incoming = 'Q052_RESULTATINDTAG_OPGAVE_V103.json'
parent_cert = 'Q052_SKALAR_FORTSAETTELSESCERTIFIKAT_V103.zip'
repo = 'https://github.com/Morfindien/Bubbleverse'
head = 'f14501efb7af52dabde7183b1ea915d0a3590841'
tree = read(work/'repository_tree.json')
assert not tree['truncated'] and tree['sha'] == 'c1def992ca8714f7ae8d41f170ca83fbcdecdd02'
paths = {entry['path']:entry['sha'] for entry in tree['tree']}
assert not set(names).intersection(paths)
canonical = {}
for name in [previous_journal, incoming, parent_cert, 'Q052_KORT_RESULTAT_V103.md']:
    b = (source/name).read_bytes()
    assert blob(b) == paths[name], name
    canonical[name] = {'sha256':digest(b),'git_blob':paths[name],'bytes':len(b),'url':f'{repo}/blob/{head}/{name}'}
math = (source/'Bubbleverse_Matematikmotor_2.3.0-42.md').read_bytes()
intake = (source/'Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0-109.md').read_bytes()
for path, body in [('Bubbleverse_Matematikmotor_2.3.0.md',math),('Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0.md',intake)]:
    assert paths[path] == blob(body)

with ZipFile(source/parent_cert) as z:
    assert z.testzip() is None and len(set(z.namelist())) == len(z.namelist())
    manifest = json.loads(z.read('manifest.json'))
    assert set(z.namelist()) == {'manifest.json'} | {x['path'] for x in manifest['archive_members']}
    for entry in manifest['archive_members']:
        b = z.read(entry['path'])
        assert len(b) == entry['bytes'] and digest(b) == entry['sha256']
    for entry in manifest['external_deliverables']:
        b = (source/entry['filename']).read_bytes()
        assert len(b) == entry['bytes'] and digest(b) == entry['sha256']
    def archived(name):
        return json.loads(z.read(name))
    r,t,prior,raw,parent,oldv,old_d = map(archived, ['result103.json','task102.json','activity_ledger.json','result_raw103.json','result101.json','verification103.json','criticalpoint_diagnostic103.json'])
    frozen_source = z.read('source_register.json')
    tr = archived('trig_diagnostic103.json')
    capture_hash = digest(z.read('capture.json'))
    r_hash = digest(z.read('result103.json'))
    old_task_hash = digest(z.read('task102.json'))
    prior_ledger_hash = digest(z.read('activity_ledger.json'))
    assert digest(z.read('result101.json')) == t['input_result_sha256']
    assert digest(z.read('result_raw103.json')) == manifest['raw_result_sha256']

received = read(source/incoming)
replay = read(data/'verification103.json')
diagnosis = read(data/'criticalpoint_diagnostic103.json')
for observed, original in [(replay,oldv),(diagnosis,old_d)]:
    assert {k:v for k,v in observed.items() if k not in ['wall_seconds','platform','python','mpmath']} == {k:v for k,v in original.items() if k not in ['wall_seconds','platform','python','mpmath']}
assert replay['status']=='PASS_CONDITIONAL' and replay['total_checks']==3261 and not replay['failures']
assert diagnosis['new_accepted_cells']==0 and diagnosis['status']=='PASS_STORED_CANDIDATE_INDEPENDENT_CHECK_ONLY'
assert tr['range_clipped_picard_pass']==[True,False]
assert fingerprint(received)==received['fingerprint_sha256']
assert fingerprint(t)==t['fingerprint_sha256']==r['task_fingerprint']==raw['task_fingerprint']
assert digest(intake)==received['engine_prompt_sha256'] and digest(math)==t['engine_prompt_sha256']
assert r_hash==received['input_result_sha256']==manifest['result_snapshot_sha256']
assert received['case_id']==t['case_id'] and received['current_q']==received['target_q']=='Q052'
assert received['exact_question']==r['exact_question']==t['exact_question']==parent['exact_question']
assert received['source_commit']==r['source_commit']==t['source_commit']==raw['source_commit']==parent['source_commit']
assert capture_hash==received['capture_sha256']==r['capture_sha256']==t['capture_sha256']==raw['capture_sha256']==parent['capture_sha256']
assert r['checkpoint']==received['input_checkpoint'] and r['input_checkpoint']==t['input_checkpoint']==parent['checkpoint']
assert r['inherited_unchanged']==parent['inherited_unchanged']
assert r['accepted_new_cells']==len(raw['cells'])==179 and parent['accepted_cells']==1071
assert raw['cells'][0]['a0']==parent['checkpoint']['certified_end_a']
assert raw['cells'][0]['initial']==parent['checkpoint']['endpoint']
assert raw['cells'][-1]['endpoint']==r['checkpoint']['endpoint']
assert not raw['target_reached'] and not r['candidate_promoted']
assert all(raw[k]==0 for k in ['new_native_pairs','new_full_history_integrations','new_weight_evaluations'])
parent_j = (source/previous_journal).read_bytes()
previous_prefix = manifest['parent_journal']
assert digest(parent_j[:previous_prefix['bytes']]) == previous_prefix['sha256']
assert parent_j.startswith((source/'Q052_INGESTION_OG_SAMLET_JOURNAL_V102.md').read_bytes())

run = 'LOCAL-Q052-V103-PREFIX-INGESTION-V104'
event = 'Q052-ACTIVITY-V103-PREFIX-INGESTION-V104'
stamp = datetime.now(timezone.utc).isoformat()
basis = 'Afrundet skøn for ny indtagskontrol, gennemgang af intervalbevis og afgrænsning af næste forsøg. Tidligere fremføring, gamle kontroller som historisk arbejde og pakning tæller ikke igen.'
breakdown = {'input_and_chain_ingestion':20,'trigonometric_proof_review_and_task_design':30,'repository_and_engine_verification':10}
assert sum(x['run_points'] for x in prior['entries'])==prior['total_points_after']==13300
assert not prior['pending_packages'] and len(prior['delivered_milestone_ids'])==13
event_ids = [e.get('activity_event_id',e['run_id']) for e in prior['entries']]
assert len(set(event_ids))==len(event_ids) and event not in event_ids
ledger = {**prior,'entries':prior['entries']+[{'activity_event_id':event,'run_id':run,'engine':received['engine'],'run_points':60,'breakdown':breakdown,'basis':basis,'counted_once':True}],
    'previous_ledger_ref':f'{parent_cert}#activity_ledger.json','previous_total_points':13300,'total_points_after':13360,'cycle_progress':360,'points_to_next_publication':640,'ledger_revision':'V104',
    'parent_ledger_sha256':prior_ledger_hash,'last_updated_utc':stamp,'new_milestones':[],'note':basis,
    'reconciliation':{'prior_total':13300,'new_unique_event_points':60,'current_total':13360}}
assert sum(x['run_points'] for x in ledger['entries'])==13360
engine_ref = {'path':'Bubbleverse_Matematikmotor_2.3.0.md','git_blob':blob(math),'sha256':digest(math)}
candidate = read(data/'last_diagnostic103.json')
checkpoint = r['checkpoint']
task = {
    **{k:t[k] for k in ['schema_version','engine','case_id','current_q','target_q','exact_question','source_commit','capture_sha256','frozen','return_engine','continue_same_q']},
    'task_id':'LOCAL-Q052-V104-TRIG-VALIDATED-SCALAR-CONTINUATION','engine_prompt_sha256':digest(math),'state':'PREPARED_NOT_EXECUTED',
    'input_certificate':parent_cert,'input_certificate_sha256':canonical[parent_cert]['sha256'],'input_result_sha256':r_hash,'input_checkpoint':checkpoint,
    'input_last_relative_step':received['input_last_relative_step'],'ingestion_certificate':cert,
    'objective':'Continue the fixed source-real scalar IVP from the last accepted V103 checkpoint toward exact z=800. Resolve the demonstrated trigonometric enclosure issue in the independent checker.',
    'execution_limits':t['execution_limits'],
    'coverage':{'a_start':checkpoint['certified_end_a'],'a_target':'1/801','z_target':'800','exact_connection_required':True},
    'method':{**{k:t['method'][k] for k in ['coordinates','center','tube_and_defect','comparison']},
      'independent_trigonometric_enclosure':'Use directed rational interval evaluation. For each whole argument interval, retain a valid coarse enclosure and intersect with the universal range. When a certified sign of the derivative establishes monotonicity, enclose the range from outward endpoint evaluations. For f=sin or cos, f″=-f: when f>0 is certified throughout, use the minimum of endpoint lower bounds and upper bound 1; when f<0 is certified throughout, use lower bound -1 and the maximum of endpoint upper bounds. Intersect all justified enclosures. For remaining intervals keep the valid coarse bound, subdivide with a covering union, or use certified range reduction and critical-point inclusion. Uncertain signs never establish monotonicity. Respect the evaluator argument domain and use the same sound cosine enclosure for independent endpoint energy, including when monotonicity cannot be certified.',
      'first_cell':'From the exact V103 checkpoint regenerate the stored failed proposal at its exact a1 if within the existing limits. Run every acceptance gate including fresh defect computation, independent checks and exact connection. A diagnostic pass on stored data does not grant acceptance. If inclusion remains unresolved, stop and record the precise witness. Ordinary producer rejections may halve under the existing retry cap.',
      'controller':'After the first fresh accepted cell, retain the existing reuse/growth/halving controller and interior 2^-120 grid. Cap relative step at 1/16. Clip at exact target. No second V102 doubling gate. Retain componentwise per-unit-t defect ceilings of 1e-8.'},
    'diagnostic_candidate':{'a0':candidate['a0'],'a1':candidate['a1'],'status':'NOT_ACCEPTED_IN_V103','reference':f'{parent_cert}#last_unaccepted_candidate103.json'},
    'decision_gates':{k:v for k,v in t['decision_gates'].items() if not k.startswith('waypoint')},
    'verification':'On each accepted new cell check exact chain, reference-in-box, Picard, positive H², source guard, signed Jacobian domination, comparison tail and end enclosure. Recompute the defect/comparison at higher precision as in V103, documenting shared code. Use independent rational evaluation of field, Picard, guard, Jacobian, comparison and endpoint energy. Check the new trig branch against the stored witness and endpoint/turning-point/uncertain-sign cases before relying on it.',
    'stop_condition':'Use one bounded prototype with a monotonic clock and at most 300 seconds for new propagation and checks. Stop on exact target, first unresolved validation premise, empty intersection, retry or runtime limit. Preserve the last verified checkpoint. Run at most one frozen weight screen, only after the validated exact target is reached.',
    'no_repeat':received['no_repeat'],'total_points':13360,'next_milestone':14000,'points_to_next_publication':640}
task['fingerprint_sha256']=fingerprint(task)
ref = lambda n: f'{cert}#{n}'
source_ref = ref('source_register.json')
audit = {'run_id':run,'timestamp':stamp,'repository_head':head,'repository_tree_sha':tree['sha'],'v103_files':canonical,
         'verified_math_engine':engine_ref,'received_task_fingerprint':received['fingerprint_sha256'],'v102_task_sha256':old_task_hash,
         'conditional_cells':179,'retained_checkpoint':checkpoint,'stored_record_checks':replay['total_checks'],'failures':replay['failures'],
         'inherited_unchanged':r['inherited_unchanged'],'runtime':r['runtime_interpretation'],'stored_diagnostic':diagnosis,
         'scope':'Archive and record audit, independent endpoint energy, and a repeat of the stored-candidate diagnostic. Zero new scalar cells, native pairs, full histories or weight screens.'}
memory = {'repository_url':repo,'repository_segment_id':None,'base_commit_sha':head,'source_freshness':'V103_BLOBS_VERIFIED_AT_OBSERVED_HEAD','journal_path':journal,
          'current_state_path':None,'index_refs':[],'cross_reference_refs':[previous_journal,parent_cert],
          'memory_update_ref':ref('github_memory_update.json'),'target_paths_status':'FOUR_NEW_ROOT_FILES','sync_status':'USER_UPLOAD_PENDING','commit_sha':None,'pull_request_url':None,'upload_instructions_ref':ref('README.md'),
          'proposed_files':names}
claims = [{'claim':'179 V103 cells usable under inherited source and B-star premises.','evidence':[f'{parent_cert}#result103.json',ref('audit104.json')]},
          {'claim':'Concavity based sine enclosure resolves the recorded independent-check failure for the stored candidate. Acceptance still requires all new-cell gates.','evidence':[ref('stored_candidate_review.json'),ref('METHOD.md')]},
          {'claim':'Q052 remains inconclusive with z800 anchor, weight decision and native certificate outstanding.','evidence':[f'{parent_cert}#result103.json']}]
completed = {'prior_ref':f'{parent_cert}#handoff103.json','completed':[{'task_id':received['task_id'],'fingerprint':received['fingerprint_sha256'],'result_id':r['result_id'],'disposition':'ACCEPTED_CONDITIONAL_PREFIX'}],'no_repeat':task['no_repeat']}
route = {'previous':received['engine'],'selected':task['engine'],'task':taskfile,'task_fingerprint':task['fingerprint_sha256']}
anomaly = {'id':'Q052-V103-INDEPENDENT-TRIGONOMETRIC-RANGE-LOSS','state':'REPRODUCED_AND_LOCAL_REMEDY_VERIFIED','candidate_accepted':False,'next_action':taskfile}
handoff = {
    'schema_id':'bubbleverse.result_ingestion_handoff','schema_version':'3.0.0','prompt_id':'bubbleverse.result_ingestion_routing','prompt_version':'2.3.0',
    'handoff_id':run,'created_at_utc':stamp,'case_id':t['case_id'],'current_q':'Q052','exact_question':t['exact_question'],'target_q':'Q052',
    'evidence_cutoff':{'source_commit':r['source_commit'],'input_version':'V103','scope':'Q052 and required predecessors'},
    'case_lifecycle':'ACTIVE','disposition':'CONTINUE','epistemic_status':'INCONCLUSIVE','ingestion_state':'ACCEPTED_CONDITIONAL_PARTIAL_PREFIX',
    'new_result_ids':[r['result_id']],'source_state_version':'V103','target_state_version':'V104','selected_next_engine_id':task['engine'],'engine_registry_ref':engine_ref,
    'execution_profile_ref':ref('METHOD.md'),'journal_ref':journal,'source_register_ref':source_ref,'claim_evidence_map_ref':ref('claim_map.json'),
    'result_provenance_ref':ref('audit104.json'),'anomaly_tension_registry_ref':ref('anomaly.json'),'completed_task_ledger_ref':ref('completed_tasks.json'),
    'route_history_ref':ref('route.json'),'integrity_manifest_ref':ref('manifest.json'),'closure_snapshot_ref':None,
    'what_changed':['Conditional V103 prefix admitted for checkpoint reuse','Concavity diagnosis replayed and next bounded task prepared'],
    'frozen_configuration_refs':[f'{parent_cert}#v73.json',f'{parent_cert}#capture.json',f'{parent_cert}#result99.json'],
    'open_material_uncertainties':['Validated z800 energy anchor','Optical weight screen decision','Native reproducibility, trajectory consistency and numerical-error certificate'],
    'missing_information':['No anchor or native certificate in admitted evidence'],
    'next_task':taskfile,'next_task_fingerprint':task['fingerprint_sha256'],'success_condition':task['decision_gates'],'failure_or_falsification_condition':'A failed validated-enclosure gate limits this numerical continuation.',
    'stop_condition':task['stop_condition'],'completion_gate_satisfied':False,'completion_gate_reason':'Scalar prefix ends before z=800 and native numerical-error certificate is outstanding.',
    'handoff_completeness':'READY_MANUAL_CONTRACT_CHECK','writeback_status':'GITHUB_USER_UPLOAD_PENDING','delivery_status':'FILES_WITH_HANDOFF','operator_gate':'NONE_FOR_LOCAL_PREPARATION',
    'output_file_refs':names,'output_manifest_ref':ref('manifest.json'),'repository_memory':memory,
    'question_activity_points':{'policy_id':'bubbleverse.question_activity_some_milestones','policy_version':'2.0.0','ledger_id':'Q052','ledger_ref':ref('activity_ledger.json'),'ledger_version':'V104','parent_ledger_version':'V103','run_id':run,'activity_event_id':event,'parent_total_pts':13300,'assessed_run_points':60,'assessment_breakdown':breakdown,'assessment_basis':basis,'assessment_confidence':'Rounded heuristic','inherited_event_ids':event_ids,'newly_applied_event_ids':[event],'total_pts':13360,'status':'RECONCILED'},
    'some_milestones':{'interval_pts':1000,'highest_threshold_reached_pts':13000,'crossed_this_run':[],'ready_package_ids':[],'pending_milestones':[],'next_threshold_pts':14000,'points_to_next_threshold':640,'milestone_ledger_ref':ref('activity_ledger.json'),'package_file_refs':[],'package_creation_status':'NOT_DUE','external_publication_status':'NOT_REQUESTED','scientific_route_changed_by_points':False}}
z_end = format(float(Fraction(checkpoint['certified_end_z'])), ',.3f').translate(str.maketrans(',.', '.,'))
method = """# Intervalbevis og næste beregning

På den gemte kandidat gav den grove evaluering sin(θ) i cirka [0,94074201; 1,05676874]. Skæring med [−1; 1] alene gav fortsat fejl i X-komponentens Picard-inklusion. Den grove nedre grænse beviser dog sin(θ)>0 på hele argumentintervallet. Da sin″=−sin, er sinus konkav der. Minimum opnås derfor ved et endepunkt, som kan evalueres med udadrettet rationel afrunding. Sammen med det universelle maksimum 1 giver det cirka [0,99418327; 1].

Ved genkontrollen bestod den gemte kandidat den separate Picard-, guard-, Jacobi- og sammenligningskontrol med denne grænse. For at acceptere cellen skal Matematikmotoren beregne den igen fra det eksakte checkpoint og køre samtlige valideringskrav, herunder frisk defektberegning. Den separate evaluator skal også håndtere senere intervaller, hvor monotoni eller fortegn er uafklaret. Den maskinlæsbare opgave angiver gyldige tilbagefald.

Brug det afprøvede lokale Python-miljø med mpmath og rationel intervalregning. Kontrollér trigonometriske intervaller ved endepunkter og vendepunkter før fremføring. Hold højst én ny prototype inden for den angivne tidsgrænse og brug det frosne energikriterium og den optiske test, hvis det eksakte anker nås.
"""
summary = f"""# Q052 V104 · Resultatindtag

**Q052 fortsætter med Matematikmotor 2.3.0.** De 179 V103-celler er optaget som en betinget udvidelse af det tidligere certifikat. Der er i alt 1.250 celler frem til z ≈ {z_end}. Alle 3.261 kontroller af de gemte V103-data bestod igen.

Sinusgrænsen baseret på konkavitet bestod den separate kontrol af den gemte fejlcelle. Den nye opgave starter fra det eksakte, godkendte V103-endepunkt og kræver fuld validering af første nye celle. Det validerede energianker ved z=800 og det endelige CLASS/P6-fejlcertifikat udestår.

Aktivitetstotalen er **13.360 point**. Der er **640 point til næste SoMe-milepæl**.

De fire V103-filer og de anvendte motorversioner matcher den observerede GitHub-base. De fire V104-filer er klar til upload.
"""
append = f"""# Q052 · V104 · Resultatindtag

Tidspunkt {stamp}. Kørsel `{run}`. Status ACTIVE / CONTINUE / INCONCLUSIVE.

> {t['exact_question']}

## Beslutning

Optag V103's 179 celler som betinget skalarpræfiks med den arvede B★-baggrund, eksakt-reelle kildeparametre og initialisering. Forbindelsen fra V101's 1.071 celler er eksakt. Det godkendte checkpoint er a = `{checkpoint['certified_end_a']}` og z ≈ {z_end}. Den eksakte tilstand og energi er bevaret i opgaven. Ankeret ved z=800, den efterfølgende optiske beslutning og et dokumenteret native fejlcertifikat udestår.

Manifest, kildehash, opgavefingerprints og frosne, arvede resultater er kontrolleret. Ved indtaget bestod 3.261 gemte-data- og energikontroller. Den løbende rationelle feltkontrol er arvet fra V103, mens den højere præcisions defektkontrol deler implementering. Ingen ny uafhængig Taylor-implementering er udført. Kildeinitialiseringen er en arvet betingelse.

V103's to rettelser før første accepterede celle var udadrettet afrunding af defekt, norm og hale for at undgå serialiseringsfejlen samt udadrettet afrunding af Jacobisammenligningsmatricen på 2⁻¹⁴⁴-gitteret. Tidsgrænsen blev fortolket som akkumuleret aktiv forløbstid med en natlig suspension. Prototypen registrerede {r['active_prototype_wall_seconds']:.4f} aktive sekunder. Diagnosen er et efterfølgende tjek af den gemte fejlcelle og giver nul ekstra accepterede trin. V104 er indtag uden fremføring.

{method}

## Intern aktivitetsregistrering

| Felt | Værdi |
|---|---|
| Rundens aktivitet | 60 point |
| Samlet aktivitet | 13.360 point |
| Interval | 1.000 point |
| Nye milepæle | Ingen |
| Næste milepæl | 14.000 point |
| Afstand | 640 point |
| Pakke | NOT_DUE |
| Næste motor | BUBBLEVERSE.MATHEMATICS 2.3.0 |

{basis} Fordeling 20 indtag, 30 bevisgennemgang og opgavedesign, 10 repository- og motoridentitet. M001–M013 står som leveret.

## Projektstatus og overlevering

Hele V103-journalen er bevaret byte for byte som præfiks. GitHub-base `{head}` og de fire V103-blobidentiteter er verificeret. Filpakken er klargjort til brugerupload. Overleveringen bruger fallbackskema 3.0.0 med manuel kontraktkontrol. Den ene næste opgave findes i `{taskfile}`.
"""
readme = f"""# Q052 V104 · Certifikat for resultatindtag

Upload `{short}`, `{journal}`, `{taskfile}` og `{cert}` som nye filer i roden af {repo}. Kontrollér først, om der er kommet en nyere Q052-version siden `{head}`. Historiske versioner bevares. Opdatér kun en eksisterende Q052-henvisning, når den er identificeret, og alle fire filer kan åbnes. Den observerede base og filernes hashes står i manifestet.

Det uændrede V103-arkiv med de oprindelige rådata er bundet til SHA-256 `{canonical[parent_cert]['sha256']}`. [Åbn V103-arkivet ved den verificerede GitHub-base]({canonical[parent_cert]['url']}).

Læs `METHOD.md` og opgaven for intervalbevis, første celles valideringskrav og stopbetingelser. Audit og lagret kandidatkontrol angiver omfanget af V104-indtaget.
"""
(out/short).write_text(summary)
(out/taskfile).write_bytes(dump(task))
(out/journal).write_bytes(parent_j+b'\n\n---\n\n'+append.encode()+b'\n## Maskinlaesbar overlevering V104\n\n```json\n'+dump(handoff)+b'```\n\n## Kumulativt aktivitetsledger V104\n\n```json\n'+dump(ledger)+b'```\n')
payload = {'README.md':readme.encode(),'METHOD.md':method.encode(),'handoff104.json':dump(handoff),'activity_ledger.json':dump(ledger),'audit104.json':dump(audit),
           'source_register.json':frozen_source,'github_memory_update.json':dump(memory),'claim_map.json':dump(claims),'anomaly.json':dump(anomaly),'route.json':dump(route),
           'completed_tasks.json':dump(completed),'verification_replay.json':dump(replay),'stored_candidate_review.json':dump(diagnosis),
           'repository_tree.json':(work/'repository_tree.json').read_bytes(),'build104.py':Path(__file__).read_bytes(),taskfile:(out/taskfile).read_bytes()}
roles = ['short_result','complete_cumulative_journal','next_mathematics_task']
new_manifest = {'schema':'Q052_V104_OUTPUT_MANIFEST','case_id':t['case_id'],'q':'Q052','version':'V104','run_id':run,'base_commit':head,'repository':repo,'parent_artifacts':canonical,
                'archive_members':[{'path':n,'bytes':len(b),'sha256':digest(b)} for n,b in sorted(payload.items())],
                'external_deliverables':[{'filename':n,'target_path':n,'role':role,'operation':'ADD','bytes':(out/n).stat().st_size,'sha256':digest((out/n).read_bytes())} for n,role in zip(names,roles)],
                'container':{'filename':cert,'target_path':cert,'role':'ingestion_audit_and_handoff','operation':'ADD','self_hash_omitted':True},'validation':'MANUAL_CONTRACT_CHECK'}
payload['manifest.json']=dump(new_manifest)
with ZipFile(out/cert,'w',compression=ZIP_DEFLATED) as z:
    for name,b in payload.items():
        z.writestr(name,b)
with ZipFile(out/cert) as z:
    assert z.testzip() is None and set(z.namelist())==set(payload)
    for name,b in payload.items():
        assert z.read(name)==b
        if name.endswith('.json'):
            json.loads(b)
for row in new_manifest['external_deliverables']:
    assert digest((out/row['filename']).read_bytes())==row['sha256']
assert (out/journal).read_bytes().startswith(parent_j)
for val in handoff.values():
    if isinstance(val,str) and val.startswith(cert+'#'):
        assert val.split('#',1)[1] in payload
assert fingerprint(read(out/taskfile))==handoff['next_task_fingerprint']
assert task['engine']==handoff['selected_next_engine_id']
(work/'upload_request.json').write_bytes(dump({'uploads':[{'local_path':str(out/n),'purpose':'create_library_file','library_artifact_type':'report' if n.endswith('.md') else 'other'} for n in names]}))
print('PASS',[(n,(out/n).stat().st_size) for n in names])
