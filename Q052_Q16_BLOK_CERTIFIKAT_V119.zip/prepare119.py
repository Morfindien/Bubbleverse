"""Verify supplied immutable archives and extract the exact frozen inputs. No field evaluation."""
from pathlib import Path
from hashlib import sha256,sha1
from zipfile import ZipFile
from io import BytesIO
from datetime import datetime,timezone
import json
P=Path(__file__).resolve().parent; U=P.parents[1]/'upload'
sha=lambda b:sha256(b).hexdigest()
def write(n,b):
 p=P/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def j(z,n):return json.loads(z.read(n))
t=json.loads((U/'Q052_MATEMATIKOPGAVE_V118.json').read_bytes())
tt=dict(t);fp=tt.pop('fingerprint_sha256')
assert sha(json.dumps(tt,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==fp
assert t['task_id']=='LOCAL-Q052-V119-CONSTANT-Q16-CELLS236-245'
assert t['current_q']==t['target_q']=='Q052'
tree=json.loads((P/'repository_tree119.json').read_bytes())
assert not tree['truncated']; byname={r['path']:r for r in tree['tree']}
names=['Q052_INGESTION_CERTIFICATE_V118.zip','Q052_INGESTION_OG_SAMLET_JOURNAL_V118.md','Q052_KORT_RESULTAT_V118.md','Q052_MATEMATIKOPGAVE_V118.json']
repo=[]
for name in names+['Bubbleverse_Matematikmotor_2.3.0.md']:
 local=name if name in names else 'Bubbleverse_Matematikmotor_2.3.0-50.md'
 raw=(U/local).read_bytes(); blob=sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 assert blob==byname[name]['sha'] and len(raw)==byname[name]['size'],name
 repo.append({'path':name,'sha256':sha(raw),'git_blob_sha1':blob,'size_bytes':len(raw)})
assert sha((U/'Bubbleverse_Matematikmotor_2.3.0-50.md').read_bytes())==t['engine_prompt_sha256']
write('prompts/Bubbleverse_Matematikmotor_2.3.0.md',(U/'Bubbleverse_Matematikmotor_2.3.0-50.md').read_bytes())
checks={}
with ZipFile(U/names[0]) as z:
 assert z.testzip() is None
 mf=j(z,'manifest118.json')
 for r in mf['archive_members']:
  raw=z.read(r['path']);assert len(raw)==r['bytes'] and sha(raw)==r['sha256'],r['path']
 for n in names[1:]:assert z.read(n)==(U/n).read_bytes(),n
 for n in ['manifest118.json','audit118.json','activity_ledger118.json','handoff118.json','source_register118.json','journal_append118.md','Q052_MATEMATIKOPGAVE_V118.json']:
  write('input/'+n,z.read(n))
 for archive,h in t['archive_refs'].items():
  raw=z.read(t['archive_locations'][archive]);assert sha(raw)==h
  with ZipFile(BytesIO(raw)) as a:
   assert a.testzip() is None
   if 'V117' in archive:
    manifest=j(a,'manifest117.json')
    for r in manifest['members']:assert sha(a.read(r['path']))==r['sha256'] and len(a.read(r['path']))==r['size_bytes']
    for n,v in t['V117_member_sha256'].items():assert sha(a.read(n))==v,n
    for n in t['V117_member_sha256']:
     write(n if n.startswith(('calc/','runtime/')) or n=='preflight114.py' else 'input/v117/'+n,a.read(n))
    for n in ['manifest117.json','execution117.json','input_check117.json','symbolic_check117.json','PROOF_V117.md','runtime_check117.json']:
     write('input/v117/'+n,a.read(n))
    parent=z.read(names[1]);off=mf['parent_prefix_bytes']
    assert parent[:off]==a.read('Q052_MATEMATIK_OG_SAMLET_JOURNAL_V117.md')
    assert sha(parent[:off])==mf['parent_journal_sha256'] and parent[off:]==z.read('journal_append118.md')
   else:
    assert sha(a.read('manifest.json'))==t['V89_manifest_sha256']
    for n,h in j(a,'manifest.json')['members_sha256'].items():assert sha(a.read(n))==h,n
    for n,h in t['V89_member_sha256'].items():assert sha(a.read(n))==h,n
    for n in ['v19.json','v20.py','v62.json','v77.json']:
     assert (P/'calc'/n).read_bytes()==a.read(n),n
    write('calc/certify87.py',a.read('certify87.py'))
    for n in ['result.json','control.json','manifest.json','PROOF_V87.md','PROOF_V85.md','PROOF_V89.md','verification.json','run89.py','check89.py','task88.json','sources.json','pins.json']:
     write('input/v89/'+n,a.read(n))
  checks[archive]={'sha256':sha(raw),'manifest_all_members':'PASS','zip_integrity':'PASS'}
ledger=json.loads((P/'input/activity_ledger118.json').read_bytes())
assert sum(r['run_points'] for r in ledger['entries'])==ledger['total_points_after']==t['total_points']==14415
assert not any(r.get('run_id')==t['task_id'] for r in ledger['entries'])
assert 'Q052-SOME-M014' in ledger['delivered_milestone_ids'] and not ledger['pending_packages']
write('input_check119.json',(json.dumps({'status':'PASS','task_fingerprint':fp,'task_sha256':sha((P/'input/Q052_MATEMATIKOPGAVE_V118.json').read_bytes()),'archive_checks':checks,'V118_manifest_all_members':'PASS','journal_prefix_check':'PASS','total_points':14415,'scientific_evaluations':0,'repository':{'repository':'Morfindien/Bubbleverse','verified_commit':'4d7c610cc2c0ba0a9a7f1ce40447dbf28ec0791c','files':repo,'write_state':'USER_UPLOAD_PENDING'},'verified_utc':datetime.now(timezone.utc).isoformat()},indent=2)+'\n').encode())
print('PASS: immutable inputs, repository blobs, archive members, journal prefix and ledger verified')
