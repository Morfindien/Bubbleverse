"""Stored-receipt audit only: hashes, exact coverage, inclusion and rational margins."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json
P=Path(__file__).resolve().parent
load=lambda n:json.loads((P/n).read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
hx=lambda s:F(float.fromhex(s))
t=load('input/Q052_MATEMATIKOPGAVE_V118.json');run=load('execution119.json');seed=load('input/v117/result117.json')
assert run['run_id']==t['task_id'] and run['technical_state']=='PASS' and run['scientific_execution_state']=='ALL_TEN_PASS'
assert run['code_unchanged'] and run['code_sha256_before']==run['code_sha256_after']
for n,h in run['code_sha256_before'].items():assert sha(P/n)==h,n
for n,h in run['output_sha256'].items():assert sha(P/n)==h,n
for n,h in t['V117_member_sha256'].items():
 p=P/n if n.startswith(('calc/','runtime/')) or n=='preflight114.py' else P/'input/v117'/n
 assert sha(p)==h,n
assert sha(P/'calc/certify87.py')==t['V89_member_sha256']['certify87.py']
assert run['task_sha256']==sha(P/'input/Q052_MATEMATIKOPGAVE_V118.json')
assert run['primary_passes']==run['independent_controls']==1 and 0<run['wall_seconds']<300
assert run['primary_closed_slabs']==160 and run['control_closed_pieces']==80
assert run['accepted_cells']==run['visited_cells']==list(range(236,246))
assert len(run['commands'])==21 and all(x['exit_code']==0 for x in run['commands'])
assert load('runtime_check119.json')['status']=='PASS' and load('runtime_check119.json')['version']=='4.2.1'
for k in ['new_native_pairs','new_optical_evaluations','new_scalar_integrations','new_full_history_integrations','parameter_searches']:assert run[k]==0
Q=F(t['target']['q']);B=F(t['target']['constant_b']);assert B==Q/16
assert seed['claim_id']==t['target']['entry']['claim'] and F(seed['exit_E_strictly_greater_than'])==B
current=F(seed['exit_z']);totals={'cached':0,'fresh':0,'excluded':0};control_counts={'INWARD':0,'MIXED_EXCLUDED':0}
summaries=[];old=load('input/v89/result.json')['cells']
for req in t['target']['rows']:
 cell=req['historical_cell'];a=load(f'receipts/primary_cell{cell}.json');b=load(f'receipts/control_cell{cell}.json')
 assert a['status']==b['status']=='PASS'
 for k in ['q','constant_b','z_ascending','hR_face_bounds','H_per_s','entry_claim','chain_entry_z','chain_entry_E_strictly_greater_than','common_branch_normalized_lower','kappa_lower','source_commit','background_dependency_id']:
  assert a[k]==b[k],k
 lo,hi=map(F,a['z_ascending']);assert hi==current and a['z_ascending']==req['z_ascending']
 hmin,hmax=map(F,a['hR_face_bounds']);common=(Q-2*B)/hmax
 assert common==F(a['common_branch_normalized_lower'])>0
 assert F(a['kappa_lower'])==1-(Q-2*B)/hmin-B*(Q-B)/hmin**2>0
 localcounts={'cached':0,'fresh':0,'excluded':0}
 assert len(a['rows'])==16 and len(b['rows'])==8
 am=[];bm=[]
 for i,r in enumerate(a['rows']):
  assert list(map(F,r['z']))==[hi-(hi-lo)*F(i+1,16),hi-(hi-lo)*F(i,16)]
  l,u=map(F,r['new_projection']);pl,pu=map(hx,r['physical_escape']);cl,cu=map(hx,r['critical'])
  factor=1+(Q-B)/(1-hmax);assert factor==F(r['guard_factor_upper'])
  assert l==max(pl,cl) and u==min(pu,cu*factor)
  if r['status']=='MIXED_EXCLUDED':
   assert l>u and F(r['strict_gap'])==l-u;localcounts['excluded']+=1
  else:
   if r['method']=='VERIFIED_V89_CACHE_INCLUSION':
    s=old[cell-236]['slabs'][i];assert r['old_escape']==s['escape'] and r['archived_excess']==s['excess']
    assert hx(s['escape'][0])<=l<=u<=hx(s['escape'][1])
    assert list(map(F,r['channel_excess_upper']))==[hx(x[1]) for x in s['excess']]
    assert r['dk']==s['dk'] and r['rate_box']=={k:s[k] for k in ['beta_s','beta_p','j','lam']}
    localcounts['cached']+=1
   else:
    assert r['method']=='FRESH_CHANGED_PROJECTION' and hx(r['escape'][0])<=l<=u<=hx(r['escape'][1])
    assert not hx(r['old_escape'][0])<=l<=u<=hx(r['old_escape'][1])
    assert list(map(F,r['channel_excess_upper']))==[hx(x[1]) for x in r['excess']]
    localcounts['fresh']+=1
   ms=[1-(1+F(x))*(1-common) for x in r['channel_excess_upper']]
   assert ms==list(map(F,r['channel_normalized_lower'])) and min(ms)==F(r['margin'])>0
   am.extend(ms)
 assert a['counts']==localcounts and sum(localcounts.values())==16
 for k,v in localcounts.items():totals[k]+=v
 for i,r in enumerate(b['rows']):
  assert list(map(F,r['z']))==[hi-(hi-lo)*F(i+1,8),hi-(hi-lo)*F(i,8)]
  control_counts[r['status']]+=1
  if r['status']=='MIXED_EXCLUDED':
   pair=r['H_intersection_bounds'] if r['exclusion']=='H_INTERSECTION' else r['raw_escape_bounds']
   l,u=map(F,pair);assert l>u and F(r['strict_gap'])==l-u
  else:
   xs=list(map(F,r['log_ratio_caps']));assert all(0<=x<1 for x in xs)
   ratios=[1/(1-x) for x in xs];assert ratios==list(map(F,r['channel_ratio_caps']))
   ms=[1-r*(1-common) for r in ratios];assert ms==list(map(F,r['channel_normalized_lower'])) and min(ms)==F(r['margin'])>0
   bm.extend(ms)
 assert min([common]+am)==F(a['normalized_lower']) and min([common]+bm)==F(b['normalized_lower'])
 summaries.append({'cell':cell,'z_ascending':a['z_ascending'],'hR_face_bounds':a['hR_face_bounds'],
 'primary_margin':a['normalized_lower'],'control_margin':b['normalized_lower'],'common_margin':str(common),
 'primary_counts':localcounts,'control_exclusions':sum(r['status']=='MIXED_EXCLUDED' for r in b['rows'])})
 current=lo
assert str(current)==run['reached_z']==t['target']['z_ascending'][0]
assert totals=={'cached':152,'fresh':1,'excluded':7}
assert control_counts=={'INWARD':77,'MIXED_EXCLUDED':3}
ap=min(F(x['primary_margin']) for x in summaries);bp=min(F(x['control_margin']) for x in summaries)
assert ap>F('0.000021736') and bp>F('0.000015511')
result={'status':'PASS','audit_scope':'Stored exact arithmetic and hashes; no new interval physical evaluations or replay',
 'cells':summaries,'primary_counts':totals,'control_counts':control_counts,'closed_primary_slabs':160,'closed_control_pieces':80,
 'primary_normalized_lower':str(ap),'control_normalized_lower':str(bp),'display':{'primary':float(ap),'control':float(bp)},
 'z_ascending':t['target']['z_ascending'],'q':str(Q),'constant_b':str(B),'entry_claim':seed['claim_id'],
 'exit_z':str(current),'exit_E_strictly_greater_than':str(B),'code_unchanged':True,'native_pairs':0,'new_physical_evaluations_in_audit':0}
(P/'validation119.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='cells'},indent=2))
