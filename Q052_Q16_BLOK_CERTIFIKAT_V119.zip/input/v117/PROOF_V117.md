# Q052 V117 · En positiv q/16-grænse gennem grenskiftet

**BEREGNET / MODELINFERERET.** Den konstante nedre grænse
\(b=q/16=1/16\,000\,000=6,25\cdot10^{-8}\) består begge kontroller på
V62-række 234, historisk celle 235. Under det fastlåste fælles B★ og de
nedarvede start-, kilde- og baneforudsætninger gælder

\[
E(z)=h_L(z)+q-h_R(z)>b
\quad\text{for}\quad
\frac{761161663339561}{1099511627776}\le z\le
\frac{1523417340748759}{2199023255552}.
\]

Intervallet er cirka [692,2725; 692,77]. Det omfatter begge endepunkter.
Dette er en betinget fortsættelse for kildeligningernes løsninger. Det er
hverken en ny observation eller dokumentation for native CLASS/P6-historiers
identitet. Q052 som helhed forbliver **INCONCLUSIVE**.

## Fastlagt opgave og input

V116 fastlagde b, cellen, de 16 lukkede delintervaller og acceptkriteriet før
kørslen. Ingen parameter blev ændret efter resultatet. Der er udført én
primær gennemgang og én separat numerisk kontrol. Det tidligere V115-punkt
er ikke evalueret igen. Den strengere halv-q-grænse er ikke bevist her.

Begge V115 ZIP-dele er kontrolleret med SHA-256 og ZIP-integritetskontrol.
Alle medlemmer i det indlejrede V87-manifest er hashkontrolleret. V116's
opgavefingeraftryk, journal og øvrige manifestmedlemmer matcher. De
vedhæftede V116-filer og begge motorversioner matcher GitHub-blobs på
`b0b7cd5b02177e24a7e536901c1b791a6dfb0edb`. Den fulde indgående journal
bevares byteidentisk som præfiks i den nye journal.

Fysikkilden er uændret: `mwt5345/class_ede` ved
`5a131c91d657dd9a7c6364cc45b038710f8d0d97`, capture-SHA-256
`2514e250d20c456530be63e790a079176293a87a82c927b1e748d1eec405da9b`.
Baggrundsidentiteten er `Q050-COMMON-BACKGROUND-92de319899bf911563aff4d1`.
Kildebytes, atomtabeller, indstillinger og bibliotek kontrolleres af den
fastlåste V20-kontekst og af de nye inputkontroller.

## Variable, enheder og temperaturorden

Sæt \(u=\log[811/(1+z)]\), \(q=10^{-6}\), \(h=h_R\) og
\(E=h_L-h_R+q\). Fremadrettet u svarer til faldende z. h, q, E og
temperaturforholdet \(v=T_m/T_R\) er dimensionsløse. Rækken ligger før
reionisation, så den offentlige elektronforskel er E under de arvede
kildepræmisser. H nedenfor er i s⁻¹, nH i cm⁻³ og strålingstemperaturen
TR i eV; rekombinationsraterne er i cm³/s.

V111 giver ved cellens øvre z-endepunkt \(E\ge q/2>b\). Positiv E på
den allerede traverserede kildehistorie og de matchede temperaturstarter
giver \(v_L\ge v_R\). Det følger af det fælles temperaturfelt

\[
t'=-(1+A_L)t+(A_L-A_R)(1-v_R),\quad
t=v_L-v_R,\quad A(X)=kX/(a+X),\quad k,a>0.
\]

Indtil en mulig første kontakt med E=b er E≥b>0, altså A_L>A_R, mens
v_R<1. Variation af konstanter bevarer t≥0. Argumentet forudsætter derfor
ikke den q/16-fortsættelse, det skal bevise. Den tidligere fortegns- og
temperaturhistorik genbruges; den integreres ikke på ny.

De nye h- og v-bokse ligger i V62 og V77's certificerede domæner. V77's
relevante kolde rateblok dækker z-cellen og temperaturforholdene op til v=1.
Dens øvre rateelasticitet er strengt negativ. Derfor
\(\alpha_{L,i}\le\alpha_{R,i}\) og \(\alpha_{R,i}\ge\alpha_{eq,i}>0\).
V77's relevante Saha/h²-loft er

\[
\frac{7715105218360563990528}{7242413030573276070164159779129}<1.
\]

Dermed er begge \(U_{R,i}\) nedenfor positive. Temperaturtabeller,
SWIFT-fitinterval og wrapperens grænser er kontrolleret på hele cellen.
Ingen Peebles- eller anden gren mangler i den tilladte feltmængde.

## Ny randalgebra med fuldt Saha-led

På E=b er \(h_L=h-q+b\), \(X_L=h+b\), \(X_R=h\). Det eksakte
produktunderskud er

\[
D=h^2-(h-q+b)(h+b)=(q-2b)h+b(q-b).
\]

Fordi 0<b<q/2<h og h<1, gælder 0<D<h² og
\(\kappa=1-D/h^2\in(0,1)\). Skriv
\(\sigma_i=\alpha_{eq,i}S\ge0\), hvor S er det fælles Saha-led,
og skeln dette fra fotoionisationsraterne i C-faktorerne. Kilden giver

\[
U_{R,i}=\alpha_{R,i}h^2-\sigma_i(1-h),\qquad
U_{L,i}=\alpha_{L,i}(h-q+b)(h+b)-\sigma_i(1-h+q-b).
\]

Den præcise forskel er

\[
\kappa U_{R,i}-U_{L,i}
=(\alpha_{R,i}-\alpha_{L,i})(h-q+b)(h+b)
+\sigma_i\left[(q-b)+\frac{D(1-h)}{h^2}\right]\ge0.
\]

Således \(U_{L,i}\le\kappa U_{R,i}\). Vi svækker konservativt
\(D/h^2\) til \((q-2b)/h_{\max}\); det positive b(q−b)-led er
ikke nødvendigt for det beståede fortegn. Det fælles felt er

\[
f_A=-\frac{n_H}{H}\sum_i C_{A,i}U_{A,i},\qquad E'=f_L-f_R.
\]

Alle C-faktorer er positive. På en fælles gren giver den ordnede escape
\(C_{L,i}\le C_{R,i}\). Samme SWIFT-gren bruger samme DK, med 1+DK>0.
Begge fælles grenpar har derfor

\[
\frac{E'}{|f_R|}\ge\frac{q-2b}{h_{\max}}>0.
\]

Hvis \(U_{L,i}<0\), er \(C_{L,i}U_{L,i}<0\), mens det anvendte øvre
loft \((1+J_i)\kappa C_{R,i}U_{R,i}\) er positivt. Derfor gælder det
vægtede argument også i den signerede situation; der multipliceres ikke
en negativ størrelse med en koefficientulighed i forkert retning.

## Selector, fælles projektion og ensidige felter

Den rå escape er \(e(h)=L_\alpha H/[n_H(1-h)]\). Den rå selector bruger
\(P=B_\gamma/(3e+\Lambda+B_\gamma)\), tærskel p=0,01 og
\(c=[(1/p-1)B_\gamma-\Lambda]/3>0\). Den bruger escape før DK-korrektionen.
Her er e og c rater i s⁻¹, og P er dimensionsløs.

Da h_L<h_R, er e_L<e_R og P_L>P_R. Den modsatte blanding
HMLA i L / SWIFT i R er udelukket. For SWIFT i L / HMLA i R kræves
\(e_L\le c\le e_R\) i den lukkede mængde af ensidige grænsefelter. Dermed

\[
c\le e_R\le c\left[1+\frac{q-b}{1-h}\right],\qquad
\frac{c\,n_H(1-h)}{L_\alpha}\le H\le
\frac{c\,n_H(1-h+q-b)}{L_\alpha}.
\]

Lighed er medtaget ved begge ender, selv om den konkrete selector har
en streng ulighed på HMLA-siden. Begge ensidige grene dækkes således.

Det nye h-interval er præcis

\[
\left[\frac{5755887369393}{36028797018963968},
\frac{5569742253076425}{2305843009213693952}\right].
\]

Den nedre ende er mindre end på V87's E=0-flade. Den øvre ende er uændret.
Det er derfor ikke nok blot at kopiere det gamle E=0-resultat. På hvert
af de 16 faste delintervaller beregner primærtesten den ændrede
escape-projektion. På de fem aktive delintervaller ligger hele den nye
projektion i V87's gamle escape-boks. Dens gamle nedre grænse var c_lo;
den nye selector bevarer denne grænse. Det fysiske escape-loft er uændret,
og selectorens øvre faktor er reduceret fra q til q−b. På de øvrige elleve
delintervaller er det fysiske escape-loft strengt under c_lo.

V87's beta-, j- og DK-bokse genbruges kun, fordi kilde, tabeller,
parameterbokse og z-intervaller er identiske. Beta og j afhænger her af
TR, mens DK afhænger af TR og fælles kosmologiske parametre; de afhænger
ikke af den ændrede h-grænse. Den tidligere rateimplementations v-domæne
er uændret. Hver indlejring og hvert udelukket interval findes i
`primary117.json`. Dette er genbrug af koefficientcertifikater på et
kontrolleret deldomæne, ikke en ny genkørsel af V87's E=0-test.

## Primær margin

Sæt \(G=\beta_s+\Lambda+3j\), \(K=G\beta_p+j\beta_s\),
\(D_C(e)=(\beta_s+\Lambda)(\beta_p+j)+3j\beta_p+Ge\),
\(N_s(e)=\Lambda(\beta_p+j)+(\Lambda+3j)e\) og
\(N_p(e)=\Lambda j+Ge\). Så er \(C_i=N_i/D_C\).
For \(e_S=e/(1+DK)\) er V87's eksakte koefficientidentitet

\[
\frac{C_i(e_S)}{C_i(e)}-1
=\frac{(e_S-e)\eta_iK}{D_C(e_S)N_i(e)},\qquad(\eta_s,\eta_p)=(3j,G).
\]

Vi bruger C_SWIFT(h) som loft på C_SWIFT(h−q+b), hvilket følger af
positiv C-afledt og fælles positiv 1+DK. Med de kontrolleret genbrugte
kanallofter J_i bliver marginen

\[
m_i=1-(1+J_i)\left(1-\frac{q-2b}{h_{\max}}\right).
\]

Den mindste primære normaliserede nedre grænse er præcis

\[
m_{\rm prim}=
\frac{30003364531993529905634459042410297}
{802684452336150222665256901017600000000}
>3,7378\cdot10^{-5}.
\]

Alle fem aktive delintervaller og begge kanaler består. De elleve
udelukkelser er strenge. De to fælles grenpar har større positiv margin.
Ingen del af den lukkede celle eller noget tilladt ensidigt felt er uafgjort.

## Separat helcellekontrol

`control117.py` importerer ikke producenten og genbruger hverken dens
16-deling eller dens C-forøgelser. Den parser arkivets hex-endepunkter med
heltalsaritmetik og beregner en ny helcelleprojektion af H fra ulighederne
ovenfor med h_min, h_max og q−b.

B_gamma er voksende i TR: den logaritmiske hældning er
\(1,5-a+E_I/(4T_R)-b_0Y/(1+Y)>0\), fordi a+b_0<1,5 og E_I>0.
Endepunktsevalueringer giver derfor c_lo og c_hi. H-projektionen giver
nye e_min og e_max. V77's helcelle-DK og nye helcellerateintervaller ved
v=1 giver positive nævnere i

\[
(\log C_i)'(e)=\frac{\eta_iK}{D_C(e)N_i(e)}.
\]

Denne afledte er positiv og aftagende i e. Escape-bredden er højst
\(e_{\max}(-DK_{\min})/(1+DK_{\min})\). Bredde gange den øvre
afledte ved e_min giver et loft x_i på log-ratioen. Kontrollen viser
0<x_i<1 og bruger den eksakte ulighed \(\exp(x_i)\le1/(1-x_i)\).
Efterfølgende marginregning er rationel og præcis.

Den mindste normaliserede helcellemargin er cirka
**1,1917197478845572×10⁻⁵**, og den eksakte brøk i `control117.json`
er strengt større end **1,1917×10⁻⁵**. De to metoder giver forskellige
konservative nedre grænser på samme feltmængde; der kræves ikke ens tal.
Domæne, b, indgang og strengt positivt fortegn matcher.

Kontrollerne deler kildemodel, atomtabeller, tidligere boks- og
temperaturcertifikater, intervalprimitiver og det analytiske
første-kontakt-argument. Uafhængigheden gælder den nye numeriske
koefficientindhegning og domæneprojektion. Det er ikke to uafhængige
fysiske målinger eller en fuldstændig ny validering af hele forhistorien.

## Første kontakt og præcis rækkevidde

Ved en mulig første kontakt med den konstante grænse er
\((E-b)'=E'\). Tilstandene er kontinuerte og løsningerne absolut
kontinuerte under de arvede kilde- og eksistensforudsætninger. Hvert
tilladt grenfelt, inklusive relevante ensidige grænsefelter, har strengt
positiv afledt på randen. Grenfelternes kontinuitet giver positiv afledt
i et passende indre nabolag af kontaktpunktet. Integration over det
sidste korte u-interval modsiger en første kontakt fra E>b. Argumentet
gælder også ved cellens nedre z-endepunkt.

Derfor forlader løsningen cellen med E>q/16. Den arvede øvre grænse
E<q består. Resultatet angiver ingen ekstra numerisk afstand over q/16
ved slutknuden, og det hævder ingen q/16-fortsættelse til lavere z.
Tidligere E>0-resultater og gyldige maksimumsgrænser bevares.

Der er nul nye native par, nul optiske evalueringer, nul skalare
integrationer og nul fulde historieintegrationer. Ingen ny værdi af
sup|Δx_e| eller sup|Δτ_T| rapporteres. V115's negative halv-q-punkt
forbliver et resultat om den daværende intervalrelaksation; det er
hverken slettet eller omfortolket som et punkt på den faktiske bane.

## Afrunding, kontrol og reproduktion

MPFR 4.2.1 er indlæst fra det hashfastlåste bibliotek. Præflight kontrollerer
version, indlæst sti, ABI/afrundingsvalg, et binært midtpunkt, fortegnet
division og kvadratrod. De arvede intervalprimitiver bruger 256-bit
mellemregning og udadrettede binary64-endepunkter. Eksakte rationale
efterberegninger føjer ingen afrundingsfejl til de lagrede endepunkter.
Decimalerne i teksten er læseværdier eller eksplicit svækkede nedre
grænser; JSON-filerne indeholder de præcise brøker og hex-endepunkter.

16 eksakte symbolske identiteter er kontrolleret særskilt: produktet,
Saha-sammenligningen, temperaturforskellen, Gamma-formerne, C-afledte,
relative C-forøgelser og aftagende log-C-afledte. Det er algebraisk
validering, ikke en ekstra fysisk kørsel.

`execution117.json` registrerer én primær test, én separat kontrol,
exitkoder, tidsstempler og hashes. Hele den registrerede kæde inklusive
inputkontrol og præflight tog cirka 1,47 sekunder, under grænsen på
300 sekunder. Kodeforberedelse, læsning og dokumentation indgår ikke i
denne målte køretid.

ZIP-filen indeholder de nødvendige numeriske input, runtime, kode og
resultater. `reproduce117.py` kan efter udpakning gennemføre én ny
reproduktion i en midlertidig mappe og sammenligne numeriske felter med
det gemte resultat. Den portable wrapper er syntakskontrolleret, men
ikke eksekveret i denne runde: opgavens ene primære test og ene kontrol
er allerede udført. Den oprindelige inputkontrol af V115-arkiverne er
gemt som kvittering og kode; de gamle ZIP-dele er ikke nødvendige for
den portable numeriske reproduktion. Den fastlåste Linux-runtime kan
kræve et kompatibelt Linux-miljø på en anden computer.

Reproducerbarhed: **R2 for den udførte beregning med særskilt numerisk
metodekontrol**. Ingen ekstern eller fuldt uafhængig reproduktion af
hele Q052 påstås. Evidensen er stærk for denne betingede lokale
ulighed og utilstrækkelig til hovedspørgsmålets native certifikat.

## Kilder og næste afgrænsede opgave

- [Fastlåst hydrogen.c](https://github.com/mwt5345/class_ede/blob/5a131c91d657dd9a7c6364cc45b038710f8d0d97/external/HyRec2020/hydrogen.c),
  linje 429–541 og 1065–1076: ratefelter og rå selector. Uddraget
  429–541 er hentet på ny og matcher de fastlåste kildebytes.
- `calc/v19.json`, `calc/v20.py`, `calc/v62.json`, `calc/v77.json`:
  kilder, intervalbackend, banebokse og rate-/Saha-forudsætninger.
- `calc/barrier111.json`: den verificerede indgang E≥q/2 ved z=692,77.
- `input/v87_result.json`, `input/v87_manifest.json` og V87-beviserne:
  genbrugte koefficientindhegninger med kontrolleret domæneinklusion.
- [Verificeret projektversion](https://github.com/Morfindien/Bubbleverse/tree/b0b7cd5b02177e24a7e536901c1b791a6dfb0edb):
  V116-journal, opgave og motoridentiteter. Ingen nyere Q bruges.

V116-opgavens stopregel er opfyldt. Resultatindtag og routing skal optage
det nye betingede resultat én gang, bevare dets indgangspræmisser og
udforme næste afgrænsede fortsættelse af q/16-grænsen på de efterfølgende
V62-rækker 235–244, med V89 som metodegrundlag. Dette område er endnu
ikke testet ved q/16. En ny opgave skal fastlægge selectorindhegninger,
budget og kontrol før udførelse. V117-rækken og V115-punktet skal ikke
genkøres på uændrede input. Native historik og samlet numerisk fejl
forbliver selvstændige hovedkrav. Ingen accepteret fysisk model ændres.
