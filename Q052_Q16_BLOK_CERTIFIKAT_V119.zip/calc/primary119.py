"""One changed-face pass; cached V89 C excess only after exact domain inclusion."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
import v20 as m
from certify87 import selector_threshold,fitted_correction
P=Path(__file__).resolve().parent;ROOT=P.parent
Q=F(1,1000000);B=Q/16;GAP=Q-B
hx=lambda s:F(float.fromhex(s))
load=lambda p:json.loads(p.read_bytes())

def main(index):
 t=load(ROOT/'input/Q052_MATEMATIKOPGAVE_V118.json')
 req=t['target']['rows'][index-235];assert req['V62_row']==index
 for n,h in t['V117_member_sha256'].items():
  if n.startswith(('calc/','runtime/')):assert sha256((ROOT/n).read_bytes()).hexdigest()==h,n
 for n in ['result.json','manifest.json']:
  h=t['V89_manifest_sha256'] if n=='manifest.json' else t['V89_member_sha256'][n]
  assert sha256((ROOT/'input/v89'/n).read_bytes()).hexdigest()==h
 c=m.Context(P/'v19.json')
 loaded={s.split()[-1] for s in Path('/proc/self/maps').read_text().splitlines() if '/libmpfr.so' in s}
 assert loaded=={str((ROOT/'runtime/libmpfr.so.6').resolve())} and c.mp.VERSION=='4.2.1'
 assert c.ctx['frozen']['physics_commit']==t['source_commit']
 assert c.raw['q048_prefix_config_v1.json']['sha256']==t['capture_sha256']
 assert c.binding['q_branches'][0]['background_dependency_id']==t['background_dependency_id']
 a=load(P/'v62.json');L,R=[a['arms'][x]['records'][index] for x in 'LR']
 assert L['z']==R['z'] and L['H_per_s']==R['H_per_s']
 assert L['allowed_branches']==R['allowed_branches']==['HMLA','SWIFT']
 lo,hi=sorted(map(hx,R['z']));assert [lo,hi]==list(map(F,req['z_ascending']))
 hmin=max(hx(R['whole_source'][0][0]),hx(L['whole_source'][0][0])+GAP)
 hmax=min(hx(R['whole_source'][0][1]),hx(L['whole_source'][0][1])+GAP)
 assert [hmin,hmax]==list(map(F,req['hR_face_bounds'])) and 0<B<Q/2<Q<hmin<hmax<1
 h=m.enc(hmin,hmax);hs=m.enc(*map(hx,R['H_per_s']))
 vmin=min(hx(r['whole_source'][1][0]) for r in [L,R]);vmax=max(hx(r['whole_source'][1][1]) for r in [L,R]);v=m.enc(vmin,vmax)
 assert F(1,10)<vmin<vmax<1 and hs.lo>0
 seed=load(ROOT/'input/v117/result117.json')
 assert seed['local_result']=='PASS_CONDITIONAL_CONSTANT_Q16_BARRIER'
 assert seed['claim_id']==t['target']['entry']['claim']
 assert seed['exit_z']==t['target']['entry']['z'] and F(seed['exit_E_strictly_greater_than'])==B
 assert seed['exact_question']==t['exact_question']
 v77=load(P/'v77.json');assert v77['status']=='PASS_UNDER_FROZEN_PREMISES'
 groups=[g for g in v77['elasticity_blocks'] if min(map(F,g['z']))<=lo<=hi<=max(map(F,g['z']))]
 assert len(groups)==1;group=groups[0]
 assert F(group['v_lower'])<=vmin and -1<hx(group['elasticity_hex'][0])<=hx(group['elasticity_hex'][1])<0
 assert 0<=F(group['saha_over_h_squared_upper'])<=F(v77['saha_over_h_squared_max'])<1
 assert F(v77['thermal_forcing_max'])<F(v77['thermal_cap'])==F(99,100)
 neff=list(map(hx,a['Neff_from_archived_row']));assert F('3.04')<neff[0]<=neff[1]<F('3.05')
 common=(Q-2*B)/hmax;kmin=1-(Q-2*B)/hmin-B*GAP/hmin**2
 assert 0<common<1 and 0<kmin<1
 old=load(ROOT/'input/v89/result.json')['cells'][index-235]
 assert old['cell']==index+1 and old['status']=='PASS' and old['z_exact']==req['z_ascending']
 assert old['whole_v']==v.hex() and old['whole_H_per_s']==hs.hex() and old['V77_rate_group']==group
 assert len(old['slabs'])==16
 rows=[];fit=None;counts={'cached':0,'fresh':0,'excluded':0}
 for i,slab in enumerate(old['slabs']):
  zl=hi-(hi-lo)*F(i+1,16);zh=hi-(hi-lo)*F(i,16)
  assert list(map(F,slab['z']))==[zl,zh]
  temp,tr,nh,_=c.background(m.enc(1+zl,1+zh))
  assert c.trmin.hi<tr.lo<=tr.hi<c.trmax.lo and c.fit_first.hi<temp.lo<=temp.hi<c.fit_last.lo
  critical=selector_threshold(c,tr);assert critical.hex()==slab['critical'] and critical.lo>0
  physical=c.lya*hs/(nh*(1-h));factor=1+GAP/(1-hmax)
  lower=max(F(critical.lo),F(physical.lo));upper=min(F(critical.hi)*factor,F(physical.hi))
  row={'slab_zero_based':i,'z':list(map(str,[zl,zh])),'critical':critical.hex(),'physical_escape':physical.hex(),
       'new_projection':list(map(str,[lower,upper])),'guard_factor_upper':str(factor),'Tgamma_K':temp.hex(),'TR_eV':tr.hex()}
  if lower>upper:
   row.update(status='MIXED_EXCLUDED',strict_gap=str(lower-upper));counts['excluded']+=1
  else:
   cached=slab['status']=='INWARD' and hx(slab['escape'][0])<=lower<=upper<=hx(slab['escape'][1])
   if cached:
    dl,dh=map(hx,slab['dk']);assert -1<dl<=dh<0
    assert slab['lam']==c.lam.hex()
    assert all(0<hx(slab[k][0])<=hx(slab[k][1]) for k in ['beta_s','beta_p','j','lam'])
    excess=[hx(x[1]) for x in slab['excess']]
    row.update(method='VERIFIED_V89_CACHE_INCLUSION',old_escape=slab['escape'],dk=slab['dk'],
      rate_box={k:slab[k] for k in ['beta_s','beta_p','j','lam']},archived_excess=slab['excess'])
    counts['cached']+=1
   else:
    if fit is None:
     ratio=(m.lit('2.7255')/m.enc(c.T0)).power(m.I(3))
     shifts=[m.I(1),(m.I(0,1)-m.lit('.14175'))*ratio,(m.enc(0,F('.03'))-m.lit('.02242')*(1-m.lit('.246738546372')))*ratio,m.enc(F('3.04'),F('3.05'))-m.lit('3.046')]
     fit=[[m.lit(x) for x in line.split()] for line in c.sources['fit_swift.dat']['content'].splitlines() if line.strip()]
    e=m.enc(lower,upper);dk=fitted_correction(c,temp,fit,shifts);assert -1<dk.lo<=dk.hi<0
    _,_,_,rates=c.rates(tr,v)
    bs,bp=[m.enc(*map(hx,x['hex'])) for x in rates['beta']];j=m.enc(*map(hx,rates['R2p2s']['hex']));lam=c.lam
    assert min(bs.lo,bp.lo,j.lo,lam.lo)>0
    g=bs+lam+3*j;d0=(bs+lam)*(bp+j)+3*j*bp;k=g*bp+j*bs
    es=e/(1+dk);ns=lam*(bp+j)+(lam+3*j)*e;np=lam*j+g*e;de=(-dk)*e/(1+dk)
    xs=[de*y*k/((d0+g*es)*n) for y,n in [(3*j,ns),(g,np)]]
    excess=[F(x.hi) for x in xs]
    row.update(method='FRESH_CHANGED_PROJECTION',escape=e.hex(),dk=dk.hex(),rate_receipt=rates,
      rate_box={'beta_s':bs.hex(),'beta_p':bp.hex(),'j':j.hex(),'lam':lam.hex()},excess=[x.hex() for x in xs],old_escape=slab.get('escape'))
    counts['fresh']+=1
   assert all(x>=0 for x in excess)
   margins=[1-(1+x)*(1-common) for x in excess]
   row.update(status='INWARD' if min(margins)>0 else 'INCONCLUSIVE',channel_excess_upper=list(map(str,excess)),channel_normalized_lower=list(map(str,margins)),margin=str(min(margins)))
  rows.append(row)
 margin=min([common]+[F(r['margin']) for r in rows if 'margin' in r])
 return {'status':'PASS' if margin>0 else 'INCONCLUSIVE','cell':index+1,'V62_row':index,'q':str(Q),'constant_b':str(B),
  'z_ascending':req['z_ascending'],'hR_face_bounds':list(map(str,[hmin,hmax])),'v_domain':list(map(str,[vmin,vmax])),
  'H_per_s':R['H_per_s'],'entry_claim':seed['claim_id'],'chain_entry_z':seed['exit_z'],'chain_entry_E_strictly_greater_than':str(B),
  'common_branch_normalized_lower':str(common),'kappa_lower':str(kmin),'normalized_lower':str(margin),'display_margin':float(margin),
  'counts':counts,'closed_slabs':len(rows),'rows':rows,'elasticity_block':group,
  'source_commit':t['source_commit'],'background_dependency_id':t['background_dependency_id'],'source_pins':c.pins,
  'runtime':{'mpfr_version':c.mp.VERSION,'loaded_library':sorted(loaded)},
  'one_sided_fields':'Both common branches; SWIFT/HMLA closure; HMLA/SWIFT strictly excluded by eL<eR'}

if __name__=='__main__':print(json.dumps(main(int(sys.argv[1])),indent=2))
