"""Separate eight-piece H projection and decreasing log-C control. No primary outputs/J."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys
import v20 as m
P=Path(__file__).resolve().parent;ROOT=P.parent
Q=F(1,1000000);B=F(1,16000000)
load=lambda p:json.loads(p.read_bytes())
def hx(s):
 sign=-1 if s.startswith('-') else 1;s=s.lstrip('+-');mant,exponent=s.split('p');a,b=mant.removeprefix('0x').split('.')
 return sign*F(int(a+b,16))*F(2)**(int(exponent)-4*len(b))
def ends(i):return F(i.lo),F(i.hi)
def beta(c,tr):
 x=tr/(10000*c.k)
 return c.saha*tr*tr.sqrt()*(-c.EI/(4*tr)).exp()*m.lit('4.309e-13')*x.power(m.lit('-0.6166'))/(1+m.lit('0.6703')*x.power(m.lit('0.5300')))
def main(index):
 t=load(ROOT/'input/Q052_MATEMATIKOPGAVE_V118.json');req=t['target']['rows'][index-235];assert req['V62_row']==index
 for n,h in t['V117_member_sha256'].items():
  if n.startswith(('calc/','runtime/')):assert sha256((ROOT/n).read_bytes()).hexdigest()==h,n
 c=m.Context(P/'v19.json')
 loaded={s.split()[-1] for s in Path('/proc/self/maps').read_text().splitlines() if '/libmpfr.so' in s}
 assert loaded=={str((ROOT/'runtime/libmpfr.so.6').resolve())} and c.mp.VERSION=='4.2.1'
 assert c.ctx['frozen']['physics_commit']==t['source_commit'] and c.raw['q048_prefix_config_v1.json']['sha256']==t['capture_sha256']
 assert c.binding['q_branches'][0]['background_dependency_id']==t['background_dependency_id']
 a=load(P/'v62.json');L,R=[a['arms'][x]['records'][index] for x in 'LR']
 assert L['z']==R['z'] and L['H_per_s']==R['H_per_s'] and L['allowed_branches']==R['allowed_branches']==['HMLA','SWIFT']
 lo,hi=sorted(map(hx,R['z']));Hlo,Hhi=map(hx,R['H_per_s'])
 hmin=max(hx(R['whole_source'][0][0]),hx(L['whole_source'][0][0])+Q-B)
 hmax=min(hx(R['whole_source'][0][1]),hx(L['whole_source'][0][1])+Q-B)
 assert [lo,hi]==list(map(F,req['z_ascending'])) and [hmin,hmax]==list(map(F,req['hR_face_bounds']))
 assert Q<hmin<hmax<1 and 0<B<Q/2 and Hlo>0
 vmin=min(hx(r['whole_source'][1][0]) for r in [L,R]);vmax=max(hx(r['whole_source'][1][1]) for r in [L,R]);assert F(1,10)<vmin<vmax<1
 seed=load(ROOT/'input/v117/result117.json');assert seed['claim_id']==t['target']['entry']['claim'] and seed['exit_z']==t['target']['entry']['z']
 assert seed['local_result']=='PASS_CONDITIONAL_CONSTANT_Q16_BARRIER' and F(seed['exit_E_strictly_greater_than'])==B
 v77=load(P/'v77.json');assert v77['status']=='PASS_UNDER_FROZEN_PREMISES'
 blocks=[g for g in v77['elasticity_blocks'] if min(map(F,g['z']))<=lo<=hi<=max(map(F,g['z']))]
 assert len(blocks)==1;block=blocks[0]
 assert F(block['v_lower'])<=vmin and -1<hx(block['elasticity_hex'][0])<=hx(block['elasticity_hex'][1])<0
 assert 0<=F(block['saha_over_h_squared_upper'])<=F(v77['saha_over_h_squared_max'])<1
 assert F(v77['thermal_forcing_max'])<F(v77['thermal_cap'])==F(99,100)
 jumps=[x for x in v77['mixed_branch_checks'] if x['z']==R['z']];assert len(jumps)==1
 jump=jumps[0];assert jump['H_per_s']==R['H_per_s']
 dklo,dkhi=map(hx,jump['DK']);assert -1<dklo<=dkhi<0
 pmin,pmax=ends(m.lit('.01'));lm,lh=ends(c.lam);ll,lu=ends(c.lya)
 assert F(m.lit('.6166').hi)+F(m.lit('.5300').hi)<F(3,2)
 common=(Q-2*B)/hmax;kmin=1-(Q-2*B)/hmin-B*(Q-B)/hmin**2
 assert 0<kmin<1 and 0<common<1
 rows=[]
 for i in range(8):
  zl=hi-(hi-lo)*F(i+1,8);zh=hi-(hi-lo)*F(i,8)
  temp,tr,n,_=c.background(m.enc(1+zl,1+zh))
  assert c.trmin.hi<tr.lo<=tr.hi<c.trmax.lo and c.fit_first.hi<temp.lo<=temp.hi<c.fit_last.lo
  bl=F(beta(c,m.I(tr.lo)).lo);bh=F(beta(c,m.I(tr.hi)).hi)
  cl=((1/pmax-1)*bl-lh)/3;cu=((1/pmin-1)*bh-lm)/3;assert 0<cl<=cu
  nl,nu=ends(n)
  Hl=max(Hlo,cl*nl*(1-hmax)/lu);Hu=min(Hhi,cu*nu*(1-hmin+Q-B)/ll)
  row={'piece_zero_based':i,'z':list(map(str,[zl,zh])),'selector_threshold':list(map(str,[cl,cu])),
    'H_intersection_bounds':list(map(str,[Hl,Hu])),'TR_eV':tr.hex(),'Tgamma_K':temp.hex()}
  if Hl>Hu:
   row.update(status='MIXED_EXCLUDED',exclusion='H_INTERSECTION',strict_gap=str(Hl-Hu));rows.append(row);continue
  emin=max(ll*Hl/(nu*(1-hmin)),cl);emax=min(lu*Hu/(nl*(1-hmax)),cu*(1+(Q-B)/(1-hmax)))
  row.update(raw_escape_bounds=list(map(str,[emin,emax])))
  if emin>emax:
   row.update(status='MIXED_EXCLUDED',exclusion='RAW_ESCAPE_INTERSECTION',strict_gap=str(emin-emax));rows.append(row);continue
  assert emin>0
  width=emax*(-dklo)/(1+dklo)
  _,_,_,rates=c.rates(tr,m.I(1))
  bs,bp=[tuple(map(hx,x['hex'])) for x in rates['beta']];jl,jh=map(hx,rates['R2p2s']['hex'])
  assert min(*bs,*bp,jl,jh,lm,lh)>0
  gl=bs[0]+lm+3*jl;gh=bs[1]+lh+3*jh;K=gh*bp[1]+jh*bs[1]
  D=(bs[0]+lm)*(bp[0]+jl)+3*jl*bp[0]+gl*emin
  Ns=lm*(bp[0]+jl)+(lm+3*jl)*emin;Np=lm*jl+gl*emin
  assert min(D,Ns,Np)>0
  logs=[width*3*jh*K/(D*Ns),width*gh*K/(D*Np)]
  if not all(0<=x<1 for x in logs):
   row.update(status='INCONCLUSIVE',failure='LOG_CAP_OUTSIDE_0_1',log_ratio_caps=list(map(str,logs)))
  else:
   ratios=[1/(1-x) for x in logs];margins=[1-r*(1-common) for r in ratios]
   row.update(status='INWARD' if min(margins)>0 else 'INCONCLUSIVE',escape_width_cap=str(width),rate_receipt=rates,
    log_ratio_caps=list(map(str,logs)),channel_ratio_caps=list(map(str,ratios)),channel_normalized_lower=list(map(str,margins)),
    margin=str(min(margins)),positive_denominator_lower=list(map(str,[D,Ns,Np])))
  rows.append(row)
 margin=min([common]+[F(r['margin']) for r in rows if 'margin' in r]);ok=all(r['status']!='INCONCLUSIVE' for r in rows)
 return {'status':'PASS' if ok else 'INCONCLUSIVE','cell':index+1,'V62_row':index,'q':str(Q),'constant_b':str(B),
  'z_ascending':req['z_ascending'],'hR_face_bounds':list(map(str,[hmin,hmax])),'H_per_s':R['H_per_s'],
  'entry_claim':seed['claim_id'],'chain_entry_z':seed['exit_z'],'chain_entry_E_strictly_greater_than':str(B),
  'common_branch_normalized_lower':str(common),'kappa_lower':str(kmin),'normalized_lower':str(margin),'display_margin':float(margin),
  'closed_pieces':len(rows),'rows':rows,'whole_cell_DK':jump['DK'],'elasticity_block':block,
  'source_commit':t['source_commit'],'background_dependency_id':t['background_dependency_id'],
  'runtime':{'mpfr_version':c.mp.VERSION,'loaded_library':sorted(loaded)},
  'independence':'Separate process and integer hex parser; no primary output, slabs or stored J. Shared pinned tables, MPFR primitives and inherited analytic premises.',
  'one_sided_fields':'Both common branches; SWIFT/HMLA closure; HMLA/SWIFT excluded by strict raw escape order'}
if __name__=='__main__':print(json.dumps(main(int(sys.argv[1])),indent=2))
