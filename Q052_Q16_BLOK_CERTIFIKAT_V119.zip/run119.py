"""Frozen one-pass cell traversal, at most 300 execution wallseconds. Refuses a second run."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
import json,os,subprocess,sys,time,traceback
P=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
def dump(n,x):(P/n).write_text(json.dumps(x,indent=2)+'\n')
with (P/'run119.lock').open('x') as f:f.write(datetime.now(timezone.utc).isoformat()+'\n')
t=load(P/'input/Q052_MATEMATIKOPGAVE_V118.json')
codes=['calc/primary119.py','calc/control119.py','calc/certify87.py','calc/v20.py','preflight114.py','run119.py']
rec={'run_id':t['task_id'],'started_utc':datetime.now(timezone.utc).isoformat(),'technical_state':'INCOMPLETE',
 'code_sha256_before':{n:sha(P/n) for n in codes},'task_sha256':sha(P/'input/Q052_MATEMATIKOPGAVE_V118.json'),
 'execution_limits':t['execution_limits'],'primary_passes':0,'independent_controls':0,'commands':[],
 'new_native_pairs':0,'new_optical_evaluations':0,'new_scalar_integrations':0,'new_full_history_integrations':0,'parameter_searches':0,
 'accepted_cells':[],'visited_cells':[],'primary_closed_slabs':0,'control_closed_pieces':0}
dump('freeze119.json',rec)
env=dict(os.environ);env['LD_LIBRARY_PATH']=str(P/'runtime')
start=time.monotonic();current=F(t['target']['entry']['z'])
def run(script,out,args=[]):
 remain=300-(time.monotonic()-start);assert remain>0,'WALL_LIMIT'
 at=time.monotonic()
 try:r=subprocess.run([sys.executable,str(P/script),*args],cwd=P,env=env,capture_output=True,timeout=remain)
 except subprocess.TimeoutExpired as e:
  (P/out).write_bytes(e.stdout or b'');(P/(out+'.stderr.log')).write_bytes(e.stderr or b'')
  rec['commands'].append({'script':script,'args':args,'output':out,'state':'TIMEOUT'});raise
 (P/out).write_bytes(r.stdout);(P/(out+'.stderr.log')).write_bytes(r.stderr)
 rec['commands'].append({'script':script,'args':args,'output':out,'exit_code':r.returncode,'wall_seconds':time.monotonic()-at})
 assert r.returncode==0,(script,args,r.stderr.decode()[-3000:])
 return load(P/out)
try:
 assert load(P/'input_check119.json')['status']=='PASS'
 assert rec['task_sha256']==load(P/'input_check119.json')['task_sha256']
 pre=run('preflight114.py','runtime_check119.json');assert pre['status']=='PASS'
 (P/'receipts').mkdir(exist_ok=True)
 for req in t['target']['rows']:
  row=req['V62_row'];lo,hi=map(F,req['z_ascending']);assert hi==current
  rec['visited_cells'].append(row+1)
  rec['primary_passes']=1
  a=run('calc/primary119.py',f'receipts/primary_cell{row+1}.json',[str(row)])
  rec['primary_closed_slabs']+=a['closed_slabs']
  rec['independent_controls']=1
  b=run('calc/control119.py',f'receipts/control_cell{row+1}.json',[str(row)])
  rec['control_closed_pieces']+=b['closed_pieces']
  for k in ['cell','V62_row','q','constant_b','z_ascending','hR_face_bounds','H_per_s','entry_claim','chain_entry_z','chain_entry_E_strictly_greater_than','common_branch_normalized_lower','kappa_lower','source_commit','background_dependency_id']:
   assert a[k]==b[k],k
  assert a['closed_slabs']==16 and b['closed_pieces']==8
  if a['status']!='PASS' or b['status']!='PASS':
   rec['stop_reason']='FIRST_UNRESOLVED_CELL';rec['unresolved_cell']=row+1;break
  assert min(F(a['normalized_lower']),F(b['normalized_lower']))>0
  current=lo;rec['accepted_cells'].append(row+1)
  print(json.dumps({'cell':row+1,'primary_margin':a['display_margin'],'control_margin':b['display_margin'],'primary_counts':a['counts'],'accepted':True}),flush=True)
  dump('checkpoint119.json',{'accepted_cells':rec['accepted_cells'],'exit_z':str(current),'constant_b':t['target']['constant_b'],'elapsed_wall_seconds':time.monotonic()-start})
 else:rec['stop_reason']='ALL_TEN_CELLS_COMPLETED'
 rec['technical_state']='PASS';rec['scientific_execution_state']='ALL_TEN_PASS' if len(rec['accepted_cells'])==10 else 'PARTIAL_PREFIX'
except Exception as e:
 rec['technical_state']='FAIL';rec['stop_reason']='MANDATORY_GATE_OR_RUNTIME_FAILURE';rec['failure']=str(e);rec['traceback']=traceback.format_exc()
finally:
 rec['ended_utc']=datetime.now(timezone.utc).isoformat();rec['wall_seconds']=time.monotonic()-start
 rec['reached_z']=str(current);rec['code_sha256_after']={n:sha(P/n) for n in codes}
 rec['code_unchanged']=rec['code_sha256_after']==rec['code_sha256_before']
 rec['output_sha256']={str(p.relative_to(P)):sha(p) for p in sorted((P/'receipts').glob('*.json'))}
 if (P/'runtime_check119.json').exists():rec['output_sha256']['runtime_check119.json']=sha(P/'runtime_check119.json')
 dump('execution119.json',rec)
 print(json.dumps({k:v for k,v in rec.items() if k not in ['output_sha256','commands','code_sha256_before','code_sha256_after']},indent=2))
 if rec['technical_state']!='PASS':sys.exit(1)
