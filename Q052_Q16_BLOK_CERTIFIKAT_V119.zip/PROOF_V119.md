# Q052 V119 — q/16 gennem de næste ti grenskifteceller

**BEREGNET / MODELINFERERET.** Under den fastlåste fælles baggrund og de
nedarvede kilde-, start-, eksistens- og baneboksforudsætninger gælder

\[
E(z)=h_L(z)+q-h_R(z)>b=\frac{q}{16}=\frac1{16000000},\qquad q=10^{-6},
\]

på hele det lukkede interval

\[
\frac{6045532743931003}{8796093022208}\le z\le
\frac{761161663339561}{1099511627776},
\]

altså cirka **687,2975 ≤ z ≤ 692,2725**. Det er V62-rækker 235–244,
historiske celler 236–245. V117 leverer den strenge indgang E>b ved det
øvre endepunkt. V119 fastslår ingen numerisk ekstra afstand E−b ved udgangen.
Det er et betinget resultat for kildeligningernes løsninger. Q052's krav
om faktiske native CLASS/P6-historier og et samlet fejlcertifikat er stadig
**INCONCLUSIVE**.

## Fast kontrakt, kilde og historik

V118 fastlagde b, 16 primære lukkede delintervaller pr. celle, en separat
fast ottedeling, stop ved første uafklarede celle og højst 300 sekunders
beregningskørsel. Ingen parameter eller opdeling blev ændret efter resultatet.
Begge metoder blev anvendt på hver celle i faldende z-rækkefølge, og kun
det sammenhængende præfiks med to beståede metoder blev accepteret.

Fysikkilden er `mwt5345/class_ede` ved commit
`5a131c91d657dd9a7c6364cc45b038710f8d0d97`. Capture-SHA-256 er
`2514e250d20c456530be63e790a079176293a87a82c927b1e748d1eec405da9b`;
baggrundsidentiteten er
`Q050-COMMON-BACKGROUND-92de319899bf911563aff4d1`.
Den hashfastlåste V20-kontekst kontrollerer kildemedlemmer, atomtabeller,
aktive flag, fælles baggrunds-ID og matchede starter ved z=810.
H på de nye celler hentes fra deres faktiske V62-rækker i s⁻¹; den første
baggrundscelles H anvendes ikke som erstatning.

Den vedhæftede V118-pakke, de indlejrede V117/V89-arkiver og samtlige
manifestmedlemmer er integritetskontrolleret. Projektfilerne og motoren
matcher GitHub-blobs ved `4d7c610cc2c0ba0a9a7f1ce40447dbf28ec0791c`.
V118-journalen videreføres byteidentisk som præfiks. Dette bevarer
historikken; det er ikke en ny udførelse af gamle beregninger.

## Kontaktflade, temperaturorden og fuldt Saha-led

Fremadrettet tid er u=ln[811/(1+z)]. h, q, E, b og v=T_m/T_R er
dimensionsløse. n_H anvendes i cm⁻³, H i s⁻¹, T_R i eV, T_γ i K,
rekombinationskoefficienter i cm³/s og escape-, beta- og j-rater i s⁻¹.
Intervallet ligger før reionisation under de nedarvede wrapperpræmisser.

På en mulig første kontakt med E=b sættes h=h_R,
h_L=h−q+b og X_L=h+b, X_R=h. De nye præcise h-grænser beregnes som

\[
h_{\min}=\max(R_{\min},L_{\min}+q-b),\qquad
h_{\max}=\min(R_{\max},L_{\max}+q-b).
\]

Hver celle opfylder q<h_min<h_max<1. V77's relevante kolde rateblok
dækker hele z- og v-domænet; rateelasticiteten er negativ og dens Saha/h²-loft
er mindre end 1. Dens temperatur- og fitdomæner er kontrolleret.

Temperaturordenen v_L≥v_R følger fra de matchede starter, den nedarvede
positive historie og, indtil en mulig første kontakt, E≥b>0. Med
t=v_L−v_R og den voksende kobling A(X)=kX/(a+X), k,a>0, gælder

\[
t'=-(1+A_L)t+(A_L-A_R)(1-v_R).
\]

Da v_R<1, bevares t≥0 ved variation af konstanter. Dette antager kun
positivitet før den første kontakt, ikke den ønskede konklusion efter den.
Det giver α_L,i≤α_R,i og α_R,i≥α_eq,i>0.

Sæt P=(h−q+b)(h+b) og D=h²−P=(q−2b)h+b(q−b). Da 0<b<q/2<h,
er 0<D<h², så κ=1−D/h² ligger i (0,1). For σ_i=α_eq,i S≥0 er

\[
U_{R,i}=\alpha_{R,i}h^2-\sigma_i(1-h)>0,
\quad
U_{L,i}=\alpha_{L,i}P-\sigma_i(1-h+q-b).
\]

Den fulde sammenligning, inklusive Saha-leddet, er

\[
\kappa U_{R,i}-U_{L,i}
=(\alpha_{R,i}-\alpha_{L,i})P
+\sigma_i\left[q-b+\frac{D(1-h)}{h^2}\right]\ge0.
\]

Dermed U_L,i≤κU_R,i. Det strengt positive b(q−b)/h²-led kan svækkes
væk, så κ≤1−(q−2b)/h_max. Kildehastigheden er
f_A=−(n_H/H)Σ_i C_A,i U_A,i og E′=f_L−f_R.
Hvis U_L,i<0, følger den nødvendige øvre sammenligning direkte af
fortegnet; der multipliceres ikke en negativ størrelse med en
koefficientulighed i forkert retning. Ellers anvendes C_L,i/C_R,i≤1+J_i.
Algebraen er den samme som i det allerede kontrollerede V117-bevis;
dets 16 symbolske checks genbruges som arkivbevis og tælles ikke igen.

## Alle grene og ensidige felter

Den rå escape er e(h)=L_α H/[n_H(1−h)]. Selectoren bruger
P_γ=B_γ/(3e+Λ+B_γ), tærskel p=0,01 og
c=[(1/p−1)B_γ−Λ]/3>0, før DK-korrektionen.
På kontaktfladen er h_L<h_R, derfor e_L<e_R. Blandingen
L:HMLA / R:SWIFT er dermed strengt udelukket.

For de to fælles grenpar er C_L,i≤C_R,i, også på SWIFT med fælles
positiv 1+DK. De har normaliseret indadrettet margin
(q−2b)/h_max>0. Den resterende blanding L:SWIFT / R:HMLA kræver i
den lukkede mængde af ensidige felter

\[
e_L\le c\le e_R,\qquad
c\le e_R\le c\left(1+\frac{q-b}{1-h}\right).
\]

Begge lighedstilfælde er medtaget. Samme fælles H anvendes i begge arme.
For en fysisk escape-boks [e_p^−,e_p^+] og selectorboks [c^−,c^+]
indhegnes den relevante højre escape ved

\[
\left[\max(e_p^-,c^-),\ \min\left(e_p^+,c^+\left(1+\frac{q-b}{1-h_{\max}}\right)\right)\right].
\]

En streng omvendt endepunktsorden udelukker den blandede gren. I de
syv udelukkede primære stykker i sidste celle ligger det fysiske
escape-minimum over selectorloftet. Dette er ikke tilfældet fra V117,
hvor den fysiske øvre grænse lå under selectorens nedre grænse.

## Primær beregning og tilladt genbrug

De præcise V89-stykker er verificeret som 16 lukkede intervaller pr.
celle i faldende fysisk z-rækkefølge. Den ændrede h_min bruges i en ny
udadrettet beregning af fysisk escape og dens snit med selectoren.
På **152 stykker** ligger hele den nye projektion i den gamle
escape-boks. Genbrug er begrundet i identiske z- og v-domæner, H,
kildebytes, parameterrum og DK-/rateforudsætninger. Beta og j afhænger
her af T_R, og DK af T_γ og fælles kosmologiske parametre; den ændrede
h_min ændrer ikke disse input. Kontrollen af domæneinklusion er ny.

På historisk celle 245, stykkeindeks 8, falder den nye nedre escape
uden for cacheboksen. Her beregnes et nyt interval for koefficienterne
på præcis det nye stykke med den på forhånd tilladte V87-formel.
Der er således **én frisk koefficientberegning**, ikke et ubetinget
genbrug. På de sidste **syv stykker** er blandingen strengt udelukket.

Med G=β_s+Λ+3j, K=Gβ_p+jβ_s og

\[
D_C(e)=(\beta_s+\Lambda)(\beta_p+j)+3j\beta_p+Ge,
\quad N_s(e)=\Lambda(\beta_p+j)+(\Lambda+3j)e,
\quad N_p(e)=\Lambda j+Ge
\]

er C_i=N_i/D_C. Sæt e_S=e/(1+DK). Den eksakte identitet er

\[
\frac{C_i(e_S)}{C_i(e)}-1
=\frac{(e_S-e)\eta_i K}{D_C(e_S)N_i(e)},
\qquad (\eta_s,\eta_p)=(3j,G).
\]

C er voksende, så C_SWIFT(h_R) er et konservativt loft på
C_SWIFT(h_L). DK ligger strengt mellem −1 og 0. De positive
nævnere indhegnes udadrettet. De nye eller kontrolleret genbrugte
kanallofter J_i giver margin

\[
m_i=1-(1+J_i)\left(1-\frac{q-2b}{h_{\max}}\right)>0.
\]

Den mindste primære margin er præcis

\[
\frac{34279236566861417692737060894967393}
{1577058927785914784506536722956288000000}
>2,1736\cdot10^{-5}.
\]

## Separat kontrol med fast ottedeling

Kontrollen kører i en separat proces og bruger ingen primære resultater,
ingen primære J-værdier og ingen primær opdeling. Arkivets hex-endepunkter
parses med heltalsaritmetik. Hver celle deles fra de eksakte endepunkter
i otte lige store lukkede stykker.

B_γ er voksende i T_R, fordi dens logaritmiske hældning er
1,5−a+E_I/(4T_R)−b₀Y/(1+Y)>0, idet a+b₀<1,5.
Nye rettede endepunktsevalueringer giver c_min,c_max. Fælles H begrænses af

\[
H\ge c n_H(1-h)/L_\alpha,\qquad
H\le c n_H(1-h+q-b)/L_\alpha.
\]

Den resulterende rå escape indhegnes igen og skæres med
[c_min,c_max(1+(q−b)/(1−h_max))]. Kun streng disjunkthed udelukker
blandingen. Den faste metode anvender V77's verificerede helcelle-DK,
men **nye** per-stykke-intervaller for ligevægtsraterne β_s,β_p,j.
Disse er uafhængige af v; beregningen ved v=1 er tilstrækkelig.

Den positive logaritmiske afledte

\[
(\log C_i)'(e)=\frac{\eta_i K}{D_C(e)N_i(e)}
\]

er aftagende i e. Integrationsbredden i koefficientsammenligningen
er højst w=e_max(−DK_min)/(1+DK_min); der udføres ingen
historieintegration. Positivt øvre afledt loft ved e_min gange w
giver x_i≥0. Alle aktive stykker har x_i<1, så
exp(x_i)≤1/(1−x_i). Derfor er

\[
1-\frac{1-(q-2b)/h_{\max}}{1-x_i}>0.
\]

Alle **80 kontrolstykker** er dækket: 77 har positiv blandet margin,
og 3 udelukker blandingen strengt. Den mindste kontrolmargin er
cirka **1,551118741283978×10⁻⁵**, strengt større end
**1,5511×10⁻⁵**. Den præcise brøk findes i `validation119.json` og
`result119.json`. Begge metoders tal er konservative nedre grænser;
de skal have samme domæne og fortegn, men behøver ikke være ens.

Metoderne deler kildemodel, atomtabeller, MPFR-primitiver og de tidligere
baneboks-, temperatur- og Saha-præmisser. Uafhængigheden gælder den nye
numeriske projektion og koefficientindhegning, ikke hele fysikgrundlaget.
Det er ikke to uafhængige observationer.

## Første kontakt og kontinuerlig fortsættelse

Indgangen er V117's E>b, uden ekstra kvantificeret afstand. Hvis løsningen
ramte E=b første gang, ville alle tilladte grenfelter og ensidige
grænsefelter have positiv E′ på randen. Med nedarvet kontinuitet af
tilstanden, absolut kontinuitet af løsningen og kontinuerte grenfelter
gælder positiviteten i et passende lokalt indre nabolag. Integration
over det sidste korte u-interval modsiger en første kontakt fra E>b.
Det gælder også ved cellernes endepunkter. Det strenge udgangsresultat
fra hver godkendt celle er indgangen til den næste. Alle ti blev godkendt.

Marginerne i denne pakke er grænser for E′/|f_R| på kontaktfladen.
De er **ikke** realiserede værdier af E−b eller et nyt globalt maksimum.
En fortsættelse under z=687,2975 er ikke bevist i denne kørsel. De
tidligere gyldige fortegns- og maksimumsresultater bevares, ligesom
V115's begrænsning for halv-q-metoden bevares.

## Beregningsprovenance, fejl og reproduktion

Der er udført én primær gennemgang og én separat kontrol, med 10
celler, 160 primære stykker og 80 kontrolstykker. Kørsel med præflight
tog **21,7161 sekunder**, under kontraktens 300 sekunder. Forberedelse
og dokumentation er ikke inkluderet i det tal. Der er nul nye native
par, optiske evalueringer, skalare historieintegrationer, fulde
historieintegrationer og parametersøgninger.

Det hashfastlåste MPFR 4.2.1-bibliotek består præflight af version,
indlæst sti, ABI/afrundingsvalg, binært midtpunkt, fortegnet division
og kvadratrod. Intervalprimitiverne anvender 256-bit mellemregning
og udadrettede binary64-endepunkter. Efterfølgende marginregning
bruger eksakte rationale tal. Decimalerne her er læseværdier eller
udtrykkeligt svækkede nedre grænser.

`freeze119.json` fastholder kodehashene før kørsel; `execution119.json`
bekræfter uændret kode, exitkoder, tid, stopgrund og resultathashes.
`validation119.json` kontrollerer de gemte resultaters præcise
partitionsdækning, inklusioner, udelukkelser og marginaritmetik uden
at gentage feltberegningen. `reproduce119.py` kan udføre en særskilt
reproduktion i en ny midlertidig mappe og sammenligne de videnskabelige
felter. Den er syntakskontrolleret, men ikke kørt i denne runde.
Den pakkede Linux-runtime forudsætter et kompatibelt system med GMP.
Ingen ekstern reproduktion eller native fejlcertificering påstås.

## Primære kilder og næste trin

- [Fastlåst hydrogen.c](https://github.com/mwt5345/class_ede/blob/5a131c91d657dd9a7c6364cc45b038710f8d0d97/external/HyRec2020/hydrogen.c):
  rate- og selectorligninger; bytes genbrugt og hashkontrolleret fra inputpakken.
- `calc/v19.json` og `calc/v20.py`: indlejrede kildebytes, konfiguration,
  matchede starter, rater og intervalbackend.
- `calc/v62.json` og `calc/v77.json`: arvede banebokse, H, rateelasticitet,
  Saha- og DK-forudsætninger. Disse tidligere certifikater genudføres ikke.
- `input/v89/` og `input/v117/`: præcise koefficientreceipts,
  domæner, beviser og indgangen E>b.
- [Verificeret projektversion](https://github.com/Morfindien/Bubbleverse/tree/4d7c610cc2c0ba0a9a7f1ce40447dbf28ec0791c):
  V118-input og motoridentitet. Det fulde V118-arkiv følger i `history/`.

Kontraktens stop ved celle 245 er nået. Resultatindtag og routing skal
optage den afgrænsede nye fortsættelse én gang og forberede næste faste
kontrakt. Den umiddelbart følgende V62-celle 246 har kun HMLA tilladt;
V91 er det historiske grundlag for de efterfølgende fælles grenfelter.
Næste kontrakt må først fastlægge et større q/16-domæne efter kontrol
af de konkrete arkivpræmisser. Ingen optisk værdi eller større
q/16-rækkevidde må udledes ved blot at flytte versionsnummeret.
De faktiske native historier og deres samlede numeriske fejl er
fortsat afgørende for afslutning af hovedspørgsmålet.
