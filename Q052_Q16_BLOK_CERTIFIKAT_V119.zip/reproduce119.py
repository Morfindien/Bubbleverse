"""Optional new numerical replay in a fresh directory; not executed by V119 production."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from tempfile import TemporaryDirectory
import json,shutil,subprocess,sys
P=Path(__file__).resolve().parent
manifest=json.loads((P/'manifest119.json').read_bytes())
for r in manifest['members']:
 p=P/r['path'];assert p.stat().st_size==r['size_bytes'] and sha256(p.read_bytes()).hexdigest()==r['sha256'],r['path']
with TemporaryDirectory(prefix='q052_v119_replay_') as tmp:
 target=Path(tmp)
 for name in ['calc','runtime','input']:
  shutil.copytree(P/name,target/name,ignore=shutil.ignore_patterns('__pycache__'))
 for name in ['run119.py','preflight114.py','input_check119.json','validate119.py']:
  shutil.copy2(P/name,target/name)
 result=subprocess.run([sys.executable,str(target/'run119.py')],cwd=target)
 assert result.returncode==0
 result=subprocess.run([sys.executable,str(target/'validate119.py')],cwd=target)
 assert result.returncode==0
 compared=[]
 for p in sorted((P/'receipts').glob('*.json')):
  expected=json.loads(p.read_bytes());actual=json.loads((target/'receipts'/p.name).read_bytes())
  expected.pop('runtime');actual.pop('runtime')
  assert actual==expected,p.name;compared.append(p.name)
 print(json.dumps({'status':'PASS','compared_scientific_receipts':compared,'new_reproduction':True,'original_history_modified':False},indent=2))
