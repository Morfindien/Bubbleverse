"""Separate new-domain checker: integer hex parsing, a-density, Decimal roots."""
from pathlib import Path
from fractions import Fraction as R
from decimal import Decimal,localcontext
from collections import defaultdict
import json,hashlib,time
P=Path(__file__).resolve().parent
def load(n):return json.loads((P/n).read_bytes())
def hexrat(s):
 sign=-1 if s.startswith('-') else 1
 significand,power=s.lstrip('+-').lower().split('p');digits=significand[2:].split('.')
 fractional=digits[1] if len(digits)>1 else '';integer=int(digits[0]+fractional,16);exponent=int(power)-4*len(fractional)
 return sign*R(integer)*R(2)**exponent
def sqrtbox(x):
 with localcontext() as ctx:
  ctx.prec=100;y=(Decimal(x.numerator)/Decimal(x.denominator)).sqrt();lo,hi=R(y-Decimal('1e-85')),R(y+Decimal('1e-85'))
 assert 0<=lo and lo*lo<=x<=hi*hi,'square-root enclosure'
 return lo,hi

def validate(deadline):
 for n,h in load('input_pins107.json').items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
 barrier=load('barrier107.json')
 assert hashlib.sha256((P/'barrier107.json').read_bytes()).hexdigest()=='f9c7e79852097535ec48cbfcc3afa2a1824de9f8d9c4da097190c7ce173cd7b5'
 domains={x['V62_row']:tuple(map(R,reversed(x['z_descending']))) for x in barrier['source_rows']}
 r=load('result_raw_recovery.json');task=load('task106.json');anchor=load('result105.json')
 recovery=load('Q052_MATEMATIKOPGAVE_V108.json')
 assert r['barrier_sha256']==hashlib.sha256((P/'barrier107.json').read_bytes()).hexdigest()
 assert r['task_fingerprint']==recovery['fingerprint_sha256'] and r['task_id']==recovery['task_id'] and r['exact_question']==task['exact_question']
 assert anchor['anchor_z800_gate']=='PASS' and anchor['checkpoint']['certified_end_a']=='1/801'
 ec_anchor=R(anchor['checkpoint']['energy_endpoint'][1]);assert R(r['scalar_anchor_energy_upper'])==ec_anchor
 bg=load('capture.json')['cases']['hillipop-ede_n3']['background'];f={k:hexrat(v) for k,v in bg['fields'].items()}
 nu=bg['neutrinos'][0];nf={k:hexrat(v) for k,v in nu['fields'].items()};qs=list(map(hexrat,nu['q_ncdm_bg']));ws=list(map(hexrat,nu['w_ncdm_bg']))
 assert len(qs)==len(ws)==r['neutrino_nodes']==11 and all(x>0 for x in qs+ws)
 guard=load('guard.json')['evaluators'][0]['rows'];bind=load('binding.json');bindings={x['source_guard_index']:x for x in bind['cells']}
 floorlo,floorhi=map(R,r['scalar_floor_interval']);srcfloor=load('guard.json')['source_intervals']
 assert floorlo==R(srcfloor['floorlo']) and floorhi==R(srcfloor['floorhi'])
 c=load('audit98.json')['optical_constant_inputs'];kl=R(c['nH0_m_minus3_exact'])*R(c['sigma_m2']['exact'][0])*R(c['Mpc_m']['exact'][0]);ku=R(c['nH0_m_minus3_exact'])*R(c['sigma_m2']['exact'][1])*R(c['Mpc_m']['exact'][1])
 assert list(map(R,r['optical_K_inverse_Mpc']))==[kl,ku]
 assert [-3+2+1,-1-(-1)]==[0,0]
 cache={}
 def density(a):
  if a not in cache:
   ordinary=f['H0']**2*((f['Omega0_b']+f['Omega0_cdm'])/a**3+(f['Omega0_g']+f['Omega0_ur'])/a**4);lo=hi=R(0)
   for node,weight in reversed(list(zip(qs,ws))):
    l,u=sqrtbox(node**2+(nf['M_ncdm']*a)**2);lo+=node**2*weight*l;hi+=node**2*weight*u
   factor=nf['factor_ncdm']/a**4;cache[a]=ordinary+factor*lo,ordinary+factor*hi
  return cache[a]
 sources=load('v66.json')['source_segments'];expected=[];old_upper=R(0);old_rows=0
 for idx,src in enumerate(sources):
  left,right=max(R(700),R(src['z'][0])),min(R(750),R(src['z'][1]))
  if left>=right:continue
  assert src['origin']=='V62';old_rows+=1
  old_upper+=R((R(src['K_over_H_exact'][1])*R(1,1000000)*((right-left)+(right**2-left**2)+(right**3-left**3)/3)*2**100).__ceil__(),2**100)
  for gidx in range(74,69,-1):
   gl,gu=R(guard[gidx]['z1']),R(guard[gidx]['z0']);a,b=max(left,gl),min(right,gu)
   if a<b:expected.append((idx,gidx,a,b))
 expected.sort(key=lambda x:x[2]);assert len(expected)==len(r['cells'])==r['subcells']==106 and old_rows==r['source_rows']==102
 assert list(map(R,r['prior_block_interval']))==[R(0),old_upper]==list(map(R,task['tolerances']['prior_block_interval']))
 groups=defaultdict(lambda:[R(0)]*6);cursor=R(700);max_bgap=max_wgap=R(0);capfractions=[]
 for expected_cell,row in zip(expected,r['cells']):
  assert time.monotonic()<deadline
  idx,gidx,left,right=expected_cell;assert (row['V66_row'],row['guard_row'],*map(R,row['z']))==expected_cell and left==cursor;cursor=right
  dl,du=domains[row['V62_row']];assert dl<=left<right<=du
  assert row['background_dependency_id']==bind['background_dependency_id']==task['frozen']['background_dependency_id']
  ec=min(R(guard[gidx]['E_input_left']),ec_anchor);assert R(row['scalar_energy_cap'])==ec
  bl,bu=map(R,row['B0_box']);dll,dlu=density(1/(1+left));dul,duu=density(1/(1+right))
  assert bl<=dll<=dlu and dul<=duu<=bu;max_bgap=max(max_bgap,dlu-bl,bu-dul)
  assert dlu-bl<R(1,2**140) and bu-dul<R(1,2**140)
  hll,hlu=sqrtbox(dll+floorlo/3);hul,huu=sqrtbox(duu+(ec+floorhi)/3);guardlo,guardhi=map(R,bindings[gidx]['H'])
  ihl,ihu=max(hll,guardlo),min(huu,guardhi);hl,hu=map(R,row['H_box']);assert 0<hl<=ihl<=ihu<=hu
  assert ihl-hl<R(1,2**140) and hu-ihu<R(1,2**140)
  assert list(map(R,row['H_squared_raw']))==[bl+floorlo/3,bu+(ec+floorhi)/3]
  wrlo,wrhi=map(R,row['weight_raw']);assert wrlo<=kl/ihu and ku/ihl<=wrhi
  max_wgap=max(max_wgap,kl/ihu-wrlo,wrhi-ku/ihl);assert kl/ihu-wrlo<R(1,2**140) and wrhi-ku/ihl<R(1,2**140)
  oldlo,oldhi=map(R,sources[idx]['K_over_H_exact']);wl,wu=map(R,row['weight_intersection'])
  assert [wl,wu]==[max(wrlo,oldlo),min(wrhi,oldhi)] and 0<wl<=wu
  assert list(map(R,row['electron_interval']))==[R(1,2000000),R(1,1000000)]
  elo,ehi=map(R,sources[idx]['dx_exact']);assert elo<=0<R(1,2000000)<R(1,1000000)<=ehi
  mass=(right-left)+(right**2-left**2)+(right**3-left**3)/3;assert R(row['cubic_mass'])==mass
  el,eu=wl*mass/2000000,wu*mass/1000000;lo,hi=map(R,row['increment'])
  assert lo<=el<=eu<=hi and el-lo<R(1,2**100) and hi-eu<R(1,2**100)
  assert (lo*2**100).denominator==(hi*2**100).denominator==1
  g=groups[gidx]
  for i,x in enumerate([el,eu,lo,hi,(wu-wl)*mass*R(3,4000000),(wu+wl)*mass*R(1,4000000)]):g[i]+=x
  capfractions.append(ec/(3*bu))
 assert cursor==750 and len(groups)==5
 el,eu,lo,hi,ww,ew=[sum(g[i] for g in groups.values()) for i in range(6)];assert eu-el==ww+ew
 assert list(map(R,r['block_interval']))==[lo,hi] and R(r['block_width'])==hi-lo
 assert R(r['width_accounting']['weight_factor_enclosure'])==ww and R(r['width_accounting']['electron_enclosure'])==ew
 assert R(r['width_accounting']['outward_increment_rounding'])==hi-lo-ww-ew
 ceiling=3*old_upper/4;assert R(r['block_width_ceiling'])==ceiling==R(task['tolerances']['block_width_ceiling'])
 assert r['target_met']==(hi-lo<=ceiling) and r['block_method_target']==('PASS' if hi-lo<=ceiling else 'FAIL_25_PERCENT_WIDTH_TARGET')
 assert R(r['block_width_reduction_fraction'])==1-(hi-lo)/old_upper
 assert 0<=lo<hi<=old_upper
 oldglobal=list(map(R,task['tolerances']['V105_global_interval']));newglobal=[oldglobal[0]+lo,oldglobal[1]-old_upper+hi]
 assert list(map(R,r['new_global_interval']))==newglobal and R(r['global_width'])==newglobal[1]-newglobal[0]
 assert R(r['global_width_reduction_fraction'])==1-(newglobal[1]-newglobal[0])/(oldglobal[1]-oldglobal[0])
 assert R(r['global_width_goal_ratio'])==R(r['global_width'])/R(task['tolerances']['provisional_full_width_goal'])
 assert r['global_width_goal_met']==(R(r['global_width'])<=R(task['tolerances']['provisional_full_width_goal']))
 assert list(map(R,r['scalar_cap_over_three_B0_range']))==[min(capfractions),max(capfractions)]
 oldbins=load('budget106.json')['current_bins'];newbins=r['current_bins']
 assert set(oldbins)==set(newbins)
 assert all(oldbins[k]==newbins[k] for k in oldbins if k!='700:750')
 assert [sum(R(v[i]) for v in newbins.values()) for i in [0,1]]==newglobal
 assert r['new_scalar_integrations']==r['new_native_pairs']==r['new_full_history_integrations']==0 and r['new_domain_optical_evaluations']==1
 return {'status':'PASS','independence':'No import of producer. Separate integer-hex parser, reuse of the immutable V107 barrier domain, a-coordinate density, reversed neutrino nodes, Decimal-root brackets checked by exact squaring, expanded polynomial masses and guard-grouped rational sums. Shares inherited physical premises and symbolic V97 proof.',
  'barrier_rows':102,'source_rows':102,'subcells':106,'distinct_density_endpoints':len(cache),'guard_groups':5,'nodes_per_density':11,
  'exact_unrounded_block':list(map(str,[el,eu])),'exact_weight_width':str(ww),'exact_electron_width':str(ew),'method_target_met':hi-lo<=ceiling,
  'max_B0_enclosure_slack':str(max_bgap),'max_weight_enclosure_slack':str(max_wgap),'old_pilot_and_other_bins_unchanged':True,
  'grouped_sums':{str(k):list(map(str,v)) for k,v in sorted(groups.items())}}
