"""Single bounded run; inclusive producer and independent-control clock."""
import time
started=time.monotonic()
from datetime import datetime,timezone
from pathlib import Path
import json,sys,platform,hashlib,traceback
P=Path(__file__).resolve().parent
stamp=datetime.now(timezone.utc).isoformat()
task=json.loads((P/'Q052_MATEMATIKOPGAVE_V108.json').read_text())
identity={k:v for k,v in task.items() if k!='fingerprint_sha256'}
assert hashlib.sha256(json.dumps(identity,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()==task['fingerprint_sha256']
limit=task['execution_limits']['first_prototype_wall_seconds']
# Atomically reserve this fresh working directory before any optical work.
with (P/'recovery_run.lock').open('x') as lock:
 lock.write(task['fingerprint_sha256']+'\n')
deadline=started+limit
execution={'task_fingerprint':task['fingerprint_sha256'],'start_utc':stamp,'prototype_limit_seconds':limit,'clock_scope':'Includes imports, new-domain premise checks, one optical evaluation and separate control. Extraction and packaging excluded.',
 'new_scalar_integrations':0,'new_native_pairs':0,'new_full_history_integrations':0,'new_domain_optical_evaluations':0,'python':sys.version,'platform':platform.platform()}
try:
 from compute_recovery import main
 from control_recovery import validate
 r=main(deadline);execution['new_domain_optical_evaluations']=1
 check=validate(deadline)
 (P/'control_recovery.json').write_text(json.dumps(check,ensure_ascii=False,indent=2)+'\n')
 assert time.monotonic()<deadline
 execution.update({'technical_state':'PASS','method_target':r['block_method_target'],'stop_reason':'FIRST_BOUNDED_NEW_DOMAIN_EVALUATION_AND_CONTROL_COMPLETE','barrier_status':'PASS_CONDITIONAL_HALF_Q_EXTENSION'})
except Exception as e:
 execution.update({'technical_state':'FAIL','stop_reason':'FIRST_UNRESOLVED_PREMISE_OR_EXECUTION_FAILURE','exception_type':type(e).__name__,'exception':str(e),'traceback':traceback.format_exc()})
 raise
finally:
 if (P/'attempt_progress_recovery.json').exists():
  execution['new_domain_optical_evaluations']=json.loads((P/'attempt_progress_recovery.json').read_text())['evaluations_started']
 execution['wall_seconds']=time.monotonic()-started;execution['end_utc']=datetime.now(timezone.utc).isoformat()
 execution['code_sha256']={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in ['run_recovery.py','compute_recovery.py','control_recovery.py']}
 execution['output_sha256']={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in ['barrier107.json','attempt_progress_recovery.json','candidate_cells_recovery.json','result_raw_recovery.json','control_recovery.json'] if (P/n).exists()}
 (P/'execution_recovery.json').write_text(json.dumps(execution,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(execution,ensure_ascii=False,indent=2))
