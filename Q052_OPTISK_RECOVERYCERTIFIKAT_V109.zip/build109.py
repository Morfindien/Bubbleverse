from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256,sha1
from datetime import datetime,timezone
from zipfile import ZipFile,ZIP_DEFLATED
import json,sys,subprocess,io

P=Path(__file__).resolve().parent;ROOT=P.parents[1];U=ROOT/'upload';I=P/'input108';C=I/'recovery_work/calc'
O=ROOT/'output/V109';O.mkdir(parents=True,exist_ok=True)
short,journal,taskfile,cert=names=['Q052_KORT_RESULTAT_V109.md','Q052_MATEMATIK_OG_SAMLET_JOURNAL_V109.md','Q052_RESULTATINDTAG_OPGAVE_V109.json','Q052_OPTISK_RECOVERYCERTIFIKAT_V109.zip']
parent='Q052_INGESTION_CERTIFICATE_V108.zip';parentjournal='Q052_INGESTION_OG_SAMLET_JOURNAL_V108-1.md'
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:sha256(b).hexdigest()
dump=lambda x:(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
fp=lambda x:sha(json.dumps({k:v for k,v in x.items() if k!='fingerprint_sha256'},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
ref=lambda n:cert+'#'+n
hist=lambda n:ref('history/'+parent+'#'+n)
t=read(U/'Q052_MATEMATIKOPGAVE_V108.json');r=read(C/'result_raw_recovery.json');e=read(C/'execution_recovery.json');control=read(C/'control_recovery.json')
prior=read(I/'activity_ledger.json');repo=read(P/'repository_snapshot.json');context=read(P/'repository_context.json')
assert not repo['truncated'] and fp(t)==t['fingerprint_sha256']==r['task_fingerprint']==e['task_fingerprint']
assert e['technical_state']==e['method_target']==control['status']==r['block_method_target']=='PASS'
assert e['new_domain_optical_evaluations']==1 and all(e[k]==0 for k in ['new_scalar_integrations','new_native_pairs','new_full_history_integrations'])
assert e['wall_seconds']<t['execution_limits']['first_prototype_wall_seconds']==300
for n,h in t['recovery_code_sha256'].items():assert sha((C/n).read_bytes())==h==e['code_sha256'][n]
for n,h in e['output_sha256'].items():assert sha((C/n).read_bytes())==h
for n,h in read(C/'input_pins107.json').items():assert sha((C/n).read_bytes())==h
attachments=['Q052_KORT_RESULTAT_V108-1.md','Q052_MATEMATIKOPGAVE_V108.json',parent,parentjournal,'Bubbleverse_Matematikmotor_2.3.0-58.md']
for n in attachments[:4]:
 b=(U/n).read_bytes();assert sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()==repo['paths'][n]
assert sha((U/attachments[-1]).read_bytes())==t['engine_prompt_sha256']
assert sum(x['run_points'] for x in prior['entries'])==prior['total_points_after']==13755 and not prior['pending_packages']
run='LOCAL-Q052-OPTICAL-RECOVERY-700-750-V109';event='Q052-ACTIVITY-OPTICAL-RECOVERY-V109';stamp=datetime.now(timezone.utc).isoformat()
breakdown={'ANALYSIS_POINTS':20,'COMPUTATION_POINTS':15,'SEARCH_POINTS':5,'VALIDATION_POINTS':30}
points=sum(breakdown.values());total=prior['total_points_after']+points;nextmilestone=1000*(total//1000+1);remaining=nextmilestone-total
basis={'ANALYSIS_POINTS':'Fortolkning af det nye optiske interval, eksakt blokudskiftning og adskillelse af teknisk PASS, metodekriterium og åbent hovedspørgsmål.',
 'COMPUTATION_POINTS':'Ét faktisk rettet forsøg: 102 kilderækker, 106 delceller, 107 tæthedsendepunkter og 11 neutrinoknuder; eksisterende kode genbrugt.',
 'SEARCH_POINTS':'Målrettet GitHub-provenance: fire V108-filer, begge motorer og relevante README-/registry-poster; ingen ny litteratursøgning.',
 'VALIDATION_POINTS':'Ny separat optisk kontrol med a-koordinat, heltals-hexparser, Decimal-rodintervaller kontrolleret ved eksakt kvadrering og grupperede summer.',
 'policy':'Afrundet heuristisk aktivitetsvurdering, ikke en måling af credits eller procent færdiggørelse. V107-beviset, V108-kodeforberedelsen, pakning og filgenlevering tælles ikke igen.'}
assert event not in [x.get('activity_event_id',x['run_id']) for x in prior['entries']]
entry={'activity_event_id':event,'run_id':run,'engine':t['engine'],'run_points':points,'breakdown':breakdown,'basis':basis,'counted_once':True,'assessment_type':'HEURISTIC_DOCUMENTED_ACTIVITY_INDEX'}
ledger={**prior,'entries':prior['entries']+[entry],'previous_ledger_ref':hist('activity_ledger.json'),'previous_total_points':13755,'total_points_after':total,
 'cycle_progress':total%1000,'next_publication_at':nextmilestone,'points_to_next_publication':remaining,'new_milestones':[],
 'ledger_revision':'V109','parent_ledger_sha256':sha((I/'activity_ledger.json').read_bytes()),'last_updated_utc':stamp,'note':basis['policy'],
 'reconciliation':{'prior_total':13755,'new_unique_event_points':points,'current_total':total,'old_entries_preserved':True}}
assert total//1000==13755//1000
widths=sorted([{'bin':k,'interval':v[:2],'width':str(F(v[1])-F(v[0])),'contribution_fraction':str((F(v[1])-F(v[0]))/F(r['global_width']))} for k,v in r['current_bins'].items()],key=lambda x:-F(x['width']))
remaining_uncertainties=['Global source-only optical precision: width remains above provisional 4e-9 goal.',
 'Native CLASS/P6 background membership and common-background identity.',
 'Native/source coordinate and trajectory consistency, reproducibility and validated whole-history numerical error.']
result={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','result_id':run,'created_at_utc':stamp,
 **{k:t[k] for k in ['case_id','current_q','target_q','exact_question','source_commit','capture_sha256']},
 'input_task_id':t['task_id'],'input_task_fingerprint':t['fingerprint_sha256'],'technical_state':'PASS','scientific_state':'INCONCLUSIVE',
 'local_result_state':'SUPPORTED_WITHIN_CONDITIONAL_SOURCE_REAL_DOMAIN','method_target':'PASS','native_certificate_state':'OPEN','completion_gate_satisfied':False,
 'optical_result':{k:v for k,v in r.items() if k not in ['cells','technical_state']},
 'raw_result_ref':ref('calc/result_raw_recovery.json'),'raw_result_sha256':sha((C/'result_raw_recovery.json').read_bytes()),
 'independent_control_ref':ref('calc/control_recovery.json'),'independent_control_status':control['status'],
 'execution_ref':ref('calc/execution_recovery.json'),'runtime_seconds':e['wall_seconds'],'attempts':1,
 'inherited_half_q_barrier_ref':ref('calc/barrier107.json'),'inherited_half_q_barrier_recomputed':False,
 'remaining_uncertainties':remaining_uncertainties,'resolved_blocker':'V107 optical order/counter failure; corrected V108 implementation completes and passes control.',
 'blocker_id':'LOCAL-Q052-GLOBAL-PRECISION-AND-NATIVE-CERTIFICATE-OPEN-V109','historical_failure_preserved':hist('history/Q052_DELCERTIFIKAT_OG_FEJLDIAGNOSE_V107.zip'),
 'accepted_source_optical_candidate':'V109; ready for the explicit result-ingestion decision','last_previously_ingested_optical_state':'V105',
 'scope_warning':'Deterministic conditional enclosure of literal source-real accumulation. Not a measured native value, statistical confidence interval or physical confirmation.'}
result_hash=sha(dump(result))
ingestion_prompt=U/'Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0-51.md'
intake={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','task_id':'LOCAL-Q052-V109-OPTICAL-RESULT-INTAKE','engine':'BUBBLEVERSE.RESULT_INGESTION_ROUTING 2.3.0',
 'engine_prompt_sha256':sha(ingestion_prompt.read_bytes()),'state':'PREPARED_NOT_EXECUTED',
 **{k:t[k] for k in ['case_id','current_q','target_q','exact_question','source_commit','capture_sha256']},
 'input_certificate':cert,'input_result_ref':ref('result109.json'),'input_result_sha256':result_hash,'input_task_fingerprint':t['fingerprint_sha256'],
 'objective':'Admit the independently checked conditional [700,750] optical result and exact global-bin replacement; reconcile remaining width and native-certificate obligations and prepare one bounded next mathematics task.',
 'required_actions':[
 'Verify manifest, exact V108 journal prefix, source/background/task/code identities, one-attempt receipt and independent optical PASS. No scientific rerun is needed for authentic unchanged inputs.',
 'Admit only the conditional source-real block interval and global replacement in result109.json. Preserve the V105 [750,800] pilot and all other bins byte-for-byte at their existing records.',
 'Carry the V107 failed attempt and V108 repair record unchanged. V109 supplies the first validated optical result for the repaired task; do not relabel the original failed attempt.',
 'Use the stored bin ledger to rank remaining width. The largest block is [600,650], followed by [650,700]; the current strict half-q seed reaches z=700 only.',
 'Define one finite next task that checks how far the inherited half-q proof can extend continuously below z=700 using the archived whole-cell SWIFT/cold-rate premises and shared trajectory. Identify the first actual premise obstruction; do not assume a bound below z=700, jump to [600,650] without a certified bridge or silently restart cells.',
 'Prefer a justified contiguous multi-bin task over automatic 50-redshift repetition. Freeze the exact domain, criterion, shared input hashes and one-evaluation/control limit before any new optical execution; preserve mixed-branch and native obligations.',
 'Carry all activity and delivered-milestone records; Q052 stays open. No new native pair, scalar integration, grid search or full-history run belongs to this intake.' ],
 'execution_limits':{'new_optical_evaluations':0,'new_scalar_integrations':0,'new_native_pairs':0,'new_full_history_integrations':0},
 'acceptance_criteria':'Authentic finite result, exact 106-cell cover, independent agreement, fixed 25% screen met, unchanged other bins and one executable next task that addresses a remaining uncertainty.',
 'rejection_criteria':'Input, dependency, interval containment or control conflict blocks the affected promotion; preserve the candidate and unaffected historical evidence.',
 'inconclusive_criteria':'A valid conditional optical result does not settle native history or the provisional global precision goal.',
 'stop_condition':'One ingestion decision and one frozen next-task handoff; no additional scientific execution in this intake.',
 'no_repeat':t['no_repeat']+['V109 corrected 106-subcell optical result and independent numerical control on unchanged inputs.','V109 packaging and stored-arithmetic verification do not count as another scientific run.'],
 'continue_same_q':True,'activity_ledger_ref':ref('activity_ledger.json'),'total_points':total,'next_milestone':nextmilestone,'points_to_next_publication':remaining,
 'remaining_width_ref':ref('width_budget109.json'),'resume_condition':'Read and accept or reject the preserved result; freeze a genuinely new domain or proof question before new mathematics.'}
intake['fingerprint_sha256']=fp(intake)
claims=[{'claim_id':'Q052-V109-C1','claim':'The conditional optical contribution over [700,750] lies in the exact block interval in result109.json.','evidence':[ref('calc/result_raw_recovery.json'),ref('calc/control_recovery.json')],'scope':'Fixed admitted common background and inherited source-real half-q premises.'},
 {'claim_id':'Q052-V109-C2','claim':'The block width is reduced by approximately 51.0421%; the preregistered 25% method threshold passes.','evidence':[ref('result109.json'),ref('calc/control_recovery.json')]},
 {'claim_id':'Q052-V109-C3','claim':'Replacing only this block reduces the conditional global width by approximately 4.44695%. All other bins are unchanged.','evidence':[ref('result109.json'),ref('width_budget109.json')]},
 {'claim_id':'Q052-V109-C4','claim':'Q052 is still inconclusive; source optical precision and native whole-history certification remain open.','evidence':[ref('result109.json')]}]
setup={'current':'Codex Work Mode; Python 3.12.14, rational/Decimal arithmetic, local files and read-only GitHub connector used.',
 'recommended':'Continue the bounded archive intake in this setup; no additional compute is justified for ingestion.',
 'availability':'VERIFIED_AVAILABLE for executed capabilities','capability_classes':['H','A','C'],'reasoning_level':'UNKNOWN_NOT_ASSERTED',
 'rationale':'The one optical run and separate control finished in under one second; evidence linkage is now the relevant task.',
 'fallback':'Use the self-contained certificate with a Python 3 environment; no native CLASS binary needed for this certificate.',
 'upgrade_trigger':'A concrete validated full-history or source/native identity task exceeds measured local capacity.',
 'downgrade_trigger':'After authenticity and arithmetic are settled, use simple file review for ingestion.',
 'tools':'Local Python and GitHub reads used. No agents, external simulations, paid jobs or GitHub writes.'}
audit={'status':'PASS','created_at_utc':stamp,'input_manifest_members_verified':18,'restored_input_files':39,'scientific_input_hashes_verified':read(C/'input_pins107.json'),
 'attached_files':[{'filename':n,'bytes':(U/n).stat().st_size,'sha256':sha((U/n).read_bytes())} for n in attachments],
 'repository_head':repo['head'],'repository_read_state':'VERIFIED_V108_FOUR_GIT_BLOBS_AND_BOTH_ENGINE_BLOBS','repository_context_ref':ref('repository_context.json'),
 'journal_alias':'Supplied and GitHub -1.md names are byte-identical to V108 manifest canonical .md deliverables.',
 'code_hashes':e['code_sha256'],'output_hashes':e['output_sha256'],'runtime_inventory':setup,
 'input_checks':'18 V108 member hashes and ZIP CRC, three external V108 deliverable hashes, prompt hash, predecessor journal prefix, task fingerprint, original input pins, source/background identity, code pins and partition identity.',
 'execution_counts':{k:e[k] for k in ['new_scalar_integrations','new_native_pairs','new_full_history_integrations','new_domain_optical_evaluations']}}
memory={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','q':'Q052','run_id':run,'prompt_id':'BUBBLEVERSE.MATHEMATICS','prompt_version':'2.3.0','prompt_sha256':t['engine_prompt_sha256'],
 'repository_url':'https://github.com/Morfindien/Bubbleverse','branch':'main','base_commit_sha':repo['head'],'source_journal':parentjournal,'journal_path':journal,
 'main_question':t['exact_question'],'GITHUB_READ_STATE':'VERIFIED','GITHUB_WRITE_STATE':'READY_FOR_MANUAL_UPLOAD','new_commit_sha':None,
 'workflow_state':'READY_FOR_HANDOFF','scientific_state':'INCONCLUSIVE','technical_state':'PASS','new_information':'First independently controlled optical result for corrected [700,750] task; 51.04% block and 4.45% global width reductions.',
 'claims_ref':ref('claim_map.json'),'result_ref':ref('result109.json'),'units':'Dimensionless optical depths and electron fractions; z dimensionless.',
 'run_points':points,'total_points':total,'points_basis':basis,'previous_points_entry':prior['entries'][-1]['run_id'],'ledger_ref':ref('activity_ledger.json'),
 'new_milestones':[],'pending_packages':[],'delivered_milestone_ids':prior['delivered_milestone_ids'],'next_publication':nextmilestone,'points_to_next_publication':remaining,
 'external_publication_status':'NOT_POSTED','blocker_id':result['blocker_id'],'completed_tests':[t['task_id']],'no_repeat':intake['no_repeat'],
 'next_engine':intake['engine'],'next_task':taskfile,'resume_condition':intake['resume_condition'],
 'proposed_files':[{'path':n,'role':role,'operation':'ADD','hash_ref':ref('manifest.json')} for n,role in zip(names,['primary_handoff','full_cumulative_journal','next_intake_task','self_contained_certificate'])],
 'index_updates':[{'path':'README.md','action':'Proposed append/prepend current Q052 research pointer to V109 after all files are verified; retain historical launcher text.'},
 {'path':'bubbleverse_program_registry.json','action':'Do not change or dispatch the historical executable targets for this archival mathematical result. Any later research pointer must be explicit and must not imply native completion.'}],
 'related_evidence':['Q051 analytic bounds inherited through Q052','Q050 common background identity inherited','Q052 V97/V105/V107/V108'],
 'upload_instructions_ref':ref('README.md')}
handoff={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','prompt_id':'BUBBLEVERSE.MATHEMATICS','prompt_version':'2.3.0','handoff_id':run,'created_at_utc':stamp,
 **{k:t[k] for k in ['case_id','current_q','target_q','exact_question','source_commit','capture_sha256']},
 'authorized_q_range':['Q052'],'evidence_boundary':'Q052 V108 and its pinned predecessor evidence; no later-Q scientific evidence.',
 'workflow_state':'READY_FOR_HANDOFF','scientific_state':'INCONCLUSIVE','technical_state':'PASS','case_lifecycle':'ACTIVE','disposition':'CONTINUE',
 'journal_ref':journal,'journal_version':'V109','journal_completeness':'Full supplied V108 journal retained byte-for-byte as prefix.',
 'result_ref':ref('result109.json'),'proof_ref':ref('PROOF_V109.md'),'run_manifest_ref':ref('calc/execution_recovery.json'),'integrity_manifest_ref':ref('manifest.json'),
 'claim_refs':[c['claim_id'] for c in claims],'source_register_ref':ref('source_register.json'),'completed_tests':[t['task_id']],
 'new_information_this_round':memory['new_information'],'blocker_id':result['blocker_id'],'blocker_description':remaining_uncertainties,
 'next_engine':intake['engine'],'next_task':taskfile,'next_task_fingerprint':intake['fingerprint_sha256'],
 'acceptance_criteria':intake['acceptance_criteria'],'rejection_criteria':intake['rejection_criteria'],'inconclusive_criteria':intake['inconclusive_criteria'],
 'expected_output_artifact':'One V110 ingestion decision, updated source-only width ledger and frozen next mathematics task.',
 'no_repeat_constraints':intake['no_repeat'],'resume_condition':intake['resume_condition'],'setup_assessment':setup,
 'equations_parameters_units_uncertainty_ref':ref('PROOF_V109.md'),'completion_gate_satisfied':False,'continue_same_q':True,
 'points':{'run_id':run,'previous_entry':prior['entries'][-1]['run_id'],'run_points':points,'total_points':total,'breakdown':breakdown,'basis':basis,'points_state':'VERIFIED','ledger_ref':ref('activity_ledger.json')},
 'publication':{'interval':1000,'cycle_progress':total%1000,'next_milestone':nextmilestone,'points_to_next_publication':remaining,'state':'NOT_DUE','new_milestones':[],'pending_packages':[],'delivered_milestone_ids':prior['delivered_milestone_ids']},
 'delivery_files':names,'github_memory_update_ref':ref('github_memory_update.json'),'GITHUB_READ_STATE':'VERIFIED','GITHUB_WRITE_STATE':'READY_FOR_MANUAL_UPLOAD',
 'contract_validation':'MANUAL_LOCAL_CONTRACT and automated integrity/stored-arithmetic checks; no external formal schema claimed.'}

proof=r'''# Q052 V109 · Kontrolleret optisk resultat

## Resultat og betingelser

Det ene rettede forsøg fra V108 er udført, og den separate optiske kontrol består. Fysisk domæne, deling, kilde, konstanter, baggrundsidentitet og 25 %-kriterium er fastholdt. V107's fejlede forsøg bevares i historikarkivet; det nye resultat er en særskilt V109-kørsel.

Resultatet gælder kildeligningernes baner under den fælles, på forhånd tilladte baggrund B★, kildecommit `5a131c91d657dd9a7c6364cc45b038710f8d0d97`, modellen hillipop-ede_n3 og matchede startdata ved z=810. Det er et deterministisk indhyllingsinterval, ikke en statistisk usikkerhed, native observation eller modelbekræftelse.

Den arvede halv-q-sætning giver q/2 < E(z)=ΔX_e(z) < q med q=10^-6 på [700,750]. Bevis og anvendelighedskontrol fra V107 er hashbundet og genbrugt, ikke genberegnet. V97 giver samme betingede grænse på [750,800]. Intet nyt elektronforløb startes ved z=750 eller ved delcellegrænser.

## Integral, enheder og vægte

Definér det betingede akkumulerede kildebidrag

F(Z) = ∫₀ᶻ K (1+z)² E(z) / H_B(z) dz,

hvor K=n_H0 σ_T Mpc_m. n_H0 er i m^-3, σ_T i m², Mpc_m i meter per Mpc, K og CLASS' H_B i Mpc^-1; W=K/H_B, z, E og F er dimensionsløse. Der indsættes ingen ekstra lyshastighed i den fastholdte CLASS-konvention.

På hver [a,b] er massen M=((1+b)^3-(1+a)^3)/3 eksakt. Med W∈[W_l,W_u] og E∈[q/2,q] fås bidraget [q W_l M/2, q W_u M], rundet udad til 2^-100-gitter. Intervallets ubetingede fysiske gyldighed påstås ikke: alle tidligere kilde- og baggrundspræmisser er fortsat nødvendige.

Vægtene beregnes med den positive materie-/strålingsdel og alle 11 fastholdte neutrinoknuder. Ved s=1+z bruges den eksakte form B₀(s)=matter·s³+radiation·s⁴+factor·s³ Σ_j q_j² w_j sqrt(q_j²s²+M_nu²). Dette er den samme massefylde som kontrollens a=1/s-form, som evalueres separat. Positivitet giver endepunktsgrænser på hele delcellen.

Skalarenergien opfylder de/dln(a)=-3X²≤0 langs den samme bane. Derfor bruges min(V105's certificerede z=800-energiloft, den tilknyttede historiske guard-cap), sammen med det validerede potentialegulv. Den rå H²-indhylling er [B₀,lower+floor_lower/3, B₀,upper+(energy_cap+floor_upper)/3]. Kvadratrodsintervaller rundes udad på 2^-160-gitter og skæres med den arvede guard-H-indhylling. K/H skæres derefter med hver arkiveret V66-vægt. Ingen interpolation eller gættede vægtprøver indgår.

## Dækning og separat kontrol

102 V66-kilderækker (4642–4743, nulbaseret) afskæres ved 700 og 750 og splittes ved guard-grænserne 710,720,730,740. Det giver præcis 106 delceller uden huller eller overlappende indre. De matcher V108's kanoniske rationelt sorterede deling. V62-rækkerne 118–219 og guard-rækkerne 70–74 er de samme som i opgaven. Pilotintervallet [750,800] bevares; den fælles endepunktsrække afskæres, så ingen indre bidrag dobbelttælles.

Producenten bruger heltalskvadratrod og binære rationelle udadgrænser. Kontrolløren importerer ikke producenten: den parser hex-tal med heltal, omskriver tæthed til a-koordinaten, summerer neutrinoknuder i omvendt rækkefølge, bruger 100-cifret Decimal-kvadratrod med eksakt kvadrering af begge intervalender og grupperer masserne efter de fem guard-intervaller. Den kontrollerer samtlige 106 vægt- og integralindhyllinger samt de 107 tæthedsendepunkter.

Uafhængigheden omfatter numerisk formulering, parser, rødder og summering. Begge implementationer deler den samme arkiverede fysik, V97's symbolske argument, V107-barrieren og Python-rationel aritmetik. Kontrollen er ikke en uafhængig bekræftelse af de underliggende fysiske antagelser eller hele forhistorien.

## Nyt interval og global opdatering

Afrundede visningstal (autoritative eksakte brøker findes i result109.json og calc/result_raw_recovery.json):

| Størrelse | Før | V109 |
|---|---:|---:|
| [700,750]-interval | [0; 3,812360440724·10^-6] | ca. [1,849590008120·10^-6; 3,716040711905·10^-6] |
| Blokbredde | 3,812360440724·10^-6 | 1,866450703785·10^-6 |
| Globalt kildeinterval | ca. [1,948167546682·10^-6; 4,570648398217·10^-5] | ca. [3,797757554802·10^-6; 4,561016425335·10^-5] |
| Global bredde | 4,375831643549·10^-5 | 4,181240669854·10^-5 |

Blokbredden falder 51,0421238284 %, så det forud fastsatte krav om mindst 25 % reduktion består. Den globale bredde falder 4,4469483642 %. Opdateringen er eksakt for hver intervalende: new_global_i = V105_global_i − old_block_i + new_block_i. Kontrolløren efterviser, at alle øvrige bins er uændrede, og at deres sum giver det nye globale interval.

Maksimum ved z=810 for den definerede kildeakkumulation genbruges fra V95's fortegnsresultat. Det søges ikke på ny, og det identificeres ikke med et endnu ucertificeret native maksimum.

## Breddebudget og præcisionsafstand

Produktbredden før afrunding dekomponeres eksakt:

(q W_u − q W_l/2) M = q(W_l+W_u)M/4 + 3q(W_u−W_l)M/4.

Det første led henføres til elektronindhyllingen, det andet til vægtindhyllingen. Summen over delcellerne er henholdsvis ca. 1,853805182036·10^-6 og 1,264552174871·10^-8. Udadrettet inkrementafrunding bidrager ca. 8,678734580724·10^-29. Elektronintervallet står derfor for ca. 99,3225 % af den nye blokbredde. Flere roddecimaler er ikke den væsentlige vej til forbedring her.

Kvadraturresten er nul for den eksakte integration af de omsluttende konstante bokse. Dette er ikke en påstand om et fejlfrit beregnet punktvist elektronforløb; usikkerheden fra de ukendte forløb ligger i boksbredderne.

Det foreløbige globale breddemål er 4·10^-9. Den nye bredde er ca. 10.453,10 gange målet. Dette er et breddeforhold, ikke et estimat af resterende tid, antal runder eller procent færdiggørelse. Native baggrundstilhørsforhold, koordinatsammenfald, reproducerbarhed og fejlcertifikat for hele historien er særskilte, fortsat åbne krav.

De største resterende lagrede breddebidrag er [600,650] og [650,700]. Halv-q-grænsen er aktuelt kun videreført ned til z=700. Et eventuelt nyt domæne skal forbindes kontinuerligt til denne grænse og kontrolleres for samtlige gren-, temperatur-, rate- og baggrundspræmisser. Bredderegistret alene beviser ikke, at metoden gælder der.

## Execution og evidensgrænse

Kørslen brugte præcis én optisk evaluering og én separat kontrol; ingen ny skalarintegration, native par eller fuldhistorieintegration. Forsøget blev markeret før beregningen, og en ukontrolleret kandidat blev skrevet før de afsluttende gates. Den rå kandidat bevarer sin oprindelige status; den nye result109.json sammenfatter den efterfølgende kontrol.

Kilde- og inputhashes, kodehashes, UTC-start/slut, faktisk Python/platform og runtime står i input_audit109.json og calc/execution_recovery.json. Runtime var ca. 0,88346 sekunder, inden for 300 sekunder; udpakning og dokumentation var uden for denne beregningsgrænse. Stopkriteriet var første kontrollerede resultat, så ingen yderligere optisk evaluering blev startet.

Dette opfylder R2 for det udførte forløb og R3 for den særskilt kontrollerede lokale optiske aritmetik, under delte historiske præmisser. Det giver ikke R3 for hele Q052 eller den native implementation.

V108-filerne og begge motorversioner er sammenholdt med GitHub-blobs ved den dokumenterede repository-base. README og launcher-registry beskriver ældre execution-targets; de er ikke bevis for den aktuelle matematiske status eller en ordre om genkørsel. V109 er leveret til manuel upload; ingen GitHub-write eller offentlig postning er udført.
'''
summary=f'''# BUBBLEVERSE — OVERLEVERING

Q052 · V109 · Matematikmotor 2.3.0

**Den rettede optiske kørsel og den separate kontrol bestod. Intervalbredden for z=700–750 faldt 51,04 %; den samlede bredde faldt 4,45 %. Q052 er fortsat åbent.**

## Dokumenteret resultat

Under den fastholdte kilde og fælles tilladte baggrund er bidraget fra z=700–750 cirka [1,849590008120·10^-6; 3,716040711905·10^-6]. Det nye globale kildeinterval er cirka [3,797757554802·10^-6; 4,561016425335·10^-5], dimensionsløst. Eksakte brøker og forudsætninger står i certifikatet.

Præcis 106 delceller blev beregnet og kontrolleret separat. Kravet om mindst 25 % smallere blokinterval bestod. De øvrige blokke, herunder pilotintervallet z=750–800, er uændrede. Det ene forsøg med kontrol tog {e['wall_seconds']:.5f} sekunder inden for loftet på 300 sekunder. V107's halv-q-bevis blev genbrugt.

Den globale bredde er stadig cirka 10.453 gange det foreløbige mål 4·10^-9. Der mangler desuden dokumentation for den faktiske CLASS/P6-histories baggrundsbinding, koordinatsammenfald, reproducerbarhed og numeriske fejl. Breddeforholdet siger ikke, hvor lang tid der er tilbage. Delresultatet er betinget matematisk evidens, ikke en fysisk bekræftelse eller et fuldt native fejlcertifikat.

## Status og næste opgave

TARGET_Q: Q052. WORKFLOW_STATE: READY_FOR_HANDOFF. SCIENTIFIC_STATE: INCONCLUSIVE. TECHNICAL_STATE: PASS. Lokal metodescreen: PASS. CONTINUE_SAME_Q: true.

Næste motor er **Result Ingestion & Routing 2.3.0**. Den skal optage det kontrollerede resultat, opdatere den samlede bredde ved eksakt blokudskiftning og afgrænse én ny opgave for en sammenhængende udvidelse under z=700. Den skal bruge de resterende breddebidrag og faktiske bevispræmisser; intet nyt interval under z=700 er bevist her. Opgaven og accept-/afvisningskriterierne ligger i `{taskfile}`. Genkør ikke det færdige V109-forsøg på uændrede input.

BLOCKER_ID: {result['blocker_id']}.

## Point og udgivelse

RUN_ID: {run}. PREVIOUS_POINTS_ENTRY: {prior['entries'][-1]['run_id']}.

RUN POINTS: {points}. TOTAL POINTS: {total}. CYCLE PROGRESS: {total%1000}/1000. NEXT SOME MILESTONE: {nextmilestone}. POINTS TO NEXT PUBLICATION: {remaining}. POINTS_STATE: VERIFIED. PUBLICATION_STATE: NOT_DUE. PENDING SOME PACKAGES: NONE.

Fordeling: analyse 20, beregning 15, kilde-/provenancearbejde 5, validering 30. Pointene er en begrundet heuristisk aktivitetstæller; tidligere arbejde og fillevering er ikke krediteret igen. Milepæl M001–M013 og alle historiske poster er videreført uændret; ingen ny SoMe-pakke er forfalden.

## Journal, dokumentation og setup

Den fulde modtagne V108-journal er bevaret som eksakt bytepræfiks i `{journal}`, efterfulgt af V109-posten. Hovedspørgsmål, ligninger, antagelser, kildehenvisninger, resultat, kontrol, kode og GitHub-memory-update findes også i `{cert}`. ZIP-filen indeholder de tre øvrige V109-filer.

CHATGPT-SETUPVURDERING: Fortsæt det afgrænsede indtag i det nu anvendte Codex Work Mode med filadgang, Python og GitHub-læsning. Disse funktioner er verificeret gennem brug; et bestemt reasoning-niveau er ikke dokumenteret. Kapabilitetsklasse H/A/C. Fallback er filgennemgang og lokal Python. Eskalér først ved et konkret valideringsproblem eller målt compute-behov; nedskalér til almindelig filkontrol ved ren ingestion. Ingen ekstra model, agent eller HPC-kørsel er nødvendig for næste indtag.

GITHUB_READ_STATE: VERIFIED for V108 og motorversionerne ved `{repo['head']}`. GITHUB_WRITE_STATE: READY_FOR_MANUAL_UPLOAD. Der er ikke skrevet til GitHub i denne runde.

Lokale kontraktfelter, JSON, ZIP-integritet, input-/outputhashes, journalpræfiks, ledger og gemte intervalsummer er kontrolleret. Der påstås ikke validering mod et eksternt formelt schema. Hovedspørgsmålet er bevaret ordret i opgave, resultat, handoff og journalappend.
'''
sources={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','inherited_register_ref':hist('source_register.json'),
 'historical_path_context':'Nested archives keep their original reference context.',
 'new_sources':[{'id':'Q052-V109-S1','kind':'supplied_frozen_task','file':'task108.json','sha256':sha((U/'Q052_MATEMATIKOPGAVE_V108.json').read_bytes())},
 {'id':'Q052-V109-S2','kind':'pinned_primary_source','repository':'https://github.com/mwt5345/class_ede','commit':t['source_commit'],'files':['hyrec.c','thermo.c','background.c','wrap_hyrec.c','hydrogen.h'],'input_hashes_ref':'calc/input_pins107.json'},
 {'id':'Q052-V109-S3','kind':'inherited_conditional_certificate','files':['calc/barrier107.json','calc/result105.json','calc/result97.json'],'restoration':'restore_inputs109.py'},
 {'id':'Q052-V109-S4','kind':'new_computation_and_separate_control','files':['calc/result_raw_recovery.json','calc/control_recovery.json','calc/execution_recovery.json']},
 {'id':'Q052-V109-S5','kind':'repository_provenance','repository':'https://github.com/Morfindien/Bubbleverse','commit':repo['head'],'files':['repository_snapshot.json','repository_context.json']}],
 'no_new_observations':True,'no_external_literature_added':True,'shared_assumptions':control['independence']}
append=f'# Q052 V109 · Kontrolleret optisk genoptagelse\n\nUTC: {stamp}\n\n> {t["exact_question"]}\n\n'+summary+'\n'+proof
for label,obj in [('Resultat',result),('Handoff',handoff),('Næste indtagsopgave',intake),('Claims',claims),('Kilder',sources),('Fuld aktivitetsledger',ledger)]:
 append+='\n## '+label+'\n\n```json\n'+dump(obj).decode()+'```\n'
parent_bytes=(U/parentjournal).read_bytes()
(O/short).write_text(summary);(O/journal).write_bytes(parent_bytes+b'\n\n---\n\n'+append.encode());(O/taskfile).write_bytes(dump(intake))
restore='''from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json,subprocess,sys
P=Path(__file__).resolve().parent
work=P/'restored_v108'
work.mkdir(exist_ok=False)
with ZipFile(P/'history/Q052_INGESTION_CERTIFICATE_V108.zip') as z:
 for n in z.namelist():assert (work/n).resolve().is_relative_to(work.resolve())
 z.extractall(work)
subprocess.run([sys.executable,'prepare_recovery.py'],cwd=work,check=True)
source=work/'recovery_work/calc';target=P/'calc';count=0
for f in source.iterdir():
 if f.is_file():
  out=target/f.name
  if out.exists():assert out.read_bytes()==f.read_bytes(),f.name
  else:out.write_bytes(f.read_bytes());count+=1
for n,h in json.loads((target/'input_pins107.json').read_bytes()).items():assert sha256((target/n).read_bytes()).hexdigest()==h,n
print(json.dumps({'status':'PASS_RESTORED_FROZEN_INPUTS','copied_files':count,'scientific_evaluations':0}))
'''
readme=f'''# V109 · Kontrolleret optisk resultat

Start med `{short}`. ZIP-filen indeholder også den fulde journal og næste indtagsopgave, så én download rummer hele V109-leverancen. `PROOF_V109.md` forklarer beregning og grænser; `result109.json` er den kontrollerede sammenfatning. `calc/result_raw_recovery.json` bevares uændret med sin oprindelige før-kontrol-status. `calc/control_recovery.json` og `calc/execution_recovery.json` dokumenterer den efterfølgende kontrol og det ene forsøg.

Kontrollér pakken uden ny videnskabelig kørsel: `python verify109.py /sti/til/{cert}`. Integritetskontrollen parser JSON, kontrollerer hashes og gemte summer og bekræfter journal- og ledgerbevarelse.

For at genskabe alle frosne beregningsinput i en ny udpakningsmappe: `python restore_inputs109.py`. Den genskaber V108 og dets V107-afhængigheder og kontrollerer inputhashes; den udfører ingen ny optisk beregning. Historisk kode og forsøgslog findes både direkte og i den uændrede indgående pakke. `calc/recovery_run.lock` bevarer den udførte kørsels identitet og spærrer for utilsigtet dobbeltkørsel. En begrundet reproduktion skal bruge en særskilt ny arbejdsmappe og ny execution-provenance; den er ikke en ny forskningsopgave på uændrede input.

V109's matematiske scope er betinget kildeakkumulation. Hovedspørgsmålet er INCONCLUSIVE. Native baggrundsbinding, koordinater, reproducerbarhed og numerisk helhistoriefejl er stadig åbne.

Foreslået GitHub-upload: tilføj de fire ydre V109-filer som nye rodfiler i Morfindien/Bubbleverse. Observeret main: `{repo['head']}`. Genlæs main før upload. Bevar alle tidligere filer. README kan få en eksplicit ny Q052-forskningshenvisning, når alle fire er verificeret. De eksisterende V2/V3-launchertargets i registry må ikke genstartes eller fremstilles som V109-kørslen. Ingen ændring på GitHub er udført her.

Næste motor: Result Ingestion & Routing 2.3.0 med `{taskfile}`. Der er {total} aktivitetspoint og {remaining} til næste SoMe-milepæl. Pakning, restore og integrity-check giver ingen nye forskningspoint. Ingen social postning er udført.
'''
members={'README.md':readme.encode(),'PROOF_V109.md':proof.encode(),'result109.json':dump(result),'handoff109.json':dump(handoff),'activity_ledger.json':dump(ledger),
 'input_audit109.json':dump(audit),'source_register.json':dump(sources),'claim_map.json':dump(claims),'github_memory_update.json':dump(memory),
 'width_budget109.json':dump({'current_bins':r['current_bins'],'global_interval':r['new_global_interval'],'global_width':r['global_width'],'ranked_widths':widths,'scientific_evaluations':0,'method':'Arithmetic on stored endpoints only.'}),
 'task108.json':(U/'Q052_MATEMATIKOPGAVE_V108.json').read_bytes(),'repository_snapshot.json':(P/'repository_snapshot.json').read_bytes(),'repository_context.json':(P/'repository_context.json').read_bytes(),
 'verify109.py':(P/'verify109.py').read_bytes(),'restore_inputs109.py':restore.encode(),'build109.py':Path(__file__).read_bytes(),
 'history/'+parent:(U/parent).read_bytes(),'execution_console109.log':(I/'recovery_console109.log').read_bytes(),
 'prompts/Bubbleverse_Matematikmotor_2.3.0.md':(U/attachments[-1]).read_bytes(),'prompts/Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0.md':ingestion_prompt.read_bytes()}
for n in names[:3]:members[n]=(O/n).read_bytes()
for n in ['run_recovery.py','compute_recovery.py','control_recovery.py','barrier107.json','partition108.json','Q052_MATEMATIKOPGAVE_V108.json','input_pins107.json','attempt_progress_recovery.json','candidate_cells_recovery.json','result_raw_recovery.json','control_recovery.json','execution_recovery.json','recovery_run.lock']:
 members['calc/'+n]=(C/n).read_bytes()
manifest={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','schema':'Q052_V109_OUTPUT_MANIFEST','q':'Q052','version':'V109','case_id':t['case_id'],'run_id':run,'created_at_utc':stamp,
 'base_commit':repo['head'],'result_snapshot_sha256':result_hash,'technical_state':'PASS','scientific_state':'INCONCLUSIVE',
 'parent_journal':{'filename':parentjournal,'bytes':len(parent_bytes),'sha256':sha(parent_bytes),'preservation':'Exact byte prefix'},
 'archive_members':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in members.items()],
 'external_deliverables':[{'filename':n,'bytes':(O/n).stat().st_size,'sha256':sha((O/n).read_bytes()),'target_path':n,'operation':'ADD'} for n in names[:3]],
 'container':{'filename':cert,'target_path':cert,'self_hash_omitted':True},'next_task_fingerprint':intake['fingerprint_sha256']}
with ZipFile(O/cert,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in members.items():z.writestr(n,b)
 z.writestr('manifest.json',dump(manifest))
check=subprocess.run([sys.executable,str(P/'verify109.py'),str(O/cert)],check=True,capture_output=True,text=True)
validation=json.loads(check.stdout)
assert ledger['entries'][:-1]==prior['entries'] and ledger['milestone_records']==prior['milestone_records']
assert result['exact_question']==handoff['exact_question']==intake['exact_question']==t['exact_question']
validation.update({'total_points':total,'points_to_next_milestone':remaining,'files':[{'filename':n,'bytes':(O/n).stat().st_size,'sha256':sha((O/n).read_bytes())} for n in names]})
(P/'delivery_validation109.json').write_bytes(dump(validation))
(P/'upload_request.json').write_bytes(dump({'uploads':[{'local_path':str(O/n),'purpose':'create_library_file','library_artifact_type':'report' if n.endswith('.md') else 'other'} for n in names]}))
print(json.dumps(validation,ensure_ascii=False,indent=2))
