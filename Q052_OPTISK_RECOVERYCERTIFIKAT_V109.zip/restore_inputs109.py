from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json,subprocess,sys
P=Path(__file__).resolve().parent
work=P/'restored_v108'
work.mkdir(exist_ok=False)
with ZipFile(P/'history/Q052_INGESTION_CERTIFICATE_V108.zip') as z:
 for n in z.namelist():assert (work/n).resolve().is_relative_to(work.resolve())
 z.extractall(work)
subprocess.run([sys.executable,'prepare_recovery.py'],cwd=work,check=True)
source=work/'recovery_work/calc';target=P/'calc';count=0
for f in source.iterdir():
 if f.is_file():
  out=target/f.name
  if out.exists():assert out.read_bytes()==f.read_bytes(),f.name
  else:out.write_bytes(f.read_bytes());count+=1
for n,h in json.loads((target/'input_pins107.json').read_bytes()).items():assert sha256((target/n).read_bytes()).hexdigest()==h,n
print(json.dumps({'status':'PASS_RESTORED_FROZEN_INPUTS','copied_files':count,'scientific_evaluations':0}))
