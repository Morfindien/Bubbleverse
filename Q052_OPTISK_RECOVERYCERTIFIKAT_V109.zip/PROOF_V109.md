# Q052 V109 · Kontrolleret optisk resultat

## Resultat og betingelser

Det ene rettede forsøg fra V108 er udført, og den separate optiske kontrol består. Fysisk domæne, deling, kilde, konstanter, baggrundsidentitet og 25 %-kriterium er fastholdt. V107's fejlede forsøg bevares i historikarkivet; det nye resultat er en særskilt V109-kørsel.

Resultatet gælder kildeligningernes baner under den fælles, på forhånd tilladte baggrund B★, kildecommit `5a131c91d657dd9a7c6364cc45b038710f8d0d97`, modellen hillipop-ede_n3 og matchede startdata ved z=810. Det er et deterministisk indhyllingsinterval, ikke en statistisk usikkerhed, native observation eller modelbekræftelse.

Den arvede halv-q-sætning giver q/2 < E(z)=ΔX_e(z) < q med q=10^-6 på [700,750]. Bevis og anvendelighedskontrol fra V107 er hashbundet og genbrugt, ikke genberegnet. V97 giver samme betingede grænse på [750,800]. Intet nyt elektronforløb startes ved z=750 eller ved delcellegrænser.

## Integral, enheder og vægte

Definér det betingede akkumulerede kildebidrag

F(Z) = ∫₀ᶻ K (1+z)² E(z) / H_B(z) dz,

hvor K=n_H0 σ_T Mpc_m. n_H0 er i m^-3, σ_T i m², Mpc_m i meter per Mpc, K og CLASS' H_B i Mpc^-1; W=K/H_B, z, E og F er dimensionsløse. Der indsættes ingen ekstra lyshastighed i den fastholdte CLASS-konvention.

På hver [a,b] er massen M=((1+b)^3-(1+a)^3)/3 eksakt. Med W∈[W_l,W_u] og E∈[q/2,q] fås bidraget [q W_l M/2, q W_u M], rundet udad til 2^-100-gitter. Intervallets ubetingede fysiske gyldighed påstås ikke: alle tidligere kilde- og baggrundspræmisser er fortsat nødvendige.

Vægtene beregnes med den positive materie-/strålingsdel og alle 11 fastholdte neutrinoknuder. Ved s=1+z bruges den eksakte form B₀(s)=matter·s³+radiation·s⁴+factor·s³ Σ_j q_j² w_j sqrt(q_j²s²+M_nu²). Dette er den samme massefylde som kontrollens a=1/s-form, som evalueres separat. Positivitet giver endepunktsgrænser på hele delcellen.

Skalarenergien opfylder de/dln(a)=-3X²≤0 langs den samme bane. Derfor bruges min(V105's certificerede z=800-energiloft, den tilknyttede historiske guard-cap), sammen med det validerede potentialegulv. Den rå H²-indhylling er [B₀,lower+floor_lower/3, B₀,upper+(energy_cap+floor_upper)/3]. Kvadratrodsintervaller rundes udad på 2^-160-gitter og skæres med den arvede guard-H-indhylling. K/H skæres derefter med hver arkiveret V66-vægt. Ingen interpolation eller gættede vægtprøver indgår.

## Dækning og separat kontrol

102 V66-kilderækker (4642–4743, nulbaseret) afskæres ved 700 og 750 og splittes ved guard-grænserne 710,720,730,740. Det giver præcis 106 delceller uden huller eller overlappende indre. De matcher V108's kanoniske rationelt sorterede deling. V62-rækkerne 118–219 og guard-rækkerne 70–74 er de samme som i opgaven. Pilotintervallet [750,800] bevares; den fælles endepunktsrække afskæres, så ingen indre bidrag dobbelttælles.

Producenten bruger heltalskvadratrod og binære rationelle udadgrænser. Kontrolløren importerer ikke producenten: den parser hex-tal med heltal, omskriver tæthed til a-koordinaten, summerer neutrinoknuder i omvendt rækkefølge, bruger 100-cifret Decimal-kvadratrod med eksakt kvadrering af begge intervalender og grupperer masserne efter de fem guard-intervaller. Den kontrollerer samtlige 106 vægt- og integralindhyllinger samt de 107 tæthedsendepunkter.

Uafhængigheden omfatter numerisk formulering, parser, rødder og summering. Begge implementationer deler den samme arkiverede fysik, V97's symbolske argument, V107-barrieren og Python-rationel aritmetik. Kontrollen er ikke en uafhængig bekræftelse af de underliggende fysiske antagelser eller hele forhistorien.

## Nyt interval og global opdatering

Afrundede visningstal (autoritative eksakte brøker findes i result109.json og calc/result_raw_recovery.json):

| Størrelse | Før | V109 |
|---|---:|---:|
| [700,750]-interval | [0; 3,812360440724·10^-6] | ca. [1,849590008120·10^-6; 3,716040711905·10^-6] |
| Blokbredde | 3,812360440724·10^-6 | 1,866450703785·10^-6 |
| Globalt kildeinterval | ca. [1,948167546682·10^-6; 4,570648398217·10^-5] | ca. [3,797757554802·10^-6; 4,561016425335·10^-5] |
| Global bredde | 4,375831643549·10^-5 | 4,181240669854·10^-5 |

Blokbredden falder 51,0421238284 %, så det forud fastsatte krav om mindst 25 % reduktion består. Den globale bredde falder 4,4469483642 %. Opdateringen er eksakt for hver intervalende: new_global_i = V105_global_i − old_block_i + new_block_i. Kontrolløren efterviser, at alle øvrige bins er uændrede, og at deres sum giver det nye globale interval.

Maksimum ved z=810 for den definerede kildeakkumulation genbruges fra V95's fortegnsresultat. Det søges ikke på ny, og det identificeres ikke med et endnu ucertificeret native maksimum.

## Breddebudget og præcisionsafstand

Produktbredden før afrunding dekomponeres eksakt:

(q W_u − q W_l/2) M = q(W_l+W_u)M/4 + 3q(W_u−W_l)M/4.

Det første led henføres til elektronindhyllingen, det andet til vægtindhyllingen. Summen over delcellerne er henholdsvis ca. 1,853805182036·10^-6 og 1,264552174871·10^-8. Udadrettet inkrementafrunding bidrager ca. 8,678734580724·10^-29. Elektronintervallet står derfor for ca. 99,3225 % af den nye blokbredde. Flere roddecimaler er ikke den væsentlige vej til forbedring her.

Kvadraturresten er nul for den eksakte integration af de omsluttende konstante bokse. Dette er ikke en påstand om et fejlfrit beregnet punktvist elektronforløb; usikkerheden fra de ukendte forløb ligger i boksbredderne.

Det foreløbige globale breddemål er 4·10^-9. Den nye bredde er ca. 10.453,10 gange målet. Dette er et breddeforhold, ikke et estimat af resterende tid, antal runder eller procent færdiggørelse. Native baggrundstilhørsforhold, koordinatsammenfald, reproducerbarhed og fejlcertifikat for hele historien er særskilte, fortsat åbne krav.

De største resterende lagrede breddebidrag er [600,650] og [650,700]. Halv-q-grænsen er aktuelt kun videreført ned til z=700. Et eventuelt nyt domæne skal forbindes kontinuerligt til denne grænse og kontrolleres for samtlige gren-, temperatur-, rate- og baggrundspræmisser. Bredderegistret alene beviser ikke, at metoden gælder der.

## Execution og evidensgrænse

Kørslen brugte præcis én optisk evaluering og én separat kontrol; ingen ny skalarintegration, native par eller fuldhistorieintegration. Forsøget blev markeret før beregningen, og en ukontrolleret kandidat blev skrevet før de afsluttende gates. Den rå kandidat bevarer sin oprindelige status; den nye result109.json sammenfatter den efterfølgende kontrol.

Kilde- og inputhashes, kodehashes, UTC-start/slut, faktisk Python/platform og runtime står i input_audit109.json og calc/execution_recovery.json. Runtime var ca. 0,88346 sekunder, inden for 300 sekunder; udpakning og dokumentation var uden for denne beregningsgrænse. Stopkriteriet var første kontrollerede resultat, så ingen yderligere optisk evaluering blev startet.

Dette opfylder R2 for det udførte forløb og R3 for den særskilt kontrollerede lokale optiske aritmetik, under delte historiske præmisser. Det giver ikke R3 for hele Q052 eller den native implementation.

V108-filerne og begge motorversioner er sammenholdt med GitHub-blobs ved den dokumenterede repository-base. README og launcher-registry beskriver ældre execution-targets; de er ikke bevis for den aktuelle matematiske status eller en ordre om genkørsel. V109 er leveret til manuel upload; ingen GitHub-write eller offentlig postning er udført.
