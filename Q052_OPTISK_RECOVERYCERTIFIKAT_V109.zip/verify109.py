"""Integrity and stored-arithmetic checks; does not repeat scientific evaluation."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from fractions import Fraction as F
import json, sys

archive=Path(sys.argv[1])
sha=lambda b:sha256(b).hexdigest()
with ZipFile(archive) as z:
    assert z.testzip() is None
    m=json.loads(z.read('manifest.json'))
    assert len(z.namelist())==len(set(z.namelist()))
    assert set(z.namelist())=={'manifest.json'}|{x['path'] for x in m['archive_members']}
    for x in m['archive_members']:
        b=z.read(x['path']);assert len(b)==x['bytes'] and sha(b)==x['sha256'],x['path']
        if x['path'].endswith('.json'):json.loads(b)
    for x in m['external_deliverables']:
        b=z.read(x['filename']);assert sha(b)==x['sha256'] and len(b)==x['bytes']
        if (archive.parent/x['filename']).exists():assert b==(archive.parent/x['filename']).read_bytes()
    raw=json.loads(z.read('calc/result_raw_recovery.json'))
    result=json.loads(z.read('result109.json'))
    control=json.loads(z.read('calc/control_recovery.json'))
    execution=json.loads(z.read('calc/execution_recovery.json'))
    task=json.loads(z.read('Q052_RESULTATINDTAG_OPGAVE_V109.json'))
    ledger=json.loads(z.read('activity_ledger.json'))
    assert control['status']==execution['technical_state']==result['technical_state']=='PASS'
    assert result['scientific_state']=='INCONCLUSIVE' and result['native_certificate_state']=='OPEN'
    assert result['optical_result']=={k:v for k,v in raw.items() if k not in ['cells','technical_state']}
    assert execution['new_domain_optical_evaluations']==1 and execution['wall_seconds']<300
    for n,h in execution['code_sha256'].items():assert sha(z.read('calc/'+n))==h
    for n,h in execution['output_sha256'].items():assert sha(z.read('calc/'+n))==h
    assert task['input_result_sha256']==sha(z.read('result109.json'))
    nofp={k:v for k,v in task.items() if k!='fingerprint_sha256'}
    assert sha(json.dumps(nofp,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==task['fingerprint_sha256']
    cells=raw['cells'];assert len(cells)==106 and cells[0]['z'][0]=='700' and cells[-1]['z'][1]=='750'
    assert all(F(c['z'][0])<F(c['z'][1]) for c in cells)
    assert all(a['z'][1]==b['z'][0] for a,b in zip(cells,cells[1:]))
    assert [sum(F(c['increment'][i]) for c in cells) for i in [0,1]]==list(map(F,raw['block_interval']))
    assert F(raw['block_width'])<=3*F(raw['prior_block_interval'][1])/4
    assert [sum(F(v[i]) for v in raw['current_bins'].values()) for i in [0,1]]==list(map(F,raw['new_global_interval']))
    assert sum(x['run_points'] for x in ledger['entries'])==ledger['total_points_after']==task['total_points']
    with ZipFile(__import__('io').BytesIO(z.read('history/Q052_INGESTION_CERTIFICATE_V108.zip'))) as old:
        prior=json.loads(old.read('activity_ledger.json'))
        assert ledger['entries'][:-1]==prior['entries'] and ledger['milestone_records']==prior['milestone_records']
        assert ledger['delivered_milestone_ids']==prior['delivered_milestone_ids']
    j=z.read('Q052_MATEMATIK_OG_SAMLET_JOURNAL_V109.md');parent=m['parent_journal']
    assert sha(j[:parent['bytes']])==parent['sha256']
    primary=z.read('Q052_KORT_RESULTAT_V109.md').decode()
    assert primary.count('BUBBLEVERSE — OVERLEVERING')==1 and 'BUBBLEVERSE — AFSLUTTET SAG' not in primary
print(json.dumps({'status':'PASS_INTEGRITY_AND_STORED_ARITHMETIC','archive_members':len(m['archive_members']),
    'json_parsed':sum(x['path'].endswith('.json') for x in m['archive_members']),
    'journal_prefix_preserved':True,'ledger_history_preserved':True,'new_scientific_evaluations':0}))
