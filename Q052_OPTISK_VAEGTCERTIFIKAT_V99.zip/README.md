# Q052 V99 · Optisk vægtcertifikat

Læs først PROOF_V99.md. Den bestilte 25 %-metodetest fejler; det skarpere interval består den tekniske kontrol. Hovedspørgsmålet er fortsat åbent.

Pak ZIP-filen ud i en ny mappe. Koden bruger kun Python-standardbiblioteket og kræver ikke netværk eller en native CLASS-kørsel. Kør uden Python-flaget -O, da assertions er valideringsgates:

```sh
python verify_package.py
python compute99.py
python control99.py
python verify99.py
```

compute99.py genskaber result99.json og en ny timingkvittering. control99.py genskaber den uafhængige kontrol. verify99.py afviser otte fejlmutationer og sammenligner deterministiske outputs efter genkørsel i en frisk mappe. Timingfelter er kørselsafhængige; de matematiske resultater skal være byteidentiske.

Kør pakkehashkontrollen før genberegning. Efter genberegning kan timingkvitteringernes bytes naturligt ændres. Historiske guard-checks er arvede præmisser og er ikke nye V99-tests.

result99.json rummer de eksakte endepunkter og hver delcelle. Q052_RESULTATINDTAG_OPGAVE_V99.json er den næste indtagsopgave. handoff99.json og activity_ledger.json er kopier af den samlede journals afsluttende JSON-blokke. Journalen leveres særskilt som en hel fil med V98-præfikset uændret.

history/Q052_INGESTION_CERTIFICATE_V98.zip bevarer de indgående certifikater og deres historiske proveniens. manifest.json dækker alle pakkens øvrige medlemmer. De to selvstændige Markdown-leverancers hashes står også i manifestet. Et hashmanifest bekræfter byteidentitet; det erstatter ikke de matematiske præmisser.
