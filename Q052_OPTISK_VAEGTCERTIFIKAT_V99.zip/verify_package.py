from pathlib import Path
import json,hashlib,zipfile,io
p=Path(__file__).resolve().parent
m=json.loads((p/'manifest.json').read_bytes())
for name,h in m['members_sha256'].items():
    assert hashlib.sha256((p/name).read_bytes()).hexdigest()==h,name
def check_archive(data):
    z=zipfile.ZipFile(io.BytesIO(data));assert z.testzip() is None
    metadata=json.loads(z.read('manifest.json'))
    for n,h in metadata['members_sha256'].items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
    return z
z=check_archive((p/'history/Q052_INGESTION_CERTIFICATE_V98.zip').read_bytes())
for n in ['history/Q052_THOMSON_PILOTCERTIFIKAT_V97.zip','history/Q052_BAGGRUNDSCERTIFIKAT_V73.zip']:check_archive(z.read(n))
print('PASS current package and V98/V97/V73 member hashes')
