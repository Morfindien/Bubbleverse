"""Certificate integrity mutations and fresh-directory deterministic replay."""
from pathlib import Path
from copy import deepcopy
import hashlib, json, tempfile, subprocess, shutil, time
from control99 import validate

P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
original=json.loads((P/'result99.json').read_bytes())
mutants=[]
def mutation(name,edit):
    trial=deepcopy(original);edit(trial)
    try:validate(trial)
    except AssertionError:
        mutants.append({'name':name,'rejected':True})
    else:raise AssertionError('undetected mutation: '+name)
mutation('missing integration cell',lambda r:r['cells'].pop())
mutation('wrong common-background dependency',lambda r:r['cells'][0].update(background_dependency_id='OTHER'))
mutation('unbound scalar cap',lambda r:r['cells'][0].update(scalar_energy_cap='0'))
mutation('wrong Mpc conversion constant',lambda r:r.update(optical_K_inverse_Mpc=['1','2']))
mutation('unsafe H upper endpoint',lambda r:r['cells'][0]['H_box'].__setitem__(1,'1'))
mutation('unreported weight width',lambda r:r.update(new_weight_width='0'))
mutation('false 25 percent success',lambda r:r.update(target_met=True))
mutation('wrong global replacement',lambda r:r['new_global_interval'].__setitem__(0,'0'))
beg=time.monotonic()
with tempfile.TemporaryDirectory(prefix='q052-v99-replay-') as d:
    out=Path(d)
    names=list(json.loads((P/'pins.json').read_bytes()))+['pins.json','compute99.py','control99.py']
    for n in names:shutil.copy2(P/n,out/n)
    outputs=[]
    for script in ['compute99.py','control99.py']:
        run=subprocess.run(['python',str(out/script)],capture_output=True,text=True,timeout=60)
        assert run.returncode==0,run.stderr
        outputs.append({'script':script,'returncode':run.returncode})
    same={n:sha(out/n)==sha(P/n) for n in ['result99.json','control99.json']}
    assert all(same.values())
    replay={'directory':'fresh temporary directory, deleted after checks','same_input_replay_only':True,'new_method_searches':0,'byte_identical':same,'commands':outputs,'wall_seconds':time.monotonic()-beg}
report={'status':'PASS','mutation_count':len(mutants),'rejected':len(mutants),'mutations':mutants,'replay':replay,'original_prototype_execution':json.loads((P/'execution99.json').read_bytes()),'claim_scope':'Numerical certificate checks; inherited source-prefix and half-q proofs are not recomputed. One bounded method trial, one verification replay.'}
(P/'verification99.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,indent=2))
