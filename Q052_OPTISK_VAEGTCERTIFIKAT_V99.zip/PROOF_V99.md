# Q052 V99 · Skarpere optisk vægt på det fastholdte B★

Den bestilte engangstest er gennemført. Den nye vægtindhylling mindsker vægtens bidrag til pilotens intervalbredde med **10,5005258 %**. Kravet var mindst 25 %. Metodetesten når derfor ikke sit mål, selv om de nye intervaller er gyldige under de arvede kildepræmisser og skarpere på alle 105 delceller. Dette er et negativt resultat for den afprøvede præcisionsstrategi, ikke en afvisning af en fysisk model.

| Størrelse | V97 | V99 |
|---|---:|---:|
| Vægtbidrag til pilotbredde, omtrent | 8,74795235269 × 10⁻⁷ | 7,82937135878 × 10⁻⁷ |
| Pilotens samlede bredde, omtrent | 2,54524579168 × 10⁻⁶ | 2,43156406973 × 10⁻⁶ |
| Samlet kildeindhyllings bredde, omtrent | 4,43866806565 × 10⁻⁵ | 4,42729989346 × 10⁻⁵ |

Målets vægtloft er cirka 6,56096426452 × 10⁻⁷. Resultatet ligger 19,33 % over dette loft. Pilotens samlede bredde falder med 4,46643394 %, mens bredden på den samlede kildeindhylling falder med 0,25611675 %. Tallene er intervalbredder, ikke statistiske fejl eller målte fysiske variationer.

## 1. Det fastlåste spørgsmål og det betingede scope

Opgaven er Q052, `LOCAL-Q052-V98-BSTAR-WEIGHT-750-800`, med fingerprint `7bb1bb7c591f6beb4a1aeb02a14f7482179ea3d13cebf74c1a614f4c3bcbaa01`. Fysikkilden er `hillipop-ede_n3` ved commit `5a131c91d657dd9a7c6364cc45b038710f8d0d97`.

B★ er allerede valgt i V73 gennem Q048's tidlige kilde-reelle startværdiproblem. De arvede præfiksbeviser og deres betingede initialisering anvendes uændret. Q050's fælles baggrunds-ID er `Q050-COMMON-BACKGROUND-92de319899bf911563aff4d1`. Begge q-arme og alle celler vedrører samme fastholdte løsning. De korrelerede baggrundsgrænser må ikke læses som uafhængige genstarter.

V97 leverer den strenge indre elektron-grænse q/2 < E(z) < q, hvor E = ΔX_e og q = 10⁻⁶. Ved intervalintegrationen anvendes den lukkede indeslutning [q/2,q] præcis som i V97. Der er ikke genudført et nyt halv-q-bevis eller ændret på elektronindhyllingen.

Den nye baggrundsvægt er også gyldig for medlemmer af den samme fastholdte familie, der opfylder alle de anvendte guard-præmisser. Det konkrete pilotresultat kombinerer den med V97's parcertifikat for den specificerede B★ og de matchede z=810-starter. Det er ikke et certifikat for vilkårlige baggrunde, nye initialtilstande eller den faktiske native kørsels medlemskab.

## 2. Positive baggrundsled og monotoni

Sæt s=1+z. Den flade kildebaggrund har

\[
H_B^2=B_0(s)+(e+f)/3,\qquad e=X^2/2+U\ge0,\qquad de/d\ln a=-3X^2\le0.
\]

Den kosmologiske konstant og krumningen er nul i den låste konfiguration. De øvrige aktiverede almindelige komponenter giver

\[
B_0(s)=H_0^2[(\Omega_b+\Omega_{cdm})s^3+(\Omega_g+\Omega_{ur})s^4]
+A_\nu s^3\sum_{j=1}^{11}p_j^2w_j\sqrt{p_j^2s^2+M_\nu^2}.
\]

Her betegner p_j de indfangede momentumknuder; de er forskellige fra heliumparameteren q. Alle 11 knuder, vægte, massen og normaliseringsfaktoren indlæses som eksakte binary64-tal. Ingen knuder udelades. Formlen er algebraisk identisk med `background_ncdm_momenta` i den vedlagte, hashbundne `background.c`, hvor normaliseringen er A_ν s⁴ og roden √(p_j²+M_ν²/s²). Certifikatet gælder denne fastholdte endelige kildekvadratur. Der påstås ingen ny fejlgrænse i forhold til en kontinuerlig neutrino-fordelingsfunktion.

Hvert led i B₀ er positivt og voksende med s>0. For en delcelle [a,b] i z-koordinaten kan B₀ derfor indesluttes med en nedre evaluering ved 1+a og en øvre evaluering ved 1+b. For hver af de fem guard-celler 65–69 bruges den godkendte energi ved cellens høje z-ende som loft E_cap på hele cellen. Dette følger af energiens monotoni mod voksende skalafaktor. Det er et videreført loft, ikke en ny værdi af den faktiske skalarenergi.

Med de arvede konstante gulvgrænser f_l,f_u fås

\[
H_l^2=B_{0,l}(1+a)+f_l/3,\qquad
H_u^2=B_{0,u}(1+b)+(E_{cap}+f_u)/3.
\]

De positive kvadratrødder skæres med den gældende Q050-guard for H. Guard-valideringens 6.566 checks og 24 mutationsafvisninger er historisk evidens; de er ikke talt som nye tests. Identiteter, bindinger, relevante rækkehashes og fortsættelsesbindingen fra række 63 til 69 kontrolleres i denne kørsel. V73's tilordning til det tidlige startværdiproblem forbliver en arvet præmis.

## 3. Vægt, enheder og eksakt dækning

Definér

\[
K=n_{H0}\sigma_T\,\mathrm{Mpc}_m,\qquad W(z)=K/H_B(z),\qquad
F(Z)=\int_0^Z W(z)(1+z)^2E(z)\,dz.
\]

n_H0 har enheden m⁻³, σ_T m², Mpc_m m/Mpc og H_B Mpc⁻¹. Derfor har K enheden Mpc⁻¹, mens W, E og F er dimensionsløse. Konstanten n_H0 matcher den indfangede værdi. De eksakte V26-intervaller for σ_T og Mpc_m fra `audit98.json` reproducerer V66's K-interval.

På hver delcelle er W_new = [K_l/H_u,K_u/H_l], afrundet udad. Det anvendte interval er skæringen med den oprindelige V66-vægt. Alle skæringer er ikke-tomme og skarpere ved begge ender.

V66-rækkerne 4743–4843 giver de samme 101 afskårne V97-celler. Der deles kun ved eksisterende cellegrænser samt guard-grænserne 760, 770, 780 og 790. Det giver præcis 105 delceller og 106 forskellige endepunkter. Der er hverken huller, overlap af positiv længde eller arbejde uden for [750,800].

Den eksakte positive integrationsmasse er

\[
m_{a,b}=\frac{(1+b)^3-(1+a)^3}{3}.
\]

Bidraget ligger i [q W_l m/2, q W_u m]. Kvadratrødder beregnes med heltalskvadratrod og kontrollerede kvadrater på gitteret 2⁻¹⁶⁰. B₀ og W afrundes udad på samme gitter. Hvert integralbidrag afrundes derefter udad på gitteret 2⁻¹⁰⁰ og summeres rationelt. Der anvendes ingen tilnærmet ODE-integration.

## 4. Resultat og breddebogføring

Den nye pilotindeslutning er følgende udad afrundede decimalvisning:

\[
1{,}38764788\times10^{-6}\le I_{750,800}\le3{,}81921196\times10^{-6}.
\]

De autoritative eksakte endepunkter er

\[
I_l=\frac{1759052678839723865287865}{1267650600228229401496703205376},\qquad
I_u=\frac{2420713165664535241667261}{633825300114114700748351602688}.
\]

V97's symmetriske opdeling bevares:

\[
W_uE_u-W_lE_l=W_{mid}(E_u-E_l)+E_{mid}(W_u-W_l).
\]

| Bidrag til den nye pilotbredde | Omtrent |
|---|---:|
| Elektronindhylling, vægtet med W_mid | 1,64862693385 × 10⁻⁶ |
| Vægtindhylling, vægtet med E_mid=3q/4 | 7,82937135878 × 10⁻⁷ |
| Afsluttende udadrettet bidragsafrunding | 8,34254926078 × 10⁻²⁹ |
| Restled ved integration af de omsluttende bokse | 0 |

Den meget mindre afrunding af rødder, B₀ og W er allerede indeholdt i vægtbidraget. Tabellen adskiller således den afsluttende summeringsafrunding, uden at tælle den indledende intervalafrunding to gange. Elektronintervallet er uændret; dets vægtede breddebidrag ændres lidt, fordi W_mid ændres. Et nul i kvadraturrestkolonnen betyder eksakt integration af de omsluttende bokse, ikke at den ukendte kildekurve er kendt præcist.

V97's globale bogføring opdateres ved kun at erstatte pilotens bidrag ved hver ende. V95's certificerede maksimumsted ved z=810 genbruges. Den nye globale kildeindeslutning er, afrundet udad,

\[
1{,}43348504\times10^{-6}\le F(810)\le4{,}57064840\times10^{-5}.
\]

Den samlede bredde er cirka 4,42729989346 × 10⁻⁵, fortsat cirka **11.068 gange** den foreløbige målbredde 4 × 10⁻⁹. Denne målpræcision er et metodearbejdsmål og ikke en ny fysisk acceptgrænse. Udskiftningen er regnskab for additive delintervaller, ikke almindelig intervalsubtraktion mellem korrelerede ukendte integraler.

## 5. Uafhængig kontrol og første begrænsende input

`control99.py` importerer ikke producenten. Kontrollen parser hex-tal med heltal, bruger skalafaktoren a=1/s i den oprindelige neutrinoformel, vender knudernes summationsrækkefølge og beregner Decimal-kvadratrødder ved 100 cifres præcision. Hver rodindeslutning verificeres ved eksakt rationel kvadrering. Kontrollen rekonstruerer dækningen fra V66 og guard-rækkerne, evaluerer integrationsmassen som et udvidet polynomium og summerer særskilt i fem guard-grupper.

Begge scripts giver byteidentiske resultatfiler ved genkørsel i en frisk mappe. Otte tilsigtede fejl i dækning, baggrunds-ID, energiloft, omregning, H-endepunkt, bredde, målstatus og global udskiftning afvises. Kontrollen er numerisk og algebraisk uafhængig af producentens implementering; den deler de historiske fysiske præmisser.

Den begrænsende usikkerhed i denne vægtmetode er det arvede skalarenergiloft kombineret med den konservative nedre grænse e≥0. De fem lofter er cirka 22,71–26,97 Mpc⁻². Deres bidrag E_cap/3 er cirka 87–91 % af den respektive delcelles øvre B₀-værdi. Det holder H- og dermed W-intervallerne brede, selv efter de almindelige arter og alle neutrinoknuder er afgrænset præcist. Tallene er dokumenterede projektionslofter; de er ikke en måling af energien langs B★.

Der er ikke initialiseret fra en native spline, justeret et energiloft mod den lagrede kurve eller valgt nye baggrunde. Et mere præcist næste forsøg kræver et særskilt valideret strammere energibevis eller en anden dokumenteret kildeindhylling. Den aktuelle enkeltmetode er stoppet som bestilt efter første afgrænsede evaluering; den efterfølgende kontrol og genkørsel ændrer ikke strategien.

## 6. Betydning for hovedspørgsmålet og aflevering

TECHNICAL_STATE er PASS for identitets-, aritmetik-, dæknings- og reproduktionskontrollen. Den specifikke 25 %-metodetest er FAIL. Q052's SCIENTIFIC_STATE forbliver INCONCLUSIVE, og næste motor er `BUBBLEVERSE.RESULT_INGESTION_ROUTING 2.3.0`.

Native/kilde-baneidentitet, native reproducerbarhed, et tilstrækkeligt snævert optisk maksimum og den endelige sammenholdning med Q051's frosne kriterier er fortsat åbne. Ingen nye native par eller fulde historieintegrationer er kørt. V83's globale absolutte elektronmaksimum og V95's kilde-maksimumsted bevares med deres oprindelige afgrænsning.

Resultatindtaget skal registrere forbedringen og den fejlede metodegrænse én gang. Det skal bruge den dokumenterede energibegrænsning til næste routing og må ikke genbestille samme vægttest med uændrede input.
