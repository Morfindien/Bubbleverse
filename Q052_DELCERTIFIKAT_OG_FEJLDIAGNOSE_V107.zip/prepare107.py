from pathlib import Path
from hashlib import sha256,sha1
from datetime import datetime,timezone
import json,shutil,sys,platform
P=Path(__file__).resolve().parent;ROOT=P.parents[1];U=ROOT/'upload';C=P/'calc';C.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_bytes())
sha=lambda b:sha256(b).hexdigest()
blob=lambda b:sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
t=read(P/'task106.json');j=t.copy();j.pop('fingerprint_sha256')
assert sha(json.dumps(j,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode())==t['fingerprint_sha256']
assert t['current_q']==t['target_q']=='Q052' and t['state']=='PREPARED_NOT_EXECUTED'
v=read(P/'v105/result105.json');old=read(P/'v97/result.json');budget=read(P/'intake/width_budget106.json')
assert sha((P/'v105/result105.json').read_bytes())==t['parent_result_sha256']
assert v['exact_question']==t['exact_question'] and v['source_commit']==old['source_commit']==t['source_commit']
assert v['capture_sha256']==t['capture_sha256'] and v['checkpoint']['energy_endpoint'][1]==t['source_data']['scalar_anchor']['energy_upper']
assert budget['global_interval']==t['tolerances']['V105_global_interval']==v['optical_result']['new_global_interval']
assert budget['new_domain_prior_interval']==t['tolerances']['prior_block_interval']
ledger=read(P/'intake/activity_ledger.json');assert ledger['total_points_after']==t['total_points']==13610
assert not ledger['pending_packages'] and len(ledger['delivered_milestone_ids'])==13
head=read(P/'repository_head.json');tree=read(P/'repository_tree.json');assert not tree['truncated'] and tree['sha']==head['commit']['commit']['tree']['sha']
paths={x['path']:x['sha'] for x in tree['tree']}
attached={}
for n in ['Q052_KORT_RESULTAT_V106-1.md','Q052_INGESTION_OG_SAMLET_JOURNAL_V106-1.md','Q052_MATEMATIKOPGAVE_V106.json','Q052_INGESTION_CERTIFICATE_V106.zip']:
 b=(U/n).read_bytes();attached[n]={'sha256':sha(b),'bytes':len(b),'git_blob':blob(b),'repository_status':'MATCH' if paths.get(n)==blob(b) else 'NOT_PRESENT' if n not in paths else 'CONFLICT'}
 assert attached[n]['repository_status']!='CONFLICT'
parent=read(P/'intake/audit106.json')['repository_files'];verified_parent={}
for logical,x in parent.items():
 assert paths[x['repository_path']]==x['git_blob'];verified_parent[logical]=x
engines={}
for key,local,canonical in [('math','Bubbleverse_Matematikmotor_2.3.0-46.md','Bubbleverse_Matematikmotor_2.3.0.md'),('intake','Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0-44.md','Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0.md')]:
 b=(U/local).read_bytes();assert paths[canonical]==blob(b);engines[key]={'path':canonical,'sha256':sha(b),'git_blob':blob(b)}
assert engines['math']['sha256']==t['engine_prompt_sha256']
mapping={}
for p in (P/'v105/weight').iterdir():
 if p.is_file():shutil.copyfile(p,C/p.name);mapping[p.name]='v105/weight/'+p.name
for n in ['v62.json','v75.json','v77.json','v83.json','v95.json','q048_prefix_config_v1.json','hyrec.c','thermo.c','wrap_hyrec.c','hydrogen.h']:
 shutil.copyfile(P/'v97'/n,C/n);mapping[n]='v97/'+n
for dest,src in [('task106.json','task106.json'),('budget106.json','intake/width_budget106.json'),('frontier106.json','intake/frontier106.json'),('result105.json','v105/result105.json'),('result97.json','v97/result.json')]:
 shutil.copyfile(P/src,C/dest);mapping[dest]=src
pins={n:sha((C/n).read_bytes()) for n in mapping};(C/'input_pins107.json').write_text(json.dumps(pins,indent=2)+'\n')
(P/'input_mapping.json').write_text(json.dumps(mapping,indent=2)+'\n')
audit={'timestamp_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS','task_fingerprint':t['fingerprint_sha256'],'repository_head':head['commit']['sha'],
 'repository_tree':tree['sha'],'source_authority':'Supplied immutable V106 package; V105 and V97 predecessors verified against observed GitHub blobs. V106 is not yet present in that repository snapshot.',
 'attached_files':attached,'verified_parent_files':verified_parent,'verified_engines':engines,'exact_question':t['exact_question'],
 'frozen_source_commit':t['source_commit'],'capture_sha256':t['capture_sha256'],'input_mapping_ref':'input_mapping.json','input_pins_ref':'calc/input_pins107.json',
 'python':sys.version,'platform':platform.platform(),'setup':{'mode':'Local Python standard-library exact rational arithmetic','reasoning_level':'NOT_MEASURED','class':['M','C'],
 'recommended':'Current local runtime; no HPC or model change required','fallback':'Preserve certificate and exact failed premise','upgrade_trigger':'Material failure cannot be resolved within frozen task','downgrade_trigger':'Once valid record is obtained, stop computation and package it'}}
(P/'input_audit107.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','repository_head':audit['repository_head'],'V106_repo_status':[x['repository_status'] for x in attached.values()],'pinned_inputs':len(pins)},indent=2))
