# Q052 V107 · Genoptagelse og filer

Start med `Q052_RESULTATINDTAG_OPGAVE_V107.json` og den fulde journal `Q052_MATEMATIK_OG_SAMLET_JOURNAL_V107.md`. Næste motor er Result Ingestion & Routing 2.3.0. Det lokale halv-q-resultat er betinget bestået; den optiske test er ufuldstændig.

`calc/compute107.py`, `calc/control107.py`, `calc/run107.py`, `calc/barrier107.json` og `calc/execution107.json` er bevarede records fra det fejlede forsøg. De må ikke rettes eller køres igen alene for at fortsætte. `diagnosis107.json` er det efterfølgende record med den uafhængige barrierekontrol, den eksakte rækkefølgeafvigelse og tællerrettelsen. Den oprindelige kvittering har tæller 0; det korrigerede forsøgstal er 1. Der er nul nye accepterede optiske resultater.

`REPAIR_NOT_EXECUTED.patch` er et forslag, ikke udført kode. Anvend det kun i en ny version/arbejdsmappe under den næste afgrænsede opgave med nye run-ID'er. Bevar originalerne, genbrug V107-barrieren, og hold de oprindelige 106 delceller og 25 %-kriteriet uændrede.

## Inputgenfinding uden ny beregning

Dette arkiv indeholder `history/Q052_INGESTION_CERTIFICATE_V106.zip`, byteidentisk med den leverede V106-pakke. Heri ligger originale V105- og V97-arkiver. `restore_inputs107.py` pakker disse arkiver ud lokalt og genskaber de 39 inputfiler i `calc/` fra `input_mapping.json`, kontrolleret mod `calc/input_pins107.json`. Scriptet foretager ingen videnskabelig evaluering. Det er testet i en frisk udpakning af denne leverance.

`prepare107.py`, `diagnose107.py` og `build107.py` dokumenterer producentens workflow; deres oprindelige workspace-stier er provenance. Brug gendannelsesscriptet ved flytning til en ny mappe. Den fulde journal er separat rodleverance, og dens forgænger er bevaret som eksakt bytepræfiks.

## GitHub klar til brugerupload

Repository: https://github.com/Morfindien/Bubbleverse. Observeret base `424c133782fec817a6ae26b305519f4b80a74481`. V105-/V97-kæden og motorversioner er verificeret her; V106-filerne findes ikke i dette snapshot. Genlæs main og sikr forgængernes tilgængelighed, før pointeren opdateres. Tilføj de fire nye rodfiler `Q052_KORT_RESULTAT_V107.md`, `Q052_MATEMATIK_OG_SAMLET_JOURNAL_V107.md`, `Q052_RESULTATINDTAG_OPGAVE_V107.json`, `Q052_DELCERTIFIKAT_OG_FEJLDIAGNOSE_V107.zip`. Bevar alle gamle versioner og brug den eksisterende Q052-pointer; der er ikke opfundet en ny registry-sti.

Ingen commit, PR eller offentlig post er udført. Aktivitetsledger: 13.700 point; næste milepæl 14.000; 300 til næste. M001–M013 videreføres uændret. Nye lokale IDs er foreløbige. Manifester udelader egen hash og den omsluttende ZIP-hash for at undgå cirkulær selvreference.
