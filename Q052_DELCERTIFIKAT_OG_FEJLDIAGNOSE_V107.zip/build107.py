from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
from zipfile import ZipFile,ZIP_DEFLATED
import json,difflib,tempfile,subprocess,sys
P=Path(__file__).resolve().parent;ROOT=P.parents[1];U=ROOT/'upload';C=P/'calc';O=ROOT/'output/V107';O.mkdir(parents=True,exist_ok=True)
def read(p):return json.loads(p.read_bytes())
def sha(b):return sha256(b).hexdigest()
def dump(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def fp(x):return sha(json.dumps({k:v for k,v in x.items() if k!='fingerprint_sha256'},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
t=read(P/'task106.json');a=read(P/'input_audit107.json');d=read(P/'diagnosis107.json');e=read(C/'execution107.json');barrier=read(C/'barrier107.json')
prior=read(P/'intake/activity_ledger.json');old=read(P/'v105/result105.json');budget=read(P/'intake/width_budget106.json')
assert fp(t)==t['fingerprint_sha256'] and e['technical_state']=='FAIL' and d['barrier_control']['status']=='PASS_CONDITIONAL'
assert d['new_optical_evaluations_in_this_diagnosis']==0 and d['counter_correction']['accepted_new_optical_results']==0
short='Q052_KORT_RESULTAT_V107.md';journal='Q052_MATEMATIK_OG_SAMLET_JOURNAL_V107.md';taskfile='Q052_RESULTATINDTAG_OPGAVE_V107.json';cert='Q052_DELCERTIFIKAT_OG_FEJLDIAGNOSE_V107.zip'
names=[short,journal,taskfile,cert];parent_cert='Q052_INGESTION_CERTIFICATE_V106.zip';parent_journal='Q052_INGESTION_OG_SAMLET_JOURNAL_V106-1.md'
paths={x['path'] for x in read(P/'repository_tree.json')['tree']};assert not set(names)&paths
run='LOCAL-Q052-SWIFT-EXTENSION-AND-ORDER-STOP-V107';event='Q052-ACTIVITY-SWIFT-EXTENSION-ORDER-STOP-V107';now=datetime.now(timezone.utc);stamp=now.isoformat()
ref=lambda n:f'{cert}#{n}';hist=lambda n:f'{cert}#history/{parent_cert}#{n}'
head=a['repository_head'];repo='https://github.com/Morfindien/Bubbleverse'
points=90;total=13700;remaining=300
breakdown={'new_domain_barrier_analysis_and_premise_checks':25,'bounded_producer_implementation_and_attempt':25,'independent_barrier_check_and_order_diagnosis':30,'input_and_repository_provenance':10}
basis='Afrundet heuristisk skøn for den nye [700,750]-barriere, ét optisk forsøg, separat præmiskontrol og den konkrete rækkefølge-/tællerdiagnose. De arvede beviser, tidligere integrationer og V106-indtag tæller ikke igen. Pakning og genaflevering giver ingen point.'
ids=[x.get('activity_event_id',x['run_id']) for x in prior['entries']]
assert len(set(ids))==len(ids) and event not in ids and sum(x['run_points'] for x in prior['entries'])==prior['total_points_after']==13610
assert sum(breakdown.values())==points and total==13610+points and not prior['pending_packages']
ledger={**prior,'entries':prior['entries']+[{'activity_event_id':event,'run_id':run,'engine':t['engine'],'run_points':points,'breakdown':breakdown,'basis':basis,'counted_once':True,'assessment_type':'HEURISTIC_DOCUMENTED_ACTIVITY_INDEX','uncertainty':'Subjective rounded activity estimate; not a calibrated measure of compute, correctness or completion.'}],
 'previous_ledger_ref':hist('activity_ledger.json'),'previous_total_points':13610,'total_points_after':total,'cycle_progress':700,'next_publication_at':14000,'points_to_next_publication':remaining,
 'ledger_revision':'V107','parent_ledger_sha256':sha((P/'intake/activity_ledger.json').read_bytes()),'last_updated_utc':stamp,'new_milestones':[],'note':basis,
 'reconciliation':{'prior_total':13610,'new_unique_event_points':points,'current_total':total}}

# Prepare a concrete correction without modifying or rerunning the failed code.
oldcode=(C/'compute107.py').read_text()
newcode=oldcode.replace(" for idx in range(4642,4744):", " write('attempt_progress107.json',{'stage':'ENTERING_OPTICAL_EVALUATION','evaluations_started':1})\n for idx in range(4642,4744):",1)
needle=" assert [[c['V66_row'],c['guard_row'],*c['z']] for c in rows]==read('frontier106.json')['partition']"
replacement=""" write('candidate_cells107.json',{'status':'UNVALIDATED_CANDIDATE_ONLY','cells':rows,'low':str(low),'high':str(high),'electron_width':str(state),'weight_width':str(weight)})
 supplied=read('frontier106.json')['partition']
 observed=[[c['V66_row'],c['guard_row'],*c['z']] for c in rows]
 assert len({tuple(x) for x in supplied})==len(supplied)==106
 assert set(map(tuple,observed))==set(map(tuple,supplied))
 assert observed==sorted(supplied,key=lambda x:(F(x[2]),F(x[3]),x[0],x[1]))"""
assert needle in newcode;newcode=newcode.replace(needle,replacement,1)
oldrun=(C/'run107.py').read_text()
newrun=oldrun.replace("finally:\n", "finally:\n if (P/'attempt_progress107.json').exists():\n  execution['new_domain_optical_evaluations']=json.loads((P/'attempt_progress107.json').read_text())['evaluations_started']\n",1)
patch=''.join(difflib.unified_diff(oldcode.splitlines(True),newcode.splitlines(True),fromfile='a/calc/compute107.py',tofile='b/calc/compute107.py'))+''.join(difflib.unified_diff(oldrun.splitlines(True),newrun.splitlines(True),fromfile='a/calc/run107.py',tofile='b/calc/run107.py'))
assert patch

result={'schema':'Q052_V107_CONDITIONAL_BARRIER_AND_TECHNICAL_STOP','result_id':run,'created_at_utc':stamp,
 **{k:t[k] for k in ['case_id','current_q','target_q','exact_question','source_commit','capture_sha256']},
 'task_id':t['task_id'],'task_fingerprint':t['fingerprint_sha256'],'scientific_state':'INCONCLUSIVE','technical_state':'INCOMPLETE','workflow_state':'READY_FOR_HANDOFF',
 'local_barrier_status':'PASS_CONDITIONAL','new_barrier_domain':['700','750'],'new_strict_electron_bounds':['1/2000000','1/1000000'],
 'combined_with_V97_barrier_domain':['700','800'],'inherited_pilot_unchanged':True,'new_source_box_checks':102,
 'proof_ref':'PROOF_V107.md','barrier_record_ref':'calc/barrier107.json','independent_barrier_control_ref':'diagnosis107.json#barrier_control',
 'optical_method_screen':'NOT_COMPLETED_ORDER_GATE_FAILURE','new_optical_interval':None,'new_global_interval':None,
 'last_accepted_global_interval':budget['global_interval'],'last_accepted_global_width':budget['global_width'],'last_accepted_width_goal_ratio':budget['global_width_goal_ratio'],
 'last_accepted_global_result_ref':hist('history/Q052_SKALARANKER_OG_VAEGTCERTIFIKAT_V105.zip#result105.json'),
 'prototype_wall_seconds':e['wall_seconds'],'prototype_limit_seconds':e['prototype_limit_seconds'],
 'post_stop_barrier_check_seconds':d['barrier_control']['wall_seconds'],'post_stop_scope':'Record/order diagnosis and independent check of saved barrier only; no optical recomputation.',
 'optical_attempts_reaching_evaluation':1,'subcells_completed_before_failing_order_gate':106,'accepted_new_optical_results':0,
 'original_execution_counter':0,'counter_correction_ref':'diagnosis107.json#counter_correction',
 'new_scalar_integrations':0,'new_native_pairs':0,'new_full_history_integrations':0,'new_optical_evaluations_after_stop':0,
 'blocker_id':'LOCAL-Q052-V106-PARTITION-ORDER-MISMATCH','blocker_status':'CAUSE_IDENTIFIED_EXACT_ORDER_REPAIR_PREPARED_NOT_EXECUTED',
 'repair_ref':'REPAIR_NOT_EXECUTED.patch','repair_validation_scope':'Exact partition equality, uniqueness, sorted order and gap-free coverage verified on stored coordinates only. Patched optical producer not run.',
 'q052_completion_gate':False,'remaining_uncertainties':['New-domain optical result and target decision','Global optical precision','Native background membership, coordinate alignment, reproducibility and numerical-error certificate'],
 'limitations':['All mathematical claims inherit the frozen source-real and common-background premises.','Separate new-domain premise checking shares earlier physical source and symbolic proof assumptions.','106 loop iterations before an assertion do not establish an independently controlled integral value.','No physical falsification follows from a serialized-list ordering mismatch.'],
 'next_engine':t['return_engine'],'continue_same_q':True}
result_hash=sha(dump(result))
intake={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','task_id':'LOCAL-Q052-V107-PARTIAL-BARRIER-AND-ORDER-STOP-INGESTION','engine':t['return_engine'],
 'engine_prompt_sha256':a['verified_engines']['intake']['sha256'],'state':'PREPARED_NOT_EXECUTED',
 **{k:t[k] for k in ['case_id','current_q','target_q','exact_question','source_commit','capture_sha256']},
 'parent_result_id':run,'input_certificate':cert,'input_result_ref':ref('result107.json'),'input_result_sha256':result_hash,
 'objective':'Ingest the independently checked conditional [700,750] half-q extension, preserve the optical execution failure, and prepare one corrected bounded optical recovery task without repeating the barrier proof.',
 'required_actions':[
 'Verify archive, task fingerprint, original V106 journal prefix, conditional barrier record and its independent reverse-traversal check.',
 'Accept only the [700,750] source-real half-q extension. Combine with the inherited [750,800] theorem only within the same frozen premises. Keep the accepted optical/global intervals at V105.',
 'Verify that the 106 subcells agree exactly as a unique set; four guard-cut pairs give eight list-position mismatches. Preserve the original unsorted V106 frontier, failed code and execution receipt.',
 'Apply the append-only counter correction: one attempt reached optical work, 106 subcells were processed, zero new optical results were independently certified. The original zero is a post-return counter bug, not zero work.',
 'Review the prepared patch and make one finite next mathematics task for optical recovery with canonical subcell order, durable unvalidated-candidate output and a counter updated on entry to optical work. Preserve the physical partition, input hashes and original 25% block-width criterion. Reuse the V107 barrier.',
 'Carry the full activity and milestone ledger. Keep Q052 open until the actual native-history obligations are discharged or non-identifiability is established.' ],
 'execution_limits':{'new_scalar_integrations_in_this_intake':0,'new_native_pairs':0,'new_full_history_integrations':0,'new_weight_evaluations':0},
 'acceptance_criteria':'Authentic barrier and source link, independently verified new-domain premises, exact ordering diagnosis, honest partial-result scope, and one concrete finite recovery handoff.',
 'rejection_criteria':'A source identity, common-background, branch or proof conflict prevents promotion of the affected local theorem. Preserve unaffected evidence and original failed records.',
 'stop_condition':'Finish one ingestion decision and one corrected finite next-task handoff. Do not execute another optical attempt in intake.',
 'no_repeat':t['no_repeat']+['V107 [700,750] half-q barrier and its 102-row independent applicability check, unless a specific proof/identity defect is found.','V107 failed optical attempt must not be silently repeated or counted as a successful value. A new recorded task may recover it after the documented order/counter correction.'],
 'continue_same_q':True,'total_points':total,'next_milestone':14000,'points_to_next_publication':remaining}
intake['fingerprint_sha256']=fp(intake)
claims=[{'id':'Q052-V107-C1','claim':'For the fixed admitted source-real pair, q/2<Delta_Xe<q on [700,750].','evidence':[ref('PROOF_V107.md'),ref('calc/barrier107.json'),ref('diagnosis107.json#barrier_control')],'status':'SUPPORTED_WITHIN_CONDITIONAL_DOMAIN'},
 {'id':'Q052-V107-C2','claim':'Together with V97 the same strict bound holds on [700,800].','evidence':[ref('PROOF_V107.md'),hist('history/Q052_THOMSON_PILOTCERTIFIKAT_V97.zip#result.json')],'status':'CONDITIONAL_COMPOSITION'},
 {'id':'Q052-V107-C3','claim':'The optical attempt stopped at list-order equality. Exact subcells agree, with four swapped pairs and no missing/duplicate cells.','evidence':[ref('calc/execution107.json'),ref('diagnosis107.json')],'status':'TECHNICAL_DIAGNOSIS'},
 {'id':'Q052-V107-C4','claim':'No new optical value, global narrowing or 25% target decision is certified.','evidence':[ref('result107.json'),ref('calc/execution107.json')],'status':'OPEN'},
 {'id':'Q052-V107-C5','claim':'One attempt reached optical evaluation; the original zero counter is corrected append-only.','evidence':[ref('diagnosis107.json#counter_correction')],'status':'CORRECTION_WITH_ORIGINAL_PRESERVED'}]
sources={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','historical_register_ref':hist('source_register.json'),'historical_claim_map_ref':hist('claim_map.json'),
 'historical_path_context':'References inside historical archives retain their original context.',
 'new_references':[{'id':'Q052-V107-S1','kind':'supplied_task','path':'task106.json','sha256':sha((P/'task106.json').read_bytes())},
  {'id':'Q052-V107-S2','kind':'frozen_primary_source','source_commit':t['source_commit'],'archive':hist('history/Q052_THOMSON_PILOTCERTIFIKAT_V97.zip'),'files':['hyrec.c','thermo.c','hydrogen.h','wrap_hyrec.c'],'reviewed_hyrec_lines':[429,489]},
  {'id':'Q052-V107-S3','kind':'historical_internal_proof','archive':hist('history/Q052_THOMSON_PILOTCERTIFIKAT_V97.zip'),'files':['PROOF_V97.md','PROOF_V77.md','v62.json','v77.json','v83.json','v95.json']},
  {'id':'Q052-V107-S4','kind':'new_internal_result','files':['calc/barrier107.json','diagnosis107.json','calc/execution107.json'],'scope':'Conditional theorem plus technical failure; no new external observations.'}],
 'input_hashes_ref':'calc/input_pins107.json','input_mapping_ref':'input_mapping.json','independence':'New applicability checker is separate from producer; historical physical assumptions and V97 algebra are shared.'}
memory={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','q':'Q052','run_id':run,'repository_url':repo,'branch':'main','base_commit_sha':head,
 'source_journal':parent_journal,'proposed_journal_path':journal,'GITHUB_READ_STATE':'PARTIAL_V105_PREDECESSORS_AND_ENGINES_VERIFIED_V106_SUPPLIED_NOT_YET_IN_REPO',
 'GITHUB_WRITE_STATE':'READY_FOR_MANUAL_UPLOAD','commit_sha':None,'pull_request_url':None,'current_state_path':None,'index_refs':[],
 'exact_question':t['exact_question'],'scientific_state':'INCONCLUSIVE','technical_state':'INCOMPLETE','workflow_state':'READY_FOR_HANDOFF',
 'run_points':points,'total_points':total,'next_some_threshold':14000,'points_to_next_publication':remaining,'points_basis':basis,'ledger_ref':ref('activity_ledger.json'),
 'pending_some_packages':[],'delivered_milestone_ids':prior['delivered_milestone_ids'],'new_claims':[c['id'] for c in claims],
 'blocker_id':result['blocker_id'],'next_engine':intake['engine'],'next_task':taskfile,'resume_condition':'New recorded optical recovery task after the exact ordering/counter correction; retain the certified barrier and all original criteria.',
 'proposed_files':[{'path':n,'operation':'ADD','hash_ref':ref('manifest.json')} for n in names],
 'prior_upload_dependency':{'files':['Q052_KORT_RESULTAT_V106.md','Q052_INGESTION_OG_SAMLET_JOURNAL_V106.md','Q052_MATEMATIKOPGAVE_V106.json',parent_cert],'state':'NOT_PRESENT_AT_OBSERVED_HEAD','historical_bundle_embedded':True},
 'index_update_instruction':'Re-read main, preserve all earlier versions, ensure V106 predecessor references resolve before advancing the existing canonical Q052 pointer. No new competing pointer is proposed.',
 'upload_instructions_ref':ref('README.md'),'external_publication_status':'NOT_REQUESTED'}
handoff={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','prompt_id':'BUBBLEVERSE.MATHEMATICS','prompt_version':'2.3.0','handoff_id':run,'created_at_utc':stamp,
 **{k:t[k] for k in ['case_id','current_q','target_q','exact_question','source_commit','capture_sha256']},
 'authorized_evidence_boundary':'Q052 and required predecessor inputs only','case_lifecycle':'ACTIVE','disposition':'CONTINUE','scientific_state':'INCONCLUSIVE','technical_state':'INCOMPLETE','workflow_state':'READY_FOR_HANDOFF',
 'selected_next_engine_id':intake['engine'],'engine_registry_ref':a['verified_engines']['intake'],'journal_ref':journal,'journal_completeness':'Full supplied V106 journal retained as exact byte prefix',
 'result_ref':ref('result107.json'),'proof_ref':ref('PROOF_V107.md'),'verification_ref':ref('diagnosis107.json'),'source_register_ref':ref('source_register.json'),'claim_evidence_map_ref':ref('claim_map.json'),
 'integrity_manifest_ref':ref('manifest.json'),'run_manifest_ref':ref('calc/execution107.json'),
 'completed_tests':['102 new-domain source-box applicability checks','Independent reverse-traversal barrier check','Exact set/order/coverage diagnosis on 106 stored subcells'],
 'new_information':['Conditional half-q theorem extends to z700','Optical value is blocked by an identified list-order gate; physical partition is unchanged','Original attempt counter corrected append-only'],
 'blocker_id':result['blocker_id'],'blocker_description':d['defect'],'next_task':taskfile,'next_task_fingerprint':intake['fingerprint_sha256'],
 'acceptance_criteria':intake['acceptance_criteria'],'rejection_criteria':intake['rejection_criteria'],'inconclusive_criteria':'No new controlled optical value and full native-history certificate remains open',
 'no_repeat_constraints':intake['no_repeat'],'completion_gate_satisfied':False,'completion_gate_reason':'The exact Q052 native-history certificate and global precision requirements remain unresolved.',
 'setup_assessment':a['setup'],'equations_units_uncertainty_ref':ref('PROOF_V107.md'),'repository_memory':memory,
 'question_activity_points':{'run_id':run,'event_id':event,'run_points':points,'parent_total':13610,'total_points':total,'breakdown':breakdown,'basis':basis,'ledger_ref':ref('activity_ledger.json'),'points_state':'VERIFIED'},
 'some_milestones':{'next_threshold':14000,'points_to_next_threshold':remaining,'crossed_this_run':[],'pending_packages':[],'delivered_milestone_ids':prior['delivered_milestone_ids'],'package_creation_status':'NOT_DUE','external_publication_status':'NOT_REQUESTED'},
 'contract_validation':'MANUAL_LOCAL_CONTRACT_CHECK plus executed integrity and restoration checks; no external formal schema asserted.','continue_same_q':True,'output_file_refs':names}
proof=r'''# Q052 V107 · Halv-q-udvidelse og teknisk stop

## Resultat og afgrænsning

Under den samme fastholdte kilde, fælles tilladte baggrund B★ og matchede start ved z=810 gælder

\[
\frac{q}{2}<\Delta X_e(z)<q,\qquad q=10^{-6},\qquad 700\le z\le750.
\]

Sammen med V97 gælder den samme strenge grænse derfor på [700,800]. Dette er et betinget resultat for kildeligningernes baner. Det er ikke et nyt mål for native CLASS-output og heller ikke en observationsbekræftelse af modellen.

Den optiske del blev ikke færdigcertificeret. Producenten nåede en ordenskontrol efter de 106 delceller og stoppede dér. Den nye integralværdi blev ikke skrevet til fil og fik ingen separat optisk kontrol. 25 %-kriteriet er derfor IKKE AFGJORT. V105's accepterede globale interval og bredde står uændret.

## 1. Grundlag og variable

Opgaven er V106 med fingerprint angivet i `task106.json`. Fysikkilden er hillipop-ede_n3 ved commit `5a131c91d657dd9a7c6364cc45b038710f8d0d97`; capturehash er `2514e250d20c456530be63e790a079176293a87a82c927b1e748d1eec405da9b`. Alle arkivhashes, vedhæftede filaliases og kilde-/opgavebindinger er kontrolleret.

Ved den observerede GitHub-base findes de verificerede V105-/V97-forgængere og motorversioner. De vedhæftede V106-filer er endnu ikke til stede i dette repository-snapshot. De anvendes som den identificerede, komplette indgående pakke med verificeret forgængerkæde; der påstås ikke GitHub-synkronisering.

Sæt u=ln[811/(1+z)], h=h_R, d=h_L−h_R, E=ΔX_e=d+q og t=v_L−v_R, hvor v=T_m/T_r. h, E, q og v er dimensionsløse. u vokser, når z falder. Hele det nye interval ligger over reionisationsstarten 753585/65536, så den offentlige elektronfraktion er X_L=h_L+q og X_R=h_R.

V97 giver en streng start over d=−q/2 ved præcis z=750. Der startes ikke en ny hydrogen- eller temperaturbane dér. V62-rækker 118–219 afskæres ved 750 og 700. Alle 102 rækker har alene SWIFT som tilladt gren i begge arme, identisk positiv H-indhylling, q<h<1 og 0<v<1. Rækkerne har identiske tilstandsforbindelser ved de mellemliggende cellegrænser. V77's ratecertifikat dækker hele den nødvendige temperaturstrimmel og interpolationens endestencils.

Den mindste observerede nedre h-grænse er cirka 1,69484488·10⁻⁴, og den mindste nedre v-grænse er cirka 0,973836139. Mindste margin 1−v_upper er cirka 0,00107318845. Det fælles 1+DK er positivt under det arvede certifikat. Autoritative eksakte brøker står i `calc/barrier107.json`.

## 2. Temperaturorden og den nedre barriere

V95's positive elektronforskel på den traverserede kildehistorie og de matchede temperaturstarter giver temperaturordenen. For det fælles temperaturfelt

\[
g(X,v)=-v+A(X)(1-v),\qquad A(X)=kX/(a+X),\quad k>0,\ a>0
\]

er

\[
t'=-(1+A_L)t+(A_L-A_R)(1-v_R).
\]

Da E>0, A er voksende, v_R<1 og t starter ved nul, giver variation-af-konstanter-formlen t≥0. På den kolde ratestrimmel er ∂logα_i/∂logv<0, så α_L,i≤α_R,i. V77's Saha-loft under 1 og α_i(v_R)≥α_i(1) giver U_R,i>0.

Efter indsættelse af kildens DAlpha_i=α_i(v)−α_i(1) kan SWIFT-feltet skrives

\[
f_{arm}=-\frac{n_H}{H_s}\sum_i C_{arm,i}U_{arm,i},\qquad
U_{arm,i}=\alpha_{arm,i}h_{arm}X_{arm}-\beta_i(1-h_{arm}),
\]

hvor β_i=α_i(1)S≥0 er fælles. Dette β_i er Saha-produktet, ikke den særskilt navngivne fotoionisationsrate i C-faktorerne. I HyRec-feltet er H_s i s⁻¹, n_H i cm⁻³ og rekombinationsraten i cm³/s; feltet er derfor en dimensionsløs afledt per u. Den fastholdte wrapper konverterer CLASS' n_H fra m⁻³ med faktoren 10⁻⁶. Det optiske K=n_H0·σ_T·Mpc_m bruger derimod de dokumenterede SI-konstanter; disse to enhedskonventioner blandes ikke i beregningen.

På d=−q/2 er h_L=h−q/2, X_L=h+q/2 og h_LX_L=h²−q²/4. Med δ_i=α_R,i−α_L,i≥0 følger præcist

\[
U_{R,i}-U_{L,i}=\alpha_{R,i}q^2/4+\beta_iq/2+\delta_i(h^2-q^2/4)>0.
\]

Kilden giver escape-raten e(h)=LYA_FACT·H_s/[n_H(1−h)(1+DK)], som er positiv og voksende med h. Ved fast z er DK og de andre C-parametre fælles for armene. V97's algebraiske identiteter viser C_i>0 og dC_i/de>0. Konkret er de afledte tællere 3jK og GK, med G=B_s+Λ+3j>0 og K=GB_p+jB_s>0. Dermed C_L,i≤C_R,i på kontaktfladen.

Hvis U_L,i≥0, giver U_R,i>U_L,i og C_R,i≥C_L,i>0, at C_R,iU_R,i>C_L,iU_L,i. Hvis U_L,i<0, følger det af C_i>0 og U_R,i>0. Derfor d'=f_L−f_R>0 på d=−q/2. En første kontakt fra den strenge start modsiges. Argumentet gælder gennem de sammenhængende celler og ved de arvede kontinuerte tabelknuder. Den øvre E<q-grænse genbruges fra det tidligere kildemaksimumbevis.

Det nye arbejde er kontrol af bevisets anvendelighed på [700,750], ikke en ny genberegning af V77's ratetabeller eller V97's polynomielle identiteter.

## 3. Separat kontrol

Producenten gennemgår de 102 rækker i fremadrettet u. Den separate barrierefunktion gennemgår arkivet i modsat rækkefølge og parser hex-tal med heltalsaritmetik. Den kontrollerer selv de afskårne z-intervaller, tilstandsforbindelser, de fælles H-bokse, grenvalg, h-/v-bounds, startcertifikatet, rate- og reionisationsdomænerne. Den stemmer med det gemte barrierecertifikat.

Kontrollen er uafhængig af producentens traversal og hex-konvertering. Den deler de historiske kildepræmisser og det analytiske V97-argument. Den er ikke en ny uafhængig validering af hele Q048–Q052-forhistorien.

## 4. Hvorfor den optiske beregning stoppede

V106's `frontier106.json` indeholder de rigtige 106 unikke delceller. Listen er bygget i stigende V66-rækkefølge, men guard-rækkerne er ordnet efter faldende z. Ved hvert snit 710,720,730,740 står to delceller derfor i omvendt lokal rækkefølge. Producenten går i stigende z og sammenlignede de to lister direkte.

Den efterfølgende eksakte diagnose viser:

- Identiske delceller som mængder, inklusive række-ID'er, guard-ID'er og eksakte endepunkter.
- Fire ombyttede par, altså otte forskellige listepositioner.
- Ingen manglende celler, dubletter, huller eller overlappende indre intervaller.
- Efter sortering efter eksakt nedre z, øvre z og ID'er er listerne identiske.

Dette er en fejl i ordenskontrollen og den indgående serialisering, ikke en dokumenteret fysisk uoverensstemmelse. Den oprindelige V106-liste, den fejlede kode og loggen bevares uændret. Der udføres ingen ny tætheds-, rod- eller vægtevaluering under diagnosen.

Producenten nåede 106 delceller før assertionen. De midlertidige vægtværdier blev ikke bevaret, og den optiske kontrolfunktion blev aldrig kørt. Der gives derfor ingen rekonstrueret integralværdi, ingen ny global intervalbredde og intet bestået 25 %-resultat.

## 5. Tællerrettelse og stop

Den oprindelige eksekveringskvittering viser nul nye optiske evalueringer, fordi tælleren blev opdateret efter retur fra producenten. Assertionen forhindrede den retur. En særskilt rettelse registrerer derfor ét forsøg, som nåede optisk arbejde, 106 behandlede delceller og nul godkendte nye optiske resultater. Den oprindelige kvittering overskrives ikke.

Det bundne forsøg stoppede efter cirka 0,418 sekunder ved den første fejl, langt under loftet på 300 sekunder. Den efterfølgende barrierekontrol er tidsmålt separat og indgår ikke fejlagtigt i den oprindelige runtime. Opgavens ene optiske forsøg er brugt; der er ikke kørt et andet forsøg, en parameter- eller gitterændring, en skalarintegration, et native par eller en fuldhistorieintegration.

`REPAIR_NOT_EXECUTED.patch` er en konkret kladde til en ny registreret opgave: sammenlign unikke delceller og sorteret eksakt rækkefølge, skriv ukontrollerede kandidater før de sidste gates og registrér forsøget, når optisk arbejde begynder. Listerettelsen er efterprøvet på de gemte koordinater. Den rettede optiske kode er ikke udført. Fysisk gitter, input, 25 %-kriterium og fælles baggrund skal forblive uændrede; det nye barrierecertifikat skal genbruges.

## 6. Betydning for Q052

Den strenge elektronindhylling er nu udvidet til z=700 inden for den samme SWIFT-gren. Den accepterede optiske grænse er fortsat V105's: omtrent [1,94816754668·10⁻⁶; 4,57064839822·10⁻⁵], med bredde cirka 4,37583164355·10⁻⁵. De autoritative brøker er videreført i `result107.json`. Bredden er stadig cirka 10.939,58 gange det foreløbige mål 4·10⁻⁹. Dette er ikke et estimat af resterende køretid.

Native baggrundsbinding, koordinatsammenfald, reproducerbarhed og fuldt numerisk fejlcertifikat mangler stadig. Q052 er ACTIVE / CONTINUE / INCONCLUSIVE. Den lokale barriere er bestået under de angivne betingelser; den bestilte samlede optiske test er ufuldstændig.
'''
summary=f'''# Q052 V107 · OVERLEVERING

**Halv-q-grænsen er udvidet til z=700 under de fastholdte kilde- og baggrundsforudsætninger. Den optiske test stoppede teknisk og er ikke færdigcertificeret.**

På z=700–750 er 0,5·10⁻⁶ < ΔX_e < 10⁻⁶ nu dokumenteret med kontrol af 102 kildeceller og en separat gennemgang. Sammen med V97 dækker grænsen z=700–800. Dette vedrører kildeligningernes baner; det fulde CLASS/P6-fejlcertifikat mangler fortsat.

Den optiske producent stoppede efter 106 delceller ved sammenligning af rækkefølgen i to lister. De samme celler findes i begge, men fire par står omvendt i V106's liste. Den eksakte diagnose viser ingen ændring af gitteret. Ingen ny integralværdi blev gemt eller kontrolleret, og 25 %-målet er derfor ikke afgjort. V105's accepterede optiske resultat er uændret.

En konkret rettelse er forberedt, men ikke kørt. Det ene tilladte optiske forsøg er brugt. Den oprindelige nul-tæller er bevaret og korrigeret i et særskilt record til ét udført forsøg og nul godkendte nye optiske resultater.

**Næste motor: Result Ingestion & Routing 2.3.0.** Opgaven er at optage det betingede delbevis og fejldiagnosen og afgrænse ét korrigeret optisk forsøg, som genbruger barrierecertifikatet.

Status: ACTIVE / CONTINUE / INCONCLUSIVE. Teknisk: INCOMPLETE. Lokal barriere: PASS_CONDITIONAL.

**13.700 aktivitetspoint — 300 til næste SoMe-milepæl.** Denne runde: 90 point som begrundet heuristisk aktivitetsvurdering. Ingen ny SoMe-pakke er forfalden.

Hele V106-journalen er bevaret. Certifikatet indeholder bevis, gemte resultater, original fejlkørsel, særskilt tællerrettelse, ændringsforslag og alle nødvendige input via det originale V106-arkiv. V106 og V107 er endnu ikke uploadet til den observerede GitHub-base.
'''
readme=f'''# Q052 V107 · Genoptagelse og filer

Start med `{taskfile}` og den fulde journal `{journal}`. Næste motor er Result Ingestion & Routing 2.3.0. Det lokale halv-q-resultat er betinget bestået; den optiske test er ufuldstændig.

`calc/compute107.py`, `calc/control107.py`, `calc/run107.py`, `calc/barrier107.json` og `calc/execution107.json` er bevarede records fra det fejlede forsøg. De må ikke rettes eller køres igen alene for at fortsætte. `diagnosis107.json` er det efterfølgende record med den uafhængige barrierekontrol, den eksakte rækkefølgeafvigelse og tællerrettelsen. Den oprindelige kvittering har tæller 0; det korrigerede forsøgstal er 1. Der er nul nye accepterede optiske resultater.

`REPAIR_NOT_EXECUTED.patch` er et forslag, ikke udført kode. Anvend det kun i en ny version/arbejdsmappe under den næste afgrænsede opgave med nye run-ID'er. Bevar originalerne, genbrug V107-barrieren, og hold de oprindelige 106 delceller og 25 %-kriteriet uændrede.

## Inputgenfinding uden ny beregning

Dette arkiv indeholder `history/{parent_cert}`, byteidentisk med den leverede V106-pakke. Heri ligger originale V105- og V97-arkiver. `restore_inputs107.py` pakker disse arkiver ud lokalt og genskaber de 39 inputfiler i `calc/` fra `input_mapping.json`, kontrolleret mod `calc/input_pins107.json`. Scriptet foretager ingen videnskabelig evaluering. Det er testet i en frisk udpakning af denne leverance.

`prepare107.py`, `diagnose107.py` og `build107.py` dokumenterer producentens workflow; deres oprindelige workspace-stier er provenance. Brug gendannelsesscriptet ved flytning til en ny mappe. Den fulde journal er separat rodleverance, og dens forgænger er bevaret som eksakt bytepræfiks.

## GitHub klar til brugerupload

Repository: {repo}. Observeret base `{head}`. V105-/V97-kæden og motorversioner er verificeret her; V106-filerne findes ikke i dette snapshot. Genlæs main og sikr forgængernes tilgængelighed, før pointeren opdateres. Tilføj de fire nye rodfiler `{short}`, `{journal}`, `{taskfile}`, `{cert}`. Bevar alle gamle versioner og brug den eksisterende Q052-pointer; der er ikke opfundet en ny registry-sti.

Ingen commit, PR eller offentlig post er udført. Aktivitetsledger: 13.700 point; næste milepæl 14.000; 300 til næste. M001–M013 videreføres uændret. Nye lokale IDs er foreløbige. Manifester udelader egen hash og den omsluttende ZIP-hash for at undgå cirkulær selvreference.
'''
append=f'''# Q052 · V107 · Betinget halv-q-udvidelse og teknisk stop

UTC: {stamp}. Europe/Copenhagen: {now.astimezone(ZoneInfo('Europe/Copenhagen')).isoformat()}.
Kørsel: `{run}`. CASE: {t['case_id']}. CURRENT_Q=TARGET_Q=Q052.

EXACT CURRENT Q:

> {t['exact_question']}

RUN COST: {points} pts
TOTAL WORK POINTS: {total} pts
SOME INTERVAL: 1000 pts
NEWLY CROSSED SOME MILESTONES: []
NEXT SOME MILESTONE: 14000 pts
POINTS TO NEXT SOME MILESTONE: {remaining} pts
SOME PACKAGE STATUS: NOT_DUE
SCIENTIFIC STATUS: ACTIVE / INCONCLUSIVE
TECHNICAL STATE: INCOMPLETE (local barrier PASS_CONDITIONAL; optical test stopped)
NEXT SCIENTIFIC ENGINE: BUBBLEVERSE.RESULT_INGESTION_ROUTING 2.3.0

{basis}

Hele den indgående V106-journal bevares før dette tillæg. Historiske konklusioner, raw-output og points/milepæle er ikke omskrevet. Den oprindelige optiske nultæller bevares sammen med den nye eksplicitte rettelse. Relevante journalafsnit og kildecertifikater er læst; der påstås ikke en ny fuldlæsning af hele forhistorien.

{proof}
'''
for label,obj in [('Resultat',result),('Fejldiagnose og rettelse',d),('Handoff',handoff),('Næste indtagsopgave',intake),('Claims',claims),('Kilder',sources),('Fuld aktivitetsledger',ledger)]:append+='\n## '+label+'\n\n```json\n'+dump(obj).decode()+'```\n'
parent_bytes=(U/parent_journal).read_bytes();(O/short).write_text(summary);(O/journal).write_bytes(parent_bytes+b'\n\n---\n\n'+append.encode());(O/taskfile).write_bytes(dump(intake))
members={'README.md':readme.encode(),'PROOF_V107.md':proof.encode(),'result107.json':dump(result),'handoff107.json':dump(handoff),'activity_ledger.json':dump(ledger),
 'diagnosis107.json':(P/'diagnosis107.json').read_bytes(),'input_audit107.json':dump(a),'source_register.json':dump(sources),'claim_map.json':dump(claims),'github_memory_update.json':dump(memory),
 'REPAIR_NOT_EXECUTED.patch':patch.encode(),'task106.json':(P/'task106.json').read_bytes(),taskfile:dump(intake),'input_mapping.json':(P/'input_mapping.json').read_bytes(),
 'repository_head.json':(P/'repository_head.json').read_bytes(),'repository_tree.json':(P/'repository_tree.json').read_bytes(),
 'restore_inputs107.py':(P/'restore_inputs107.py').read_bytes(),'prepare107.py':(P/'prepare107.py').read_bytes(),'diagnose107.py':(P/'diagnose107.py').read_bytes(),'build107.py':Path(__file__).read_bytes(),
 'history/'+parent_cert:(U/parent_cert).read_bytes()}
for n in ['compute107.py','control107.py','run107.py','barrier107.json','execution107.json','input_pins107.json']:members['calc/'+n]=(C/n).read_bytes()
manifest={'schema':'Q052_V107_OUTPUT_MANIFEST','case_id':t['case_id'],'q':'Q052','version':'V107','run_id':run,'created_at_utc':stamp,'repository':repo,'base_commit':head,
 'input_artifacts':a['attached_files'],'parent_journal':{'filename':parent_journal,'bytes':len(parent_bytes),'sha256':sha(parent_bytes),'preservation':'Exact byte prefix'},
 'result_snapshot_sha256':result_hash,'original_failed_run_preserved':True,'proposed_repair_executed':False,
 'archive_members':[{'path':n,'bytes':len(content),'sha256':sha(content)} for n,content in members.items()],
 'external_deliverables':[{'filename':n,'target_path':n,'role':role,'operation':'ADD','bytes':(O/n).stat().st_size,'sha256':sha((O/n).read_bytes())} for n,role in zip(names[:3],['primary_handoff','full_cumulative_journal','next_intake_task'])],
 'container':{'filename':cert,'target_path':cert,'self_hash_omitted':True},'contract_check':'MANUAL_LOCAL_CONTRACT; scientific incompleteness preserved'}
members['manifest.json']=dump(manifest)
with ZipFile(O/cert,'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
 for n,content in members.items():z.writestr(n,content)
with ZipFile(O/cert) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
 for x in manifest['archive_members']:assert sha(z.read(x['path']))==x['sha256'] and len(z.read(x['path']))==x['bytes']
 for n,h in e['code_sha256'].items():assert sha(z.read('calc/'+n))==h
 assert sha(z.read('calc/barrier107.json'))==e['output_sha256']['barrier107.json']
 assert sha(z.read('result107.json'))==intake['input_result_sha256']
 with tempfile.TemporaryDirectory() as td:
  z.extractall(td);test=subprocess.run([sys.executable,str(Path(td)/'restore_inputs107.py')],capture_output=True,text=True,timeout=60)
  assert test.returncode==0,test.stderr;restore=json.loads(test.stdout);assert restore['files']==39 and restore['scientific_evaluations']==0
assert (O/journal).read_bytes().startswith(parent_bytes)
assert ledger['entries'][:-1]==prior['entries'] and ledger['milestone_records']==prior['milestone_records'] and sum(x['run_points'] for x in ledger['entries'])==total
assert fp(read(O/taskfile))==intake['fingerprint_sha256'] and intake['exact_question']==result['exact_question']==handoff['exact_question']==t['exact_question']
validation={'status':'PASS_DELIVERY_INTEGRITY_ONLY','scientific_result_status':'CONDITIONAL_LOCAL_BARRIER_ONLY','optical_status':'INCOMPLETE',
 'journal_prefix_preserved':True,'prior_activity_entries_preserved':True,'original_failed_code_and_receipt_preserved':True,'next_task_fingerprint':intake['fingerprint_sha256'],
 'restore_test':restore,'total_points':total,'points_to_next_milestone':remaining,'files':[{'filename':n,'bytes':(O/n).stat().st_size,'sha256':sha((O/n).read_bytes())} for n in names]}
(P/'delivery_validation107.json').write_bytes(dump(validation));(P/'upload_request.json').write_bytes(dump({'uploads':[{'local_path':str(O/n),'purpose':'create_library_file','library_artifact_type':'report' if n.endswith('.md') else 'other'} for n in names]}))
print(json.dumps(validation,indent=2))
