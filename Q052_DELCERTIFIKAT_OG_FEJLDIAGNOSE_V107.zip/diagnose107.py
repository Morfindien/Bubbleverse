"""Post-stop record audit; no density/root/weight evaluation or integration."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime,timezone
import json,time,sys,importlib.util
P=Path(__file__).resolve().parent;C=P/'calc'
read=lambda p:json.loads(p.read_bytes())
task=read(P/'task106.json');front=read(P/'intake/frontier106.json');v66=read(C/'v66.json');binding=read(C/'binding.json')
expected=[]
for idx in range(4642,4744):
 source=v66['source_segments'][idx];a,b=max(F(700),F(source['z'][0])),min(F(750),F(source['z'][1]))
 cuts=sorted({a,b}|{F(k) for k in [710,720,730,740] if a<k<b})
 for left,right in zip(cuts,cuts[1:]):
  matches=[g['source_guard_index'] for g in binding['cells'] if F(g['z'][1])<=left<right<=F(g['z'][0])];assert len(matches)==1
  expected.append([idx,matches[0],str(left),str(right)])
received=front['partition'];assert len(expected)==len(received)==106
assert len({tuple(x) for x in expected})==len(expected)
assert len({tuple(x) for x in received})==len(received)
assert set(map(tuple,expected))==set(map(tuple,received))
key=lambda x:(F(x[2]),F(x[3]),x[0],x[1])
assert sorted(received,key=key)==expected
assert expected!=received
cursor=F(700)
for x in expected:assert F(x[2])==cursor<F(x[3]);cursor=F(x[3])
assert cursor==750
diff=[{'position':i,'provided':a,'ascending':b} for i,(a,b) in enumerate(zip(received,expected)) if a!=b]
boundaries=[k for k in [710,720,730,740] if any(F(x[2])==k or F(x[3])==k for x in received)]
assert len(diff)==8 and len(boundaries)==4
execution=read(C/'execution107.json')
assert execution['technical_state']=='FAIL' and "compute107.py\", line 119" in execution['traceback']
assert not (C/'result_raw107.json').exists() and not (C/'control107.json').exists()

# Validate only the already written new-domain barrier record, independently.
# The optical validate() entry point is intentionally not called.
spec=importlib.util.spec_from_file_location('control107_barrier_only',C/'control107.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
start=time.monotonic();domains=module.barrier_check(time.monotonic()+60);elapsed=time.monotonic()-start
assert len(domains)==102
barrier=read(C/'barrier107.json')
report={'schema':'Q052_V107_POST_STOP_DIAGNOSIS','created_at_utc':datetime.now(timezone.utc).isoformat(),
 'status':'EXACT_PARTITION_EQUAL_AS_SET_DIFFERENT_ORDER','historical_input_unchanged':True,
 'input_frontier_sha256':sha256((P/'intake/frontier106.json').read_bytes()).hexdigest(),
 'defect':'The V106 partition loops over guard rows in descending physical z within each V66 row. At each of four guard cuts the two subcells are stored in reverse order. The producer walks increasing z and compares the ordered lists directly.',
 'physical_partition_changed':False,'subcells':106,'mismatched_list_positions':len(diff),'guard_boundaries':boundaries,'differences':diff,
 'ascending_partition':expected,'original_ordered_equality_gate_passes':False,'canonical_ordered_equality_gate_passes':True,
 'exact_cover':['700','750'],'gaps':0,'overlapping_interiors':0,'duplicate_subcells':0,
 'barrier_control':{'status':'PASS_CONDITIONAL','source_rows':len(domains),'wall_seconds':elapsed,'barrier_sha256':sha256((C/'barrier107.json').read_bytes()).hexdigest(),
 'scope':'Reverse row traversal, separate integer-hex parser, source bounds, shared H, branch restriction, seed and rate-domain premises. V97 symbolic algebra and earlier physical certificates inherited, not recomputed.',
 'certified_electron_interval':['1/2000000','1/1000000'],'strict_interior':True,'domain':['700','750']},
 'optical_value_status':'NOT_PERSISTED_NOT_INDEPENDENTLY_CONTROLLED_NOT_CERTIFIED',
 'counter_correction':{'original_receipt_optical_counter':execution['new_domain_optical_evaluations'],
 'diagnosed_attempts_reaching_optical_evaluation':1,'completed_subcells_before_order_gate':106,'accepted_new_optical_results':0,
 'reason':'The original run counter increments only after main() returns. Failure at the post-loop order gate leaves the counter at zero despite completed weight work. Original execution receipt is preserved unchanged.'},
 'new_optical_evaluations_in_this_diagnosis':0,'new_scalar_integrations':0,'new_native_pairs':0,'new_full_history_integrations':0,
 'repair_contract':'On a separately authorized next attempt, compare unique exact subcell sets and canonical increasing-z order, check gap-free coverage and update the attempt counter before invoking the producer. Preserve original V106 frontier and failed run. Do not change the physical partition, inputs, tolerances or target. Reuse the certified V107 barrier.',
 'task_limit_handling':'The one permitted optical attempt was consumed. No rerun, grid refinement or second parameter evaluation was performed.'}
(P/'diagnosis107.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k in ['status','physical_partition_changed','subcells','mismatched_list_positions','barrier_control','optical_value_status','counter_correction','task_limit_handling']},indent=2))
