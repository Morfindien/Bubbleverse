"""One new-domain half-q/anchored optical evaluation, exact outward arithmetic."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import json,hashlib,time
P=Path(__file__).resolve().parent;S=1<<160;T=1<<100;Q=F(1,1000000)
def read(n):return json.loads((P/n).read_bytes())
def write(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def hx(s):return F.from_float(float.fromhex(s))
def down(x,s=S):return F((x*s).__floor__(),s)
def up(x,s=S):return F((x*s).__ceil__(),s)
def root(x):
 assert x>=0
 k=isqrt(x.numerator*S*S//x.denominator);lo=F(k,S);hi=lo if lo*lo==x else F(k+1,S)
 assert lo*lo<=x<=hi*hi and hi-lo<=F(1,S)
 return lo,hi
ss=lambda x:list(map(str,x))

def main(deadline):
 def tick():assert time.monotonic()<deadline,'PROTOTYPE_TIME_LIMIT'
 tick()
 for n,h in read('input_pins107.json').items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h,n
 task=read('task106.json');v62=read('v62.json');v77=read('v77.json');v83=read('v83.json');v95=read('v95.json');old=read('result97.json');anchor=read('result105.json')
 assert task['current_q']==task['target_q']=='Q052'
 assert old['source_electron_interval']==ss([Q/2,Q]) and old['auxiliary_barrier_domain'][0]=='750'
 assert old['barrier']=='d > -q/2; strict interior on [750,800]'
 assert v77['status']=='PASS_UNDER_FROZEN_PREMISES' and v77['phase5_z'][0]=='50'
 assert -1<hx(v77['cold_log_elasticity_hex'][0])<=hx(v77['cold_log_elasticity_hex'][1])<0
 assert F(v77['saha_over_h_squared_max'])<1
 assert v83['global_sup_abs_Delta_Xe']==str(Q) and v95['combined_positive_z']==['0','810'] and v95['status']=='ALL_373_PASS'
 assert hx(v62['one_plus_DK_range'][0])>0
 cfg=read('q048_prefix_config_v1.json')['cases']['hillipop-ede_n3']
 assert cfg['background']['thermal_flags']=={'has_varconst':0,'has_exotic_injection':0,'has_idm_b':0,'has_idm_g':0,'has_idm_dr':0,'recombination':1}
 assert F(cfg['frozen_reionization']['fixed_reio_start_exact'])<700
 v62rows=[];previous=F(750);mins={'h_lower':F(1),'v_lower':F(1),'one_minus_h_upper':F(1),'one_minus_v_upper':F(1),'H_lower':F(1)}
 for i in range(118,220):
  tick();L,R=[v62['arms'][arm]['records'][i] for arm in ['L','R']]
  za,zb=map(hx,R['z']);a,b=min(za,F(750)),max(zb,F(700))
  assert a==previous and b<a and L['z']==R['z'] and L['H_per_s']==R['H_per_s']
  assert hx(R['H_per_s'][0])>0
  for arm in [L,R]:
   assert arm['allowed_branches']==['SWIFT']
   hl,hu=map(hx,arm['whole_source'][0]);vl,vu=map(hx,arm['whole_source'][1])
   assert Q<hl<hu<1 and 0<vl<=vu<1
   mins['h_lower']=min(mins['h_lower'],hl);mins['v_lower']=min(mins['v_lower'],vl)
   mins['one_minus_h_upper']=min(mins['one_minus_h_upper'],1-hu);mins['one_minus_v_upper']=min(mins['one_minus_v_upper'],1-vu)
   if i>118:assert arm['initial']==v62['arms']['L' if arm is L else 'R']['records'][i-1]['end_source']
  mins['H_lower']=min(mins['H_lower'],hx(R['H_per_s'][0]))
  v62rows.append({'V62_row':i,'z_descending':ss([a,b]),'status':'PASS_WHOLE_CELL_SWIFT_BARRIER_PREMISES'})
  previous=b
 assert previous==700 and len(v62rows)==102
 barrier={'status':'PASS_CONDITIONAL_HALF_Q_EXTENSION','domain':['700','750'],'electron_interval':ss([Q/2,Q]),'strict_interior':True,
  'seed_z':'750','seed_ref':'result97.json','new_source_rows':102,'source_rows':v62rows,'minimum_margins':{k:str(v) for k,v in mins.items()},
  'proof':'V97 first-contact U and C monotonicity identities; E>0 implies temperature order, negative cold rate slopes imply alpha_L<=alpha_R. On d=-q/2, U_R-U_L>0 and C_L<=C_R, so d_prime>0. No native-history claim.',
  'inherited_temperature_order':'Matched initial temperatures; positive source electron difference on the traversed pre-reionization history and the positive temperature forcing imply v_L>=v_R.',
  'source_commit':task['source_commit'],'task_fingerprint':task['fingerprint_sha256']}
 write('barrier107.json',barrier)
 bind=read('binding.json');guard=read('guard.json');valid=read('guard_validation.json');cp=read('checkpoint.json');v73=read('v73.json');cap=read('capture.json');v66=read('v66.json')
 sh=lambda n:hashlib.sha256((P/n).read_bytes()).hexdigest()
 for obj in [bind,guard,cp,v73]:assert obj['capture_sha256']==sh('capture.json')==task['capture_sha256']
 for obj in [bind,cp,v73]:assert obj['guard_sha256']==sh('guard.json')
 assert bind['checkpoint_sha256']==v73['v151_sha256']==sh('checkpoint.json')
 assert valid['technical_state']=='PASS' and valid['phase']=='FINAL' and valid['result_sha256']==sh('guard.json')
 assert valid['checks_total']==valid['checks_passed']==6566 and valid['mutations_total']==valid['mutations_rejected']==24
 assert bind['source_commit']==guard['source_commit']==cap['source_commit']==anchor['source_commit']==task['source_commit']
 dep=bind['background_dependency_id'];assert dep==task['frozen']['background_dependency_id']
 assert all(x['background_dependency_id']==dep for x in bind['q_branches']) and [F(x['q']) for x in bind['q_branches']]==[Q,F(0)]
 assert anchor['checkpoint']['certified_end_a']=='1/801' and anchor['anchor_z800_gate']=='PASS'
 ec_anchor=F(anchor['checkpoint']['energy_endpoint'][1]);assert str(ec_anchor)==task['source_data']['scalar_anchor']['energy_upper']
 bg=cap['cases']['hillipop-ede_n3']['background'];fields={k:hx(v) for k,v in bg['fields'].items()}
 assert bg['flags']=={'has_scf':1,'has_lambda':0,'has_cdm':1,'has_ncdm':1,'has_ur':1,'has_idm':0,'has_idr':0,'has_dcdm':0,'has_dr':0,'has_fld':0,'has_curvature':0}
 assert fields['K']==fields['Omega0_lambda']==0 and bg['N_ncdm']==len(bg['neutrinos'])==1
 nu=bg['neutrinos'][0];nf={k:hx(v) for k,v in nu['fields'].items()};nodes=list(zip(map(hx,nu['q_ncdm_bg']),map(hx,nu['w_ncdm_bg'])))
 assert len(nodes)==11 and all(q>0 and w>0 for q,w in nodes) and nf['M_ncdm']>0 and nf['factor_ncdm']>0
 matter=fields['H0']**2*(fields['Omega0_b']+fields['Omega0_cdm']);radiation=fields['H0']**2*(fields['Omega0_g']+fields['Omega0_ur']);assert matter>0 and radiation>0
 B=hx(bg['scalar']['scf_parameters'][3]);flo=B*min(F('3.968e-8'),F.from_float(3.968e-8));fhi=B*max(F('3.968e-8'),F.from_float(3.968e-8))
 assert [flo,fhi]==[F(guard['source_intervals'][k]) for k in ['floorlo','floorhi']]
 constants=read('audit98.json')['optical_constant_inputs'];n=F(constants['nH0_m_minus3_exact']);sig=list(map(F,constants['sigma_m2']['exact']));mpc=list(map(F,constants['Mpc_m']['exact']))
 assert n==hx(cap['cases']['hillipop-ede_n3']['thermal_starts'][0]['constants']['nH0_SI'])
 kl,ku=n*sig[0]*mpc[0],n*sig[1]*mpc[1];assert ss([kl,ku])==v66['summary']['kernel_constants_exact']['C_inverse_Mpc']
 grow=guard['evaluators'][0]['rows'];slabs={}
 for i in range(69,75):
  g,prev=grow[i],grow[i-1];assert g['index']==i and g['committed'] and g['whole_cell_qualified'] and F(g['G_lower'])>0
  assert g['E_input_left']==prev['E_right'] and g['Y_left']==prev['Y_right'] and g['a0']==prev['a1']
 for cell in bind['cells']:
  i=cell['source_guard_index']
  if 70<=i<=74:
   g=grow[i];assert hashlib.sha256(json.dumps(g,sort_keys=True,separators=(',',':')).encode()).hexdigest()==cell['source_row_sha256']
   assert cell['background_dependency_id']==dep and cell['source_energy_cap']==g['E_input_left'] and F(cell['source_scalar_floor_upper'])==fhi
   assert list(map(F,cell['z']))==[F(g['z0']),F(g['z1'])];slabs[i]=cell
 assert len(slabs)==5
 cache={}
 def b0(s):
  if s not in cache:
   nl=nuu=F(0)
   for q,w in nodes:
    rl,ru=root(q*q*s*s+nf['M_ncdm']**2);nl+=q*q*w*rl;nuu+=q*q*w*ru
   base=matter*s**3+radiation*s**4;factor=nf['factor_ncdm']*s**3;cache[s]=[down(base+factor*nl),up(base+factor*nuu)]
  return cache[s]
 low=high=state=weight=prior_high=F(0);rows=[];cursor=F(700);caprange=[];bounds={F(x) for x in range(700,751,10)}
 for idx in range(4642,4744):
  tick();src=v66['source_segments'][idx];a,b=map(F,src['z']);a,b=max(a,F(700)),min(b,F(750))
  assert src['origin']=='V62' and a==cursor and a<b
  matches=[r['V62_row'] for r in v62rows if hx(v62['arms']['R']['records'][r['V62_row']]['z'][1])<=a<b<=hx(v62['arms']['R']['records'][r['V62_row']]['z'][0])];assert len(matches)==1
  el,eu=map(F,src['dx_exact']);assert el<=0<Q/2<Q<=eu
  oldwl,oldwu=map(F,src['K_over_H_exact']);assert 0<oldwl<=oldwu
  prior_high+=up(Q*oldwu*((b+1)**3-(a+1)**3)/3,T)
  cuts=sorted({a,b}|{x for x in bounds if a<x<b})
  for left,right in zip(cuts,cuts[1:]):
   tick();gs=[(i,g) for i,g in slabs.items() if F(g['z'][1])<=left<right<=F(g['z'][0])];assert len(gs)==1
   i,g=gs[0];ec=min(ec_anchor,F(g['source_energy_cap']));bl,bu=b0(1+left)[0],b0(1+right)[1]
   h2l,h2u=bl+flo/3,bu+(ec+fhi)/3;hl,hu=root(h2l)[0],root(h2u)[1];hl,hu=max(hl,F(g['H'][0])),min(hu,F(g['H'][1]));assert 0<hl<=hu
   rawl,rawu=down(kl/hu),up(ku/hl);wl,wu=max(oldwl,rawl),min(oldwu,rawu);assert 0<wl<=wu,'EMPTY_WEIGHT_INTERSECTION'
   mass=((right+1)**3-(left+1)**3)/3;il,iu=down(Q*wl*mass/2,T),up(Q*wu*mass,T)
   low+=il;high+=iu;state+=Q*(wl+wu)*mass/4;weight+=3*Q*(wu-wl)*mass/4;caprange.append(ec/(3*bu))
   rows.append({'V66_row':idx,'V62_row':matches[0],'guard_row':i,'z':ss([left,right]),'B0_box':ss([bl,bu]),'scalar_energy_cap':str(ec),'H_squared_raw':ss([h2l,h2u]),'H_box':ss([hl,hu]),'weight_raw':ss([rawl,rawu]),'weight_intersection':ss([wl,wu]),'electron_interval':ss([Q/2,Q]),'cubic_mass':str(mass),'increment':ss([il,iu]),'background_dependency_id':dep})
  cursor=b
 assert cursor==750 and len(rows)==106
 assert [[c['V66_row'],c['guard_row'],*c['z']] for c in rows]==read('frontier106.json')['partition']
 oldlo,oldhi=map(F,task['tolerances']['prior_block_interval']);assert oldlo==0 and oldhi==prior_high
 rounding=high-low-state-weight;assert 0<=rounding<212*F(1,T)
 assert oldlo<=low<=high<=oldhi
 ceiling=F(task['tolerances']['block_width_ceiling']);assert ceiling==3*(oldhi-oldlo)/4
 budget=read('budget106.json');assert budget['current_bins']['700:750'][:2]==task['tolerances']['prior_block_interval']
 oldglobal=list(map(F,task['tolerances']['V105_global_interval']));newglobal=[oldglobal[0]-oldlo+low,oldglobal[1]-oldhi+high]
 bins={k:list(v) for k,v in budget['current_bins'].items()};bins['700:750']=[str(low),str(high),106]
 assert [sum(F(v[i]) for v in bins.values()) for i in [0,1]]==newglobal
 assert bins['750:800']==budget['current_bins']['750:800']
 result={'schema':'Q052_V107_HALF_Q_ANCHORED_BLOCK','result_id':'LOCAL-Q052-SWIFT-700-750-CERTIFICATE-V107','task_id':task['task_id'],'task_fingerprint':task['fingerprint_sha256'],
  'source_commit':task['source_commit'],'capture_sha256':task['capture_sha256'],'exact_question':task['exact_question'],
  'technical_state':'PASS_PRODUCER_PENDING_CONTROL','scientific_state':'INCONCLUSIVE','block_method_target':'PASS' if high-low<=ceiling else 'FAIL_25_PERCENT_WIDTH_TARGET',
  'domain':['700','750'],'barrier_ref':'barrier107.json','barrier_sha256':sh('barrier107.json'),'strict_source_electron_interval':ss([Q/2,Q]),
  'source_rows':102,'subcells':106,'guard_rows':list(range(70,75)),'neutrino_nodes':11,'background_dependency_id':dep,'scalar_anchor_energy_upper':str(ec_anchor),
  'scalar_floor_interval':ss([flo,fhi]),'optical_K_inverse_Mpc':ss([kl,ku]),'prior_block_interval':ss([oldlo,oldhi]),'block_interval':ss([low,high]),'block_width':str(high-low),
  'block_width_ceiling':str(ceiling),'block_width_reduction_fraction':str(1-(high-low)/(oldhi-oldlo)),'target_met':high-low<=ceiling,
  'width_accounting':{'electron_enclosure':str(state),'weight_factor_enclosure':str(weight),'outward_increment_rounding':str(rounding),'quadrature_remainder':'0','branch_uncertainty':'0 within the certified common SWIFT domain'},
  'prior_global_interval':ss(oldglobal),'new_global_interval':ss(newglobal),'global_width':str(newglobal[1]-newglobal[0]),
  'global_width_reduction_fraction':str(1-(newglobal[1]-newglobal[0])/(oldglobal[1]-oldglobal[0])),
  'global_width_goal_ratio':str((newglobal[1]-newglobal[0])/F(task['tolerances']['provisional_full_width_goal'])),
  'global_width_goal_met':newglobal[1]-newglobal[0]<=F(task['tolerances']['provisional_full_width_goal']),'maximum_location':'810 inherited source-only V95 result',
  'current_bins':bins,'scalar_cap_over_three_B0_range':ss([min(caprange),max(caprange)]),'new_scalar_integrations':0,'new_native_pairs':0,'new_full_history_integrations':0,'new_domain_optical_evaluations':1,
  'native_comparison':'OPEN: source-real conditional result does not establish native background membership, coordinate alignment or whole-history numerical error.',
  'cells':rows}
 write('result_raw107.json',result);tick();return result
