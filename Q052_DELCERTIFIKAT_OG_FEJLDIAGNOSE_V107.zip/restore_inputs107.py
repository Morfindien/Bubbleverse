"""Restore pinned input bytes only. Does not execute scientific calculations."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import json
P=Path(__file__).resolve().parent
def unpack(archive,dest):
 with ZipFile(archive) as z:
  assert z.testzip() is None
  for name in z.namelist():
   target=dest/name
   assert target.resolve().is_relative_to(dest.resolve())
   if name.endswith('/'):continue
   data=z.read(name);target.parent.mkdir(parents=True,exist_ok=True)
   if target.exists():assert target.read_bytes()==data
   else:target.write_bytes(data)
base=P/'recovered_inputs';base.mkdir(exist_ok=True)
unpack(P/'history/Q052_INGESTION_CERTIFICATE_V106.zip',base/'intake')
unpack(base/'intake/history/Q052_SKALARANKER_OG_VAEGTCERTIFIKAT_V105.zip',base/'v105')
unpack(base/'intake/history/Q052_THOMSON_PILOTCERTIFIKAT_V97.zip',base/'v97')
mapping=json.loads((P/'input_mapping.json').read_text());pins=json.loads((P/'calc/input_pins107.json').read_text());count=0
for name,src in mapping.items():
 data=(P/src if src=='task106.json' else base/src).read_bytes();assert sha256(data).hexdigest()==pins[name]
 target=P/'calc'/name;target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==data
 else:target.write_bytes(data)
 count+=1
print(json.dumps({'status':'PASS_RESTORED_INPUT_BYTES_ONLY','files':count,'scientific_evaluations':0}))
