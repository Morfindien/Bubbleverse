# Q052 V107 · Halv-q-udvidelse og teknisk stop

## Resultat og afgrænsning

Under den samme fastholdte kilde, fælles tilladte baggrund B★ og matchede start ved z=810 gælder

\[
\frac{q}{2}<\Delta X_e(z)<q,\qquad q=10^{-6},\qquad 700\le z\le750.
\]

Sammen med V97 gælder den samme strenge grænse derfor på [700,800]. Dette er et betinget resultat for kildeligningernes baner. Det er ikke et nyt mål for native CLASS-output og heller ikke en observationsbekræftelse af modellen.

Den optiske del blev ikke færdigcertificeret. Producenten nåede en ordenskontrol efter de 106 delceller og stoppede dér. Den nye integralværdi blev ikke skrevet til fil og fik ingen separat optisk kontrol. 25 %-kriteriet er derfor IKKE AFGJORT. V105's accepterede globale interval og bredde står uændret.

## 1. Grundlag og variable

Opgaven er V106 med fingerprint angivet i `task106.json`. Fysikkilden er hillipop-ede_n3 ved commit `5a131c91d657dd9a7c6364cc45b038710f8d0d97`; capturehash er `2514e250d20c456530be63e790a079176293a87a82c927b1e748d1eec405da9b`. Alle arkivhashes, vedhæftede filaliases og kilde-/opgavebindinger er kontrolleret.

Ved den observerede GitHub-base findes de verificerede V105-/V97-forgængere og motorversioner. De vedhæftede V106-filer er endnu ikke til stede i dette repository-snapshot. De anvendes som den identificerede, komplette indgående pakke med verificeret forgængerkæde; der påstås ikke GitHub-synkronisering.

Sæt u=ln[811/(1+z)], h=h_R, d=h_L−h_R, E=ΔX_e=d+q og t=v_L−v_R, hvor v=T_m/T_r. h, E, q og v er dimensionsløse. u vokser, når z falder. Hele det nye interval ligger over reionisationsstarten 753585/65536, så den offentlige elektronfraktion er X_L=h_L+q og X_R=h_R.

V97 giver en streng start over d=−q/2 ved præcis z=750. Der startes ikke en ny hydrogen- eller temperaturbane dér. V62-rækker 118–219 afskæres ved 750 og 700. Alle 102 rækker har alene SWIFT som tilladt gren i begge arme, identisk positiv H-indhylling, q<h<1 og 0<v<1. Rækkerne har identiske tilstandsforbindelser ved de mellemliggende cellegrænser. V77's ratecertifikat dækker hele den nødvendige temperaturstrimmel og interpolationens endestencils.

Den mindste observerede nedre h-grænse er cirka 1,69484488·10⁻⁴, og den mindste nedre v-grænse er cirka 0,973836139. Mindste margin 1−v_upper er cirka 0,00107318845. Det fælles 1+DK er positivt under det arvede certifikat. Autoritative eksakte brøker står i `calc/barrier107.json`.

## 2. Temperaturorden og den nedre barriere

V95's positive elektronforskel på den traverserede kildehistorie og de matchede temperaturstarter giver temperaturordenen. For det fælles temperaturfelt

\[
g(X,v)=-v+A(X)(1-v),\qquad A(X)=kX/(a+X),\quad k>0,\ a>0
\]

er

\[
t'=-(1+A_L)t+(A_L-A_R)(1-v_R).
\]

Da E>0, A er voksende, v_R<1 og t starter ved nul, giver variation-af-konstanter-formlen t≥0. På den kolde ratestrimmel er ∂logα_i/∂logv<0, så α_L,i≤α_R,i. V77's Saha-loft under 1 og α_i(v_R)≥α_i(1) giver U_R,i>0.

Efter indsættelse af kildens DAlpha_i=α_i(v)−α_i(1) kan SWIFT-feltet skrives

\[
f_{arm}=-\frac{n_H}{H_s}\sum_i C_{arm,i}U_{arm,i},\qquad
U_{arm,i}=\alpha_{arm,i}h_{arm}X_{arm}-\beta_i(1-h_{arm}),
\]

hvor β_i=α_i(1)S≥0 er fælles. Dette β_i er Saha-produktet, ikke den særskilt navngivne fotoionisationsrate i C-faktorerne. I HyRec-feltet er H_s i s⁻¹, n_H i cm⁻³ og rekombinationsraten i cm³/s; feltet er derfor en dimensionsløs afledt per u. Den fastholdte wrapper konverterer CLASS' n_H fra m⁻³ med faktoren 10⁻⁶. Det optiske K=n_H0·σ_T·Mpc_m bruger derimod de dokumenterede SI-konstanter; disse to enhedskonventioner blandes ikke i beregningen.

På d=−q/2 er h_L=h−q/2, X_L=h+q/2 og h_LX_L=h²−q²/4. Med δ_i=α_R,i−α_L,i≥0 følger præcist

\[
U_{R,i}-U_{L,i}=\alpha_{R,i}q^2/4+\beta_iq/2+\delta_i(h^2-q^2/4)>0.
\]

Kilden giver escape-raten e(h)=LYA_FACT·H_s/[n_H(1−h)(1+DK)], som er positiv og voksende med h. Ved fast z er DK og de andre C-parametre fælles for armene. V97's algebraiske identiteter viser C_i>0 og dC_i/de>0. Konkret er de afledte tællere 3jK og GK, med G=B_s+Λ+3j>0 og K=GB_p+jB_s>0. Dermed C_L,i≤C_R,i på kontaktfladen.

Hvis U_L,i≥0, giver U_R,i>U_L,i og C_R,i≥C_L,i>0, at C_R,iU_R,i>C_L,iU_L,i. Hvis U_L,i<0, følger det af C_i>0 og U_R,i>0. Derfor d'=f_L−f_R>0 på d=−q/2. En første kontakt fra den strenge start modsiges. Argumentet gælder gennem de sammenhængende celler og ved de arvede kontinuerte tabelknuder. Den øvre E<q-grænse genbruges fra det tidligere kildemaksimumbevis.

Det nye arbejde er kontrol af bevisets anvendelighed på [700,750], ikke en ny genberegning af V77's ratetabeller eller V97's polynomielle identiteter.

## 3. Separat kontrol

Producenten gennemgår de 102 rækker i fremadrettet u. Den separate barrierefunktion gennemgår arkivet i modsat rækkefølge og parser hex-tal med heltalsaritmetik. Den kontrollerer selv de afskårne z-intervaller, tilstandsforbindelser, de fælles H-bokse, grenvalg, h-/v-bounds, startcertifikatet, rate- og reionisationsdomænerne. Den stemmer med det gemte barrierecertifikat.

Kontrollen er uafhængig af producentens traversal og hex-konvertering. Den deler de historiske kildepræmisser og det analytiske V97-argument. Den er ikke en ny uafhængig validering af hele Q048–Q052-forhistorien.

## 4. Hvorfor den optiske beregning stoppede

V106's `frontier106.json` indeholder de rigtige 106 unikke delceller. Listen er bygget i stigende V66-rækkefølge, men guard-rækkerne er ordnet efter faldende z. Ved hvert snit 710,720,730,740 står to delceller derfor i omvendt lokal rækkefølge. Producenten går i stigende z og sammenlignede de to lister direkte.

Den efterfølgende eksakte diagnose viser:

- Identiske delceller som mængder, inklusive række-ID'er, guard-ID'er og eksakte endepunkter.
- Fire ombyttede par, altså otte forskellige listepositioner.
- Ingen manglende celler, dubletter, huller eller overlappende indre intervaller.
- Efter sortering efter eksakt nedre z, øvre z og ID'er er listerne identiske.

Dette er en fejl i ordenskontrollen og den indgående serialisering, ikke en dokumenteret fysisk uoverensstemmelse. Den oprindelige V106-liste, den fejlede kode og loggen bevares uændret. Der udføres ingen ny tætheds-, rod- eller vægtevaluering under diagnosen.

Producenten nåede 106 delceller før assertionen. De midlertidige vægtværdier blev ikke bevaret, og den optiske kontrolfunktion blev aldrig kørt. Der gives derfor ingen rekonstrueret integralværdi, ingen ny global intervalbredde og intet bestået 25 %-resultat.

## 5. Tællerrettelse og stop

Den oprindelige eksekveringskvittering viser nul nye optiske evalueringer, fordi tælleren blev opdateret efter retur fra producenten. Assertionen forhindrede den retur. En særskilt rettelse registrerer derfor ét forsøg, som nåede optisk arbejde, 106 behandlede delceller og nul godkendte nye optiske resultater. Den oprindelige kvittering overskrives ikke.

Det bundne forsøg stoppede efter cirka 0,418 sekunder ved den første fejl, langt under loftet på 300 sekunder. Den efterfølgende barrierekontrol er tidsmålt separat og indgår ikke fejlagtigt i den oprindelige runtime. Opgavens ene optiske forsøg er brugt; der er ikke kørt et andet forsøg, en parameter- eller gitterændring, en skalarintegration, et native par eller en fuldhistorieintegration.

`REPAIR_NOT_EXECUTED.patch` er en konkret kladde til en ny registreret opgave: sammenlign unikke delceller og sorteret eksakt rækkefølge, skriv ukontrollerede kandidater før de sidste gates og registrér forsøget, når optisk arbejde begynder. Listerettelsen er efterprøvet på de gemte koordinater. Den rettede optiske kode er ikke udført. Fysisk gitter, input, 25 %-kriterium og fælles baggrund skal forblive uændrede; det nye barrierecertifikat skal genbruges.

## 6. Betydning for Q052

Den strenge elektronindhylling er nu udvidet til z=700 inden for den samme SWIFT-gren. Den accepterede optiske grænse er fortsat V105's: omtrent [1,94816754668·10⁻⁶; 4,57064839822·10⁻⁵], med bredde cirka 4,37583164355·10⁻⁵. De autoritative brøker er videreført i `result107.json`. Bredden er stadig cirka 10.939,58 gange det foreløbige mål 4·10⁻⁹. Dette er ikke et estimat af resterende køretid.

Native baggrundsbinding, koordinatsammenfald, reproducerbarhed og fuldt numerisk fejlcertifikat mangler stadig. Q052 er ACTIVE / CONTINUE / INCONCLUSIVE. Den lokale barriere er bestået under de angivne betingelser; den bestilte samlede optiske test er ufuldstændig.
