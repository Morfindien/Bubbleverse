# Q052 · V71 · Reproduktion

Python 3.10 eller nyere med standardbiblioteket. Den afleverede kontrol blev kørt med Python 3.12.14. Kør med assertions slået til. Pak dette arkiv ud. Læg de tre videnskabelige input i samme mappe, her kaldet `inputs`.

| Inputfil | Rolle |
| --- | --- |
| Q052_FULL_HISTORY_RAW_V60.json | Begge observerede tabeller og historikker på det fælles interval |
| Q052_UPPER_CELL_RAW_V69.json | Nye post-history-rækker, eta-kurvatur og baggrundsstencil for z = 810 |
| Q052_THOMSON_CERTIFICATE_V66.zip | Eksakt præfiks, panelvise kildeindeslutninger og Q051-beviset |

Hvis V60 kun findes som fire dele, findes `recover_raw.py` i V66-arkivet. Brug dette program til at genskabe filen under navnet i tabellen. Alle tre input er bundet til SHA-256 i `result.json` og i producenten.

```sh
python certify71.py inputs > rebuilt.json
python check71.py inputs rebuilt.json > rebuilt_control.json
cmp result.json rebuilt.json
cmp control.json rebuilt_control.json
```

`result.json` indeholder eksakte rationale værdier som strenge og rationale intervaller for det algebraiske maksimum. `control.json` er kvitteringen fra en separat algebraisk beregningsvej. Celleindeks er nulbaserede. Lokal koordinat er andelen af en hel splinecelle. Alle par bruger L minus R. Den akkumulerede dybde har nulpunkt ved z = 0. Endepunktet for hovedresultatet bruger den faktisk returnerede konforme tid. Se journalens V71-afsnit for antagelserne bag fejlgrænserne.
