"""Python 3.10+; use: python certify71.py INPUT_DIRECTORY > result.json."""
import hashlib
import json
import sys
import zipfile
from fractions import Fraction as F
from pathlib import Path
from math import comb

FILES = {
    "Q052_FULL_HISTORY_RAW_V60.json": "e683333446b1ea3d889cd837520f8f475a8926c1bad4cdc4459150dffb11bfcb",
    "Q052_UPPER_CELL_RAW_V69.json": "9fda67b212a565e9286bccc00dfec9ec5268875bef513fb354b47750a0e799fa",
    "Q052_THOMSON_CERTIFICATE_V66.zip": "013112b720bef72b3b587665334a25f1c327982b48678a5eb65c861991252612",
}

def exact(s):
    return F(float.fromhex(s))

def sha(b):
    return hashlib.sha256(b).hexdigest()

def cubic(y0, y1, m0, m1, h):
    k=h*h/6
    return [y0, y1-y0-k*(2*m0+m1), 3*k*m0, k*(m1-m0)]

def ev(p,x):
    out=0
    for c in reversed(p):
        out=out*x+c
    return out

def bern(p,a,b):
    """Bernstein coefficients of p(a+(b-a)t) on [0,1]."""
    n=len(p)-1
    shifted=[(b-a)**k*sum(comb(i,k)*p[i]*a**(i-k) for i in range(k,n+1)) for k in range(n+1)]
    return [sum(F(comb(j,k),comb(n,k))*shifted[k] for k in range(j+1)) for j in range(n+1)]

def span(x):
    return [min(x),max(x)]

def as_text(obj):
    if isinstance(obj,F): return str(obj)
    raise TypeError(type(obj).__name__)

def run(directory):
    inputs=[(directory/n).read_bytes() for n in FILES]
    assert [sha(b) for b in inputs]==list(FILES.values())
    raw,upper=map(json.loads,inputs[:2])
    with zipfile.ZipFile(directory/list(FILES)[2]) as archive:
        receipt=json.loads(archive.read('receipt.json'))
        band=json.loads(archive.read('band_intersection.json'))
        assert sha(archive.read('receipt.json'))==band['receipt_sha256']
        assert sha(archive.read('Q051_GLOBAL_HYBRID_AND_OBSERVABLE_PROOF_V7.md'))==band['Q051_proof_sha256']
    rows={}; tops={}
    for arm in 'LR':
        old=raw['arms'][arm]; new=upper['arms'][arm]
        for filename in ['public_table_hex.jsonl','history.csv']:
            assert sha(old[filename].encode())==new[filename]['sha256']
        toptext=new['upper_cell69.json']['text']
        assert sha(toptext.encode())==new['upper_cell69.json']['sha256']
        top=tops[arm]=json.loads(toptext)
        assert [top[k] for k in ('arm','lower_i','upper_i','xe_column','opacity_column','eta_curvature_column')]==[arm,4860,4861,0,1,3]
        table=[json.loads(line) for line in old['public_table_hex.jsonl'].splitlines()[1:]]
        assert table[-2:]==top['top_rows'][:2]
        rows[arm]=table+[top['top_rows'][2]]
    assert tops['L']['eta810_native']==tops['R']['eta810_native']
    stencil=tops['L']['background_eta_z_stencil']; assert stencil==tops['R']['background_eta_z_stencil']
    L,R=rows['L'],rows['R']
    assert len(L)==len(R)==4862 and all((l['i'],l['z'],l['eta'])==(i,r['z'],r['eta']) and i==r['i'] for i,(l,r) in enumerate(zip(L,R)))
    z=[exact(v['z']) for v in L]; assert z[0]==0 and all(a<b for a,b in zip(z,z[1:])) and z[-2]<810<z[-1]
    def diff(i,key,j):
        return exact(L[i][key][j])-exact(R[i][key][j])
    y=[diff(i,'values',0) for i in range(len(z))]
    m=[diff(i,'d2_dz2',0) for i in range(len(z))]
    panels=receipt['source_segments']; fused=band['source_segments']
    assert len(panels)==len(fused)==4990
    sidx=0; cells=[]; err=[F(0),F(0)]; top_err=[None,None]
    for i,(a,b) in enumerate(zip(z,z[1:])):
        h=b-a; end=min(b,F(810)); limit=(end-a)/h
        p=cubic(y[i],y[i+1],m[i],m[i+1],h)
        controls=bern(p,F(0),limit)
        cells.append((p,limit,max(map(abs,controls))))
        first=sidx; here=a; lowers=[]; uppers=[]
        while here<end:
            seg=panels[sidx]; za,zb=map(F,seg['z']); assert za==here and zb<=end
            cap=F('0.0023814') if za<F(4006,49) else F('0.00099225') if za<695 else F('0.00033075')
            slo,shi=map(F,seg['dx_exact']); slo=max(slo,-cap); shi=min(shi,cap); assert slo<=shi
            pc=bern(p,(za-a)/h,(zb-a)/h)
            lowers.append(min(pc)-shi); uppers.append(max(pc)-slo)
            sidx+=1; here=zb
        err=[min(err[0],min(lowers)),max(err[1],max(uppers))]
        if i==len(z)-2: top_err=[min(lowers),max(uppers)]; top_first=first
    assert sidx==len(panels)
    witness=max(max(abs(ev(p,limit*u)) for u in [F(0),F(1,2),F(1)]) for p,limit,_ in cells)
    candidates=[i for i,c in enumerate(cells) if c[2]>=witness]
    assert len(candidates)==1
    win=candidates[0]; p,u,_=cells[win]
    d=[p[i]*i for i in range(1,4)]
    assert ev(d,0)>0>ev(d,u) and p[0]>0 and ev(p,u)>0
    # A quadratic with opposite signs at the endpoints has exactly one interior root.
    lo,hi=F(0),u
    for _ in range(170):
        mid=(lo+hi)/2
        if ev(d,mid)>0: lo=mid
        else: hi=mid
    peak=span(bern(p,lo,hi)); zw=[z[win]+s*(z[win+1]-z[win]) for s in (lo,hi)]
    other=max(c[2] for i,c in enumerate(cells) if i!=win); assert peak[0]>other
    top,limit,_=cells[-1]; der=[i*top[i] for i in range(1,4)]
    # Count roots on the top interval using its derivative Bernstein coefficients.
    top_d=bern(der,F(0),limit)
    # Distinct endpoint signs imply one simple stationary point. Handle any sign pattern exactly.
    def roots_q(q,c):
        import math
        a,b,d=q[2],q[1],q[0]
        if a==0:
            return [[-d/b,-d/b]] if b and 0< -d/b <c else []
        disc=b*b-4*a*d
        if disc<0:return []
        scale=2**190; j=math.isqrt((disc.numerator*scale**2)//disc.denominator)
        s=F(j,scale); upper=s if s*s==disc else s+F(1,scale)
        bounds=[sorted([(-b+sign*v)/(2*a) for v in (s,upper)]) for sign in (-1,1)]
        for l,h in bounds: assert not (l<=0<=h or l<=c<=h)
        return [pair for pair in bounds if 0<pair[0] and pair[1]<c]
    top_roots=roots_q(der,limit)
    top_values=[ev(top,0),ev(top,limit)]
    for l,h in top_roots: top_values.extend(bern(top,l,h))
    # The opacity uses its post-history eta curvature, stored in values[3].
    D=exact(L[-2]['eta'])-exact(L[-1]['eta']); assert D>0
    op=cubic(diff(-2,'values',1),diff(-1,'values',1),diff(-2,'values',3),diff(-1,'values',3),D)
    eta0=exact(L[-2]['eta']); native=exact(tops['L']['eta810_native'])
    hits=[s for s in stencil if min(map(exact,s['z']))<=810<=max(map(exact,s['z']))]; assert len(hits)==1
    st=hits[0]; a,b=map(exact,st['z']); eta=ev(cubic(*map(exact,st['eta']),*map(exact,st['d2eta_dz2']),b-a),(810-a)/(b-a))
    tN,tI=[(eta0-v)/D for v in (native,eta)]
    controls=bern(op,F(0),max(tN,tI)); assert min(controls)>0 and 0<min(tN,tI)<=max(tN,tI)<1
    pre=F(receipt['stored_cells'][-1]['pair_end_exact']); assert pre==F(receipt['summary']['max_ideal_knot_abs_exact'])
    # V66 outward-rounded prefix supremum is sufficient even without exact endpoint equality.
    prefix_bound=exact(receipt['summary']['ideal_stored_sup_abs_dTau'][1])
    prim=[pre]+[D*v/(k+1) for k,v in enumerate(op)]
    vN,vI=[ev(prim,u) for u in (tN,tI)]; assert min(vN,vI)>prefix_bound
    sL=min(F(v['whole'][0]) for v in fused[top_first:]); sU=max(F(v['whole'][1]) for v in fused[top_first:])
    prefix_err=list(map(F,band['summary']['stored_curve_minus_source'])); top_te=[pre-sU,vN-sL]; full_te=[min(prefix_err[0],top_te[0]),max(prefix_err[1],top_te[1])]
    endsrc=list(map(F,fused[-1]['end'])); x810=ev(top,limit); e810=x810-F(1,10**6)
    return dict(schema='Q052_STORED_CERTIFICATE_V71',input_sha256=FILES,sign='L(q=1e-6) minus R(q=0); signed error = stored pair minus conditional source pair',cells=len(cells),source_panels=sidx,top_panels=sidx-top_first,top_z=[z[-2],z[-1]],top_z_cut=limit,xe=dict(winning_cell=win,winning_cell_z=z[win:win+2],z_max=zw,sup_abs=peak,other_cells_abs_upper=other,peak_polynomial=p,peak_normalized_root_interval=[lo,hi],top_polynomial=top,top_derivative_bernstein=top_d,top_stationary_roots=top_roots,top_range=span(top_values),at_810=x810,signed_error=err,signed_error_top=top_err,conditional_source_at_810=F(1,10**6),signed_error_at_810=e810,conditional_sup_abs_error_lower=abs(e810)),tau=dict(eta810_returned_hex=tops['L']['eta810_native'],eta810_returned=native,eta810_ideal=eta,eta_width=D,t_returned=tN,t_ideal=tI,opacity_polynomial=op,positive_controls=controls,primitive_polynomial=prim,prefix_endpoint=pre,prefix_abs_upper=prefix_bound,increment_at_810=vN-pre,sup_abs_returned_cut=vN,sup_abs_ideal_cut=vI,returned_minus_ideal=vN-vI,signed_error_top=top_te,signed_error=full_te,signed_error_at_810=[vN-endsrc[1],vN-endsrc[0]],conditional_source_sup_abs=band['summary']['full_sup_abs_source']))

if __name__=='__main__':
    print(json.dumps(run(Path(sys.argv[1])),default=as_text,indent=2))
