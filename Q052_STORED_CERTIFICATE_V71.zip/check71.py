"""Second implementation; python check71.py INPUT_DIRECTORY result.json > control.json."""
import hashlib
import json
import sys
import zipfile
from fractions import Fraction as F
from pathlib import Path

def binary(s):
    return F(float.fromhex(s))

def bezier(row0,row1,v,k,w):
    a,b=[binary(r[v[0]][v[1]]) for r in (row0,row1)]
    c,d=[binary(r[k[0]][k[1]]) for r in (row0,row1)]
    h2=w*w
    return [a,(2*a+b)/3-h2*(2*c+d)/18,(a+2*b)/3-h2*(c+2*d)/18,b]

def split(poly,t):
    layers=[poly]
    while len(layers[-1])>1:
        prev=layers[-1]
        layers.append([a+(b-a)*t for a,b in zip(prev,prev[1:])])
    return [row[0] for row in layers],[row[-1] for row in reversed(layers)]

def restrict(p,a,b):
    if a==0 and b==1: return p
    tail=split(p,a)[1] if a else p
    return split(tail,(b-a)/(1-a))[0] if b<1 else tail

def val(p,u):
    return split(p,u)[0][-1]

def point_formula(y,m,h,u):
    a,b=y; c,d=m; v=1-u
    return v*a+u*b+h*h*((v**3-v)*c+(u**3-u)*d)/6

def within(rng,*values):
    lo,hi=map(F,rng)
    assert all(lo<=v<=hi for v in values)

def verify(base,file):
    r=json.loads(file.read_bytes()); X=r['xe']; T=r['tau']
    raw,top=[json.loads(next(base.glob(p)).read_bytes()) for p in ('*RAW_V60.json','*RAW_V69.json')]
    with zipfile.ZipFile(next(base.glob('*CERTIFICATE_V66.zip'))) as archive:
        receipt=json.loads(archive.read('receipt.json')); fused=json.loads(archive.read('band_intersection.json'))
    table=[]; tops=[]
    for arm in 'LR':
        old=raw['arms'][arm]; capture=top['arms'][arm]
        for name in ('history.csv','public_table_hex.jsonl'):
            assert hashlib.sha256(old[name].encode()).hexdigest()==capture[name]['sha256']
        y=list(map(json.loads,old['public_table_hex.jsonl'].splitlines()[1:]))
        t=json.loads(capture['upper_cell69.json']['text']); assert t['top_rows'][:2]==y[-2:]
        y.append(t['top_rows'][2]); table.append(y); tops.append(t)
    z=[binary(row['z']) for row in table[0]]
    winner=X['winning_cell']; lower=F(X['sup_abs'][0]); n=0; peak_t=None; errlo=errhi=0
    for i,(a,b) in enumerate(zip(z,z[1:])):
        w=b-a; end=min(b,F(810)); limit=(end-a)/w
        arms=[bezier(t[i],t[i+1],('values',0),('d2_dz2',0),w) for t in table]
        c=[x-y for x,y in zip(*arms)]
        whole=restrict(c,F(0),limit)
        if i!=winner:
            assert max(map(abs,whole))<=F(X['other_cells_abs_upper'])<lower
        else:
            d=[3*(y-x) for x,y in zip(c,c[1:])]
            assert d[0]>0 and d[-1]<0 and all(v>0 for v in c)
            assert sum((a>0)!=(b>0) for a,b in zip(d,d[1:]))==1
            left,right=F(0),F(1)
            for _ in range(225):
                mid=(left+right)/2
                if val(d,mid)>0:left=mid
                else:right=mid
            within(X['z_max'],a+w*left,a+w*right)
            within(X['sup_abs'],*restrict(c,left,right))
            peak_t=[str(left),str(right)]
        current=a
        while current<end:
            panel=receipt['source_segments'][n]
            start,stop=map(F,panel['z']); assert start==current and stop<=end
            caps=[abs(F(fused['summary']['band_bounds'][entry[2]])) for entry in fused['source_segments'][n]['subinterval_bands']]
            bound=max(caps); low,high=map(F,panel['dx_exact'])
            low=max(low,-bound); high=min(high,bound)
            sub=restrict(c,(start-a)/w,(stop-a)/w)
            el,eu=min(sub)-high,max(sub)-low
            within(X['signed_error'],el,eu)
            if i==len(z)-2:within(X['signed_error_top'],el,eu)
            errlo=min(errlo,el);errhi=max(errhi,eu)
            current=stop; n+=1
        if i==len(z)-2:
            assert all(p>q for p,q in zip(whole,whole[1:])) and not X['top_stationary_roots']
            assert list(map(F,X['top_range']))==[whole[-1],whole[0]]
            assert val(c,limit)-F('0.000001')==F(X['signed_error_at_810'])
    assert [errlo,errhi]==list(map(F,X['signed_error']))
    assert peak_t and n==4990
    t=tops[0]; eta0=binary(t['top_rows'][1]['eta'])
    h=eta0-binary(t['top_rows'][2]['eta'])
    native=binary(t['eta810_native']); st=next(v for v in t['background_eta_z_stencil'] if min(map(binary,v['z']))<=810<=max(map(binary,v['z'])))
    za,zb=map(binary,st['z'])
    ideal=point_formula(list(map(binary,st['eta'])),list(map(binary,st['d2eta_dz2'])),zb-za,(810-za)/(zb-za))
    assert ideal==F(T['eta810_ideal']) and native==F(T['eta810_returned'])
    arms=[bezier(x[-2],x[-1],('values',1),('values',3),h) for x in table]
    pd=[x-y for x,y in zip(*arms)]
    assert min(restrict(pd,F(0),(eta0-min(native,ideal))/h))>0
    prefix=F(receipt['stored_cells'][-1]['pair_end_exact']); vals=[]
    for e in [native,ideal]:
        u=(eta0-e)/h
        # Simpson's rule is an identity for cubics. Integrate each arm separately.
        integrals=[(eta0-e)*(p[0]+4*val(p,u/2)+val(p,u))/6 for p in arms]
        vals.append(prefix+integrals[0]-integrals[1])
    assert vals==[F(T[k]) for k in ('sup_abs_returned_cut','sup_abs_ideal_cut')]
    assert min(vals)>binary(receipt['summary']['ideal_stored_sup_abs_dTau'][1])
    assert vals[0]-vals[1]==F(T['returned_minus_ideal'])
    segs=[s for p,s in zip(receipt['source_segments'],fused['source_segments']) if F(p['z'][0])>=z[-2]]
    errs=[[prefix-F(s['whole'][1]),vals[0]-F(s['whole'][0])] for s in segs]
    te=[min(er[0] for er in errs),max(er[1] for er in errs)]; assert te==list(map(F,T['signed_error_top']))
    prefix_err=list(map(F,fused['summary']['stored_curve_minus_source']))
    assert [min(te[0],prefix_err[0]),max(te[1],prefix_err[1])]==list(map(F,T['signed_error']))
    sl,sh=map(F,segs[-1]['end']); assert [vals[0]-sh,vals[0]-sl]==list(map(F,T['signed_error_at_810']))
    return dict(status='PASS',method='Per-arm cubic Bernstein form; de Casteljau subdivision; independent derivative localization; exact separate-arm Simpson integration; source-panel interval comparisons',shared_evidence='Same exported coefficients and inherited V66 source bounds; algebraic cross-check, no second physical experiment.',source_panels=n,top_source_panels=len(segs),stored_cells=len(z)-1,winning_cell=winner,peak_t_bracket=peak_t,new_native_runs=0,result_sha256=hashlib.sha256(file.read_bytes()).hexdigest())

if __name__=='__main__':
    print(json.dumps(verify(Path(sys.argv[1]),Path(sys.argv[2])),indent=2))
