"""Exact algebra checks; no evaluation of a physical state or trajectory."""
from pathlib import Path
from datetime import datetime,timezone
import sympy as s
import json

h,q,b,aR,aL,sigma=s.symbols('h q b aR aL sigma')
bs,bp,j,lam,e,de=s.symbols('bs bp j lam e de')
vL,vR,AL,AR=s.symbols('vL vR AL AR')
P=(h-q+b)*(h+b);D=(q-2*b)*h+b*(q-b);kap=1-D/h**2
UR=aR*h**2-sigma*(1-h)
UL=aL*P-sigma*(1-h+q-b)
G=bs+lam+3*j;K=G*bp+j*bs
den=(bs+lam)*(bp+j)+3*j*bp+G*e
Ns=lam*(bp+j)+(lam+3*j)*e
Np=lam*j+G*e
cs=Ns/den;cp=Np/den
gammaS=G;gammaP=bp+j+e
checks=[]
def check(name,expr):
    r=s.factor(expr);assert r==0,(name,r)
    checks.append({'name':name,'residual':'0'})
check('product_deficit',h**2-P-D)
check('positive_product_kappa',kap-P/h**2)
check('full_Saha_U_comparison',kap*UR-UL-((aR-aL)*P+sigma*((q-b)+D*(1-h)/h**2)))
check('direct_U_difference',UR-UL-(aR*D+(aR-aL)*P+sigma*(q-b)))
check('deficit_normalized_lower',D/h**2-(q-2*b)/h-b*(q-b)/h**2)
check('thermal_difference',(-vL+AL*(1-vL))-(-vR+AR*(1-vR))-(-(1+AL)*(vL-vR)+(AL-AR)*(1-vR)))
check('C_s_Gamma_identity',cs-(lam+3*j*e/gammaP)/(gammaS-3*j*j/gammaP))
check('C_p_Gamma_identity',cp-(e+j*lam/gammaS)/(gammaP-3*j*j/gammaS))
for name,N,C,eta in [('s',Ns,cs,3*j),('p',Np,cp,G)]:
    check('C_'+name+'_positive_derivative',s.diff(C,e)-eta*K/den**2)
    check('C_'+name+'_relative_excess',C.subs(e,e+de)/C-1-de*eta*K/(den.subs(e,e+de)*N))
    logder=eta*K/(den*N)
    check('C_'+name+'_log_derivative',s.diff(C,e)/C-logder)
    check('C_'+name+'_decreasing_log_derivative',s.diff(logder,e)+eta*K*(G*N+s.diff(N,e)*den)/(den*N)**2)
result={'status':'PASS','sympy_version':s.__version__,'checks':checks,
 'sign_premises':'0<b<q/2<h, h<1; alphaR>=alphaL>0; sigma>=0; bs,bp,j,lambda,e>0; de>=0',
 'scope':'Exact symbolic validation of the new proof and two coefficient formulas; not an extra physical run.',
 'verified_utc':datetime.now(timezone.utc).isoformat()}
Path(__file__).with_name('symbolic_check117.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'PASS','exact_identities':len(checks)}))
