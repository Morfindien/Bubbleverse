"""One primary pass and one separate control, hard 300 s combined limit."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
from fractions import Fraction as F
import os,sys,subprocess,json,time,traceback

P=Path(__file__).resolve().parent
dump=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
sha=lambda p:sha256(p.read_bytes()).hexdigest()
lock=P/'run117.lock'
with lock.open('x') as f:f.write(datetime.now(timezone.utc).isoformat()+'\n')
start=time.monotonic();stamp=datetime.now(timezone.utc).isoformat()
env=dict(os.environ);env['LD_LIBRARY_PATH']=str(P/'runtime')
record={'run_id':'LOCAL-Q052-V117-CONSTANT-Q-OVER-16-CELL235','started_utc':stamp,
 'technical_state':'INCOMPLETE','primary_passes':0,'independent_controls':0,'wall_limit_seconds':300,
 'parameter_searches':0,'new_native_pairs':0,'new_optical_evaluations':0,
 'new_scalar_integrations':0,'new_full_history_integrations':0,'commands':[]}
try:
    for name,out,role in [('validate117.py','input_check117.log','input'),('preflight114.py','runtime_check117.json','preflight'),
                         ('calc/primary117.py','primary117.json','primary'),('calc/control117.py','control117.json','control')]:
        remaining=300-(time.monotonic()-start);assert remaining>0
        if role=='primary':record['primary_passes']+=1
        if role=='control':record['independent_controls']+=1
        r=subprocess.run([sys.executable,str(P/name)],cwd=P,env=env,capture_output=True,timeout=remaining)
        (P/out).write_bytes(r.stdout);(P/(out+'.stderr.log')).write_bytes(r.stderr)
        record['commands'].append({'script':name,'exit_code':r.returncode,'output':out})
        assert r.returncode==0,(name,r.stderr.decode()[-4000:])
    a=json.loads((P/'primary117.json').read_bytes());b=json.loads((P/'control117.json').read_bytes())
    for key in ['q','constant_b','z_ascending','hR_face_bounds','seed_z','entry_E_lower']:
        assert a[key]==b[key],key
    assert F(a['mixed_normalized_lower'])>0 and F(b['whole_cell_normalized_lower'])>0
    assert a['resolved_mixed_slabs']+a['excluded_mixed_slabs']==a['closed_slabs']==16
    record['technical_state']='PASS';record['comparison']='PASS_DOMAIN_SEED_AND_STRICT_SIGN'
except Exception as e:
    record['technical_state']='FAIL';record['failure']=str(e);record['traceback']=traceback.format_exc()
finally:
    record['ended_utc']=datetime.now(timezone.utc).isoformat();record['wall_seconds']=time.monotonic()-start
    record['code_sha256']={n:sha(P/n) for n in ['validate117.py','preflight114.py','calc/primary117.py','calc/control117.py','run117.py']}
    record['output_sha256']={n:sha(P/n) for n in ['input_check117.json','runtime_check117.json','primary117.json','control117.json'] if (P/n).exists()}
    record['task_sha256']=sha(P/'input/Q052_MATEMATIKOPGAVE_V116.json')
    dump(P/'execution117.json',record)
    print(json.dumps(record,indent=2))
    if record['technical_state']!='PASS':sys.exit(1)
