"""Portable numerical reproduction using only the extracted V117 ZIP.
Creates a temporary directory; leaves original historical results unchanged.
The producer and control are each run once, under a combined 300 second limit.
"""
from pathlib import Path
from hashlib import sha256
import tempfile,shutil,subprocess,os,sys,time,json

P=Path(__file__).resolve().parent
manifest=json.loads((P/'manifest117.json').read_bytes())
for row in manifest['members']:
    f=P/row['path'];assert f.is_file(),f
    assert f.stat().st_size==row['size_bytes'] and sha256(f.read_bytes()).hexdigest()==row['sha256'],f
start=time.monotonic()
with tempfile.TemporaryDirectory(prefix='q052_v117_reproduction_') as td:
    root=Path(td)
    for name in ['calc','input','runtime']:shutil.copytree(P/name,root/name)
    shutil.copyfile(P/'preflight114.py',root/'preflight114.py')
    env=dict(os.environ);env['LD_LIBRARY_PATH']=str(root/'runtime')
    for script,expected in [('preflight114.py','runtime_check117.json'),('calc/primary117.py','primary117.json'),('calc/control117.py','control117.json')]:
        remaining=300-(time.monotonic()-start);assert remaining>0
        r=subprocess.run([sys.executable,str(root/script)],cwd=root,env=env,capture_output=True,timeout=remaining)
        assert r.returncode==0,(script,r.stderr.decode())
        actual=json.loads(r.stdout);stored=json.loads((P/expected).read_bytes())
        if script=='preflight114.py':
            assert actual['status']=='PASS'
            for k in ['version','library_sha256','source_sha256','backend_sha256','checks']:assert actual[k]==stored[k],k
        else:
            # The absolute library path changes in the private replay directory.
            actual['runtime'].pop('loaded_library');stored['runtime'].pop('loaded_library')
            assert actual==stored,(script,'NUMERIC_OR_SCOPE_MISMATCH')
print(json.dumps({'status':'PASS','primary_runs':1,'separate_controls':1,'numeric_outputs_match':True,'wall_seconds':time.monotonic()-start},indent=2))
