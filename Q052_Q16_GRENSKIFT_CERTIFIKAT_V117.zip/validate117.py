"""Validate immutable inputs; no physical field evaluation."""
from pathlib import Path
from hashlib import sha256, sha1
from zipfile import ZipFile
from io import BytesIO
from datetime import datetime, timezone
import json

P=Path(__file__).resolve().parent
U=P.parents[1]/'upload'
digest=lambda b:sha256(b).hexdigest()
load=lambda p:json.loads(p.read_bytes())

def main():
    t=load(P/'input/Q052_MATEMATIKOPGAVE_V116.json')
    unsealed=dict(t);fp=unsealed.pop('fingerprint_sha256')
    assert digest(json.dumps(unsealed,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==fp
    assert t['task_id']=='LOCAL-Q052-V117-CONSTANT-Q-OVER-16-CELL235'
    assert t['current_q']==t['target_q']=='Q052'
    for n,h in t['input_member_sha256'].items():
        assert digest((P/n).read_bytes())==h,n
    archive_checks={}
    for n,h in t['input_archive_refs'].items():
        assert digest((U/n).read_bytes())==h,n
        with ZipFile(U/n) as z: assert z.testzip() is None
        archive_checks[n]={'sha256':h,'zip_integrity':'PASS'}
    with ZipFile(U/'Q052_V115_DEL_2_AF_2.zip') as z115:
        with ZipFile(BytesIO(z115.read('history/Q052_BACKEND_FEJLPAKKE_V113.zip'))) as z113:
            with ZipFile(BytesIO(z113.read('history/Q052_INGESTION_CERTIFICATE_V112.zip'))) as z112:
                raw=z112.read('history/Q052_GRENSKIFT_CERTIFIKAT_V87.zip')
    assert digest(raw)==t['input_v87_archive_sha256']
    with ZipFile(BytesIO(raw)) as z87:
        manifest=json.loads(z87.read('manifest.json'))
        for n,h in manifest['members_sha256'].items(): assert digest(z87.read(n))==h,n
        for n,h in t['input_v87_receipt_sha256'].items():
            assert digest((P/'input'/('v87_'+n)).read_bytes())==h,n
        for n in ['PROOF_V85.md','PROOF_V87.md','verification.json','sources.json','task86.json']:
            assert (P/'input'/('v87_'+n)).read_bytes()==z87.read(n),n
    with ZipFile(U/'Q052_INGESTION_CERTIFICATE_V116.zip') as z116:
        m=json.loads(z116.read('manifest116.json'))
        for row in m['archive_members']:
            raw=z116.read(row['path']);assert len(raw)==row['bytes'] and digest(raw)==row['sha256']
            f=U/row['path'] if (U/row['path']).is_file() else P/'input'/row['path']
            assert f.read_bytes()==raw,row['path']
    repo=load(P/'repository_tree117.json');files=[]
    for row in repo['files']:
        n=row['path'];local=n
        if n=='Bubbleverse_Matematikmotor_2.3.0.md': local='Bubbleverse_Matematikmotor_2.3.0-98.md'
        if n=='Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0.md': local='Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0-128.md'
        raw=(U/local).read_bytes()
        blob=sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        assert blob==row['sha'] and len(raw)==row['size'],n
        files.append({'path':n,'git_blob_sha1':blob,'sha256':digest(raw),'size_bytes':len(raw)})
    assert digest((U/'Bubbleverse_Matematikmotor_2.3.0-98.md').read_bytes())==t['engine_prompt_sha256']
    source=(P/'input/hyrec.c').read_bytes()
    assert digest(source)=='734800ccd69b41d60b519f200003ce27c3b7640f76a70353499424842ba19616'
    assert '\n'.join(source.decode().splitlines()[428:541])==(P/'input/github_hydrogen_excerpt.txt').read_text().rstrip('\n')
    result={'status':'PASS','task_sha256':digest((P/'input/Q052_MATEMATIKOPGAVE_V116.json').read_bytes()),
      'task_fingerprint':fp,'archive_checks':archive_checks,'v87_manifest_all_members_verified':True,
      'V116_manifest_all_members_verified':True,'input_member_sha256':t['input_member_sha256'],
      'repository':{'repository':'Morfindien/Bubbleverse','branch':'main','commit':repo['commit'],
        'files':files,'read_state':'VERIFIED_FOR_V116_AND_ENGINE_IDENTITIES','write_state':'READY_FOR_MANUAL_UPLOAD'},
      'physics_excerpt':{'commit':t['source_commit'],'path':'external/HyRec2020/hydrogen.c','lines':[429,541],'matches_pinned_bytes':True},
      'verified_utc':datetime.now(timezone.utc).isoformat(),'scientific_evaluations':0}
    (P/'input_check117.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','archives':len(archive_checks),'repository_commit':repo['commit']}))

if __name__=='__main__': main()
