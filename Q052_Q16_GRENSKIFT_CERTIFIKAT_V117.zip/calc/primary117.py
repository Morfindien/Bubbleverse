"""Changed constant face, one pass over the 16 frozen closed V87 slabs.
Reuses V87 channel-excess certificates ONLY after new-face inclusion checks.
No V87 face evaluation or V115 point is repeated.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json
import v20 as m
from certify87 import selector_threshold

P=Path(__file__).resolve().parent
ROOT=P.parent
Q=F(1,1000000); B=Q/16; GAP=Q-B
hx=lambda x:F(float.fromhex(x))
load=lambda p:json.loads(p.read_bytes())

def main():
    t=load(ROOT/'input/Q052_MATEMATIKOPGAVE_V116.json')
    for name,h in t['input_member_sha256'].items():
        assert sha256((ROOT/name).read_bytes()).hexdigest()==h,name
    c=m.Context(P/'v19.json')
    loaded={line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if '/libmpfr.so' in line}
    assert loaded=={str((ROOT/'runtime/libmpfr.so.6').resolve())} and c.mp.VERSION=='4.2.1'
    assert c.raw['q048_prefix_config_v1.json']['sha256']==t['capture_sha256']
    assert c.binding['q_branches'][0]['background_dependency_id']==t['target']['frozen_background']
    v62=load(P/'v62.json');L,R=[v62['arms'][a]['records'][234] for a in 'LR']
    assert L['z']==R['z'] and L['H_per_s']==R['H_per_s']
    assert L['allowed_branches']==R['allowed_branches']==['HMLA','SWIFT']
    zlo,zhi=sorted(map(hx,R['z']));assert [zlo,zhi]==list(map(F,t['target']['z_ascending']))
    ls,rs=[list(map(hx,row['whole_source'][0])) for row in [L,R]]
    hmin=max(rs[0],ls[0]+GAP);hmax=min(rs[1],ls[1]+GAP)
    assert [hmin,hmax]==list(map(F,t['target']['hR_face_bounds']))
    assert 0<B<Q/2<Q<hmin<hmax<1
    oldmin=max(rs[0],ls[0]+Q);oldmax=min(rs[1],ls[1]+Q)
    assert hmin<oldmin and hmax==oldmax
    h=m.enc(hmin,hmax);hs=m.enc(*map(hx,R['H_per_s']))
    vmin=min(hx(row['whole_source'][1][0]) for row in [L,R])
    vmax=max(hx(row['whole_source'][1][1]) for row in [L,R])
    assert F(1,10)<vmin<vmax<1 and hs.lo>0
    seed=load(P/'barrier111.json')
    assert seed['status']=='PASS_CONDITIONAL_HALF_Q_EXTENSION' and seed['strict_interior']
    assert F(seed['domain'][0])==zhi and F(seed['electron_interval'][0])==Q/2>B
    assert seed['background_dependency_id']==t['target']['frozen_background'] and seed['source_commit']==t['source_commit']
    v77=load(P/'v77.json');assert v77['status']=='PASS_UNDER_FROZEN_PREMISES'
    blocks=[r for r in v77['elasticity_blocks'] if min(map(F,r['z']))<=zlo<=zhi<=max(map(F,r['z']))]
    assert len(blocks)==1;block=blocks[0]
    assert F(block['v_lower'])<=vmin and hx(block['elasticity_hex'][1])<0
    assert 0<=F(block['saha_over_h_squared_upper'])<=F(v77['saha_over_h_squared_max'])<1
    assert v77['thermal_cap']=='99/100' and F(v77['thermal_forcing_max'])<F(99,100)
    kmin=1-((Q-2*B)/hmin+B*GAP/hmin**2)
    common=(Q-2*B)/hmax
    assert 0<kmin<1 and 0<common<1
    archived=load(ROOT/'input/v87_result.json')
    assert archived['status']=='INWARD_ON_ALL_BRANCHES' and archived['H_s']==R['H_per_s']
    assert list(map(F,archived['z_exact']))==[zlo,zhi] and len(archived['rows'])==16
    rows=[]
    for i,old in enumerate(archived['rows']):
        a=zlo+(zhi-zlo)*F(i,16);b=zlo+(zhi-zlo)*F(i+1,16)
        assert list(map(F,old['z']))==[a,b]
        temperature,tr,nh,_=c.background(m.enc(1+a,1+b))
        assert c.trmin.hi<tr.lo<=tr.hi<c.trmax.lo
        assert c.fit_first.hi<temperature.lo<=temperature.hi<c.fit_last.lo
        critical=selector_threshold(c,tr)
        assert critical.hex()==old['critical'] and critical.lo>0
        physical=c.lya*hs/(nh*(1-h))
        assert physical.hi==float.fromhex(old['physical_escape'][1])
        guard_factor=1+GAP/(1-hmax)
        assert guard_factor<1+Q/(1-hmax)
        lower=max(F(critical.lo),F(physical.lo))
        upper=min(F(critical.hi)*guard_factor,F(physical.hi))
        row={'slab_zero_based':i,'z':list(map(str,[a,b])),
            'new_projection':list(map(str,[lower,upper])),'guard_factor_upper':str(guard_factor),
            'physical_escape':physical.hex(),'critical':critical.hex(),
            'Tgamma_K':temperature.hex(),'TR_eV':tr.hex(),
            'common_branch_normalized_lower':str(common)}
        if old['status']=='MIXED_EXCLUDED':
            assert F(physical.hi)<F(critical.lo) and upper<lower
            row.update(status='MIXED_EXCLUDED',strict_exclusion_margin=str(F(critical.lo)-F(physical.hi)))
        else:
            assert old['status']=='INWARD' and lower<=upper
            elo,ehi=map(hx,old['escape'])
            assert elo==hx(old['critical'][0]) and elo<=lower<=upper<=ehi
            dl,du=map(hx,old['dk']);assert -1<dl<=du<0
            assert old['lam']==c.lam.hex()
            for key in ['beta_s','beta_p','j','lam']:
                lo,hi=map(hx,old[key]);assert 0<lo<=hi
            # These cached bounds concern z, atomic tables and DK alone; h and
            # its changed lower endpoint do not enter beta, j or DK. The same
            # frozen temperature/rate domain and fixed parameter boxes apply.
            excess=[hx(x[1]) for x in old['excess']]
            assert len(excess)==2 and all(x>=0 for x in excess)
            margins=[1-(1+x)*(1-common) for x in excess]
            assert all(x>0 for x in margins)
            row.update(status='INWARD',old_escape=old['escape'],projection_inclusion=True,
                cached_dk=old['dk'],cached_rate_box={k:old[k] for k in ['beta_s','beta_p','j','lam']},
                channel_excess_upper=list(map(str,excess)),channel_normalized_lower=list(map(str,margins)),
                margin=str(min(margins)),cache_scope='Same z/rate/DK premises; verified new escape projection subset')
        rows.append(row)
    assert len([r for r in rows if r['status']=='INWARD'])==5
    assert len([r for r in rows if r['status']=='MIXED_EXCLUDED'])==11
    minimum=min(F(r['margin']) for r in rows if 'margin' in r)
    return {'status':'PASS_CONDITIONAL_CONSTANT_BARRIER','q':str(Q),'constant_b':str(B),
        'z_ascending':list(map(str,[zlo,zhi])),'hR_face_bounds':list(map(str,[hmin,hmax])),
        'kappa_lower':str(kmin),'common_branch_normalized_lower':str(common),
        'mixed_normalized_lower':str(minimum),'mixed_lower_display':float(minimum),
        'v_domain':list(map(str,[vmin,vmax])),'elasticity_applicability_block':block,
        'saha_over_h_squared_upper':block['saha_over_h_squared_upper'],
        'entry_E_lower':str(Q/2),'seed_z':str(zhi),'exit_z':str(zlo),'exit_E_strictly_greater_than':str(B),
        'source_commit':t['source_commit'],'background_dependency_id':t['target']['frozen_background'],
        'closed_slabs':16,'resolved_mixed_slabs':5,'excluded_mixed_slabs':11,
        'opposite_mixed_orientation':'Excluded by strict raw e_L<e_R at E=b',
        'one_sided_fields':'Both common fields and SWIFT/HMLA closure covered',
        'rows':rows,'runtime':{'mpfr_version':c.mp.VERSION,'loaded_library':list(loaded),
          'library_sha256':sha256((ROOT/'runtime/libmpfr.so.6').read_bytes()).hexdigest()},
        'source_pins':c.pins,'new_native_pairs':0,'new_optical_evaluations':0,
        'new_scalar_integrations':0,'new_full_history_integrations':0,'parameter_searches':0,
        'scope':'Conditional source-real continuation. No assertion of native trajectory identity.'}

if __name__=='__main__':print(json.dumps(main(),indent=2))
