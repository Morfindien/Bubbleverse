"""Separate whole-cell H projection and integrated log-C derivative control.
Does not import primary117 or reuse its slabs or coefficient excesses.
"""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json
import v20 as m

P=Path(__file__).resolve().parent;ROOT=P.parent
Q=F(1,1000000);B=F(1,16000000)
load=lambda p:json.loads(p.read_bytes())

def hx(s):
    # Parse binary64 hex endpoints directly as integers, without float.fromhex.
    sign=-1 if s.startswith('-') else 1
    s=s.lstrip('+-');mant,exponent=s.split('p');a,b=mant.removeprefix('0x').split('.')
    e=int(exponent)-4*len(b)
    return sign*F(int(a+b,16))*F(2)**e

def ends(interval):return F(interval.lo),F(interval.hi)

def guard_beta(c,tr):
    x=tr/(10000*c.k)
    return c.saha*tr*tr.sqrt()*(-c.EI/(4*tr)).exp()*m.lit('4.309e-13')*x.power(m.lit('-0.6166'))/(1+m.lit('0.6703')*x.power(m.lit('0.5300')))

def main():
    t=load(ROOT/'input/Q052_MATEMATIKOPGAVE_V116.json')
    for n,h in t['input_member_sha256'].items():assert sha256((ROOT/n).read_bytes()).hexdigest()==h,n
    c=m.Context(P/'v19.json')
    loaded={line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if '/libmpfr.so' in line}
    assert loaded=={str((ROOT/'runtime/libmpfr.so.6').resolve())} and c.mp.VERSION=='4.2.1'
    a=load(P/'v62.json');L,R=[a['arms'][x]['records'][234] for x in 'LR']
    assert L['z']==R['z'] and L['H_per_s']==R['H_per_s']
    assert L['allowed_branches']==R['allowed_branches']==['HMLA','SWIFT']
    zlo,zhi=sorted(map(hx,R['z']));Hlo,Hhi=map(hx,R['H_per_s'])
    hmin=max(hx(R['whole_source'][0][0]),hx(L['whole_source'][0][0])+Q-B)
    hmax=min(hx(R['whole_source'][0][1]),hx(L['whole_source'][0][1])+Q-B)
    assert [zlo,zhi]==list(map(F,t['target']['z_ascending']))
    assert [hmin,hmax]==list(map(F,t['target']['hR_face_bounds']))
    assert Q<hmin<hmax<1 and 0<B<Q/2
    seed=load(P/'barrier111.json')
    assert seed['strict_interior'] and F(seed['domain'][0])==zhi and F(seed['electron_interval'][0])>B
    assert seed['background_dependency_id']==t['target']['frozen_background']
    pmin,pmax=ends(m.lit('0.01'));lam_min,lam_max=ends(c.lam)
    temperature,tr,n,_=c.background(m.enc(1+zlo,1+zhi))
    assert c.trmin.hi<tr.lo<=tr.hi<c.trmax.lo
    assert c.fit_first.hi<temperature.lo<=temperature.hi<c.fit_last.lo
    assert all(F(1,10)<hx(r['whole_source'][1][0])<hx(r['whole_source'][1][1])<1 for r in [L,R])
    # d log B/d log TR = 1.5-a+EI/(4TR)-bY/(1+Y)>0.
    assert F(m.lit('0.6166').hi)+F(m.lit('0.5300').hi)<F(3,2)
    bl=F(guard_beta(c,m.I(tr.lo)).lo);bh=F(guard_beta(c,m.I(tr.hi)).hi)
    ec_min=((1/pmax-1)*bl-lam_max)/3
    ec_max=((1/pmin-1)*bh-lam_min)/3
    assert 0<ec_min<=ec_max
    nlo,nhi=ends(n);lya_lo,lya_hi=ends(c.lya)
    H_lower=max(Hlo,ec_min*nlo*(1-hmax)/lya_hi)
    H_upper=min(Hhi,ec_max*nhi*(1-hmin+Q-B)/lya_lo)
    assert 0<H_lower<=H_upper
    emin=lya_lo*H_lower/(nhi*(1-hmin))
    emax=lya_hi*H_upper/(nlo*(1-hmax))
    assert 0<emin<=emax
    old=load(P/'v77.json')['mixed_branch_checks'][0]
    assert old['z']==R['z'] and old['H_per_s']==R['H_per_s']
    dklo,dkhi=map(hx,old['DK']);assert -1<dklo<=dkhi<0
    width=emax*(-dklo)/(1+dklo)
    _,_,_,rates=c.rates(tr,m.I(1))
    bs,bp=[tuple(map(hx,v['hex'])) for v in rates['beta']]
    jlo,jhi=map(hx,rates['R2p2s']['hex'])
    assert all(x>0 for x in [*bs,*bp,jlo,jhi,lam_min,lam_max])
    gl=bs[0]+lam_min+3*jlo;gh=bs[1]+lam_max+3*jhi
    K=gh*bp[1]+jhi*bs[1]
    D=(bs[0]+lam_min)*(bp[0]+jlo)+3*jlo*bp[0]+gl*emin
    Ns=lam_min*(bp[0]+jlo)+(lam_min+3*jlo)*emin
    Np=lam_min*jlo+gl*emin
    assert min(D,Ns,Np)>0
    logs=[width*3*jhi*K/(D*Ns),width*gh*K/(D*Np)]
    assert all(0<x<1 for x in logs)
    ratios=[1/(1-x) for x in logs]
    margins=[1-r*(1-(Q-2*B)/hmax) for r in ratios]
    assert min(margins)>0
    return {'status':'PASS_CONDITIONAL_CONSTANT_BARRIER','q':str(Q),'constant_b':str(B),
      'z_ascending':list(map(str,[zlo,zhi])),'hR_face_bounds':list(map(str,[hmin,hmax])),
      'seed_z':str(zhi),'entry_E_lower':seed['electron_interval'][0],
      'selector_threshold':list(map(str,[ec_min,ec_max])),
      'selector_conditioned_H_per_s':list(map(str,[H_lower,H_upper])),
      'raw_escape_bounds':list(map(str,[emin,emax])),'escape_width_cap':str(width),
      'whole_cell_DK':old['DK'],'rate_receipt':rates,
      'positive_denominator_lower':list(map(str,[D,Ns,Np])),
      'log_ratio_caps':list(map(str,logs)),'channel_ratio_caps':list(map(str,ratios)),
      'channel_normalized_lower':list(map(str,margins)),
      'whole_cell_normalized_lower':str(min(margins)),'whole_cell_lower_display':float(min(margins)),
      'runtime':{'mpfr_version':c.mp.VERSION,'loaded_library':list(loaded),
          'library_sha256':sha256((ROOT/'runtime/libmpfr.so.6').read_bytes()).hexdigest()},
      'method':'New whole-cell selector H projection; decreasing log-C derivative; exp(x)<=1/(1-x); exact rational endpoint bounds.',
      'independence':'Separate process, integer hex parser, no producer import/slabs/excesses. Shared source tables, MPFR primitives, V62/V77/seed and analytic first-contact premises.',
      'native_pairs':0,'optical_evaluations':0,'integrations':0,'witness_searches':0}

if __name__=='__main__':print(json.dumps(main(),indent=2))
