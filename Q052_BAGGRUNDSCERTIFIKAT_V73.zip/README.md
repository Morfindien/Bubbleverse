# Reproducer V73

Pak arkivet ud. Brug Python 3.10 eller nyere uden -O. Kør i den udpakkede mappe.

```sh
python3 verify73.py > result.replay.json
python3 control73.py > control.replay.json
cmp result.replay.json result.json
cmp control.replay.json control.json
```

`PROOF_V73.md` indeholder argumentet, kildeligningerne, enhederne og fortolkningen. De to programmer efterprøver hver deres rationale uligheder. Begge bruger det samme historiske Q048-anker. `native_excerpt.json` indeholder de udvalgte rækker til splinetjekket. De kommer fra en separat fuld SHA-256-kontrol af tabellerne. For at gentage selve udtrækket bruges følgende ekstra originalfiler.

```sh
python3 extract_native.py q052-native-pair-v36-41171153649.zip Q052_FULL_HISTORY_RAW_V60.json Q052_UPPER_CELL_RAW_V69.json
```

Dette gendanner native_excerpt.json. manifest.json indeholder SHA-256 for hvert andet medlem. Historiske kildeudsnit og kvitteringer under lineage er præmisser for V73. Kør kun de tre aktuelle programmer i arkivets rod. Hele V72-journalen bevares i den særskilte V73-journal.
