# Q048 V12 — local-V/common-time compatibility and frozen test contract

This is a new compatibility/consumer proof for the linked V11 endpoint at
a=1/1451. Math015/017 source/virial lemmas and the V10 common-time result are
premises, not rerun campaigns. Exact Q/source/capture and all63 actual paired
cells/four H-to-frec tubes remain frozen. No new hydrogen/thermal cell is claimed.

## Qualified local cap and inherited state

Write u=log(a), e=X²/2+U(theta), V=H X theta/lambda and
Y=e+alpha V, alpha=24/23. e,Y,V and H² have the inherited CLASS source units
Mpc^-2; a,theta,u are dimensionless. The inherited connected central well has
|theta|<2, U(2)>E_input, e_u=-3X²<=0. Positive background components are
nonincreasing, H²=B0+(e+floor)/3>0, and the flat positive-source stress bounds
give ell=H_u/H in[-3,0]. These statements require no G>0 assumption.

At a left endpoint with e<=E_input, every future point in the qualified well
obeys H<=H_up(left,E_input), |X|<=sqrt(2E_input), hence

    |V| <= V_local = up(2 H_up sqrt(2E_input)/lambda_lower).

The old qualified future cap remains valid. Set
V_j=min(V_previous,V_local)>0. Taking the smaller of two valid upper bounds
does not assert a sign of V or create a new physical initial state.
At the target only, reuse V10's already-validated source-domain record,
including V_local, without reevaluating its old failed guard. Subsequent new
cells qualify their new local bounds using the unchanged source primitives.

Keep **Y_left exactly inherited**. The pointwise identity e=Y-alpha V gives
E_safe_left=min(E_input,up(Y_left+alpha V_j)). This is intersection of valid
projections of the same scalar IVP, not an independent Cartesian restart.
Never set Y_left=E_input+alpha V_j. Compute V_local from E_input before any
intersection, so the qualification cannot depend circularly on its own gain.

## Comparison with a changed cap

Reuse the source virial identity from Math015/017:

    Y_u+kY = (k/2-3+alpha)X²+kU-alpha theta U_theta
             +alpha(ell-3+k)V.

For k=90/23, n=theta U_theta/U>=15/4, the first two terms are nonpositive;
beta=alpha max(|k-6|,|k-3|)=1152/529. Thus the newly qualified local cap gives
Y_u+kY<=beta V_j on this whole cell. Set Q_j=up(beta V_j/k), A=Y_left-Q_j.
The new forcing Q_j may be smaller than the old one; the initial Y upper is
unchanged. Linear comparison yields, for x=a_left/a in[r,1],

    Y(a)<=Q_j+A x^k,
    e(a)<=min(E_safe_left, C+A x^k), C=Q_j+alpha V_j.

No restriction A>=0 is silently imposed. Primary exact-rational log/exp
enclosures use upper decay if A>=0 and lower decay if A<0. The distinct finite
control uses d_plus(x)=1/(1+k(1-x))>=x^k for A>=0, and d_minus(x)=x^4<=x^k
for A<0 (3<k<4). Both orientations give conservative energy upper bounds.
The Bernoulli inequality here follows from x^-k>=(1+k(1-x)); it is not a
small-cell approximation. Primary log/exp evaluation is range-reduced before
alternating series when needed; outward rounding follows every squaring.

## Whole-cell guard, not just an endpoint

Use the unchanged positive background polynomial lower bound
Bpoly=R x^4+M x^3+Lambda. Primary radiation includes the q³ neutrino lower;
control includes each independent finite-node root lower at a_left, divided
by a^4 thereafter (the root factor is nondecreasing). Define
F(x)=3Bpoly-C-A x^k for the primary, or the corresponding control decay.

For A>=0, either decay has derivative at most k, giving

    F'(x)>=12R r³+9M r²-kA.

For A<0, -A times the derivative of either positive increasing decay is
nonnegative, so F'(x)>=12R r³+9M r². Therefore the common sufficient lower is

    D_j=down(12R r³+9M r²-k max(A,0)).

Require D_j>0 and G_j=down(3Bpoly(r)-C-A*d_selected(r))>0. Then F is
increasing on[r,1], so G_j bounds the complete cell. Floor>=0 is omitted
conservatively. E_right=min(E_safe_left,up(Y_right+alpha V_j)),
Y_right=up(Q_j+A*d_selected(r)); inherit these exact recorded upper bounds
without resetting Y. A failed sufficient bound is METHOD_INSUFFICIENT, not
a physical crossing or model falsification.

## Predetermined execution and gates

- First target1450->1440 only. Persist its raw result and run the separate,
  producer-free finite validator before any continuation. Reuse that target
  snapshot and validation receipt in the final continuation validation.
- On validated target PASS, continue only new fixed Delta_z10 cells, same
  source family, primary/control paths and new per-cell caps. No subdivision.
- Commit a new cell only if both paths pass. A one-path candidate PASS on a
  stopping cell is uncommitted and not reusable certified common coverage.
- Stop at first new source/domain/margin/derivative obstruction, a=1,
  max145 common cells/max290 track rows, or300s including the target gate.
- No old63-cell/guard producer/validator run; no old constant-Vbar failed
  comparison replay; no native/P6/refit/recapture/likelihood/new Q.
- Mandatory new tests: local cap used in forcing and recovery, inherited Y,
  signed-amplitude orientation, full-cell derivative gate, source/parent/cell
  binding, forged margin, invalid local cap, Y-reset and full-history mutations.
- Separate verifier imports neither producer/core nor historical helper.
  It shares frozen physical source premises and is not independent physics.
- Return once to Result Ingestion & Routing2.1.0 with original results,
  exact obstruction or coverage, checkpoint, source pins and complete journal.

The source theorem and all historical failures remain conditional premises
with their original provenance. This proof closes only the changed local-cap
consumption obligation. It does not close Q048 or qualify native P6.
