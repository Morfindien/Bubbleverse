# Conditional background-input enclosure for Q050

This is an input certificate for the retained connected frozen-capture scalar family. It does not establish background existence, a complete native error certificate, literal selector existence, or Q050 closure.

The pinned CLASS source `background.c` at commit `5a131c91d657dd9a7c6364cc45b038710f8d0d97` defines, at lines 584–588, for the captured flat background:

\[
H^2=\rho,\qquad \frac{dH}{d\tau}=-\frac32a(\rho+p).
\]

Its `H_prime` is a conformal-time derivative. The captured convention is \(a=1/(1+z)\), also reflected by source line 2603. Define \(\ell=d\log H/d\log a\). Then

\[
\ell=-\frac{3(\rho+p)}{2\rho},\qquad
\frac{d\log H}{dz}=-\frac{\ell}{1+z}.
\]

The frozen configuration has zero curvature, no unsupported exotic fluid, nonnegative ordinary densities, and positive finite quadrature weights for massive neutrinos. Radiation has \(p=\rho/3\), matter has \(p=0\), nonnegative vacuum density has \(p=-\rho\), and each massive-neutrino node has \(0\le p\le\rho/3\). The captured n=3 scalar potential is a nonnegative multiple of \((1-\cos\theta)^3\) plus a nonnegative constant floor. Its kinetic energy is nonnegative; hence \(-\rho_\phi\le p_\phi\le\rho_\phi\).

Thus \(0\le\rho+p\le2\rho\), so

\[
-3\le\ell\le0,\qquad
0\le\frac{H_z}{H}\le\frac3{1+z}.
\]

The bound holds along every existing admitted member of the retained scalar family under these source premises; no selected representative trajectory or new initial-state restart is introduced. For a cell with \(a\in[a_L,a_R]\), use the conservative whole-cell bound \(H_z/H\in[0,3a_R]\). With \(H\le H_U\), also \(H_z\in[0,3a_RH_U]\). Units are \(H\) in inverse Mpc with c=1 and \(H_z\) per unit redshift, not the source's conformal-time derivative.

For the positive lower enclosure, retain only captured radiation, matter and nonnegative vacuum density at the largest a of the cell:

\[
B_L=(\gamma+u_r)a_R^{-4}+m a_R^{-3}+\lambda>0.
\]

Massive-neutrino and scalar densities are omitted only for this lower bound. The producer computes an exact-rational downward square-root bound \(0<H_L\le\sqrt{B_L}\); the verifier checks \(H_L^2\le B_L\).

The upper enclosure is the exact retained `H_upper_left` of each accepted primary Q048 scalar-guard row. The verifier checks that its square bounds `B0_upper_left + (E_input_left + floorhi)/3`. The historical scalar energy/family guard is a retained premise; its evolution proof is not rerun. The pinned guard method constructs these whole-cell bounds without resetting the connected E/Y/V family.

Rows 64–79 cover the requested domain. Row 63's canonical sorted-compact JSON hash matches the accepted V151 checkpoint; row 64's a/E/Y/V inputs glue exactly to that checkpoint. Subsequent E/Y/V glue and committed/accepted whole-cell flags are checked. The final source row 660→650 is restricted to the frozen binary64 lower boundary `650.2566501559347`; no normal calculation outside the requested surface is performed.

The primary trajectory family is retained. Control rows are checked as source-admission evidence, never averaged with or substituted for primary endpoint values. Every cell and both q=10^-6 and q=0 branches carry the same common-background dependency identifier. Enclosing interval projections do not license independently restarting a background in each cell or choosing different backgrounds for the paired branches.

The exact Q050 quantifier is preserved. This binding covers each fixed admitted background of the inherited connected frozen-capture family. It is not a claim about unrelated scalar initial states or arbitrary backgrounds outside that family. A consumer must retain that applicability contract and still establish its source-faithful normal and selector obligations. Supplying this file to V6's identity-only filename guard would not implement or validate a normal evaluator; use a separately versioned compatible consumer.

Validation is producer-free for the binding's hashes, coverage, ancestry and inequalities, but shares the frozen source and accepted scalar-guard premises. It is not an independent cosmological measurement or an independent reproof of the old guard.

## Retained guard final admission

The original final scalar-guard validation was recovered separately: q048_guard_local_v_validation_v12.json,206698bytes,SHA25651e4dfd3ef7a429b459af73b125d251e789bb0ac9244ef7630d5a44d4d99b554. FINAL/PASS binds the exact raw guard90c8d452e0a7e60e5ffea6dc40fe41570f1b3fa6ec195dc6495044f241bf21b5, with6566/6566 historical checks and24/24 rejected mutations. Named geometry/inherited-E-Y-V/domain/H-X checks for both tracks and rows64–79 are present. The raw PENDING_VALIDATION marker is preserved; admission comes from this separate final receipt. No original validator was rerun. See Q050_BG_BINDING_GUARD_ADMISSION_ADDENDUM.json. All binding/code/18-input-lock bytes and numeric values are unchanged. This supplemental source-premise audit is within the same95-point event, with no extra points.
