"""Second arithmetic path: widened constants and an integrating-factor comparison."""
import hashlib,json
from fractions import Fraction as Q
from pathlib import Path
base=Path(__file__).resolve().parent

def check():
    if not __debug__: raise RuntimeError('Use Python without optimization')
    package=json.loads((base/'Q052_FIRST_CELL_VALIDATOR_INPUTS_V16.json').read_bytes())['files']
    cert=package['q048_guard_local_v_result_v12.json']['content'].encode()
    assert hashlib.sha256(cert).hexdigest()=='90c8d452e0a7e60e5ffea6dc40fe41570f1b3fa6ec195dc6495044f241bf21b5'
    old=json.loads(cert)
    row=old['evaluators'][0]['rows'][132]
    assert row['committed'] and row['z1']==120 and row['domain']['admitted'] and row['source_state_reset']==False
    e,y=map(Q,[row['E_right'],row['Y_right']])
    p=old['background_parameters']; h2=Q(p['H0'])**2; M=Q(p['M']); factor=Q(p['factor'])
    nodes=list(zip(map(Q,p['q']),map(Q,p['w']))); assert len(nodes)==11 and all(q>0 and w>0 for q,w in nodes)
    # Separate radiation-like and matter-like majorants for the finite-node density.
    R=h2*(Q(p['og'])+Q(p['our']))+factor*sum(q**3*w for q,w in nodes)
    dust=h2*(Q(p['ob'])+Q(p['oc'])); dust_upper=dust+factor*M*sum(q**2*w for q,w in nodes)
    assert Q(p['ol'])==0 and R*121**4+dust_upper*121**3<Q('0.031') and 3*dust*121**3>Q('0.086')
    src=old['source_intervals']; assert Q(src['lamlo'])>12 and 0<Q(src['floorlo'])<=Q(src['floorhi'])<Q('0.00000011')
    assert Q(src['Alo'])*Q(11,24)**3>1>e and e<Q('0.082')
    S=Q('0.082'); d=Q(1,5); alpha=Q(24,23); beta=Q(1152,529); k=Q(90,23)
    C=Q('0.031')+(S+Q('0.00000011')*121**3)/3
    assert 2*C<12**2*d**2*S
    # W=Y/x^3 satisfies W'<=-(k-3)W+beta*d*S.
    upper=max(y,beta*d*S/(k-3))+alpha*d*S
    assert upper<S and Q('0.086')>S
    return {'status':'PASS','method':'integrating factor for W with one-sided rational parameter majorants',
            'shared_input':'V12 committed primary anchor and source virial identity',
            'alternative_S':str(S),'alternative_delta':str(d),'first_contact_upper_scaled_e':str(upper),
            'alternate_uniform_guard_lower':str((Q('0.086')-S)/121**3)}
if __name__=='__main__': print(json.dumps(check(),indent=2))
