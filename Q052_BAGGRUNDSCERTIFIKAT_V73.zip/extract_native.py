"""Optional provenance replay: python extract_native.py ARCHIVE_V37 RAW_V60 RAW_V69"""
import hashlib, json, sys, zipfile
from pathlib import Path

def sha(b):
    return hashlib.sha256(b).hexdigest()

def extract(archive, v60, v69):
    assert sha(archive.read_bytes())=='548d38abefcc530d312e59dc15522b0b01535db063833489adeed10c3b303e54'
    assert sha(v60.read_bytes())=='e683333446b1ea3d889cd837520f8f475a8926c1bad4cdc4459150dffb11bfcb'
    assert sha(v69.read_bytes())=='9fda67b212a565e9286bccc00dfec9ec5268875bef513fb354b47750a0e799fa'
    old, new=[json.loads(path.read_bytes()) for path in (v60,v69)]
    answer={'source_sha256':{p.name:sha(p.read_bytes()) for p in (archive,v60,v69)},'arms':{}}
    with zipfile.ZipFile(archive) as z:
        for arm in 'LR':
            name='background_table_hex.jsonl'
            header=new['arms'][arm][name]['new_header'].encode()+b'\n'
            assert json.loads(header)['bt_size']==40000
            whole=hashlib.sha256(header); body=hashlib.sha256(); size=len(header); rows={}
            with z.open(arm+'/'+name) as src:
                assert json.loads(src.readline())['bt_size']==40000
                count=0
                for index,line in enumerate(src):
                    whole.update(line); body.update(line); size+=len(line); count+=1
                    if index in (0,31687,31688):
                        row=json.loads(line); assert row['i']==index; rows[str(index)]=row
            assert count==40000 and whole.hexdigest()==new['arms'][arm][name]['sha256']
            assert size==new['arms'][arm][name]['bytes']
            text={}
            for key in ('point.ini','effective_identity.json'):
                item=old['arms'][arm][key]
                for before,after in new['replacements']:item=item.replace(before,after)
                assert sha(item.encode())==new['arms'][arm][key]['sha256']
                text[key]=item
            answer['arms'][arm]={'v69_table_sha256':whole.hexdigest(),'body_sha256':body.hexdigest(),
                'row_count':count,'size_bytes':size,'selected_rows':rows,'metadata':text}
    assert answer['arms']['L']['body_sha256']==answer['arms']['R']['body_sha256']
    return answer

if __name__=='__main__':
    out=extract(*map(Path,sys.argv[1:]))
    Path(__file__).with_name('native_excerpt.json').write_text(json.dumps(out,indent=2)+'\n')
