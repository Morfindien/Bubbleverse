"""Python 3.10+. Exact-rational bounds. Run without -O, in any directory."""
import hashlib
import json
from decimal import Decimal, localcontext
from fractions import Fraction as F
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def sha(b): return hashlib.sha256(b).hexdigest()
def read(path): return json.loads((ROOT/path).read_bytes())
def hexq(s): return F(float.fromhex(s))
def corners(x,y): return [v*w for v in x for w in y]
def mul(x,y):
    p=corners(x,y)
    return min(p),max(p)
def add(x,y): return x[0]+y[0],x[1]+y[1]
def scale(c,x): return mul((c,c),x)
def outward(x):
    n=10**12
    return [str(F(v,n)) for v in (x[0]*n//1,-((-x[1]*n)//1))]
def constant_interval(d):
    return sorted([F(d),F(float(d))])

def run():
    if not __debug__: raise RuntimeError('Use Python without optimization')
    raw=read('Q052_FIRST_CELL_VALIDATOR_INPUTS_V16.json')['files']
    files={}
    for name,item in raw.items():
        blob=item['content'].encode()
        assert len(blob)==item['size_bytes'] and sha(blob)==item['sha256']
        files[name]=json.loads(blob)
    cap='q048_prefix_config_v1.json'; record='q048_guard_local_v_result_v12.json'
    val=files['q048_guard_local_v_validation_v12.json']
    bg=files['Q050_CLEAN_BG_BINDING_V1.json']; g=files[record]
    ckpt='Q048_V151_ACCEPTED_CHECKPOINT_V1.json'; cp=files[ckpt]
    assert bg['checkpoint_sha256']==raw[ckpt]['sha256']
    assert val['technical_state']=='PASS' and val['phase']=='FINAL'
    assert val['checks_total']==val['checks_passed']==6566 and val['mutations_total']==val['mutations_rejected']==24
    assert raw[record]['sha256']==val['result_sha256']==bg['guard_sha256']==cp['guard_sha256']=='90c8d452e0a7e60e5ffea6dc40fe41570f1b3fa6ec195dc6495044f241bf21b5'
    assert raw[cap]['sha256']==g['capture_sha256']==bg['capture_sha256']==cp['capture_sha256']=='2514e250d20c456530be63e790a079176293a87a82c927b1e748d1eec405da9b'
    case=files[cap]['cases']['hillipop-ede_n3']; flds=case['background']['fields']
    for track in g['evaluators']:
        rows=track['rows']
        for i,r in enumerate(rows[64:133],64):
            assert r['z0']==810-10*(i-64) and r['z1']==r['z0']-10 and r['committed'] and r['whole_cell_qualified'] and F(r['G_lower'])>0
            assert r['E_input_left']==rows[i-1]['E_right'] and r['Y_left']==rows[i-1]['Y_right'] and r['a0']==rows[i-1]['a1']
        assert rows[132]['a1']=='1/121' and not rows[133]['committed']
    primary=g['evaluators'][0]['rows'];anchor=bg['anchor']; i=cp['guard_primary_index']
    assert i==63 and primary[i]['a1']==anchor['a']=='1/811'
    assert all(primary[i][k]==anchor[j] for k,j in [('E_right','E'),('Y_right','Y'),('V_admitted','Vbar')])
    E,Y=(F(primary[132][k]) for k in ('E_right','Y_right'))
    sc=case['background']['scalar']; n=case['background']['neutrinos'][0]
    fp,mp,B=map(hexq,sc['scf_parameters'][1:4]); conv=constant_interval('4152.39')
    A0=conv[0]*mp**2*fp**2; lam=scale(1/fp,constant_interval('2.435e27'))
    floor=scale(B,constant_interval('3.968e-8')); src=g['source_intervals']
    assert [A0,*lam,*floor]==[F(src[k]) for k in ('Alo','lamlo','lamhi','floorlo','floorhi')]
    zstar=121; a=F(1,zstar); h=hexq(flds['H0'])
    assert hexq(flds['Omega0_lambda'])==hexq(flds['K'])==0 and len(case['background']['neutrinos'])==1
    matter=h*h*(hexq(flds['Omega0_b'])+hexq(flds['Omega0_cdm']))/a**3
    rad=h*h*(hexq(flds['Omega0_g'])+hexq(flds['Omega0_ur']))/a**4
    M,fac=map(hexq,[n['fields']['M_ncdm'],n['fields']['factor_ncdm']]); assert M>0 and fac>0
    q,w=[list(map(hexq,n[k])) for k in ('q_ncdm_bg','w_ncdm_bg')]
    assert len(q)==len(w)==11 and min(q+w)>0
    Bup=matter+rad+fac/a**4*sum(qi**2*wi*(qi+a*M) for qi,wi in zip(q,w))
    S=F(2,25); delta=F(1,6); alpha=F(24,23); k=F(90,23); beta=F(1152,529)
    C=Bup+S/3+floor[1]*zstar**3/3; wall=A0*F(11,24)**3
    assert 0<E<S<wall and Y<(1-alpha*delta)*S
    assert 2*C<delta**2*S*lam[0]**2 and (k-3)*(1-alpha*delta)>beta*delta
    assert k/2-3+alpha==k-alpha*F(15,4)==0 and beta==alpha*max(6-k,k-3)
    G0=3*matter-S
    assert G0>0
    native=read('native_excerpt.json')['arms']; assert native['L']['selected_rows']==native['R']['selected_rows']
    for arm,data in native.items():
        assert data['row_count']==40000 and data['body_sha256']==native['L']['body_sha256']
        assert json.loads(data['metadata']['effective_identity.json'])['fields']==flds
        ini=data['metadata']['point.ini']; assert 'scf_parameters = 1,1,1,1,1,0.0' in ini
        values=data['selected_rows']['0']['background']
        assert values[9:11]==[sc['fields']['phi_ini_scf'],sc['fields']['phi_prime_ini_scf']]
    left,right=[native['L']['selected_rows'][str(j)] for j in (31687,31688)]
    # Correctly rounded Decimal.ln at p=80, bounded by one full ulp on each side.
    with localcontext() as ctx:
        ctx.prec=80
        position=Decimal(811).ln().copy_negate()
        eps=F(10)**(position.adjusted()-79)
    lo=hexq(left['loga']); span=hexq(right['loga'])-lo
    t=((F(position)-eps-lo)/span,(F(position)+eps-lo)/span); assert 0<t[0]<t[1]<1
    vals={}
    for col in (1,9,10,17):
        y0,y1=[hexq(r['background'][col]) for r in (left,right)]
        m0,m1=[hexq(r['d2background_dloga2'][col])*span**2/6 for r in (left,right)]
        c=(y0,y1-y0-2*m0-m1,3*m0,m1-m0)
        val=(c[3],c[3])
        for coef in reversed(c[:3]):val=add((coef,coef),mul(t,val))
        vals[col]=val
    X=scale(811,vals[10]); e=add(scale(F(1,2),mul(X,X)),vals[17]); V=mul(vals[1],mul(X,vals[9]))
    Yobs=add(e,scale(alpha,V)); theta=mul(lam,vals[9])
    assert 0<e[0]<=e[1]<F(anchor['E']) and Yobs[1]<F(anchor['Y']) and max(map(abs,V))<F(anchor['Vbar']) and max(map(abs,theta))<2
    return {'schema':'Q052_V73_FROZEN_REFERENCE_GUARD','frozen_case':'hillipop-ede_n3',
       'capture_sha256':raw[cap]['sha256'],'guard_sha256':raw[record]['sha256'],'v151_sha256':raw[ckpt]['sha256'],
       'inherited_whole_cells_810_to_120':69,'historical_validation_checks':6566,'historical_mutants':24,
       'primary_at_120':{'E_upper':str(E),'Y_upper':str(Y)},'old_uncommitted_cell_z':[120,110],
       'S':str(S),'delta':str(delta),'alpha':str(alpha),'k':str(k),'beta':str(beta),'Bstar_upper':str(Bup),
       'U_at_one_lower':str(wall),'C':str(C),'three_matter_minus_S':str(G0),'uniform_G_lower_120_to_0':str(G0*a**3),
       'strict_barrier_slack':str((k-3)*(1-alpha*delta)-beta*delta),
       'native_at_exact_log_a_810_outward_1e_minus_12':{key:outward(value) for key,value in [('phi',vals[9]),('theta',theta),('X',X),('e',e),('V',V),('Y',Yobs),('H',vals[1])]},
       'scope':'Canonical fixed captured source-real IVP under inherited qualified prefix and literal source premises. Stored projections check compatibility only. Native forward trajectory accuracy unresolved.'}

if __name__=='__main__': print(json.dumps(run(),indent=2))
