# A bound is established. The sign still needs work.

We are comparing two early-universe calculations on the same fixed background, with matched starting hydrogen ionization and temperature. One retains a small ionized-helium contribution; the other sets it to zero.

Under the documented source and model assumptions, earlier work established that the largest absolute difference between the equation solutions' electron fractions is exactly one electron per million hydrogen nuclei across redshift 810 to 0. It occurs only at 810.

The new analysis proves that the difference is positive from 810 down to approximately 692.77. At the next interval, the source can select different approximation branches for the two calculations. The available bounds are insufficient to extend the sign proof there. This is a limitation of the current proof, not evidence that the actual solutions reverse order.

Why it matters: the accumulated Thomson scattering difference is an integral of the signed electron difference with a positive weight. Establishing the sign over the entire history could locate its maximum. The actual global scattering maximum and the full simulation-versus-equation error certificate remain unresolved.

The next useful step is to assess a tighter bound at the identified branch transition, respecting the source's selection conditions. No new simulation pair or full history integration was run in this analysis.

Evidence is mathematical analysis of fixed source equations and archived interval certificates, not a new astronomical observation. The numerical checks share their inherited source and background assumptions.

Project: https://bubbleverse.dk
Source and prior evidence: https://github.com/Morfindien/Bubbleverse/tree/93b59feed29294b9b8082a57db384fd8459e3a59
