# A positive sign through reionization — research ongoing

Can two matched ionization histories remain consistent with the pinned source equations and their analytic bounds, and what are the largest electron-fraction and Thomson-optical-depth differences?

The latest calculation establishes a strictly positive electron-fraction difference on the new redshift interval from 50 down to approximately 5.59556, conditional on the same fixed background, configuration and matched starting states. Joined to the previous proof, the positive interval is approximately 5.59556 ≤ z ≤ 810. The electron fraction counts electrons per hydrogen nucleus.

The new check covers 2,963 whole intervals, including the common rate-branch transition and the reionization mapping. A separate grouped rational check supports the same lower-face argument. These checks reuse earlier validated rate and trajectory enclosures; they are not independent observations or new full-history simulations.

An earlier result already fixed the global absolute electron-fraction difference for the source-equation pair at one part per million, attained only at the matched starting redshift 810. The new result extends the sign information. It does not determine a minimum amplitude.

**Status: ONGOING / UNSOLVED.** The sign below approximately 5.59556, the realized global Thomson-optical-depth maximum, and the full native/source numerical error remain unresolved. Next comes the bounded low-redshift sign test.

Sources: [research repository](https://github.com/Morfindien/Bubbleverse); [verified prior research journal](https://github.com/Morfindien/Bubbleverse/blob/ff7a7dba0775c8b66cbf2e3a0a07e4ad373e1e05/Q052_INGESTION_OG_SAMLET_JOURNAL_V92.md); [pinned HyRec source](https://github.com/mwt5345/class_ede/blob/5a131c91d657dd9a7c6364cc45b038710f8d0d97/external/HyRec2020/hydrogen.c). The new proof and exact-rational checks accompany this research package. Its repository upload is pending; no new public commit is claimed.
