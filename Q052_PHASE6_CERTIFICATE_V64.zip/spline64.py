"""Exact phase-6 cubic extrema and conditional ordered-binary64 error; uses pinned V58 arithmetic."""
import hashlib,json,sys,re,tempfile,importlib.util
from fractions import Fraction as F
from pathlib import Path

def run(journal,rawpath,receiptpath):
    data=Path(journal).read_bytes();code=next(x for x in re.findall(rb'^```python\n(.*?)^```',data,re.M|re.S) if x.startswith(b'"""Q052 V58.'));assert hashlib.sha256(code).hexdigest()=='4a1dc268d6e1b4e05c5a81ea057b2df317f1769167b8844aa3bd6891d66126c6'
    tmp=tempfile.TemporaryDirectory();path=Path(tmp.name)/'v58math.py';path.write_bytes(code);spec=importlib.util.spec_from_file_location('v58math',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    r=json.loads(Path(receiptpath).read_bytes());raw=json.loads(Path(rawpath).read_bytes());pub={};rr={}
    for arm in 'LR':pub[arm]=list(map(json.loads,raw['arms'][arm]['public_table_hex.jsonl'].splitlines()[1:]));pub[arm]=[p for p in pub[arm] if m.hx(p['z'])<=50]
    records=[];cov=r['pair'];groups={}
    for row in cov:groups.setdefault(row['native_index'],[]).append(row)
    for i in range(3333):
        z0=m.hx(pub['L'][i]['z']);z1=m.hx(pub['L'][i+1]['z']);w=z1-z0;assert w>0;arms={};armerr=[]
        for arm in 'LR':
            a,b=pub[arm][i:i+2];assert (m.hx(a['z']),m.hx(b['z']))==(z0,z1) and a['i']==i and b['i']==i+1
            d=(m.hx(a['values'][0]),m.hx(b['values'][0]),m.hx(a['d2_dz2'][0]),m.hx(b['d2_dz2'][0]),w);arms[arm]=d;armerr.append(m.eval_error(d,z0,z1))
        c=[l-rr for l,rr in zip(m.power(arms['L']),m.power(arms['R']))];roots=m.stationary(c);mn,mx=m.extrema(c,F(0),F(1),roots);assert 0<mn[0]<=mn[1]<=mx[0]<=mx[1];err=m.add_bound(max(abs(mn[0]),abs(mx[1])),sum(armerr))
        for row in groups[3332-i]:
            za,zb=map(F,row['z']);low,high=m.bernstein(arms['L'],arms['R'],(zb-z0)/w,(za-z0)/w);outer=list(map(m.hx,row['stored_pair']));assert outer[0]<=low<=high<=outer[1]
        records.append({'i':i,'z_hex':[m.outer(z0,False),m.outer(z1,True)],'minimum':m.box(*mn),'maximum':m.box(*mx),'pair_binary64_abs_error_upper':m.outer(err,True),'conditional_positive':mn[0]>err})
    bf=lambda row,k,idx:m.hx(row[k][idx]);minimum=[min(bf(v,'minimum',i) for v in records) for i in [0,1]];maximum=[max(bf(v,'maximum',i) for v in records) for i in [0,1]];candidates=[r['z_hex'] for r in records if bf(r,'maximum',1)>=maximum[0]]
    return {'schema':'Q052_V64_STORED_SPLINE_CONTROL','source':'pinned V58 arithmetic reused on3333 new phase6 cells; pointwise 4-sample Bernstein control independently compared to published hulls','v58_code_sha256':hashlib.sha256(code).hexdigest(),'minimum':m.box(*minimum),'maximum':m.box(*maximum),'maximizer_candidate_cells':candidates,'conditional_positive_cells':sum(r['conditional_positive'] for r in records),'max_pair_binary64_error':m.outer(max(m.hx(r['pair_binary64_abs_error_upper']) for r in records),True),'records':records,'conditions':['ordered literal V60 coefficients and correct containing cell for an exact binary64 query','binary64 RN-even, gradual underflow, source evaluation order without fusion/reassociation; final subtraction rounded once','historical unrecorded interior lookups not directly observed']}
if __name__=='__main__':Path(sys.argv[4]).write_text(json.dumps(run(*sys.argv[1:4]),separators=(',',':'))+'\n')
