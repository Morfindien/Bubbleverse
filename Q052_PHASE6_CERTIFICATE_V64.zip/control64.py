"""Independent Decimal transfer checks, source-map checks, exact spline evaluations and trace diagnostics."""
import json,hashlib,sys
from pathlib import Path
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
from bisect import bisect_left,bisect_right
from collections import Counter

def hx(s):return F(float.fromhex(s))
def box(xs):return tuple(map(hx,xs))
def inside(b,x):return b[0]<=x<=b[1]
def dec(f):return D(f.numerator)/D(f.denominator)
def cubic(z,lo,hi):
    z0,y0,m0=lo;z1,y1,m1=hi;w=z1-z0;t=(z-z0)/w;a=1-t
    return a*y0+t*y1+w*w*((a**3-a)*m0+(t**3-t)*m1)/6

def control(path,raw_path):
    b=Path(path).read_bytes();r=json.loads(b);raw=json.loads(Path(raw_path).read_bytes());stats=Counter();xs={};guard_checks={};max_public=F(0); T=hx(json.loads(raw['arms']['L']['effective_identity.json'])['fields']['T_cmb']);zr=hx(r['map_parameters']['accepted_z_reio_hex']);cut=F(r['map_parameters']['fixed_reio_start_exact']);P=D('1e-84')
    def map_at(z):
        if z>cut:return D(1),D(0)
        Z=dec(1+z);R=dec(1+zr);arg=(R*R.sqrt()-Z*Z.sqrt())/(D('0.75')*R.sqrt());lam=1/(1+(2*arg).exp());helium=dec(hx(json.loads(raw['arms']['L']['z810_start.json'])['fHe_CLASS']));he2=1/(1+(4*(dec(z)-D('3.5'))).exp());return lam,(1-lam)*(1+helium)+he2*helium
    with localcontext() as ctx:
        ctx.prec=100
        for a in 'LR':
            arm=r['arms'][a];rows=arm['records'];q=F(1,10**6) if a=='L' else F(0);fs=raw['arms'][a];tr=[json.loads(s) for s in fs['fullstate_trace.jsonl'].splitlines()];native=[t for t in tr if t['phase']==6 and t['tag']=='OUTPUT'];nd={hx(t['z']):t for t in native};table={hx(t['z']):(hx(t['z']),hx(t['values'][0]),hx(t['d2_dz2'][0])) for t in map(json.loads,fs['public_table_hex.jsonl'].splitlines()[1:])};lastz=F(50);prev=arm['seed'];edge=[-lastz]
            for row in rows:
                za,zb=map(F,row['z']);assert row['initial']==prev and za==lastz and za>zb and not zb<cut<za
                lastz=zb;prev=row['end'];edge.append(-zb);i=row['index'];z1=hx(native[i]['z']);z0=hx(native[i+1]['z']);assert z0<=zb<za<=z1
                h0,v0=map(box,row['initial']);h1,v1=map(box,row['end']);wh,wv=map(box,row['whole']);assert 0<wh[0]<=min(h0[0],h1[0]) and max(h0[1],h1[1])<=wh[1]<F('0.01');assert 0<wv[0]<=min(v0[0],v1[0]) and max(v0[1],v1[1])<=wv[1]<=1
                k0,k1=box(row['K']);p=hx(row['Pmax']);dl,du=box(row['dt']);dt=(dec(1+za)/dec(1+zb)).ln();assert dec(dl)<=dt-P and dec(du)>=dt+P
                assert h1[0]<=(h0[0]+q)/(1+k1*(h0[0]+q)*du)-q and h1[1]>=h0[1]/(1+k0*h0[1]*dl)+p*du
                for j,A in enumerate(box(row['A'])):
                    eq=A/(1+A);vv=dec(eq)+(dec(v0[j])-dec(eq))*(-(1+dec(A))*dt).exp();assert (dec(v1[0])<=vv-P if j==0 else dec(v1[1])>=vv+P)
                hder=(hx(native[i+1]['y'][native[i+1]['indices']['x_H']])-hx(native[i]['y'][native[i]['indices']['x_H']]))/(z1-z0);Dder=(hx(native[i+1]['y'][native[i+1]['indices']['D_Tmat']])-hx(native[i]['y'][native[i]['indices']['D_Tmat']]))/(z1-z0)
                for z in (za,(za+zb)/2,zb):
                    la,d=map_at(z);X=box(row['observable']);assert dec(X[0])-P<=la*(dec(wh[0])+dec(q))+d and dec(X[1])+P>=la*(dec(wh[1])+dec(q))+d
                    S=cubic(z,table[z0],table[z1]);assert inside(box(row['stored_cubic']),S);stats['exact_spline_samples']+=1
                    if z in nd:
                        t=nd[z];hh=hx(t['y'][t['indices']['x_H']]);DD=hx(t['y'][t['indices']['D_Tmat']]);vv=1+DD/(T*(1+z));dy=[hx(t['dy'][t['indices'][k]]) for k in ('x_H','D_Tmat')];de=[(1+z)*(hder-dy[0]),(Dder-dy[1])/T];assert all(inside(box(bounds),val) for bounds,val in zip(row['residual'],de)),(a,i,z,'native derivative');stats['native_derivative_component_checks']+=2
                        err=abs(F(la*dec(hh+q)+d)-S);max_public=max(max_public,err)
                assert row['right_endpoint_uses_camb']==(zb<=cut);assert row['reio_interior']==('camb' if za<=cut else 'identity');stats['state_comparison_cells']+=1
            assert prev==arm['terminal'] and lastz==0;xs[a]=table
            rhs=[t for t in tr if t['tag']=='RHS'];guards=list(map(json.loads,fs['hyrec_guard_trace.jsonl'].splitlines()));assert len(rhs)==len(guards);counts=Counter()
            for t,g in zip(rhs,guards):
                if t['phase']!=6:continue
                assert t['z']==g['z'];zz=-hx(t['z']);j=bisect_left(edge,zz);ids=([j-1] if j else [])+([j] if j<len(rows) and edge[j]==zz else []);assert ids
                branch=next(k for k,v in g['observed_child_calls'].items() if v);expect='PEEBLES' if branch=='TLA' else branch;assert all(expect in rows[idx]['branches'] for idx in ids);counts[expect]+=1
            guard_checks[a]=counts
        assert len(r['pair'])==len(r['arms']['L']['records'])==len(r['arms']['R']['records'])
        for row,L,R in zip(r['pair'],r['arms']['L']['records'],r['arms']['R']['records']):
            assert row['z']==L['z']==R['z'];z=F(row['z'][1]);la,_=map_at(z);el,eu=box(row['end_dxe']);hl=box(L['end'][0]);hr=box(R['end'][0]);assert dec(el)-P<=la*dec(hl[0]-hr[1]+F(1,10**6)) and dec(eu)+P>=la*dec(hl[1]-hr[0]+F(1,10**6));stats['paired_endpoint_checks']+=1
    return {'schema':'Q052_PHASE6_INDEPENDENT_CONTROL_V64','receipt_sha256':hashlib.sha256(b).hexdigest(),'checks':dict(stats),'guard_counts':guard_checks,'largest_native_knot_minus_map_on_native_h_abs_display':float(max_public),'scope':'Independent rational/100-digit Decimal transfer, affine reionization map, direct spline and finite native RHS/selector checks on shared inputs. Endpoint checks at native knots use the saved y vector, not the cached workspace Tmat.'}
if __name__=='__main__':print(json.dumps(control(*sys.argv[1:]),indent=2))
