Bubbleverse Q052 V64  |  conditional phase-6 certificate

Inputs are the unchanged V63 cumulative journal, the four original V60 raw JSON parts, and the V62 phase-5 certificate ZIP. Required SHA256 digests are enforced by phase6.py. The V63 journal carries the pinned V19/V20 interval arithmetic and atomic-rate data. Use Python 3 on Linux with libmpfr.so.6 and assertions enabled. All paths below are relative to a directory holding these files.

python recover_raw.py reconstructed60.json Q052_FULL_HISTORY_RAW_V60_PART_*OF_4*.json
python phase6.py Q052_INGESTION_OG_SAMLET_JOURNAL_V63.md reconstructed60.json Q052_PHASE5_CERTIFICATE_V62.zip replay.json
python control64.py replay.json reconstructed60.json
python spline64.py Q052_INGESTION_OG_SAMLET_JOURNAL_V63.md reconstructed60.json replay.json replay_spline.json

The certificate is phase6_receipt.json. Compare its SHA256 to replay.json. The JSON contains a row for each proof segment and arm. z stores exact rational descending redshift endpoints. initial, end and whole contain [hydrogen fraction h, temperature ratio v]. Endpoints inside each numerical bound are outward binary64 hex strings. The residual is the u derivative of the chosen piecewise-linear h,D reference minus the source field. Stored-minus-source compares the exact real polynomial determined by the public stored values/curvatures with the source observable. The cutoff's upper-side interval includes the distinct observable value at the exact cutoff when giving whole-interval bounds; state transfer integrates the appropriate one-sided field. Pair rows retain the common reionization factor and cancel the shared offset.

spline_control.json independently validates the paired Bernstein ranges, isolates all real cubic stationary points on the stored grid and calculates conditional binary64 evaluation bounds. control.json reports a separate standard-library arithmetic/trace check, not a separate physical simulation. phase6.py never uses the workspace's cached Tmat_K as the evolving temperature. Read the V64 journal for the equations, hypotheses, source bindings and numerical interpretation. Full optical-depth integration is the outstanding downstream task.
