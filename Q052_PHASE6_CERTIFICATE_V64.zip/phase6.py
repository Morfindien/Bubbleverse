"""Conditional phase-six state, observable and stored-spline enclosure for Bubbleverse Q052."""
import hashlib, json, sys, re, importlib.util, zipfile, zlib, base64
from pathlib import Path
from fractions import Fraction as Q
from functools import lru_cache
from tempfile import TemporaryDirectory
from collections import Counter

PARENT='bebf5154c2da506af45e1ba8a78054ed77e4df881c8a3d386e26947f50c5ded8'
RAW='e683333446b1ea3d889cd837520f8f475a8926c1bad4cdc4459150dffb11bfcb'
ZIP='7fb60289f13cfbb1721b6528bb4b57dfd369b8d1939e28fbb51923591878d137'
RECEIPT='63480c24d61350c9913ed3072e09c91c097049791165fa964cfa096f7d0d4ca8'
MODULE='d0feecd36359005a55fb91c26aee2381f9ed1652177395acf7ec482ea0e880fa'
sha=lambda b:hashlib.sha256(b).hexdigest()
hx=lambda x:Q(float.fromhex(x))

def native_nodes(files):
    trace=[json.loads(s) for s in files['fullstate_trace.jsonl'].splitlines()]
    outputs=[r for r in trace if r['tag']=='OUTPUT' and r['phase']==6]
    rhs={(r['z'],tuple(r['y']),tuple(r['dy'])) for r in trace if r['tag']=='RHS' and r['phase']==6}
    old=next(r for r in trace if r['tag']=='OUTPUT' and r['phase']==5 and hx(r['z'])==50)
    assert len(outputs)==3334 and all(old[k]==outputs[0][k] for k in ('z','y','dy','workspace'))
    assert all((r['z'],tuple(r['y']),tuple(r['dy'])) in rhs for r in outputs)
    pub=[json.loads(l) for l in files['public_table_hex.jsonl'].splitlines()];assert pub[0]['xe_column']==0
    table={hx(r['z']):(int(r['i']),hx(r['values'][0]),hx(r['d2_dz2'][0])) for r in pub[1:]}
    nodes=[]
    for r in outputs:
        z=hx(r['z']);h=hx(r['y'][r['indices']['x_H']]);D=hx(r['y'][r['indices']['D_Tmat']]);nodes.append((z,h,D,*table[z]))
    assert nodes[0][0]==50 and nodes[-1][0]==0 and all(a[0]>b[0] and a[3]==b[3]+1 for a,b in zip(nodes,nodes[1:]))
    return nodes

def spline_controls(hi,lo):
    w=hi[0]-lo[0];y0,m0=lo[4:];y1,m1=hi[4:];delta=(y1-y0)/3
    return [y0,y0+delta-w*w*(2*m0+m1)/18,y1-delta-w*w*(m0+2*m1)/18,y1]

def run(journal,raw_file,phase5_zip,destination):
    parent=Path(journal).read_bytes();rb=Path(raw_file).read_bytes();archive=Path(phase5_zip).read_bytes()
    assert sha(parent)==PARENT and sha(rb)==RAW and sha(archive)==ZIP
    blocks=lambda kind:re.findall(rb'^```'+kind+rb'\n(.*?)^```',parent,re.S|re.M)
    incoming=json.loads(re.findall(rb'```json\n(.*?)\n```',parent[parent.index(b'# Q052 V63'):],re.S)[0]);task=incoming['next_task']
    with zipfile.ZipFile(phase5_zip) as z: receipt=z.read('phase5_receipt.json');assert sha(receipt)==RECEIPT
    previous=json.loads(receipt);raw=json.loads(rb)
    scratch=TemporaryDirectory();work=Path(scratch.name);module=next(x for x in blocks(b'python') if sha(x)==MODULE);(work/'p.py').write_bytes(module)
    sp=importlib.util.spec_from_file_location('v20_interval',work/'p.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
    v19=zlib.decompress(base64.b64decode(json.loads(blocks(b'q052-inputs')[0])['v19.json'],validate=True));(work/'v19').write_bytes(v19);ctx=m.Context(work/'v19');I=m.I;enc=m.enc;lit=m.lit
    pars=ctx.capture['frozen_reionization'];assert pars==task['input_refs']['frozen_reionization'] and pars['parametrization']=='reio_camb'
    cutoff=Q(pars['fixed_reio_start_exact']);zr=hx(pars['accepted_z_reio_hex']);assert cutoff==zr+4 and pars['width']==pars['helium_width']==0.5 and pars['helium_redshift']==3.5 and pars['exponent']==1.5
    lim=ctx.capture['thermal_starts'][0];assert hx(lim['ap_limits'][5])==50 and hx(lim['ap_deltas'][6])==2 and cutoff<46;assert '#define _not4_ 3.9715' in ctx.sources['thermodynamics.h']['content']
    heliumY=enc(hx(lim['constants']['YHe']));he_out=m.hull([heliumY/(lit('3.9715')*(1-heliumY)),enc(ctx.he)])
    # Enclose the source expression and binary64 constants; include the captured ratio in the hull.
    src=ctx.sources['thermo.c']['content'];assert 'case reio_camb:' in src and 'array_interpolate_spline(' in src
    nodes={a:native_nodes(raw['arms'][a]) for a in 'LR'};assert [n[0] for n in nodes['L']]==[n[0] for n in nodes['R']]
    fields=ctx.capture['background']['fields'];H0=enc(hx(fields['H0']));matter=enc(hx(fields['Omega0_b'])+hx(fields['Omega0_cdm']));conv=lit('2.99792458e8')/lit('3.085677581282e22');Hmax=min(Q(row['H'][1]) for row in ctx.binding['cells'] if Q(row['z'][0])>=50)
    # Exact bands around the redshift-only thermal selector cover literal/binary constants.
    tr_edges=[Q(ctx.trmin.lo)/(ctx.T0*Q(ctx.k.hi))-1,Q(ctx.trmin.hi)/(ctx.T0*Q(ctx.k.lo))-1];cuts=sorted(set([cutoff,*tr_edges]),reverse=True)
    rec={'schema':'Q052_PHASE6_SOURCE_AND_OUTPUT_CERTIFICATE_V64','input_sha256':{'journal':PARENT,'raw':RAW,'certificate_zip':ZIP,'phase5_receipt':RECEIPT,'interval_module':MODULE,'V19':sha(v19)},'source_pins':ctx.pins,'condition':'Same fixed admitted common background, matched start, and nominal source-real configuration as V62','incoming_task':task['task_fingerprint_sha256'],'events':list(map(str,cuts)),'map_parameters':pars,'helium_output_interval':he_out.hex(),'arms':{},'pair':[]}
    @lru_cache(None)
    def tables(index):
        # HMLA table is needed only above the temperature guard. Clamp to the union of admissible table inputs.
        _,tr,_,_=ctx.background(enc(1+index,2+index));tr=I(max(tr.lo,ctx.trmin.lo),tr.hi);qt=(tr.log()-ctx.logmin)/ctx.dlog;qv=(enc(Q('0.09999'),1)-ctx.vmin)/ctx.dv
        al=[[],[]];eq=[[],[]];rr=[]
        for it,t in m.stencils(qt,100):
            rr.append(m.cubic(ctx.R[it-1:it+3],t).exp())
            for k in (0,1):
                eq[k].append(m.cubic(ctx.alpha[k][-1][it-1:it+3],t).exp())
                for iv,s in m.stencils(qv,40):
                    yz=[m.cubic(ctx.alpha[k][j][it-1:it+3],t) for j in range(iv-1,iv+3)];al[k].append(m.cubic(yz,s).exp())
        return [m.hull(x) for x in al],[m.hull(x) for x in eq],m.hull(rr)
    def ppb(T):
        t=T/10000;return lit('4.309e-13')*t.power(lit('-0.6166'))/(1+lit('0.6703')*t.power(lit('0.5300')))
    def coeff(zp,za,zb,vl,hs):
        T,tr,nh,rho=ctx.background(zp);assert T.hi<ctx.fit_first.lo and vl>0 and tr.hi<ctx.trmax.lo
        bn=ctx.saha*tr*tr.sqrt()*(-ctx.EI/(4*tr)).exp();low=[];high=[];photo=[];branches=[]
        if tr.hi>=ctx.trmin.lo:
            bins=[tables(ix) for ix in range(int(zb//1),int(za//1)+1) if ctx.background(enc(2+ix))[1].hi>=ctx.trmin.lo]
            al=[m.hull(t[0][k] for t in bins) for k in (0,1)];ae=[m.hull(t[1][k] for t in bins) for k in (0,1)];r=m.hull(t[2] for t in bins)
            bs,bp=ae[0]*bn,ae[1]*bn/3;den=(bs+ctx.lam)*(bp+r)+3*r*bp;assert den.lo>0
            low.append((al[0]*ctx.lam*(bp+r)/den+al[1]*ctx.lam*r/den).lo);high.append((al[0]+al[1]).hi);photo.append((ae[0]+ae[1]).hi);branches.append('HMLA')
        if tr.lo<=ctx.trmin.hi or vl<=Q(ctx.vmin.hi):
            am=ppb(enc(vl,1)*T);at=ppb(T);C=ctx.lam/(ctx.lam+bn*at);low.append((am*C).lo);high.append(am.hi);photo.append(at.hi);branches.append('PEEBLES')
        assert branches and min(low)>0
        return nh/hs*I(min(low),max(high)),I(max(photo))/hs*ctx.saha*tr*tr.sqrt()*(-ctx.EI/tr).exp(),rho,branches
    def cam(zp):
        zrp=enc(1+zr);arg=(zrp.power(enc(Q(3,2)))-zp.power(enc(Q(3,2))))/(enc(Q(3,2))*zrp.sqrt()*enc(Q(1,2)))
        # lambda=1/(1+exp(2arg)) preserves a tiny positive factor even near complete ionization.
        lam=1/(1+(2*arg).exp());plus=1-lam;hef=1/(1+(-4*(enc(Q(7,2))-(zp-1))).exp());return lam,plus*(1+he_out)+hef*he_out
    def map_piece(zp,active):return cam(zp) if active else (I(1),I(0))
    def advance(A,v,dt):eq=A/(1+A);return eq+(v-eq)*(-(1+A)*dt).exp()
    def box(x):return I(*map(float.fromhex,x))
    for a in 'LR':
        q=Q(1,10**6) if a=='L' else Q(0);seed=previous['arms'][a]['terminal'];assert seed==task['input_refs']['initial_h_v_boxes_hex'][a];h,v=map(box,seed);rows=[];original=nodes[a]
        for idx,(hi,lo) in enumerate(zip(original,original[1:])):
            zhi,hh,dd=hi[:3];zlo,hl,dl=lo[:3];brk=[zhi]+[z for z in cuts if zhi>z>zlo]+[zlo];width=zhi-zlo
            spline=spline_controls(hi,lo);dh=(hl-hh)/width;dD=(dl-dd)/width
            for za,zb in zip(brk,brk[1:]):
                zp=enc(1+zb,1+za);dt=enc((1+za)/(1+zb)).log();hs=I((H0*(matter*zp*zp*zp).sqrt()).lo,enc(Hmax).hi)*conv
                ha=hh+(zhi-za)*dh;hb=hh+(zhi-zb)*dh;Da=dd+(zhi-za)*dD;Db=dd+(zhi-zb)*dD
                refh=enc(min(ha,hb),max(ha,hb));refv=1+enc(min(Da,Db),max(Da,Db))/(enc(ctx.T0)*zp);vl=min(Q(v.lo)*(1+zb)/(1+za),Q(refv.lo));assert vl>0 and refv.hi<=1
                k,P,rho,branches=coeff(zp,za,zb,vl,hs);assert P.lo>=0
                hU=(I(h.hi)+I(P.hi)*dt).hi;assert Q(hU)<Q(1,100) and 0<refh.lo<=refh.hi<0.01
                l=(I(h.lo)+enc(q))/(1+I(k.hi)*(I(h.lo)+enc(q))*dt)-enc(q);U=I(h.hi)/(1+I(k.lo)*I(h.hi)*dt)+I(P.hi)*dt
                h1=I(l.lo,U.hi);wh=I(l.lo,hU);assert wh.lo>0
                active=za<=cutoff;lam,offset=map_piece(zp,active);electron=lam*(wh+enc(q))+offset
                scale=ctx.K*rho/hs;A=scale*electron/(1+enc(ctx.he)+electron);assert A.lo>0
                v1=I(advance(I(A.lo),I(v.lo),dt).lo,advance(I(A.hi),I(v.hi),dt).hi);wv=I(min(v.lo,v1.lo),max(v.hi,v1.hi));assert 0<wv.lo<=wv.hi<=1
                maps=[(lam,offset)]
                if zb==cutoff and not active:maps.append(cam(enc(1+cutoff)))
                wholeX=m.hull([la*(wh+enc(q))+of for la,of in maps]);whole_lam=m.hull(la for la,_ in maps)
                l_end,d_end=map_piece(enc(1+zb),zb<=cutoff);endX=l_end*(h1+enc(q))+d_end
                refX=m.hull([la*(refh+enc(q))+of for la,of in maps]);refA=scale*refX/(1+enc(ctx.he)+refX);F=-k*refh*(refh+enc(q))+I(0,P.hi);G=-refv+refA*(1-refv)
                S=m.bern_range(spline,(zb-zlo)/width,(za-zlo)/width)
                rows.append({'index':idx,'z':list(map(str,(za,zb))),'initial':[h.hex(),v.hex()],'end':[h1.hex(),v1.hex()],'whole':[wh.hex(),wv.hex()],'ref':[refh.hex(),refv.hex()],'error_source_minus_ref':[(wh-refh).hex(),(wv-refv).hex()],'residual':[(zp*enc(dh)-F).hex(),(enc(dD/ctx.T0)+refv-1-G).hex()],'dt':dt.hex(),'K':k.hex(),'Pmax':P.hi.hex(),'A':A.hex(),'branches':branches,'reio_interior':'camb' if active else 'identity','right_endpoint_uses_camb':zb<=cutoff,'observable':wholeX.hex(),'lambda':whole_lam.hex(),'end_X':endX.hex(),'end_lambda':l_end.hex(),'stored_cubic':S.hex(),'stored_minus_source':(S-wholeX).hex()})
                h,v=h1,v1
        rec['arms'][a]={'seed':seed,'terminal':[h.hex(),v.hex()],'X0':rows[-1]['end_X'],'branch_sets':dict(Counter('+'.join(row['branches']) for row in rows)),'records':rows}
    for l,r in zip(rec['arms']['L']['records'],rec['arms']['R']['records']):
        assert l['z']==r['z'] and l['index']==r['index'] and l['lambda']==r['lambda'];i=l['index'];za,zb=map(Q,l['z']);co=[]
        for a in 'LR':co.append(spline_controls(nodes[a][i],nodes[a][i+1]));
        native_z0=nodes['L'][i+1][0];width=nodes['L'][i][0]-native_z0
        ds=m.bern_range([x-y for x,y in zip(*co)],(zb-native_z0)/width,(za-native_z0)/width)
        dx=box(l['lambda'])*(box(l['whole'][0])-box(r['whole'][0])+enc(Q(1,10**6)))
        e=box(l['end_lambda'])*(box(l['end'][0])-box(r['end'][0])+enc(Q(1,10**6)))
        rec['pair'].append({'z':l['z'],'native_index':i,'whole_dxe':dx.hex(),'stored_pair':ds.hex(),'stored_minus_source':(ds-dx).hex(),'end_dxe':e.hex()})
    rec['summary']={'segments_per_arm':len(rec['pair']),'native_intervals_per_arm':3333,'terminal_delta_xe':rec['pair'][-1]['end_dxe'],'source_pair_range_phase6':m.hull(box(r['whole_dxe']) for r in rec['pair']).hex(),'stored_pair_range_phase6':m.hull(box(r['stored_pair']) for r in rec['pair']).hex(),'pair_error_range_phase6':m.hull(box(r['stored_minus_source']) for r in rec['pair']).hex(),'stored_delta_at_zero':str(nodes['L'][-1][4]-nodes['R'][-1][4])};Path(destination).write_text(json.dumps(rec,separators=(',',':'),allow_nan=False)+'\n');print(json.dumps(rec['summary'],indent=2))

if __name__=='__main__':run(*sys.argv[1:])
