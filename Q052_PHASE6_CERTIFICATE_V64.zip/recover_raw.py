"""Recreate the raw JSON needed by certify62 from the four numbered V60 parts."""
from pathlib import Path
import sys,json,hashlib
out=Path(sys.argv[1]); parts=sorted([json.loads(Path(s).read_bytes()) for s in sys.argv[2:]],key=lambda p:p['split_delivery']['part']);assert [p['split_delivery']['part'] for p in parts]==[1,2,3,4]
first=parts[0];meta=first['split_delivery'];arms={'L':{},'R':{}}
for p in parts:
 for arm,files in p['arms'].items():
  for name,value in files.items():arms[arm][name]=arms[arm].get(name,'')+value
arms={a:{k:files[k] for k in meta['original_arm_file_key_order'][a]} for a,files in arms.items()};raw={k:arms if k=='arms' else first[k] for k in meta['original_root_key_order']};b=(json.dumps(raw,indent=2,ensure_ascii=False)+'\n').encode();assert len(b)==47659726 and hashlib.sha256(b).hexdigest()=='e683333446b1ea3d889cd837520f8f475a8926c1bad4cdc4459150dffb11bfcb';out.write_bytes(b)
