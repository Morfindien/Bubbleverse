

# Q052 · V136 · 22. november 2026

Under the pinned hillipop-ede_n3 source/configuration, the same fixed admitted common background and matched validated z=810 start state used by Q051, does the actual native CLASS/P6 low-z implementation produce q=xHeII=10^-6 versus q=0 electron-fraction and Thomson-optical-depth histories that are reproducible, trajectory-consistent with the literal source-real dynamics, and contained within Q051's uniform analytic bounds; and what are the realized sup|Delta x_e| and sup|Delta tau_T| with a validated numerical error certificate?

# BUBBLEVERSE — OVERLEVERING

**Q052 · V136 · 22. november 2026**

Jeg har indtaget V135's tre kontrollerede størrelser for begge historiske V69-arme. Skalarhastigheden φ′η og den omregnede hastighed X var nul ved det første kald til baggrundsligningerne. Skalafaktoren ved kaldet lå 2⁻⁹⁶ under referenceværdien. Den historiske interne feltværdi φ og den tunespecifikke parameter f før første trin er fortsat uafgjorte.

**Én ny måling er gjort klar.** Den bruger det autentificerede V36-bibliotek direkte. Fire hardware-breakpoints aflæser neutrinoernes tryk/tæthedsforhold, den accepterede start lige før logaritmen, første kalds logkoordinat og H, efter at baggrundsfunktionen har beregnet den. Den endelige baggrundskørsel identificeres via kaldet direkte fra main. Skydealgoritmens prøveberegninger sorteres fra ved at kontrollere kaldestakken.

Arkiv- og læsekontrollen har bestået. Læsekontrollen brugte syntetiske data. Den faktiske måling og debuggerens adgang til de fire instruktioner afprøves på kørselsmiljøet i V137. Q052 står fortsat åbent. **Næste motor er Execution/HPC Motor Builder 2.2.0.**

V136 giver 88 point. Totalen er **15.949**, med **51 point** til SoMe-pakken ved 16.000. M015 er leveret.

## Instrumentering, bevis og genoptagelse

V135-arkivet, manifestet og de fastlåste V135-opgavefiler er verificeret. Begge indsendte kopier af opgaven er byteidentiske. Det arkiverede native bibliotek har SHA-256 8b90e21505337cb6696c4f6460616c7c92482f6c8eba7f3450d7da5cb040fae3, kendte symboler og DWARF-typer. Dets originale kode og optimeringsindstillinger kan derfor bevares i det nye forsøg. Observatøren kontrollerer det indlæste biblioteks sti og finder dets startadresse i processens hukommelseskort. Adresserne nedenfor er positioner relativt til den adresse for netop den hashbundne binærfil.

| Adresse | Data |
|---|---|
| 0x6616f | XMM0 efter division af tryk med tæthed. Antallet af opslag i den endelige initialisering giver tælleren for den ene massive art. |
| 0x65f08 | XMM0 før log-kaldet og de virkelige baggrunds- og skalartilstande fra strukturfelterne. |
| 0x67a50 | Logkoordinaten i XMM0 ved første uforstyrrede RHS-kald fra NDF15. |
| 0x67abe | H, exp(loga) og de to skalarkomponenter efter succesfuldt background_functions-kald. |

Hvert punkt blev sammenholdt med bibliotekets maskinkode. Kaldet fra main adskiller den sidste baggrundsløsning fra de tidligere forsøg gennem input_init. Det første RHS-punkt kræver desuden den direkte NDF15-kalder. En særskilt læsekontrol genberegner neutrinoporten og skalafaktortilbagetrinnene, skalarinitialiseringen med binary64-afrunding, de signerede residualer og afstandene til højpræcisions log og exp. Sidstnævnte afstande rapporteres som diagnostik for det anvendte libm. Ved succes sammenlignes de nye gemte baggrundsrækker, public_table og history med V69 via kendte hashes.

GDB findes ikke i V136-miljøet. De fire offsets er efterprøvet statisk, og tre forkerte syntetiske kvitteringer blev afvist. En triviel binærfil kan bruges til at verificere debugger- og hardwareadgang i V137 først. Kørselsforudsætninger er Python 3.10+, x86-64 Linux, den dokumenterede wrapper, de historiske tabeldatafiler og en Python-aktiveret GDB. Fremtidige måledata skal bindes til de nye procesidentiteter. V136-kvitteringen viser nul nye native kørsler.

Run LOCAL-Q052-V136-INGEST-SCALAR-START-AND-FREEZE-OBSERVER følger LOCAL-Q052-V135-NATIVE-SCALAR-INITIALIZATION-BINDING. Pointskønnet er 28 analyse, 24 beregning, 9 kildearbejde og 27 validering. GitHub ved 02557646123a0a9a7f27ce3f752f413ed5109df8 matcher tre V135-dokumenter og den indsendte indtagsmotor. Builder-versionen er fastlagt ved repo-blobbens identitet. Pakken er klar til manuel upload.
