# Q052 V136 · Registrering ved CLASS-start

Q052_KORT_RESULTAT_V136.md er overleveringen. Hele journalen ligger i ZIP-filen. Kør `python3 verify136.py` efter udpakning for at efterprøve de arkiverede filer og læseprøven. Læseprøven bruger syntetiske værdier og indeholder afvisningstests for neutrinotæller, feltværdi og skalafaktor.

## Forbered V137 på x86-64 Linux

Brug Python 3.10+, Python-aktiveret GDB med fire hardware-breakpoints, GCC og det indpakkede V36-bibliotek. SHA-256 kontrolleres af launch.py. Opbevar biblioteket under det oprindelige filnavn. Brug det originale nominelle V69-observatørprogram, hvis det er tilgængeligt. Dets binær- og kildehash samt byggebetingelser finder du i evidence/Q052_SKALARSTART_V135.zip, medlem evidence/raw69.json. Hvis programmet skal genbygges, pak evidence/observer69.c ud af V135 og brug CLASS-headertræet fra det fastlåste commit. Kontrollér headerblobberne mod SOURCE_BLOBS i V135's evidence/producer36.py. Brug samme biblioteksfil direkte ved linkning.

Følgende kommando gengiver kernen i den arkiverede byggeopskrift. Sæt CLASS_SRC til det kontrollerede headertræ og LIB til den absolutte sti til det indpakkede bibliotek.

```sh
gcc -O2 -fno-fast-math -ffp-contract=off -frounding-math -std=c99 -fopenmp -rdynamic \
  -I"$CLASS_SRC/include" -I"$CLASS_SRC/external/HyRec2020" \
  -I"$CLASS_SRC/external/heating" -I"$CLASS_SRC/external/RecfastCLASS" \
  observer69.c "$LIB" -Wl,-rpath,"$(dirname "$LIB")" -Wl,-z,now -ldl -lm -o observer69
```

Gem den udførte byggekommando, compiler, headerpins og miljø i den nye kørsels dokumentation. Giv launch.py en JSON-kvittering med source_sha256, wrapper_sha256, library_sha256 og flags. Flags er de første syv compilerflag efter gcc i kommandoen. Sørg for, at de BBN- og øvrige historiske datafiler, som biblioteksbygget forventer, er tilgængelige under de fastlagte stier. Registrér afhængighedernes hashes. Hvis data eller de fire hardware-breakpoints er utilgængelige, gem den præcise fejl fra preflight. Start ét nominelt par.

```sh
python3 launch.py evidence/libq052_class_v36.so ./observer69 ./v137-new \
  --run-id LOCAL-Q052-V137-STARTUP --wrapper-build-receipt wrapper_build.json
```

Udelad wrapper-build-receipt ved en byteidentisk V69-observatør. Outputmappen skal være ny. Programmet bruger de to hashkontrollerede punktfiler og gemmer debuggerlog, hver arms startkvittering, signeret residual og hashkontrol af den offentlige historik, tabellen og baggrundens datarækker. Exitfejl, manglende målepunkt eller afvigelser skal bevares i outputtet, så udfaldet kan indtages. Kør den særskilte readback igen med `python3 readback.py v137-new/L/scalar_start_receipt.json v137-new/R/scalar_start_receipt.json`. Observationerne gælder de nye processer. En forskel i overlappet skal registreres med egen status.
