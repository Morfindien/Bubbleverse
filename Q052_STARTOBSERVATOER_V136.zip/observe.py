"""Loaded after GDB stops at main. Reads only the pinned x86-64 CLASS process."""
import gdb
import json
import os
from pathlib import Path

record = {'run_id': os.environ['Q052_RUN_ID'], 'arm': os.environ['Q052_ARM']}
archive_path = Path(os.environ['Q052_PROBE_LIBRARY']).resolve()
out = Path(os.environ['Q052_NATIVE_OUT'])/'scalar_start_receipt.json'
required = ('ncdm', 'initial', 'rhs', 'hubble')
phase = 0
samples = []
logcoords = []
breakpoints = {}

def value(expr):
    return gdb.parse_and_eval(expr)

def hx(v):
    return float(v).hex()

def field(ptr, name):
    return ptr.dereference()[name]

def ptr(expr, typename):
    return value(expr).cast(gdb.lookup_type(typename).pointer())

def scalar(pba, vector):
    return {name: hx(vector[int(field(pba, 'index_bi_'+idx))])
            for name,idx in [('phi','phi_scf'),('phi_prime_eta','phi_prime_scf')]}

def rounding():
    mx, x87 = int(value('$mxcsr')), int(value('$fctrl'))
    if mx & 0x6000 or x87 & 0x0c00:
        raise ValueError('Round-to-nearest required at the observation sites')
    return {'mxcsr': mx, 'x87_control': x87}

def final_call():
    frame = gdb.newest_frame()
    while frame:
        if frame.name() == 'background_init':
            caller = frame.older()
            return bool(caller and caller.name() == 'main')
        frame = frame.older()
    return False

class Probe(gdb.Breakpoint):
    def __init__(self, name, entry_offset):
        super().__init__(f'*{base+entry_offset:#x}', type=gdb.BP_HARDWARE_BREAKPOINT, internal=True)
        self.name = name

    def stop(self):
        global phase
        try:
            inferior = gdb.selected_inferior()
            if self.name == 'ncdm':
                if phase == 0 and final_call():
                    samples.append(hx(value('$xmm0.v2_double[0]')))
                return False
            if self.name == 'initial':
                if phase or not final_call():
                    return False
                ppr, pba, y = ptr('$rbp','struct precision'),ptr('$rbx','struct background'),ptr('$r12','double')
                if int(field(pba,'N_ncdm')) != 1:
                    raise ValueError('Expected one neutrino species in the frozen input')
                record.update(pid=inferior.pid, caller='main', ncdm_species=1,
                    integrator=int(field(ppr,'background_evolver')),
                    a_default=hx(field(ppr,'a_ini_over_a_today_default')),
                    tol_ncdm=hx(field(ppr,'tol_ncdm_initial_w')))
                params=field(pba,'scf_parameters')
                if int(field(pba,'scf_parameters_size'))!=6 or not samples:
                    raise ValueError('Missing effective scalar parameters or neutrino branch')
                record['initial'] = dict(a_pre_log=hx(value('$xmm0.v2_double[0]')),
                    ncdm_counter=len(samples)-1,ncdm_p_over_rho=samples[-1],
                    ncdm_attempts=samples[:], attractor=int(field(pba,'attractor_ic_scf')),
                    f_scf=hx(params[1]),theta_i=hx(params[4]),
                    phi_ini=hx(field(pba,'phi_ini_scf')),phi_prime_ini=hx(field(pba,'phi_prime_ini_scf')),
                    rounding=rounding(),**scalar(pba,y))
                phase=1
            elif self.name == 'rhs':
                if phase == 1:
                    caller = gdb.newest_frame().older()
                    if not caller or caller.name() != 'evolver_ndf15':
                        raise ValueError('First RHS caller is not evolver_ndf15')
                    logcoords.append(hx(value('$xmm0.v2_double[0]')))
                    phase=2
            elif phase == 2:
                pba, state, bg=ptr('$rbx','struct background'),ptr('$r12','double'),ptr('$r14','double')
                record['first_rhs']=dict(loga=logcoords[0],a_exp=hx(bg[int(field(pba,'index_bg_a'))]),
                    H=hx(bg[int(field(pba,'index_bg_H'))]),rounding=rounding(),**scalar(pba,state))
                phase=3
                with out.open('x',encoding='utf-8') as f:
                    json.dump(record,f,indent=2)
                    f.write('\n')
                return True
            return False
        except Exception as exc:
            gdb.write(f'Q052 probe error at {self.name}: {exc}\n',gdb.STDERR)
            return True

pid=gdb.selected_inferior().pid
with open(f'/proc/{pid}/maps',encoding='utf-8') as f:
    mappings=[line.split(maxsplit=5) for line in f]
bases=[int(row[0].split('-')[0],16) for row in mappings if len(row)==6
       and int(row[2],16)==0 and row[5].strip()==str(archive_path)]
if len(bases)!=1:
    raise gdb.GdbError('Expected one offset-zero mapping of the authenticated CLASS library')
base=bases[0]
libm={row[5].strip() for row in mappings if len(row)==6 and row[5].strip().endswith('/libm.so.6')}
if len(libm)!=1:
    raise gdb.GdbError('Expected one system libm mapping')
record['mapped_libm']=str(Path(libm.pop()).resolve())
for name,offset in zip(required,(0x6616f,0x65f08,0x67a50,0x67abe),strict=True):
    breakpoints[name]=Probe(name,offset)

