"""Launch the single prospective pair under GDB and validate its two receipts."""
import argparse
from hashlib import sha256
from pathlib import Path
import json
import os
import platform
import shutil
import subprocess
from zipfile import ZipFile
from io import BytesIO

from readback import check_pair

HERE=Path(__file__).resolve().parent
LIB='8b90e21505337cb6696c4f6460616c7c92482f6c8eba7f3450d7da5cb040fae3'
def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def launch(args):
    if platform.machine()!='x86_64' or not shutil.which('gdb'):
        raise RuntimeError('Require x86-64 Linux and Python-enabled GDB')
    lib, wrapper, dest=map(Path.resolve,(args.library,args.wrapper,args.output))
    if digest(lib)!=LIB or not os.access(wrapper,os.X_OK):
        raise ValueError('Library SHA-256 or wrapper executability failed')
    with ZipFile(HERE/'evidence/Q052_SKALARSTART_V135.zip') as zip135:
        raw=json.loads(zip135.read('evidence/raw69.json'))
        with ZipFile(BytesIO(zip135.read('evidence/Q052_BAGGRUNDSCERTIFIKAT_V73.zip'))) as ref:
            records=json.loads(ref.read('native_excerpt.json'))['arms']
    if digest(wrapper)!=raw['compiled_observer_sha256']:
        if args.wrapper_build_receipt is None:
            raise ValueError('Rebuilt wrapper requires a build receipt')
        receipt=json.loads(args.wrapper_build_receipt.read_bytes())
        if receipt.get('source_sha256')!=raw['observer_source_sha256'] or receipt.get('wrapper_sha256')!=digest(wrapper) or receipt.get('library_sha256')!=LIB or receipt.get('flags')!=raw['execution']['commands'][0][1:8]:
            raise ValueError('Rebuilt wrapper provenance does not match the archived source and flags')
    dest.mkdir(parents=True,exist_ok=False)
    (dest/'execution.json').write_text(json.dumps({'status':'started','run_id':args.run_id,
        'wrapper_sha256':digest(wrapper),'library_sha256':LIB},indent=2)+'\n')
    probes={}
    overlap={}
    for arm in 'LR':
        arm_dir=dest/arm
        arm_dir.mkdir()
        ini=arm_dir/'point.ini'
        ini.write_text(records[arm]['metadata']['point.ini'])
        if digest(ini)!=raw['arms'][arm]['point.ini']['sha256']:
            raise ValueError('Point file identity failed')
        env=dict(os.environ,Q052_RUN_ID=args.run_id,Q052_ARM=arm,Q052_MODE='nominal',
                 Q052_NATIVE_OUT=str(arm_dir),Q052_PROBE_LIBRARY=str(lib))
        env['LD_LIBRARY_PATH']=str(lib.parent)
        env.pop('LD_PRELOAD',None)
        cmd=['gdb','-nx','-batch','--return-child-result','-ex','set startup-with-shell off',
             '-ex','set disable-randomization off','-ex','start','-ex',
             'python exec(compile(open('+repr(str(HERE/'observe.py'))+').read(), "observe.py", "exec"))',
              '-ex','continue','-ex',
             'python assert phase == 3; [bp.delete() for bp in breakpoints.values()]',
             '-ex','continue','--args' ,str(wrapper),str(ini)]
        with (arm_dir/'debugger.log').open('x') as log:
            subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240,check=True)
        probes[arm]=json.loads((arm_dir/'scalar_start_receipt.json').read_bytes())
        libm=Path(probes[arm]['mapped_libm'])
        probes[arm]['libm_sha256']=digest(libm)
        (arm_dir/'scalar_start_receipt.json').write_text(json.dumps(probes[arm],indent=2)+'\n')
        overlap[arm]={name:digest(arm_dir/name)==raw['arms'][arm][name]['sha256']
                      for name in ('history.csv','public_table_hex.jsonl')}
        table=(arm_dir/'background_table_hex.jsonl').read_bytes().split(b'\n',1)[1]
        overlap[arm]['background_body']=sha256(table).hexdigest()==records[arm]['body_sha256']
    result=check_pair(probes)
    result['overlap']=overlap
    result['status']='CAPTURED_WITH_OVERLAP' if all(all(x.values()) for x in overlap.values()) else 'CAPTURED_WITH_OVERLAP_DIFFERENCE'
    (dest/'result.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('library','wrapper','output'):
        p.add_argument(name,type=Path)
    p.add_argument('--run-id',required=True)
    p.add_argument('--wrapper-build-receipt',type=Path)
    launch(p.parse_args())
