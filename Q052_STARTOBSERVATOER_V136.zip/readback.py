"""Independent rational reconstruction of the prospective start receipt."""
from decimal import Context, Decimal, localcontext
from fractions import Fraction
from math import isfinite, ulp
import json
from pathlib import Path
import sys

REF = {'a':'0x1.6849b86a12b9bp-47','phi':'0x1.e25c1c67a810dp-3','phi_prime_eta':'0x0p+0'}
def dec(h):
    x=float.fromhex(h)
    if not isfinite(x):
        raise ValueError('Finite hex binary64 required')
    return Fraction(*x.as_integer_ratio())

def rn(x):
    return Fraction(float(x))

def transcendental_check(observed, arg, exp):
    # Exact binary inputs fit well within this many digits at this scale.
    with localcontext(Context(prec=120)) as c:
        exact=Decimal(arg.numerator)/Decimal(arg.denominator)
        mapped=c.exp(exact) if exp else c.ln(exact)
        # Record diagnostic distance rather than imposing bit identity on libm.
        return float(abs(Fraction(mapped)-observed)/Fraction(ulp(float(observed))))

def arm_result(r):
    if r['arm'] not in 'LR' or r['caller']!='main' or r['integrator']!=1 or r['ncdm_species']!=1 or r['pid']<=0:
        raise ValueError('Incorrect arm, process, caller or solver')
    i,b=r['initial'],r['first_rhs']
    for x in (i,b):
        if x['rounding']['mxcsr'] & 0x6000 or x['rounding']['x87_control'] & 0xc00:
            raise ValueError('Wrong rounding mode')
    start=dec(r['a_default'])
    if i['ncdm_counter']<0 or i['ncdm_counter'] != len(i['ncdm_attempts'])-1 or i['ncdm_p_over_rho']!=i['ncdm_attempts'][-1]:
        raise ValueError('Inconsistent neutrino counter')
    for k,ratio in enumerate(i['ncdm_attempts']):
        accepted = abs(rn(dec(ratio)-rn(Fraction(1,3)))) <= dec(r['tol_ncdm'])
        if accepted != (k==i['ncdm_counter']):
            raise ValueError('Neutrino branch replay disagrees')
        if not accepted:
            start=rn(start*dec(float(.1).hex()))
    if start != dec(i['a_pre_log']) or start<=0 or i['attractor']!=0:
        raise ValueError('Initializer and neutrino replay disagree')
    expected=rn(rn(dec(i['f_scf'])*dec(i['theta_i']))/rn(Fraction(2.435)*Fraction(1e27)))
    if expected!=dec(i['phi_ini']) or dec(i['phi_ini'])!=dec(i['phi']) or dec(i['phi_prime_ini'])!=dec(i['phi_prime_eta']):
        raise ValueError('Inconsistent non-attractor scalar initialization')
    fields=('phi','phi_prime_eta')
    if any(dec(i[k])!=dec(b[k]) for k in fields) or dec(b['H'])<=0 or dec(b['a_exp'])<=0:
        raise ValueError('Initial vector differs from first RHS or unphysical RHS scale')
    return {'initializer_residual':{k:str(dec(i[k])-dec(REF[k])) for k in fields},
        'pre_log_a_residual':str(start-dec(REF['a'])),
        'rhs_a_residual':str(dec(b['a_exp'])-dec(REF['a'])),
        'rhs_X_residual':str(dec(b['phi_prime_eta'])/dec(b['a_exp'])),
        'H_rhs':b['H'],'log_distance_in_ulp':transcendental_check(dec(b['loga']),start,False),
        'exp_distance_in_ulp':transcendental_check(dec(b['a_exp']),dec(b['loga']),True)}

def check_pair(pair):
    if set(pair)!={'L','R'} or any(pair[k]['arm']!=k for k in pair) or pair['L']['run_id']!=pair['R']['run_id'] or pair['L']['pid']==pair['R']['pid']:
        raise ValueError('Two distinct processes of one pair required')
    return {'run_id':pair['L']['run_id'],'arms':{k:arm_result(r) for k,r in pair.items()},
            'libm_sha256':{k:r.get('libm_sha256') for k,r in pair.items()}}

if __name__=='__main__':
    l,r=map(Path,sys.argv[1:])
    print(json.dumps(check_pair({'L':json.loads(l.read_bytes()),'R':json.loads(r.read_bytes())}),indent=2))
