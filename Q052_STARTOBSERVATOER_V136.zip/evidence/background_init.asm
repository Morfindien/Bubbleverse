
libq052_class_v36.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000067740 <background_init>:
   67740:	f3 0f 1e fa          	endbr64
   67744:	41 54                	push   %r12
   67746:	55                   	push   %rbp
   67747:	53                   	push   %rbx
   67748:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
   6774f:	48 83 0c 24 00       	orq    $0x0,(%rsp)
   67754:	48 83 ec 10          	sub    $0x10,%rsp
   67758:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   6775f:	00 00 
   67761:	48 89 84 24 08 10 00 	mov    %rax,0x1008(%rsp)
   67768:	00 
   67769:	31 c0                	xor    %eax,%eax
   6776b:	66 83 be ea 0b 00 00 	cmpw   $0x0,0xbea(%rsi)
   67772:	00 
   67773:	48 89 fd             	mov    %rdi,%rbp
   67776:	48 89 f3             	mov    %rsi,%rbx
   67779:	7e 24                	jle    6779f <background_init+0x5f>
   6777b:	bf 02 00 00 00       	mov    $0x2,%edi
   67780:	48 8d 15 10 09 08 00 	lea    0x80910(%rip),%rdx        # e8097 <_fini+0x3edf>
   67787:	48 8d 35 9a 10 08 00 	lea    0x8109a(%rip),%rsi        # e8828 <_fini+0x4670>
   6778e:	e8 6d 7e fa ff       	call   f600 <__printf_chk@plt>
   67793:	48 8d 3d a8 10 08 00 	lea    0x810a8(%rip),%rdi        # e8842 <_fini+0x468a>
   6779a:	e8 61 7d fa ff       	call   f500 <puts@plt>
   6779f:	66 83 bb e8 03 00 00 	cmpw   $0x1,0x3e8(%rbx)
   677a6:	01 
   677a7:	0f 84 93 00 00 00    	je     67840 <background_init+0x100>
   677ad:	48 89 df             	mov    %rbx,%rdi
   677b0:	e8 9b 96 fa ff       	call   10e50 <background_indices@plt>
   677b5:	83 f8 01             	cmp    $0x1,%eax
   677b8:	0f 84 92 01 00 00    	je     67950 <background_init+0x210>
   677be:	48 89 de             	mov    %rbx,%rsi
   677c1:	48 89 ef             	mov    %rbp,%rdi
   677c4:	e8 87 94 fa ff       	call   10c50 <background_checks@plt>
   677c9:	83 f8 01             	cmp    $0x1,%eax
   677cc:	0f 84 de 00 00 00    	je     678b0 <background_init+0x170>
   677d2:	48 89 de             	mov    %rbx,%rsi
   677d5:	48 89 ef             	mov    %rbp,%rdi
   677d8:	e8 e3 7e fa ff       	call   f6c0 <background_solve@plt>
   677dd:	83 f8 01             	cmp    $0x1,%eax
   677e0:	0f 84 aa 01 00 00    	je     67990 <background_init+0x250>
   677e6:	48 89 de             	mov    %rbx,%rsi
   677e9:	48 89 ef             	mov    %rbp,%rdi
   677ec:	e8 bf 87 fa ff       	call   ffb0 <background_find_equality@plt>
   677f1:	83 f8 01             	cmp    $0x1,%eax
   677f4:	0f 84 d6 01 00 00    	je     679d0 <background_init+0x290>
   677fa:	48 89 df             	mov    %rbx,%rdi
   677fd:	e8 be 95 fa ff       	call   10dc0 <background_output_budget@plt>
   67802:	83 f8 01             	cmp    $0x1,%eax
   67805:	0f 84 05 02 00 00    	je     67a10 <background_init+0x2d0>
   6780b:	66 83 bb 90 03 00 00 	cmpw   $0x1,0x390(%rbx)
   67812:	01 
   67813:	0f 84 e7 00 00 00    	je     67900 <background_init+0x1c0>
   67819:	31 c0                	xor    %eax,%eax
   6781b:	48 8b 94 24 08 10 00 	mov    0x1008(%rsp),%rdx
   67822:	00 
   67823:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
   6782a:	00 00 
   6782c:	0f 85 15 02 00 00    	jne    67a47 <background_init+0x307>
   67832:	48 81 c4 10 10 00 00 	add    $0x1010,%rsp
   67839:	5b                   	pop    %rbx
   6783a:	5d                   	pop    %rbp
   6783b:	41 5c                	pop    %r12
   6783d:	c3                   	ret
   6783e:	66 90                	xchg   %ax,%ax
   67840:	49 89 e4             	mov    %rsp,%r12
   67843:	48 8d 93 ea 03 00 00 	lea    0x3ea(%rbx),%rdx
   6784a:	31 c0                	xor    %eax,%eax
   6784c:	48 8d 35 3d 90 09 00 	lea    0x9903d(%rip),%rsi        # 100890 <_fini+0x1c6d8>
   67853:	4c 89 e7             	mov    %r12,%rdi
   67856:	48 8d ac 24 00 08 00 	lea    0x800(%rsp),%rbp
   6785d:	00 
   6785e:	e8 cd 96 fa ff       	call   10f30 <class_protect_sprintf@plt>
   67863:	4c 89 e1             	mov    %r12,%rcx
   67866:	48 89 ef             	mov    %rbp,%rdi
   67869:	31 c0                	xor    %eax,%eax
   6786b:	48 8d 15 66 90 09 00 	lea    0x99066(%rip),%rdx        # 1008d8 <_fini+0x1c720>
   67872:	48 8d 35 b8 d7 07 00 	lea    0x7d7b8(%rip),%rsi        # e5031 <_fini+0xe79>
   67879:	e8 b2 96 fa ff       	call   10f30 <class_protect_sprintf@plt>
   6787e:	49 89 e8             	mov    %rbp,%r8
   67881:	b9 46 03 00 00       	mov    $0x346,%ecx
   67886:	31 c0                	xor    %eax,%eax
   67888:	48 8d bb ec 0b 00 00 	lea    0xbec(%rbx),%rdi
   6788f:	48 8d 15 3a 48 0b 00 	lea    0xb483a(%rip),%rdx        # 11c0d0 <__func__.10>
   67896:	48 8d 35 70 d7 07 00 	lea    0x7d770(%rip),%rsi        # e500d <_fini+0xe55>
   6789d:	e8 8e 96 fa ff       	call   10f30 <class_protect_sprintf@plt>
   678a2:	b8 01 00 00 00       	mov    $0x1,%eax
   678a7:	e9 6f ff ff ff       	jmp    6781b <background_init+0xdb>
   678ac:	0f 1f 40 00          	nopl   0x0(%rax)
   678b0:	48 81 c3 ec 0b 00 00 	add    $0xbec,%rbx
   678b7:	48 8d 15 b1 0f 08 00 	lea    0x80fb1(%rip),%rdx        # e886f <_fini+0x46b7>
   678be:	48 8d 35 ad d8 07 00 	lea    0x7d8ad(%rip),%rsi        # e5172 <_fini+0xfba>
   678c5:	31 c0                	xor    %eax,%eax
   678c7:	48 8d ac 24 00 08 00 	lea    0x800(%rsp),%rbp
   678ce:	00 
   678cf:	48 89 d9             	mov    %rbx,%rcx
   678d2:	48 89 ef             	mov    %rbp,%rdi
   678d5:	e8 56 96 fa ff       	call   10f30 <class_protect_sprintf@plt>
   678da:	49 89 e8             	mov    %rbp,%r8
   678dd:	b9 51 03 00 00       	mov    $0x351,%ecx
   678e2:	48 8d 15 e7 47 0b 00 	lea    0xb47e7(%rip),%rdx        # 11c0d0 <__func__.10>
   678e9:	48 8d 35 1d d7 07 00 	lea    0x7d71d(%rip),%rsi        # e500d <_fini+0xe55>
   678f0:	48 89 df             	mov    %rbx,%rdi
   678f3:	31 c0                	xor    %eax,%eax
   678f5:	e8 36 96 fa ff       	call   10f30 <class_protect_sprintf@plt>
   678fa:	eb a6                	jmp    678a2 <background_init+0x162>
   678fc:	0f 1f 40 00          	nopl   0x0(%rax)
   67900:	48 89 de             	mov    %rbx,%rsi
   67903:	48 89 ef             	mov    %rbp,%rdi
   67906:	e8 65 8b fa ff       	call   10470 <background_find_f_and_zc@plt>
   6790b:	83 f8 01             	cmp    $0x1,%eax
   6790e:	0f 85 05 ff ff ff    	jne    67819 <background_init+0xd9>
   67914:	48 81 c3 ec 0b 00 00 	add    $0xbec,%rbx
   6791b:	48 8d 15 fe 8f 09 00 	lea    0x98ffe(%rip),%rdx        # 100920 <_fini+0x1c768>
   67922:	48 8d 35 49 d8 07 00 	lea    0x7d849(%rip),%rsi        # e5172 <_fini+0xfba>
   67929:	31 c0                	xor    %eax,%eax
   6792b:	48 8d ac 24 00 08 00 	lea    0x800(%rsp),%rbp
   67932:	00 
   67933:	48 89 d9             	mov    %rbx,%rcx
   67936:	48 89 ef             	mov    %rbp,%rdi
   67939:	e8 f2 95 fa ff       	call   10f30 <class_protect_sprintf@plt>
   6793e:	49 89 e8             	mov    %rbp,%r8
   67941:	b9 66 03 00 00       	mov    $0x366,%ecx
   67946:	eb 9a                	jmp    678e2 <background_init+0x1a2>
   67948:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   6794f:	00 
   67950:	48 81 c3 ec 0b 00 00 	add    $0xbec,%rbx
   67957:	48 8d 15 f9 0e 08 00 	lea    0x80ef9(%rip),%rdx        # e8857 <_fini+0x469f>
   6795e:	48 8d 35 0d d8 07 00 	lea    0x7d80d(%rip),%rsi        # e5172 <_fini+0xfba>
   67965:	31 c0                	xor    %eax,%eax
   67967:	48 8d ac 24 00 08 00 	lea    0x800(%rsp),%rbp
   6796e:	00 
   6796f:	48 89 d9             	mov    %rbx,%rcx
   67972:	48 89 ef             	mov    %rbp,%rdi
   67975:	e8 b6 95 fa ff       	call   10f30 <class_protect_sprintf@plt>
   6797a:	49 89 e8             	mov    %rbp,%r8
   6797d:	b9 4c 03 00 00       	mov    $0x34c,%ecx
   67982:	e9 5b ff ff ff       	jmp    678e2 <background_init+0x1a2>
   67987:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   6798e:	00 00 
   67990:	48 81 c3 ec 0b 00 00 	add    $0xbec,%rbx
   67997:	48 8d 15 ec 0e 08 00 	lea    0x80eec(%rip),%rdx        # e888a <_fini+0x46d2>
   6799e:	48 8d 35 cd d7 07 00 	lea    0x7d7cd(%rip),%rsi        # e5172 <_fini+0xfba>
   679a5:	31 c0                	xor    %eax,%eax
   679a7:	48 8d ac 24 00 08 00 	lea    0x800(%rsp),%rbp
   679ae:	00 
   679af:	48 89 d9             	mov    %rbx,%rcx
   679b2:	48 89 ef             	mov    %rbp,%rdi
   679b5:	e8 76 95 fa ff       	call   10f30 <class_protect_sprintf@plt>
   679ba:	49 89 e8             	mov    %rbp,%r8
   679bd:	b9 56 03 00 00       	mov    $0x356,%ecx
   679c2:	e9 1b ff ff ff       	jmp    678e2 <background_init+0x1a2>
   679c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   679ce:	00 00 
   679d0:	48 81 c3 ec 0b 00 00 	add    $0xbec,%rbx
   679d7:	48 8d 15 1a 8f 09 00 	lea    0x98f1a(%rip),%rdx        # 1008f8 <_fini+0x1c740>
   679de:	48 8d 35 8d d7 07 00 	lea    0x7d78d(%rip),%rsi        # e5172 <_fini+0xfba>
   679e5:	31 c0                	xor    %eax,%eax
   679e7:	48 8d ac 24 00 08 00 	lea    0x800(%rsp),%rbp
   679ee:	00 
   679ef:	48 89 d9             	mov    %rbx,%rcx
   679f2:	48 89 ef             	mov    %rbp,%rdi
   679f5:	e8 36 95 fa ff       	call   10f30 <class_protect_sprintf@plt>
   679fa:	49 89 e8             	mov    %rbp,%r8
   679fd:	b9 5b 03 00 00       	mov    $0x35b,%ecx
   67a02:	e9 db fe ff ff       	jmp    678e2 <background_init+0x1a2>
   67a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   67a0e:	00 00 
   67a10:	48 81 c3 ec 0b 00 00 	add    $0xbec,%rbx
   67a17:	48 8d 15 86 0e 08 00 	lea    0x80e86(%rip),%rdx        # e88a4 <_fini+0x46ec>
   67a1e:	48 8d 35 4d d7 07 00 	lea    0x7d74d(%rip),%rsi        # e5172 <_fini+0xfba>
   67a25:	31 c0                	xor    %eax,%eax
   67a27:	48 8d ac 24 00 08 00 	lea    0x800(%rsp),%rbp
   67a2e:	00 
   67a2f:	48 89 d9             	mov    %rbx,%rcx
   67a32:	48 89 ef             	mov    %rbp,%rdi
   67a35:	e8 f6 94 fa ff       	call   10f30 <class_protect_sprintf@plt>
   67a3a:	49 89 e8             	mov    %rbp,%r8
   67a3d:	b9 60 03 00 00       	mov    $0x360,%ecx
   67a42:	e9 9b fe ff ff       	jmp    678e2 <background_init+0x1a2>
   67a47:	e8 04 8c fa ff       	call   10650 <__stack_chk_fail@plt>

Disassembly of section .fini:
