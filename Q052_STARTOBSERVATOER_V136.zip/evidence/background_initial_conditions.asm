
libq052_class_v36.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000065ca0 <background_initial_conditions>:
   65ca0:	f3 0f 1e fa          	endbr64
   65ca4:	41 57                	push   %r15
   65ca6:	41 56                	push   %r14
   65ca8:	41 55                	push   %r13
   65caa:	41 54                	push   %r12
   65cac:	55                   	push   %rbp
   65cad:	53                   	push   %rbx
   65cae:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
   65cb5:	48 83 0c 24 00       	orq    $0x0,(%rsp)
   65cba:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
   65cc1:	f2 0f 10 3f          	movsd  (%rdi),%xmm7
   65cc5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   65ccc:	00 00 
   65cce:	48 89 84 24 78 10 00 	mov    %rax,0x1078(%rsp)
   65cd5:	00 
   65cd6:	31 c0                	xor    %eax,%eax
   65cd8:	66 83 be 92 03 00 00 	cmpw   $0x1,0x392(%rsi)
   65cdf:	01 
   65ce0:	48 89 fd             	mov    %rdi,%rbp
   65ce3:	48 89 f3             	mov    %rsi,%rbx
   65ce6:	49 89 d5             	mov    %rdx,%r13
   65ce9:	49 89 cc             	mov    %rcx,%r12
   65cec:	4d 89 c6             	mov    %r8,%r14
   65cef:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
   65cf5:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   65cfc:	00 
   65cfd:	0f 84 cd 03 00 00    	je     660d0 <background_initial_conditions+0x430>
   65d03:	66 83 bb 98 03 00 00 	cmpw   $0x1,0x398(%rbx)
   65d0a:	01 
   65d0b:	f2 0f 10 5b 20       	movsd  0x20(%rbx),%xmm3
   65d10:	0f 84 a2 03 00 00    	je     660b8 <background_initial_conditions+0x418>
   65d16:	66 83 bb 9a 03 00 00 	cmpw   $0x1,0x39a(%rbx)
   65d1d:	01 
   65d1e:	0f 84 84 03 00 00    	je     660a8 <background_initial_conditions+0x408>
   65d24:	f2 0f 10 23          	movsd  (%rbx),%xmm4
   65d28:	f2 0f 10 0d 28 40 0b 	movsd  0xb4028(%rip),%xmm1        # 119d58 <__func__.3+0x358>
   65d2f:	00 
   65d30:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
   65d36:	f2 0f 10 44 24 18    	movsd  0x18(%rsp),%xmm0
   65d3c:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
   65d42:	e8 69 b1 fa ff       	call   10eb0 <pow@plt>
   65d47:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
   65d4d:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
   65d53:	66 0f 28 c8          	movapd %xmm0,%xmm1
   65d57:	66 83 bb 92 03 00 00 	cmpw   $0x1,0x392(%rbx)
   65d5e:	01 
   65d5f:	66 0f 28 c4          	movapd %xmm4,%xmm0
   65d63:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   65d67:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
   65d6b:	66 0f 28 d0          	movapd %xmm0,%xmm2
   65d6f:	f2 0f 5e d1          	divsd  %xmm1,%xmm2
   65d73:	0f 84 c7 01 00 00    	je     65f40 <background_initial_conditions+0x2a0>
   65d79:	66 83 bb 8c 03 00 00 	cmpw   $0x1,0x38c(%rbx)
   65d80:	01 
   65d81:	0f 84 cc 01 00 00    	je     65f53 <background_initial_conditions+0x2b3>
   65d87:	66 83 bb 8e 03 00 00 	cmpw   $0x1,0x38e(%rbx)
   65d8e:	01 
   65d8f:	0f 84 cb 05 00 00    	je     66360 <background_initial_conditions+0x6c0>
   65d95:	66 83 bb 96 03 00 00 	cmpw   $0x1,0x396(%rbx)
   65d9c:	01 
   65d9d:	0f 84 da 05 00 00    	je     6637d <background_initial_conditions+0x6dd>
   65da3:	66 83 bb 90 03 00 00 	cmpw   $0x1,0x390(%rbx)
   65daa:	01 
   65dab:	75 67                	jne    65e14 <background_initial_conditions+0x174>
   65dad:	48 8b 83 58 01 00 00 	mov    0x158(%rbx),%rax
   65db4:	66 83 bb 60 01 00 00 	cmpw   $0x1,0x160(%rbx)
   65dbb:	01 
   65dbc:	f2 0f 10 08          	movsd  (%rax),%xmm1
   65dc0:	0f 84 aa 07 00 00    	je     66570 <background_initial_conditions+0x8d0>
   65dc6:	48 63 83 64 03 00 00 	movslq 0x364(%rbx),%rax
   65dcd:	f2 0f 10 83 68 01 00 	movsd  0x168(%rbx),%xmm0
   65dd4:	00 
   65dd5:	48 63 93 68 03 00 00 	movslq 0x368(%rbx),%rdx
   65ddc:	49 8d 04 c4          	lea    (%r12,%rax,8),%rax
   65de0:	f2 0f 11 00          	movsd  %xmm0,(%rax)
   65de4:	f2 0f 10 83 70 01 00 	movsd  0x170(%rbx),%xmm0
   65deb:	00 
   65dec:	f2 41 0f 11 04 d4    	movsd  %xmm0,(%r12,%rdx,8)
   65df2:	f2 0f 10 08          	movsd  (%rax),%xmm1
   65df6:	f2 0f 10 15 ea 46 0b 	movsd  0xb46ea(%rip),%xmm2        # 11a4e8 <__func__.3+0xae8>
   65dfd:	00 
   65dfe:	66 0f 28 c1          	movapd %xmm1,%xmm0
   65e02:	66 0f 54 05 06 29 0b 	andpd  0xb2906(%rip),%xmm0        # 118710 <__func__.3+0x18>
   65e09:	00 
   65e0a:	66 0f 2e d0          	ucomisd %xmm0,%xmm2
   65e0e:	0f 82 4c 06 00 00    	jb     66460 <background_initial_conditions+0x7c0>
   65e14:	f2 0f 10 44 24 18    	movsd  0x18(%rsp),%xmm0
   65e1a:	4c 89 e9             	mov    %r13,%rcx
   65e1d:	4c 89 e6             	mov    %r12,%rsi
   65e20:	48 89 df             	mov    %rbx,%rdi
   65e23:	ba 01 00 00 00       	mov    $0x1,%edx
   65e28:	e8 33 af fa ff       	call   10d60 <background_functions@plt>
   65e2d:	83 f8 01             	cmp    $0x1,%eax
   65e30:	0f 84 02 07 00 00    	je     66538 <background_initial_conditions+0x898>
   65e36:	48 63 83 dc 02 00 00 	movslq 0x2dc(%rbx),%rax
   65e3d:	f2 0f 10 0d 13 3d 0b 	movsd  0xb3d13(%rip),%xmm1        # 119b58 <__func__.3+0x158>
   65e44:	00 
   65e45:	f2 41 0f 10 54 c5 00 	movsd  0x0(%r13,%rax,8),%xmm2
   65e4c:	66 0f 28 c2          	movapd %xmm2,%xmm0
   65e50:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
   65e54:	66 0f 54 05 b4 28 0b 	andpd  0xb28b4(%rip),%xmm0        # 118710 <__func__.3+0x18>
   65e5b:	00 
   65e5c:	66 0f 2f 45 20       	comisd 0x20(%rbp),%xmm0
   65e61:	0f 87 89 05 00 00    	ja     663f0 <background_initial_conditions+0x750>
   65e67:	48 63 83 6c 02 00 00 	movslq 0x26c(%rbx),%rax
   65e6e:	66 0f ef d2          	pxor   %xmm2,%xmm2
   65e72:	49 8d 44 c5 00       	lea    0x0(%r13,%rax,8),%rax
   65e77:	f2 0f 10 00          	movsd  (%rax),%xmm0
   65e7b:	66 0f 2f d0          	comisd %xmm0,%xmm2
   65e7f:	0f 83 4b 06 00 00    	jae    664d0 <background_initial_conditions+0x830>
   65e85:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
   65e89:	66 0f 28 d1          	movapd %xmm1,%xmm2
   65e8d:	48 63 93 6c 03 00 00 	movslq 0x36c(%rbx),%rdx
   65e94:	f2 0f 10 7c 24 18    	movsd  0x18(%rsp),%xmm7
   65e9a:	f2 0f 5e d0          	divsd  %xmm0,%xmm2
   65e9e:	66 0f 28 c1          	movapd %xmm1,%xmm0
   65ea2:	f2 41 0f 11 14 d4    	movsd  %xmm2,(%r12,%rdx,8)
   65ea8:	f2 0f 10 10          	movsd  (%rax),%xmm2
   65eac:	48 63 93 74 03 00 00 	movslq 0x374(%rbx),%rdx
   65eb3:	f2 0f 59 d7          	mulsd  %xmm7,%xmm2
   65eb7:	f2 0f 5e c2          	divsd  %xmm2,%xmm0
   65ebb:	f2 0f 10 15 6d 3b 0b 	movsd  0xb3b6d(%rip),%xmm2        # 119a30 <__func__.3+0x30>
   65ec2:	00 
   65ec3:	f2 0f 51 d2          	sqrtsd %xmm2,%xmm2
   65ec7:	f2 41 0f 11 04 d4    	movsd  %xmm0,(%r12,%rdx,8)
   65ecd:	f2 0f 5e c2          	divsd  %xmm2,%xmm0
   65ed1:	48 63 93 70 03 00 00 	movslq 0x370(%rbx),%rdx
   65ed8:	f2 41 0f 11 04 d4    	movsd  %xmm0,(%r12,%rdx,8)
   65ede:	48 63 93 78 03 00 00 	movslq 0x378(%rbx),%rdx
   65ee5:	66 0f 28 c7          	movapd %xmm7,%xmm0
   65ee9:	f2 0f 58 c7          	addsd  %xmm7,%xmm0
   65eed:	f2 41 0f 11 0c d4    	movsd  %xmm1,(%r12,%rdx,8)
   65ef3:	f2 0f 59 00          	mulsd  (%rax),%xmm0
   65ef7:	48 63 93 7c 03 00 00 	movslq 0x37c(%rbx),%rdx
   65efe:	f2 41 0f 11 04 d4    	movsd  %xmm0,(%r12,%rdx,8)
   65f04:	66 0f 28 c7          	movapd %xmm7,%xmm0
   65f08:	e8 f3 9c fa ff       	call   fc00 <log@plt>
   65f0d:	31 c0                	xor    %eax,%eax
   65f0f:	f2 41 0f 11 06       	movsd  %xmm0,(%r14)
   65f14:	48 8b 94 24 78 10 00 	mov    0x1078(%rsp),%rdx
   65f1b:	00 
   65f1c:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
   65f23:	00 00 
   65f25:	0f 85 d1 07 00 00    	jne    666fc <background_initial_conditions+0xa5c>
   65f2b:	48 81 c4 88 10 00 00 	add    $0x1088,%rsp
   65f32:	5b                   	pop    %rbx
   65f33:	5d                   	pop    %rbp
   65f34:	41 5c                	pop    %r12
   65f36:	41 5d                	pop    %r13
   65f38:	41 5e                	pop    %r14
   65f3a:	41 5f                	pop    %r15
   65f3c:	c3                   	ret
   65f3d:	0f 1f 00             	nopl   (%rax)
   65f40:	66 83 bb 8c 03 00 00 	cmpw   $0x1,0x38c(%rbx)
   65f47:	01 
   65f48:	f2 0f 58 14 24       	addsd  (%rsp),%xmm2
   65f4d:	0f 85 34 fe ff ff    	jne    65d87 <background_initial_conditions+0xe7>
   65f53:	f2 0f 10 43 68       	movsd  0x68(%rbx),%xmm0
   65f58:	f2 0f 10 0d b0 3e 0b 	movsd  0xb3eb0(%rip),%xmm1        # 119e10 <__func__.3+0x410>
   65f5f:	00 
   65f60:	f2 0f 11 54 24 10    	movsd  %xmm2,0x10(%rsp)
   65f66:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
   65f6c:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   65f70:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   65f74:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
   65f79:	f2 0f 10 44 24 18    	movsd  0x18(%rsp),%xmm0
   65f7f:	e8 2c af fa ff       	call   10eb0 <pow@plt>
   65f84:	f2 0f 59 04 24       	mulsd  (%rsp),%xmm0
   65f89:	48 63 83 58 03 00 00 	movslq 0x358(%rbx),%rax
   65f90:	66 83 bb ea 0b 00 00 	cmpw   $0x3,0xbea(%rbx)
   65f97:	03 
   65f98:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
   65f9e:	f2 0f 10 54 24 10    	movsd  0x10(%rsp),%xmm2
   65fa4:	f2 41 0f 11 04 c4    	movsd  %xmm0,(%r12,%rax,8)
   65faa:	0f 8f 60 03 00 00    	jg     66310 <background_initial_conditions+0x670>
   65fb0:	66 83 bb 8e 03 00 00 	cmpw   $0x1,0x38e(%rbx)
   65fb7:	01 
   65fb8:	0f 85 d7 fd ff ff    	jne    65d95 <background_initial_conditions+0xf5>
   65fbe:	f2 0f 10 0d 4a 3d 0b 	movsd  0xb3d4a(%rip),%xmm1        # 119d10 <__func__.3+0x310>
   65fc5:	00 
   65fc6:	f2 0f 10 44 24 18    	movsd  0x18(%rsp),%xmm0
   65fcc:	f2 0f 11 54 24 10    	movsd  %xmm2,0x10(%rsp)
   65fd2:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
   65fd7:	e8 d4 ae fa ff       	call   10eb0 <pow@plt>
   65fdc:	48 63 83 58 03 00 00 	movslq 0x358(%rbx),%rax
   65fe3:	f2 0f 10 3b          	movsd  (%rbx),%xmm7
   65fe7:	66 0f 28 e0          	movapd %xmm0,%xmm4
   65feb:	f2 0f 10 0d 3d 3a 0b 	movsd  0xb3a3d(%rip),%xmm1        # 119a30 <__func__.3+0x30>
   65ff2:	00 
   65ff3:	f2 0f 10 05 5d 3b 0b 	movsd  0xb3b5d(%rip),%xmm0        # 119b58 <__func__.3+0x158>
   65ffa:	00 
   65ffb:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
   66001:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
   66005:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   66009:	f2 41 0f 59 04 c4    	mulsd  (%r12,%rax,8),%xmm0
   6600f:	f2 0f 59 43 70       	mulsd  0x70(%rbx),%xmm0
   66014:	66 49 0f 7e c7       	movq   %xmm0,%r15
   66019:	66 0f 28 c7          	movapd %xmm7,%xmm0
   6601d:	e8 8e ae fa ff       	call   10eb0 <pow@plt>
   66022:	66 49 0f 6e e7       	movq   %r15,%xmm4
   66027:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
   6602c:	f2 0f 10 54 24 10    	movsd  0x10(%rsp),%xmm2
   66032:	f2 0f 5e e0          	divsd  %xmm0,%xmm4
   66036:	66 0f ef c0          	pxor   %xmm0,%xmm0
   6603a:	66 0f 2e c3          	ucomisd %xmm3,%xmm0
   6603e:	66 49 0f 7e e7       	movq   %xmm4,%r15
   66043:	0f 87 b8 06 00 00    	ja     66701 <background_initial_conditions+0xa61>
   66049:	f2 0f 51 db          	sqrtsd %xmm3,%xmm3
   6604d:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
   66052:	f2 0f 10 0d fe 3c 0b 	movsd  0xb3cfe(%rip),%xmm1        # 119d58 <__func__.3+0x358>
   66059:	00 
   6605a:	f2 0f 10 44 24 18    	movsd  0x18(%rsp),%xmm0
   66060:	f2 0f 11 54 24 10    	movsd  %xmm2,0x10(%rsp)
   66066:	e8 45 ae fa ff       	call   10eb0 <pow@plt>
   6606b:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
   66071:	48 63 83 5c 03 00 00 	movslq 0x35c(%rbx),%rax
   66078:	66 0f 28 c8          	movapd %xmm0,%xmm1
   6607c:	66 49 0f 6e c7       	movq   %r15,%xmm0
   66081:	f2 0f 5e 04 24       	divsd  (%rsp),%xmm0
   66086:	f2 0f 10 54 24 10    	movsd  0x10(%rsp),%xmm2
   6608c:	f2 0f 59 c6          	mulsd  %xmm6,%xmm0
   66090:	f2 0f 59 c6          	mulsd  %xmm6,%xmm0
   66094:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
   66098:	f2 41 0f 11 04 c4    	movsd  %xmm0,(%r12,%rax,8)
   6609e:	e9 f2 fc ff ff       	jmp    65d95 <background_initial_conditions+0xf5>
   660a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   660a8:	f2 0f 58 5b 50       	addsd  0x50(%rbx),%xmm3
   660ad:	e9 72 fc ff ff       	jmp    65d24 <background_initial_conditions+0x84>
   660b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   660b8:	66 83 bb 9a 03 00 00 	cmpw   $0x1,0x39a(%rbx)
   660bf:	01 
   660c0:	f2 0f 58 5b 38       	addsd  0x38(%rbx),%xmm3
   660c5:	0f 85 59 fc ff ff    	jne    65d24 <background_initial_conditions+0x84>
   660cb:	eb db                	jmp    660a8 <background_initial_conditions+0x408>
   660cd:	0f 1f 00             	nopl   (%rax)
   660d0:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   660d5:	8b 86 80 00 00 00    	mov    0x80(%rsi),%eax
   660db:	31 d2                	xor    %edx,%edx
   660dd:	48 89 fb             	mov    %rdi,%rbx
   660e0:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
   660e5:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
   660ea:	49 89 f5             	mov    %rsi,%r13
   660ed:	85 c0                	test   %eax,%eax
   660ef:	0f 8e 94 05 00 00    	jle    66689 <background_initial_conditions+0x9e9>
   660f5:	4c 8d 7c 24 50       	lea    0x50(%rsp),%r15
   660fa:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
   660ff:	89 54 24 24          	mov    %edx,0x24(%rsp)
   66103:	31 ed                	xor    %ebp,%ebp
   66105:	41 be 01 00 00 00    	mov    $0x1,%r14d
   6610b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   66110:	4c 89 f8             	mov    %r15,%rax
   66113:	f2 0f 10 05 3d 3a 0b 	movsd  0xb3a3d(%rip),%xmm0        # 119b58 <__func__.3+0x158>
   6611a:	00 
   6611b:	4d 89 ef             	mov    %r13,%r15
   6611e:	f2 0f 5e 44 24 18    	divsd  0x18(%rsp),%xmm0
   66124:	45 89 f5             	mov    %r14d,%r13d
   66127:	45 31 e4             	xor    %r12d,%r12d
   6612a:	66 0f 28 d0          	movapd %xmm0,%xmm2
   6612e:	49 89 de             	mov    %rbx,%r14
   66131:	48 89 c3             	mov    %rax,%rbx
   66134:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   6613b:	00 
   6613c:	f2 0f 5c 15 14 3a 0b 	subsd  0xb3a14(%rip),%xmm2        # 119b58 <__func__.3+0x158>
   66143:	00 
   66144:	eb 66                	jmp    661ac <background_initial_conditions+0x50c>
   66146:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   6614d:	00 00 00 
   66150:	f2 0f 10 44 24 50    	movsd  0x50(%rsp),%xmm0
   66156:	f2 0f 10 0d d2 38 0b 	movsd  0xb38d2(%rip),%xmm1        # 119a30 <__func__.3+0x30>
   6615d:	00 
   6615e:	41 8b 87 80 00 00 00 	mov    0x80(%r15),%eax
   66165:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   66169:	f2 0f 5e 44 24 48    	divsd  0x48(%rsp),%xmm0
   6616f:	f2 0f 58 0c 24       	addsd  (%rsp),%xmm1
   66174:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
   66179:	f2 0f 10 0d d7 39 0b 	movsd  0xb39d7(%rip),%xmm1        # 119b58 <__func__.3+0x158>
   66180:	00 
   66181:	f2 0f 5e 0d a7 38 0b 	divsd  0xb38a7(%rip),%xmm1        # 119a30 <__func__.3+0x30>
   66188:	00 
   66189:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
   6618d:	66 0f 54 05 7b 25 0b 	andpd  0xb257b(%rip),%xmm0        # 118710 <__func__.3+0x18>
   66194:	00 
   66195:	66 41 0f 2e 46 50    	ucomisd 0x50(%r14),%xmm0
   6619b:	44 0f 47 ed          	cmova  %ebp,%r13d
   6619f:	49 83 c4 01          	add    $0x1,%r12
   661a3:	44 39 e0             	cmp    %r12d,%eax
   661a6:	0f 8e c4 00 00 00    	jle    66270 <background_initial_conditions+0x5d0>
   661ac:	49 8b 87 e0 03 00 00 	mov    0x3e0(%r15),%rax
   661b3:	31 c9                	xor    %ecx,%ecx
   661b5:	49 89 d9             	mov    %rbx,%r9
   661b8:	f2 42 0f 10 0c e0    	movsd  (%rax,%r12,8),%xmm1
   661be:	49 8b 87 a0 00 00 00 	mov    0xa0(%r15),%rax
   661c5:	f2 42 0f 10 04 e0    	movsd  (%rax,%r12,8),%xmm0
   661cb:	49 8b 87 d0 03 00 00 	mov    0x3d0(%r15),%rax
   661d2:	42 8b 14 a0          	mov    (%rax,%r12,4),%edx
   661d6:	49 8b 87 b0 03 00 00 	mov    0x3b0(%r15),%rax
   661dd:	4a 8b 34 e0          	mov    (%rax,%r12,8),%rsi
   661e1:	49 8b 87 a8 03 00 00 	mov    0x3a8(%r15),%rax
   661e8:	4a 8b 3c e0          	mov    (%rax,%r12,8),%rdi
   661ec:	6a 00                	push   $0x0
   661ee:	6a 00                	push   $0x0
   661f0:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
   661f5:	f2 0f 11 54 24 18    	movsd  %xmm2,0x18(%rsp)
   661fb:	e8 40 96 fa ff       	call   f840 <background_ncdm_momenta@plt>
   66200:	5a                   	pop    %rdx
   66201:	59                   	pop    %rcx
   66202:	83 f8 01             	cmp    $0x1,%eax
   66205:	f2 0f 10 54 24 08    	movsd  0x8(%rsp),%xmm2
   6620b:	0f 85 3f ff ff ff    	jne    66150 <background_initial_conditions+0x4b0>
   66211:	4c 89 fb             	mov    %r15,%rbx
   66214:	48 8d 15 ed 9d 09 00 	lea    0x99ded(%rip),%rdx        # 100008 <_fini+0x1be50>
   6621b:	48 8d 35 50 ef 07 00 	lea    0x7ef50(%rip),%rsi        # e5172 <_fini+0xfba>
   66222:	31 c0                	xor    %eax,%eax
   66224:	48 8d ac 24 70 08 00 	lea    0x870(%rsp),%rbp
   6622b:	00 
   6622c:	48 81 c3 ec 0b 00 00 	add    $0xbec,%rbx
   66233:	48 89 d9             	mov    %rbx,%rcx
   66236:	48 89 ef             	mov    %rbp,%rdi
   66239:	e8 f2 ac fa ff       	call   10f30 <class_protect_sprintf@plt>
   6623e:	49 89 e8             	mov    %rbp,%r8
   66241:	b9 93 08 00 00       	mov    $0x893,%ecx
   66246:	48 8d 15 b3 5d 0b 00 	lea    0xb5db3(%rip),%rdx        # 11c000 <__func__.3>
   6624d:	48 8d 35 b9 ed 07 00 	lea    0x7edb9(%rip),%rsi        # e500d <_fini+0xe55>
   66254:	48 89 df             	mov    %rbx,%rdi
   66257:	31 c0                	xor    %eax,%eax
   66259:	e8 d2 ac fa ff       	call   10f30 <class_protect_sprintf@plt>
   6625e:	b8 01 00 00 00       	mov    $0x1,%eax
   66263:	e9 ac fc ff ff       	jmp    65f14 <background_initial_conditions+0x274>
   66268:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   6626f:	00 
   66270:	4c 89 f3             	mov    %r14,%rbx
   66273:	45 89 ee             	mov    %r13d,%r14d
   66276:	8b 54 24 24          	mov    0x24(%rsp),%edx
   6627a:	4d 89 fd             	mov    %r15,%r13
   6627d:	41 83 fe 01          	cmp    $0x1,%r14d
   66281:	0f 84 5b 04 00 00    	je     666e2 <background_initial_conditions+0xa42>
   66287:	f2 0f 10 74 24 18    	movsd  0x18(%rsp),%xmm6
   6628d:	f2 0f 59 35 db 38 0b 	mulsd  0xb38db(%rip),%xmm6        # 119b70 <__func__.3+0x170>
   66294:	00 
   66295:	83 c2 01             	add    $0x1,%edx
   66298:	f2 0f 11 74 24 18    	movsd  %xmm6,0x18(%rsp)
   6629e:	81 fa 10 27 00 00    	cmp    $0x2710,%edx
   662a4:	0f 85 43 fe ff ff    	jne    660ed <background_initial_conditions+0x44d>
   662aa:	4c 8d 64 24 70       	lea    0x70(%rsp),%r12
   662af:	31 c0                	xor    %eax,%eax
   662b1:	48 8d ac 24 70 08 00 	lea    0x870(%rsp),%rbp
   662b8:	00 
   662b9:	4c 89 e7             	mov    %r12,%rdi
   662bc:	48 8d 35 9d a0 09 00 	lea    0x9a09d(%rip),%rsi        # 100360 <_fini+0x1c1a8>
   662c3:	e8 68 ac fa ff       	call   10f30 <class_protect_sprintf@plt>
   662c8:	4c 89 e1             	mov    %r12,%rcx
   662cb:	48 89 ef             	mov    %rbp,%rdi
   662ce:	31 c0                	xor    %eax,%eax
   662d0:	48 8d 15 25 f4 07 00 	lea    0x7f425(%rip),%rdx        # e56fc <_fini+0x1544>
   662d7:	48 8d 35 53 ed 07 00 	lea    0x7ed53(%rip),%rsi        # e5031 <_fini+0xe79>
   662de:	e8 4d ac fa ff       	call   10f30 <class_protect_sprintf@plt>
   662e3:	49 89 e8             	mov    %rbp,%r8
   662e6:	b9 ac 08 00 00       	mov    $0x8ac,%ecx
   662eb:	31 c0                	xor    %eax,%eax
   662ed:	49 8d bf ec 0b 00 00 	lea    0xbec(%r15),%rdi
   662f4:	48 8d 15 05 5d 0b 00 	lea    0xb5d05(%rip),%rdx        # 11c000 <__func__.3>
   662fb:	48 8d 35 0b ed 07 00 	lea    0x7ed0b(%rip),%rsi        # e500d <_fini+0xe55>
   66302:	e8 29 ac fa ff       	call   10f30 <class_protect_sprintf@plt>
   66307:	e9 52 ff ff ff       	jmp    6625e <background_initial_conditions+0x5be>
   6630c:	0f 1f 40 00          	nopl   0x0(%rax)
   66310:	f2 0f 10 4b 68       	movsd  0x68(%rbx),%xmm1
   66315:	bf 02 00 00 00       	mov    $0x2,%edi
   6631a:	b8 02 00 00 00       	mov    $0x2,%eax
   6631f:	48 8d 35 aa 23 08 00 	lea    0x823aa(%rip),%rsi        # e86d0 <_fini+0x4518>
   66326:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
   6632c:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
   66331:	e8 ca 92 fa ff       	call   f600 <__printf_chk@plt>
   66336:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
   6633b:	66 83 bb 8e 03 00 00 	cmpw   $0x1,0x38e(%rbx)
   66342:	01 
   66343:	f2 0f 10 54 24 08    	movsd  0x8(%rsp),%xmm2
   66349:	0f 85 46 fa ff ff    	jne    65d95 <background_initial_conditions+0xf5>
   6634f:	66 83 bb 8c 03 00 00 	cmpw   $0x1,0x38c(%rbx)
   66356:	01 
   66357:	0f 84 61 fc ff ff    	je     65fbe <background_initial_conditions+0x31e>
   6635d:	0f 1f 00             	nopl   (%rax)
   66360:	48 63 83 5c 03 00 00 	movslq 0x35c(%rbx),%rax
   66367:	66 83 bb 96 03 00 00 	cmpw   $0x1,0x396(%rbx)
   6636e:	01 
   6636f:	49 c7 04 c4 00 00 00 	movq   $0x0,(%r12,%rax,8)
   66376:	00 
   66377:	0f 85 26 fa ff ff    	jne    65da3 <background_initial_conditions+0x103>
   6637d:	f2 0f 10 03          	movsd  (%rbx),%xmm0
   66381:	48 8d 4c 24 68       	lea    0x68(%rsp),%rcx
   66386:	48 8d 54 24 60       	lea    0x60(%rsp),%rdx
   6638b:	48 89 df             	mov    %rbx,%rdi
   6638e:	48 8d 74 24 58       	lea    0x58(%rsp),%rsi
   66393:	f2 0f 11 14 24       	movsd  %xmm2,(%rsp)
   66398:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
   6639c:	f2 0f 59 83 10 01 00 	mulsd  0x110(%rbx),%xmm0
   663a3:	00 
   663a4:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
   663aa:	f2 0f 10 44 24 18    	movsd  0x18(%rsp),%xmm0
   663b0:	e8 fb a1 fa ff       	call   105b0 <background_w_fld@plt>
   663b5:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
   663ba:	83 f8 01             	cmp    $0x1,%eax
   663bd:	0f 84 e8 02 00 00    	je     666ab <background_initial_conditions+0xa0b>
   663c3:	f2 0f 10 44 24 68    	movsd  0x68(%rsp),%xmm0
   663c9:	f2 0f 11 14 24       	movsd  %xmm2,(%rsp)
   663ce:	e8 7d 90 fa ff       	call   f450 <exp@plt>
   663d3:	f2 0f 59 44 24 08    	mulsd  0x8(%rsp),%xmm0
   663d9:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
   663de:	48 63 83 60 03 00 00 	movslq 0x360(%rbx),%rax
   663e5:	f2 41 0f 11 04 c4    	movsd  %xmm0,(%r12,%rax,8)
   663eb:	e9 b3 f9 ff ff       	jmp    65da3 <background_initial_conditions+0x103>
   663f0:	4c 8d 64 24 70       	lea    0x70(%rsp),%r12
   663f5:	66 0f 28 c2          	movapd %xmm2,%xmm0
   663f9:	48 8d ac 24 70 08 00 	lea    0x870(%rsp),%rbp
   66400:	00 
   66401:	b8 01 00 00 00       	mov    $0x1,%eax
   66406:	4c 89 e7             	mov    %r12,%rdi
   66409:	48 8d 35 48 9e 09 00 	lea    0x99e48(%rip),%rsi        # 100258 <_fini+0x1c0a0>
   66410:	e8 1b ab fa ff       	call   10f30 <class_protect_sprintf@plt>
   66415:	4c 89 e1             	mov    %r12,%rcx
   66418:	48 89 ef             	mov    %rbp,%rdi
   6641b:	31 c0                	xor    %eax,%eax
   6641d:	48 8d 15 ac 9e 09 00 	lea    0x99eac(%rip),%rdx        # 1002d0 <_fini+0x1c118>
   66424:	48 8d 35 06 ec 07 00 	lea    0x7ec06(%rip),%rsi        # e5031 <_fini+0xe79>
   6642b:	e8 00 ab fa ff       	call   10f30 <class_protect_sprintf@plt>
   66430:	49 89 e8             	mov    %rbp,%r8
   66433:	b9 17 09 00 00       	mov    $0x917,%ecx
   66438:	31 c0                	xor    %eax,%eax
   6643a:	48 8d bb ec 0b 00 00 	lea    0xbec(%rbx),%rdi
   66441:	48 8d 15 b8 5b 0b 00 	lea    0xb5bb8(%rip),%rdx        # 11c000 <__func__.3>
   66448:	48 8d 35 be eb 07 00 	lea    0x7ebbe(%rip),%rsi        # e500d <_fini+0xe55>
   6644f:	e8 dc aa fa ff       	call   10f30 <class_protect_sprintf@plt>
   66454:	e9 05 fe ff ff       	jmp    6625e <background_initial_conditions+0x5be>
   66459:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   66460:	4c 8d 64 24 70       	lea    0x70(%rsp),%r12
   66465:	66 0f 28 c1          	movapd %xmm1,%xmm0
   66469:	48 8d ac 24 70 08 00 	lea    0x870(%rsp),%rbp
   66470:	00 
   66471:	b8 02 00 00 00       	mov    $0x2,%eax
   66476:	4c 89 e7             	mov    %r12,%rdi
   66479:	48 8d 35 d0 9c 09 00 	lea    0x99cd0(%rip),%rsi        # 100150 <_fini+0x1bf98>
   66480:	e8 ab aa fa ff       	call   10f30 <class_protect_sprintf@plt>
   66485:	4c 89 e1             	mov    %r12,%rcx
   66488:	48 89 ef             	mov    %rbp,%rdi
   6648b:	31 c0                	xor    %eax,%eax
   6648d:	48 8d 15 fc 9c 09 00 	lea    0x99cfc(%rip),%rdx        # 100190 <_fini+0x1bfd8>
   66494:	48 8d 35 96 eb 07 00 	lea    0x7eb96(%rip),%rsi        # e5031 <_fini+0xe79>
   6649b:	e8 90 aa fa ff       	call   10f30 <class_protect_sprintf@plt>
   664a0:	49 89 e8             	mov    %rbp,%r8
   664a3:	b9 08 09 00 00       	mov    $0x908,%ecx
   664a8:	31 c0                	xor    %eax,%eax
   664aa:	48 8d bb ec 0b 00 00 	lea    0xbec(%rbx),%rdi
   664b1:	48 8d 15 48 5b 0b 00 	lea    0xb5b48(%rip),%rdx        # 11c000 <__func__.3>
   664b8:	48 8d 35 4e eb 07 00 	lea    0x7eb4e(%rip),%rsi        # e500d <_fini+0xe55>
   664bf:	e8 6c aa fa ff       	call   10f30 <class_protect_sprintf@plt>
   664c4:	e9 95 fd ff ff       	jmp    6625e <background_initial_conditions+0x5be>
   664c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   664d0:	4c 8d 64 24 70       	lea    0x70(%rsp),%r12
   664d5:	48 8d ac 24 70 08 00 	lea    0x870(%rsp),%rbp
   664dc:	00 
   664dd:	b8 01 00 00 00       	mov    $0x1,%eax
   664e2:	4c 89 e7             	mov    %r12,%rdi
   664e5:	48 8d 35 2c 9e 09 00 	lea    0x99e2c(%rip),%rsi        # 100318 <_fini+0x1c160>
   664ec:	e8 3f aa fa ff       	call   10f30 <class_protect_sprintf@plt>
   664f1:	4c 89 e1             	mov    %r12,%rcx
   664f4:	48 89 ef             	mov    %rbp,%rdi
   664f7:	31 c0                	xor    %eax,%eax
   664f9:	48 8d 15 40 9e 09 00 	lea    0x99e40(%rip),%rdx        # 100340 <_fini+0x1c188>
   66500:	48 8d 35 2a eb 07 00 	lea    0x7eb2a(%rip),%rsi        # e5031 <_fini+0xe79>
   66507:	e8 24 aa fa ff       	call   10f30 <class_protect_sprintf@plt>
   6650c:	49 89 e8             	mov    %rbp,%r8
   6650f:	b9 20 09 00 00       	mov    $0x920,%ecx
   66514:	31 c0                	xor    %eax,%eax
   66516:	48 8d bb ec 0b 00 00 	lea    0xbec(%rbx),%rdi
   6651d:	48 8d 15 dc 5a 0b 00 	lea    0xb5adc(%rip),%rdx        # 11c000 <__func__.3>
   66524:	48 8d 35 e2 ea 07 00 	lea    0x7eae2(%rip),%rsi        # e500d <_fini+0xe55>
   6652b:	e8 00 aa fa ff       	call   10f30 <class_protect_sprintf@plt>
   66530:	e9 29 fd ff ff       	jmp    6625e <background_initial_conditions+0x5be>
   66535:	0f 1f 00             	nopl   (%rax)
   66538:	48 81 c3 ec 0b 00 00 	add    $0xbec,%rbx
   6653f:	48 8d 15 c2 9c 09 00 	lea    0x99cc2(%rip),%rdx        # 100208 <_fini+0x1c050>
   66546:	48 8d 35 25 ec 07 00 	lea    0x7ec25(%rip),%rsi        # e5172 <_fini+0xfba>
   6654d:	31 c0                	xor    %eax,%eax
   6654f:	48 8d ac 24 70 08 00 	lea    0x870(%rsp),%rbp
   66556:	00 
   66557:	48 89 d9             	mov    %rbx,%rcx
   6655a:	48 89 ef             	mov    %rbp,%rdi
   6655d:	e8 ce a9 fa ff       	call   10f30 <class_protect_sprintf@plt>
   66562:	49 89 e8             	mov    %rbp,%r8
   66565:	b9 11 09 00 00       	mov    $0x911,%ecx
   6656a:	e9 d7 fc ff ff       	jmp    66246 <background_initial_conditions+0x5a6>
   6656f:	90                   	nop
   66570:	f2 0f 10 05 e0 37 0b 	movsd  0xb37e0(%rip),%xmm0        # 119d58 <__func__.3+0x358>
   66577:	00 
   66578:	66 0f 28 d9          	movapd %xmm1,%xmm3
   6657c:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
   66582:	f2 0f 59 d9          	mulsd  %xmm1,%xmm3
   66586:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
   6658a:	f2 0f 59 1d 9e 34 0b 	mulsd  0xb349e(%rip),%xmm3        # 119a30 <__func__.3+0x30>
   66591:	00 
   66592:	f2 0f 5c 1d 16 3f 0b 	subsd  0xb3f16(%rip),%xmm3        # 11a4b0 <__func__.3+0xab0>
   66599:	00 
   6659a:	f2 0f 5e c3          	divsd  %xmm3,%xmm0
   6659e:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
   665a3:	e8 58 96 fa ff       	call   fc00 <log@plt>
   665a8:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
   665ad:	48 63 83 64 03 00 00 	movslq 0x364(%rbx),%rax
   665b4:	66 0f 28 d0          	movapd %xmm0,%xmm2
   665b8:	66 0f ef c0          	pxor   %xmm0,%xmm0
   665bc:	f2 0f 10 a3 68 01 00 	movsd  0x168(%rbx),%xmm4
   665c3:	00 
   665c4:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
   665ca:	66 0f 2f c3          	comisd %xmm3,%xmm0
   665ce:	49 8d 04 c4          	lea    (%r12,%rax,8),%rax
   665d2:	77 6f                	ja     66643 <background_initial_conditions+0x9a3>
   665d4:	f2 0f 10 05 bc 35 0b 	movsd  0xb35bc(%rip),%xmm0        # 119b98 <__func__.3+0x198>
   665db:	00 
   665dc:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
   665e0:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
   665e4:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   665e8:	f2 0f 11 00          	movsd  %xmm0,(%rax)
   665ec:	f2 0f 10 74 24 18    	movsd  0x18(%rsp),%xmm6
   665f2:	48 89 df             	mov    %rbx,%rdi
   665f5:	66 0f 28 fe          	movapd %xmm6,%xmm7
   665f9:	f2 0f 58 fe          	addsd  %xmm6,%xmm7
   665fd:	f2 0f 11 3c 24       	movsd  %xmm7,(%rsp)
   66602:	e8 09 95 fa ff       	call   fb10 <V_scf@plt>
   66607:	66 0f ef c9          	pxor   %xmm1,%xmm1
   6660b:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
   6660f:	0f 87 0b 01 00 00    	ja     66720 <background_initial_conditions+0xa80>
   66615:	f2 0f 51 c0          	sqrtsd %xmm0,%xmm0
   66619:	f2 0f 59 04 24       	mulsd  (%rsp),%xmm0
   6661e:	48 63 83 68 03 00 00 	movslq 0x368(%rbx),%rax
   66625:	f2 0f 59 83 70 01 00 	mulsd  0x170(%rbx),%xmm0
   6662c:	00 
   6662d:	f2 41 0f 11 04 c4    	movsd  %xmm0,(%r12,%rax,8)
   66633:	48 63 83 64 03 00 00 	movslq 0x364(%rbx),%rax
   6663a:	49 8d 04 c4          	lea    (%r12,%rax,8),%rax
   6663e:	e9 af f7 ff ff       	jmp    65df2 <background_initial_conditions+0x152>
   66643:	f2 0f 10 05 0d 35 0b 	movsd  0xb350d(%rip),%xmm0        # 119b58 <__func__.3+0x158>
   6664a:	00 
   6664b:	66 83 bb ea 0b 00 00 	cmpw   $0x0,0xbea(%rbx)
   66652:	00 
   66653:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
   66657:	f2 0f 11 00          	movsd  %xmm0,(%rax)
   6665b:	7e 8f                	jle    665ec <background_initial_conditions+0x94c>
   6665d:	66 0f 28 c1          	movapd %xmm1,%xmm0
   66661:	bf 02 00 00 00       	mov    $0x2,%edi
   66666:	b8 01 00 00 00       	mov    $0x1,%eax
   6666b:	48 8d 35 b6 9a 09 00 	lea    0x99ab6(%rip),%rsi        # 100128 <_fini+0x1bf70>
   66672:	e8 89 8f fa ff       	call   f600 <__printf_chk@plt>
   66677:	48 63 83 64 03 00 00 	movslq 0x364(%rbx),%rax
   6667e:	f2 41 0f 10 04 c4    	movsd  (%r12,%rax,8),%xmm0
   66684:	e9 63 ff ff ff       	jmp    665ec <background_initial_conditions+0x94c>
   66689:	48 89 dd             	mov    %rbx,%rbp
   6668c:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   66693:	00 
   66694:	4c 89 eb             	mov    %r13,%rbx
   66697:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
   6669c:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
   666a1:	4c 8b 74 24 38       	mov    0x38(%rsp),%r14
   666a6:	e9 58 f6 ff ff       	jmp    65d03 <background_initial_conditions+0x63>
   666ab:	48 81 c3 ec 0b 00 00 	add    $0xbec,%rbx
   666b2:	48 8d 15 2f 9a 09 00 	lea    0x99a2f(%rip),%rdx        # 1000e8 <_fini+0x1bf30>
   666b9:	48 8d 35 b2 ea 07 00 	lea    0x7eab2(%rip),%rsi        # e5172 <_fini+0xfba>
   666c0:	31 c0                	xor    %eax,%eax
   666c2:	48 8d ac 24 70 08 00 	lea    0x870(%rsp),%rbp
   666c9:	00 
   666ca:	48 89 d9             	mov    %rbx,%rcx
   666cd:	48 89 ef             	mov    %rbp,%rdi
   666d0:	e8 5b a8 fa ff       	call   10f30 <class_protect_sprintf@plt>
   666d5:	49 89 e8             	mov    %rbp,%r8
   666d8:	b9 df 08 00 00       	mov    $0x8df,%ecx
   666dd:	e9 64 fb ff ff       	jmp    66246 <background_initial_conditions+0x5a6>
   666e2:	48 89 dd             	mov    %rbx,%rbp
   666e5:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
   666ea:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
   666ef:	4c 89 fb             	mov    %r15,%rbx
   666f2:	4c 8b 74 24 38       	mov    0x38(%rsp),%r14
   666f7:	e9 07 f6 ff ff       	jmp    65d03 <background_initial_conditions+0x63>
   666fc:	e8 4f 9f fa ff       	call   10650 <__stack_chk_fail@plt>
   66701:	66 0f 28 c3          	movapd %xmm3,%xmm0
   66705:	f2 0f 11 54 24 10    	movsd  %xmm2,0x10(%rsp)
   6670b:	e8 b0 a7 fa ff       	call   10ec0 <sqrt@plt>
   66710:	f2 0f 10 54 24 10    	movsd  0x10(%rsp),%xmm2
   66716:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
   6671b:	e9 32 f9 ff ff       	jmp    66052 <background_initial_conditions+0x3b2>
   66720:	e8 9b a7 fa ff       	call   10ec0 <sqrt@plt>
   66725:	e9 ef fe ff ff       	jmp    66619 <background_initial_conditions+0x979>

Disassembly of section .fini:
