
libq052_class_v36.so:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000067a50 <background_derivs>:
   67a50:	f3 0f 1e fa          	endbr64
   67a54:	41 57                	push   %r15
   67a56:	41 56                	push   %r14
   67a58:	41 55                	push   %r13
   67a5a:	41 54                	push   %r12
   67a5c:	55                   	push   %rbp
   67a5d:	53                   	push   %rbx
   67a5e:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
   67a65:	48 83 0c 24 00       	orq    $0x0,(%rsp)
   67a6a:	48 83 ec 38          	sub    $0x38,%rsp
   67a6e:	48 8b 1a             	mov    (%rdx),%rbx
   67a71:	4c 8b 72 08          	mov    0x8(%rdx),%r14
   67a75:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
   67a7c:	00 00 
   67a7e:	48 89 84 24 28 10 00 	mov    %rax,0x1028(%rsp)
   67a85:	00 
   67a86:	31 c0                	xor    %eax,%eax
   67a88:	49 89 fc             	mov    %rdi,%r12
   67a8b:	48 89 f5             	mov    %rsi,%rbp
   67a8e:	49 89 cd             	mov    %rcx,%r13
   67a91:	e8 ba 79 fa ff       	call   f450 <exp@plt>
   67a96:	4c 89 f1             	mov    %r14,%rcx
   67a99:	ba 01 00 00 00       	mov    $0x1,%edx
   67a9e:	4c 89 e6             	mov    %r12,%rsi
   67aa1:	48 89 df             	mov    %rbx,%rdi
   67aa4:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
   67aaa:	e8 b1 92 fa ff       	call   10d60 <background_functions@plt>
   67aaf:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
   67ab5:	83 f8 01             	cmp    $0x1,%eax
   67ab8:	0f 84 ba 03 00 00    	je     67e78 <background_derivs+0x428>
   67abe:	f2 0f 10 25 92 20 0b 	movsd  0xb2092(%rip),%xmm4        # 119b58 <__func__.3+0x158>
   67ac5:	00 
   67ac6:	48 63 83 6c 02 00 00 	movslq 0x26c(%rbx),%rax
   67acd:	66 0f ef f6          	pxor   %xmm6,%xmm6
   67ad1:	66 0f 28 d4          	movapd %xmm4,%xmm2
   67ad5:	f2 41 0f 10 2c c6    	movsd  (%r14,%rax,8),%xmm5
   67adb:	66 0f 28 c4          	movapd %xmm4,%xmm0
   67adf:	48 63 83 6c 03 00 00 	movslq 0x36c(%rbx),%rax
   67ae6:	f2 0f 5e d3          	divsd  %xmm3,%xmm2
   67aea:	f2 0f 5e c5          	divsd  %xmm5,%xmm0
   67aee:	f2 0f 5e d5          	divsd  %xmm5,%xmm2
   67af2:	f2 0f 11 44 c5 00    	movsd  %xmm0,0x0(%rbp,%rax,8)
   67af8:	48 63 83 74 03 00 00 	movslq 0x374(%rbx),%rax
   67aff:	f2 0f 11 54 c5 00    	movsd  %xmm2,0x0(%rbp,%rax,8)
   67b05:	48 63 83 74 02 00 00 	movslq 0x274(%rbx),%rax
   67b0c:	f2 41 0f 10 0c c6    	movsd  (%r14,%rax,8),%xmm1
   67b12:	66 0f 2f f1          	comisd %xmm1,%xmm6
   67b16:	0f 83 64 02 00 00    	jae    67d80 <background_derivs+0x330>
   67b1c:	48 63 83 78 02 00 00 	movslq 0x278(%rbx),%rax
   67b23:	f2 0f 10 3d 05 1f 0b 	movsd  0xb1f05(%rip),%xmm7        # 119a30 <__func__.3+0x30>
   67b2a:	00 
   67b2b:	4d 8d 2c c6          	lea    (%r14,%rax,8),%r13
   67b2f:	f2 41 0f 10 45 00    	movsd  0x0(%r13),%xmm0
   67b35:	f2 0f 59 c7          	mulsd  %xmm7,%xmm0
   67b39:	f2 0f 59 05 0f 20 0b 	mulsd  0xb200f(%rip),%xmm0        # 119b50 <__func__.3+0x150>
   67b40:	00 
   67b41:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
   67b45:	f2 0f 58 c4          	addsd  %xmm4,%xmm0
   67b49:	f2 0f 59 c7          	mulsd  %xmm7,%xmm0
   67b4d:	66 0f 2e f0          	ucomisd %xmm0,%xmm6
   67b51:	0f 87 90 03 00 00    	ja     67ee7 <background_derivs+0x497>
   67b57:	f2 0f 51 c0          	sqrtsd %xmm0,%xmm0
   67b5b:	4c 63 bb 70 03 00 00 	movslq 0x370(%rbx),%r15
   67b62:	f2 0f 5e d0          	divsd  %xmm0,%xmm2
   67b66:	f2 0f 10 8b f0 01 00 	movsd  0x1f0(%rbx),%xmm1
   67b6d:	00 
   67b6e:	f2 43 0f 10 04 fc    	movsd  (%r12,%r15,8),%xmm0
   67b74:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   67b78:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   67b7c:	66 0f 28 c4          	movapd %xmm4,%xmm0
   67b80:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
   67b84:	66 0f ef c9          	pxor   %xmm1,%xmm1
   67b88:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
   67b8c:	0f 87 1f 03 00 00    	ja     67eb1 <background_derivs+0x461>
   67b92:	f2 0f 51 c0          	sqrtsd %xmm0,%xmm0
   67b96:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   67b9a:	66 83 bb 88 03 00 00 	cmpw   $0x1,0x388(%rbx)
   67ba1:	01 
   67ba2:	f2 42 0f 11 54 fd 00 	movsd  %xmm2,0x0(%rbp,%r15,8)
   67ba9:	f2 41 0f 10 55 00    	movsd  0x0(%r13),%xmm2
   67baf:	0f 84 ab 01 00 00    	je     67d60 <background_derivs+0x310>
   67bb5:	66 83 bb 8a 03 00 00 	cmpw   $0x1,0x38a(%rbx)
   67bbc:	01 
   67bbd:	0f 84 85 01 00 00    	je     67d48 <background_derivs+0x2f8>
   67bc3:	48 63 83 7c 03 00 00 	movslq 0x37c(%rbx),%rax
   67bca:	f2 0f 10 0d 1e 21 0b 	movsd  0xb211e(%rip),%xmm1        # 119cf0 <__func__.3+0x2f0>
   67bd1:	00 
   67bd2:	48 63 8b 78 03 00 00 	movslq 0x378(%rbx),%rcx
   67bd9:	66 83 bb 8c 03 00 00 	cmpw   $0x1,0x38c(%rbx)
   67be0:	01 
   67be1:	49 8d 14 c4          	lea    (%r12,%rax,8),%rdx
   67be5:	f2 0f 59 cb          	mulsd  %xmm3,%xmm1
   67be9:	f2 0f 10 02          	movsd  (%rdx),%xmm0
   67bed:	f2 0f 5e c3          	divsd  %xmm3,%xmm0
   67bf1:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
   67bf5:	f2 0f 5e c5          	divsd  %xmm5,%xmm0
   67bf9:	f2 0f 11 44 cd 00    	movsd  %xmm0,0x0(%rbp,%rcx,8)
   67bff:	f2 41 0f 59 0c cc    	mulsd  (%r12,%rcx,8),%xmm1
   67c05:	f2 0f 5e cd          	divsd  %xmm5,%xmm1
   67c09:	f2 0f 5c 0a          	subsd  (%rdx),%xmm1
   67c0d:	f2 0f 11 4c c5 00    	movsd  %xmm1,0x0(%rbp,%rax,8)
   67c13:	0f 84 e7 00 00 00    	je     67d00 <background_derivs+0x2b0>
   67c19:	81 bb 8c 03 00 00 01 	cmpl   $0x10001,0x38c(%rbx)
   67c20:	00 01 00 
   67c23:	0f 84 87 00 00 00    	je     67cb0 <background_derivs+0x260>
   67c29:	66 83 bb 96 03 00 00 	cmpw   $0x1,0x396(%rbx)
   67c30:	01 
   67c31:	74 3d                	je     67c70 <background_derivs+0x220>
   67c33:	66 83 bb 90 03 00 00 	cmpw   $0x1,0x390(%rbx)
   67c3a:	01 
   67c3b:	0f 84 af 01 00 00    	je     67df0 <background_derivs+0x3a0>
   67c41:	31 c0                	xor    %eax,%eax
   67c43:	48 8b 94 24 28 10 00 	mov    0x1028(%rsp),%rdx
   67c4a:	00 
   67c4b:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
   67c52:	00 00 
   67c54:	0f 85 52 02 00 00    	jne    67eac <background_derivs+0x45c>
   67c5a:	48 81 c4 38 10 00 00 	add    $0x1038,%rsp
   67c61:	5b                   	pop    %rbx
   67c62:	5d                   	pop    %rbp
   67c63:	41 5c                	pop    %r12
   67c65:	41 5d                	pop    %r13
   67c67:	41 5e                	pop    %r14
   67c69:	41 5f                	pop    %r15
   67c6b:	c3                   	ret
   67c6c:	0f 1f 40 00          	nopl   0x0(%rax)
   67c70:	48 63 93 8c 02 00 00 	movslq 0x28c(%rbx),%rdx
   67c77:	48 63 83 60 03 00 00 	movslq 0x360(%rbx),%rax
   67c7e:	66 83 bb 90 03 00 00 	cmpw   $0x1,0x390(%rbx)
   67c85:	01 
   67c86:	f2 41 0f 58 24 d6    	addsd  (%r14,%rdx,8),%xmm4
   67c8c:	f2 0f 59 25 7c 21 0b 	mulsd  0xb217c(%rip),%xmm4        # 119e10 <__func__.3+0x410>
   67c93:	00 
   67c94:	f2 41 0f 59 24 c4    	mulsd  (%r12,%rax,8),%xmm4
   67c9a:	f2 0f 11 64 c5 00    	movsd  %xmm4,0x0(%rbp,%rax,8)
   67ca0:	75 9f                	jne    67c41 <background_derivs+0x1f1>
   67ca2:	e9 49 01 00 00       	jmp    67df0 <background_derivs+0x3a0>
   67ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   67cae:	00 00 
   67cb0:	f2 0f 10 43 70       	movsd  0x70(%rbx),%xmm0
   67cb5:	48 63 83 5c 03 00 00 	movslq 0x35c(%rbx),%rax
   67cbc:	48 63 93 58 03 00 00 	movslq 0x358(%rbx),%rdx
   67cc3:	f2 0f 10 0d 15 21 0b 	movsd  0xb2115(%rip),%xmm1        # 119de0 <__func__.3+0x3e0>
   67cca:	00 
   67ccb:	f2 0f 5e c5          	divsd  %xmm5,%xmm0
   67ccf:	66 83 bb 96 03 00 00 	cmpw   $0x1,0x396(%rbx)
   67cd6:	01 
   67cd7:	f2 41 0f 59 0c c4    	mulsd  (%r12,%rax,8),%xmm1
   67cdd:	f2 41 0f 59 04 d4    	mulsd  (%r12,%rdx,8),%xmm0
   67ce3:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   67ce7:	f2 0f 11 44 c5 00    	movsd  %xmm0,0x0(%rbp,%rax,8)
   67ced:	0f 85 40 ff ff ff    	jne    67c33 <background_derivs+0x1e3>
   67cf3:	e9 78 ff ff ff       	jmp    67c70 <background_derivs+0x220>
   67cf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   67cff:	00 
   67d00:	f2 0f 10 43 70       	movsd  0x70(%rbx),%xmm0
   67d05:	48 63 83 58 03 00 00 	movslq 0x358(%rbx),%rax
   67d0c:	f2 0f 10 0d fc 20 0b 	movsd  0xb20fc(%rip),%xmm1        # 119e10 <__func__.3+0x410>
   67d13:	00 
   67d14:	f2 0f 5e c5          	divsd  %xmm5,%xmm0
   67d18:	f2 41 0f 10 14 c4    	movsd  (%r12,%rax,8),%xmm2
   67d1e:	f2 0f 59 ca          	mulsd  %xmm2,%xmm1
   67d22:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
   67d26:	f2 0f 5c c8          	subsd  %xmm0,%xmm1
   67d2a:	f2 0f 11 4c c5 00    	movsd  %xmm1,0x0(%rbp,%rax,8)
   67d30:	81 bb 8c 03 00 00 01 	cmpl   $0x10001,0x38c(%rbx)
   67d37:	00 01 00 
   67d3a:	0f 85 e9 fe ff ff    	jne    67c29 <background_derivs+0x1d9>
   67d40:	e9 6b ff ff ff       	jmp    67cb0 <background_derivs+0x260>
   67d45:	0f 1f 00             	nopl   (%rax)
   67d48:	48 63 83 80 02 00 00 	movslq 0x280(%rbx),%rax
   67d4f:	f2 41 0f 58 14 c6    	addsd  (%r14,%rax,8),%xmm2
   67d55:	e9 69 fe ff ff       	jmp    67bc3 <background_derivs+0x173>
   67d5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   67d60:	48 63 83 7c 02 00 00 	movslq 0x27c(%rbx),%rax
   67d67:	66 83 bb 8a 03 00 00 	cmpw   $0x1,0x38a(%rbx)
   67d6e:	01 
   67d6f:	f2 41 0f 58 14 c6    	addsd  (%r14,%rax,8),%xmm2
   67d75:	0f 85 48 fe ff ff    	jne    67bc3 <background_derivs+0x173>
   67d7b:	eb cb                	jmp    67d48 <background_derivs+0x2f8>
   67d7d:	0f 1f 00             	nopl   (%rax)
   67d80:	48 8d 6c 24 20       	lea    0x20(%rsp),%rbp
   67d85:	66 0f 28 c1          	movapd %xmm1,%xmm0
   67d89:	48 8d 35 f0 8b 09 00 	lea    0x98bf0(%rip),%rsi        # 100980 <_fini+0x1c7c8>
   67d90:	b8 01 00 00 00       	mov    $0x1,%eax
   67d95:	48 89 ef             	mov    %rbp,%rdi
   67d98:	48 8d 9c 24 20 08 00 	lea    0x820(%rsp),%rbx
   67d9f:	00 
   67da0:	e8 8b 91 fa ff       	call   10f30 <class_protect_sprintf@plt>
   67da5:	48 89 e9             	mov    %rbp,%rcx
   67da8:	48 89 df             	mov    %rbx,%rdi
   67dab:	31 c0                	xor    %eax,%eax
   67dad:	48 8d 15 f4 8b 09 00 	lea    0x98bf4(%rip),%rdx        # 1009a8 <_fini+0x1c7f0>
   67db4:	48 8d 35 76 d2 07 00 	lea    0x7d276(%rip),%rsi        # e5031 <_fini+0xe79>
   67dbb:	e8 70 91 fa ff       	call   10f30 <class_protect_sprintf@plt>
   67dc0:	49 89 d8             	mov    %rbx,%r8
   67dc3:	b9 a2 0a 00 00       	mov    $0xaa2,%ecx
   67dc8:	31 c0                	xor    %eax,%eax
   67dca:	48 8d 15 ef 41 0b 00 	lea    0xb41ef(%rip),%rdx        # 11bfc0 <__func__.1>
   67dd1:	48 8d 35 35 d2 07 00 	lea    0x7d235(%rip),%rsi        # e500d <_fini+0xe55>
   67dd8:	4c 89 ef             	mov    %r13,%rdi
   67ddb:	e8 50 91 fa ff       	call   10f30 <class_protect_sprintf@plt>
   67de0:	b8 01 00 00 00       	mov    $0x1,%eax
   67de5:	e9 59 fe ff ff       	jmp    67c43 <background_derivs+0x1f3>
   67dea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   67df0:	48 63 83 68 03 00 00 	movslq 0x368(%rbx),%rax
   67df7:	48 89 df             	mov    %rbx,%rdi
   67dfa:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
   67e00:	f2 0f 11 6c 24 08    	movsd  %xmm5,0x8(%rsp)
   67e06:	49 8d 14 c4          	lea    (%r12,%rax,8),%rdx
   67e0a:	48 63 83 64 03 00 00 	movslq 0x364(%rbx),%rax
   67e11:	f2 0f 10 02          	movsd  (%rdx),%xmm0
   67e15:	f2 0f 5e c3          	divsd  %xmm3,%xmm0
   67e19:	f2 0f 5e c5          	divsd  %xmm5,%xmm0
   67e1d:	f2 0f 11 44 c5 00    	movsd  %xmm0,0x0(%rbp,%rax,8)
   67e23:	f2 0f 10 05 a5 1f 0b 	movsd  0xb1fa5(%rip),%xmm0        # 119dd0 <__func__.3+0x3d0>
   67e2a:	00 
   67e2b:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
   67e2f:	66 49 0f 7e c5       	movq   %xmm0,%r13
   67e34:	f2 41 0f 10 04 c4    	movsd  (%r12,%rax,8),%xmm0
   67e3a:	e8 51 81 fa ff       	call   ff90 <dV_scf@plt>
   67e3f:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
   67e45:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
   67e4b:	48 63 83 68 03 00 00 	movslq 0x368(%rbx),%rax
   67e52:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
   67e56:	66 0f 28 c8          	movapd %xmm0,%xmm1
   67e5a:	66 49 0f 6e c5       	movq   %r13,%xmm0
   67e5f:	f2 0f 5e cd          	divsd  %xmm5,%xmm1
   67e63:	f2 0f 5c c1          	subsd  %xmm1,%xmm0
   67e67:	f2 0f 11 44 c5 00    	movsd  %xmm0,0x0(%rbp,%rax,8)
   67e6d:	e9 cf fd ff ff       	jmp    67c41 <background_derivs+0x1f1>
   67e72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   67e78:	48 8d 8b ec 0b 00 00 	lea    0xbec(%rbx),%rcx
   67e7f:	48 8d 15 c2 8a 09 00 	lea    0x98ac2(%rip),%rdx        # 100948 <_fini+0x1c790>
   67e86:	31 c0                	xor    %eax,%eax
   67e88:	48 8d ac 24 20 08 00 	lea    0x820(%rsp),%rbp
   67e8f:	00 
   67e90:	48 8d 35 db d2 07 00 	lea    0x7d2db(%rip),%rsi        # e5172 <_fini+0xfba>
   67e97:	48 89 ef             	mov    %rbp,%rdi
   67e9a:	e8 91 90 fa ff       	call   10f30 <class_protect_sprintf@plt>
   67e9f:	49 89 e8             	mov    %rbp,%r8
   67ea2:	b9 95 0a 00 00       	mov    $0xa95,%ecx
   67ea7:	e9 1c ff ff ff       	jmp    67dc8 <background_derivs+0x378>
   67eac:	e8 9f 87 fa ff       	call   10650 <__stack_chk_fail@plt>
   67eb1:	f2 0f 11 6c 24 18    	movsd  %xmm5,0x18(%rsp)
   67eb7:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
   67ebd:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
   67ec3:	e8 f8 8f fa ff       	call   10ec0 <sqrt@plt>
   67ec8:	f2 0f 10 25 88 1c 0b 	movsd  0xb1c88(%rip),%xmm4        # 119b58 <__func__.3+0x158>
   67ecf:	00 
   67ed0:	f2 0f 10 6c 24 18    	movsd  0x18(%rsp),%xmm5
   67ed6:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
   67edc:	f2 0f 10 54 24 08    	movsd  0x8(%rsp),%xmm2
   67ee2:	e9 af fc ff ff       	jmp    67b96 <background_derivs+0x146>
   67ee7:	f2 0f 11 6c 24 18    	movsd  %xmm5,0x18(%rsp)
   67eed:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
   67ef3:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
   67ef9:	e8 c2 8f fa ff       	call   10ec0 <sqrt@plt>
   67efe:	f2 0f 10 25 52 1c 0b 	movsd  0xb1c52(%rip),%xmm4        # 119b58 <__func__.3+0x158>
   67f05:	00 
   67f06:	f2 0f 10 6c 24 18    	movsd  0x18(%rsp),%xmm5
   67f0c:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
   67f12:	f2 0f 10 54 24 08    	movsd  0x8(%rsp),%xmm2
   67f18:	e9 3e fc ff ff       	jmp    67b5b <background_derivs+0x10b>

Disassembly of section .fini:
