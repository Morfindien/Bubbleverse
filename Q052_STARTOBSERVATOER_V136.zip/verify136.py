"""Check the archive, historical receipt and prospective readback with fixtures."""
from pathlib import Path
from zipfile import ZipFile
from tempfile import TemporaryDirectory
from hashlib import sha256
import ast,copy,json,re,subprocess,sys

sys.dont_write_bytecode=True
from readback import REF, check_pair
p=Path(__file__).resolve().parent
def sha(b):return sha256(b).hexdigest()
def obj(n):return json.loads((p/n).read_bytes())

def smoke():
    mode={'mxcsr':8064,'x87_control':895}
    start={'run_id':'SYNTHETIC-CHECK','arm':'L','caller':'main','pid':1,'ncdm_species':1,'integrator':1,'a_default':REF['a'],'tol_ncdm':float(.001).hex(),
       'initial':{'a_pre_log':REF['a'],'ncdm_counter':0,'ncdm_p_over_rho':float(1/3).hex(),'ncdm_attempts':[float(1/3).hex()],
                  'attractor':0,'f_scf':'0x1.419fbeb3d4926p+87','theta_i':float(2.95).hex(),'phi_ini':REF['phi'],
                  'phi_prime_ini':REF['phi_prime_eta'],'phi':REF['phi'],'phi_prime_eta':REF['phi_prime_eta'],'rounding':mode},
       'first_rhs':{'loga':'-0x1.01e3b843eaa73p+5','a_exp':'0x1.6849b86a12b93p-47','H':'0x1.2466e734a3ba4p+74',
                    'phi':REF['phi'],'phi_prime_eta':REF['phi_prime_eta'],'rounding':mode}}
    pair={'L':start,'R':{**start,'arm':'R','pid':2}}
    a=check_pair(pair)['arms']['L']
    assert a['rhs_a_residual']=='-1/79228162514264337593543950336' and a['rhs_X_residual']=='0'
    assert 0<=a['log_distance_in_ulp']<=1 and 0<=a['exp_distance_in_ulp']<=1
    for key,value in [('ncdm_counter',2),('phi_ini','0x1p+0'),('a_pre_log','0x1p-40')]:
        bad=copy.deepcopy(pair)
        bad['L']['initial'][key]=value
        try:check_pair(bad)
        except ValueError:pass
        else:raise AssertionError(key)

def verify():
    assert not sys.flags.optimize
    manifest=obj('manifest136.json')
    for n,meta in manifest['members'].items():
        b=(p/n).read_bytes()
        assert sha(b)==meta['sha256'] and len(b)==meta['bytes'],n
    for n in ('launch.py','observe.py','readback.py'):ast.parse((p/n).read_text())
    
    assert sha((p/"evidence"/"libq052_class_v36.so").read_bytes()) == "8b90e21505337cb6696c4f6460616c7c92482f6c8eba7f3450d7da5cb040fae3"
    for n,addresses in [('background_init',['677d8']),('background_initial_conditions',['66169','6616f','65f08']),
                        ('background_derivs',['67a50','67aaa','67abe'])]:
        asm=(p/'evidence'/f'{n}.asm').read_text()
        for addr in addresses:assert re.search(r'^\s*'+addr+':',asm,re.M)
    smoke()
    parent=p/'evidence/Q052_SKALARSTART_V135.zip'
    with TemporaryDirectory() as d, ZipFile(parent) as z:
        assert z.testzip() is None
        z.extractall(d)
        subprocess.run([sys.executable,str(Path(d)/'verify135.py')],check=True,capture_output=True)
        task=json.loads(z.read('Q052_RESULTATINDTAG_OPGAVE_V135.json'))
        for n,h in task['input_refs'].items():assert sha(z.read(n))==h
        old=json.loads(z.read('activity_ledger135.json'))
        prior=z.read(task['journal_ref'])
    assert prior+(p/'journal_append136.md').read_bytes()==(p/manifest['journal']).read_bytes()
    ledger=obj('activity_ledger136.json')
    assert ledger['entries'][:-1]==old['entries'] and ledger['delivered_milestone_ids']==old['delivered_milestone_ids']
    assert len(set(e['run_id'] for e in ledger['entries']))==len(ledger['entries'])
    t=obj('Q052_EXECUTION_OPGAVE_V136.json')
    fp=t.pop('fingerprint_sha256')
    assert sha(json.dumps(t,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==fp
    for n,h in t['input_refs'].items():assert sha((p/n).read_bytes())==h
    assert sum(e['run_points'] for e in ledger['entries'])==ledger['total_points_after']==t['total_points']
    print('PASS V136 archive and V135 replay, four probe sites, synthetic readback and rejection cases')

if __name__=='__main__':
    verify()
