# Q052 V83 · Det globale elektronmaksimum for det fastholdte kildepar

**BEREGNET / MODELINFERERET.** For det samme kilde-reelle startpar og den samme baggrund B★ som i V73–V82 gælder

\[
\max_{0\le z\le810}|X_{e,L}(z)-X_{e,R}(z)|=10^{-6}.
\]

Maksimum nås alene ved z = 810. For alle 0 ≤ z < 810 er forskellen i absolutværdi strengt mindre. Resultatet er betinget af de arvede kvalificerede kilde-, baggrunds- og startpræmisser. Det beskriver løsningerne af de fastholdte ligninger. Det er ikke en ny bestemmelse af maksimum for den gemte CLASS-kurve.

V83 lukker det tidligere åbne mellemstykke med 2.727 hele arkivceller. De eksakte ender er

\[
z_A=408663367683441/8796093022208,\qquad
z_B=787504997847845/140737488355328.
\]

| Interval | Bevisgrundlag |
| --- | --- |
| z_A ≤ z ≤ 810 | V75, V77 og V79, genbrugt. Lighed kun ved 810. |
| z_B ≤ z ≤ z_A | Nyt V83-bevis for streng grænse. |
| 0 ≤ z ≤ z_B | V79's arvede direkte loft 4667583517324017/4722366482869645213696 < 10⁻⁶, genbrugt. |

## Kilde, variable og præcis start

Kildecommit: `5a131c91d657dd9a7c6364cc45b038710f8d0d97`, case `hillipop-ede_n3`. Der bruges den samme B★, samme matchede termiske start ved 810 og q = 10⁻⁶ i L mod q = 0 i R. Eksotisk energiinjektion og variable fundamentalkonstanter er slået fra. V64's enkeltarmsbokse og koefficientgrænser er arvede præmisser, ikke nye simulationer. V81's forbedrede nedre h_R(50)-grænse er

\[
h_R(50)\ge4290379133454801/18446744073709551616.
\]

Brug u = ln[811/(1+z)], h = h_R, d = h_L−h, v = Tm/Tγ og

\[
E=d+q,\qquad y=\frac{(h+q)(v_L-v_R)}{qv_L},\qquad B=199/200.
\]

Området er −2q ≤ d ≤ 0 og |y| ≤ B. **Præcisering af V82-opgaven:** V77 giver |y| < 0,99 ved 50. V79's faktisk beviste forlængelse bruger B = 0,995. V83 fortsætter fra denne beviste grænse ved z_A; det antager ikke, at V79 allerede havde bevist 0,99 dér. Historiske filer ændres ikke. Elektronmålet |E| < q er det samme.

## En skarpere nedre hydrogengrænse uden nye baner

På højre arm er q = 0, og V64's K_j er et øvre loft for rekombinationstabet på hele den j'te arkivcelle og alle dens tilladte grene. Det ikke-negative fotoionisationsbidrag giver

\[
h'\ge-K_jh^2,\qquad (1/h)'\le K_j.
\]

Dermed har hele celle j nedre grænse

\[
h\ge\left[\frac1{h_{50,\mathrm{low}}}+\sum_{k\le j}K_{k,\mathrm{up}}\Delta u_{k,\mathrm{up}}\right]^{-1}.
\]

K og Δu er de allerede validerede V64-grænser. Sum og inversion foretages med eksakte brøker; højre endepunkt giver det svageste gulv i cellen. Vi tager også maksimum med den arvede h-grænse. Denne sammenligningsulighed bruger alle celler fra 50 for at bære V81-starten frem, men gentager ikke de tidligere parbeviser. Den kræver ingen ny løsning af ODE-systemet.

De nye helcellegulve for temperaturforholdet er V81/V82's b_i(1+z)/51 kombineret med de arvede V64-gulve, med b_L = 0,327901 og b_R = 0,327899. På alle kontrollerede celler gælder h > 2q, 0 < v_i ≤ 1. Den nye hydrogengrænse forbliver over 0,000128 på hele det nødvendige forløb. Den fjerner den utilstrækkeligt brede h-usikkerhed, som ellers ville gøre den simple temperaturfladekontrol uafgørende omkring z = 14,64.

## Bogstavelige grene og reionisation

Alle nye celler ligger under SWIFT-fittemperaturen. Før den fælles strålingstemperaturgrænse holder de nye v-gulve begge arme strengt over 0,1. HMLA er derfor fælles gren. Det meget smalle interval mellem de to eksakte strålingstærskelgrænser kontrolleres med både det fælles HMLA-felt og det fælles Peebles-felt. For enhver fast kildekonstant har armene samme strålingstemperatur, så overgangen er samtidig; uafhængige blandinger af de to grene er ikke tilladte felter dér. HMLA-polynomier kontrolleres kun på unionen af deres mulige aktive strålingstemperaturdomæner, inklusive den klampede randstencil.

Efter denne overgang er Peebles fælles gren, også når v senere kommer under 0,1. Reionisationens særskilte grænse er z = 753585/65536. V64's eksakte opdeling og endpoint-konvention bevares. Hydrogenfeltet bruger den interne fraktion X_L = h_L+q, X_R = h. Temperatur og offentlig elektronfraktion bruger

\[
M_z(X)=\lambda(z)X+b(z),\qquad 0\le\lambda\le1,\quad b\ge0.
\]

Før reionisationsgrænsen er kortet identiteten. På CAMB-grenen er både λ og b fælles; b er en sum af ikke-negative aktiveringsled. Den offentlige difference er ΔX_e = λE, også ved den særskilte endpoint-værdi. Kortets eventuelle skift ændrer ikke h, v eller y øjeblikkeligt. Begge ensidige temperaturfelter indgår i beviset.

## Ratekontrol og højre hydrogenfelt

Skriv S for Saha-leddet. På HMLA har hver kanal

\[
U_i=\alpha_i(v)hX-\alpha_i(1)S(1-h),\qquad
f=-(n_H/H_s)\sum_i C_iU_i.
\]

Peebles har samme form med én PPB-rate og én C-faktor, fudgefaktor 1. For alle aktive grene er C_i > 0 og C_i voksende med escape-raten og dermed med h. HMLA's C-monotonicitet er dokumenteret i V77. Peebles har C = (3R+Λ)/(3R+Λ+β), hvis afledte i R er ikke-negativ, og R er proportional med 1/(1−h).

De kubiske HMLA-tabeller giver −1 < ∂ln α_i/∂ln v < 0 på alle nødvendige strimler op til v = 1. Den separate kontrol giver en samlet indeslutning omtrent [−0,761738, −0,523020], afrundet udad. Den omfatter randekstrapolationen ved den laveste strålingstemperatur.

For PPB er α proportional med t^(−a)/(1+ct^b), t = Tm/10000 K, og

\[
\frac{\partial\ln\alpha}{\partial\ln v}=-a-\frac{bY}{1+Y},\qquad Y=ct^b.
\]

Her a = 0,6166, b = 0,5300 og c = 0,6703 med kildekonstanterne indhyllet. Da 0 < Tm ≤ Tγ < 10000 K, er 0 < Y < c, og en rent rationel kontrol giver a+bc/(1+c) < 1. Begge metoder beviser derfor den samme strenge hældningsbetingelse. S < h² er kontrolleret med udadrettede grænser på hele domænet. Følgelig er U_R,i > 0 og f_R < 0.

## De to hydrogengrænser

Sæt x = q/(h+q). Fra definitionen af y følger v_R/v_L = 1−xy. Integration af den verificerede loghældning giver for hver aktiv kanal

\[
1-Bx\le\alpha_L/\alpha_R\le1+Bx.
\]

Ved d = 0 er C_L = C_R. Fordi (h+q)(1−Bx) = h+(1−B)q > h, er d′ < 0. Mere præcist,

\[
\frac{d'}{|f_R|}\le-\frac{(1-B)q}{h}<0.
\]

Ved d = −2q er h_L = h−2q, X_L = h−q og C_L ≤ C_R. Uligheden (h−q)(1+Bx) < h samt det gunstige fotoionisationsled giver U_L < (1−2q/h)U_R. Hvis U_L er negativt, hjælper også dette indadrettet. Derfor

\[
\frac{d'}{|f_R|}\ge\frac{2q}{h}>0.
\]

Begge relationer gælder på hver fælles gren, inklusive begge mulige fælles felter i strålingstærsklens indhylling. De uniforme, eksakte numeriske marginer står i `face_bounds` i resultatfilen.

## De to temperaturgrænser, også under reionisation

Sæt a = 1+fHe og A(x)=k x/(a+x) med fælles k > 0. Differentiation af y med temperaturfeltet −v+A(M(X))(1−v) giver

\[
y'=\left[\frac{f_R}{h+q}-\frac{A(M(X_L))}{v_L}\right]y
+\frac{A(M(X_L))}{v_L}J,
\]

\[
J=\frac{(h+q)a\lambda(E/q)(1-v_R)}{M(X_L)[a+M(h)]}.
\]

På det foreslåede område er X_L ≥ h−q > 0, |E/q| ≤ 1, M(X_L) ≥ λ(h−q) og a/[a+M(h)] ≤ 1. Derfor

\[
|J|\le\frac{h+q}{h-q}(1-v_R)<0,973<B=0,995.
\]

Hvis λ = 0, er J = 0 direkte; de faktiske arkivgrænser har positive M. Uligheden holder også med reionisationens additive bidrag b. Den separate, grovere kontrol runder hvert led i reciprok-summen op til 12 decimaler og består stadig. Da f_R < 0, gælder på de to temperaturflader

\[
\frac{y'|_{y=B}}{A(M(X_L))/v_L}\le-(B-J_{\max})<0,\qquad
\frac{y'|_{y=-B}}{A(M(X_L))/v_L}\ge B-J_{\max}>0.
\]

Marginen er større end 0,022. Koden kontrollerer alle relevante helcellebokse, ikke kun et gitter af eksempeltilstande.

## Første kontakt, sammenføjning og globalt maksimum

Parret kommer strengt ind i området ved z_A fra det accepterede V79-bevis. Alle fire flader peger strengt indad for hvert tilladt ensidigt kildefelt. En første udgang ville kræve en kontakt med en af disse flader, hvilket modsiges ved integration i et indre nabointerval som i V77. Argumentet gælder ved cellegrænser, det fælles strålingstemperaturskift og reionisationsgrænsen, fordi tilstanden er kontinuert og alle relevante ensidige felter opfylder de samme uligheder.

Dermed er −q < E < q til og med z_B. Da 0 ≤ λ ≤ 1, er |ΔX_e| < q på hele det nye mellemstykke. Den uændrede V79-kontrol på [0,z_B] og V75/V77/V79-præfikset på [z_A,810] dækker sammen hele intervallet. Kun ved det matchede startpunkt 810 er ΔX_e = q. Det giver både det eksakte maksimum og det unikke maksimumsted.

## Validering, begrænsning og overdragelse

Primærkontrollen bruger MPFR-afrunding af de arvede logtabeller og delte Lagrange-afledte. Den anden kontrol omskriver polynomierne til eksakte rationelle Bernstein-net: 857 hele tabelstykker og 54.848 koefficientintervaller. Derudover bruger den en særskilt, grovere rationel hydrogengrænse og et analytisk PPB-loft. De to spor deler input, den arvede kilde-/banekvalifikation og de udadrettede logtabelværdier; de er ikke to uafhængige fysiske observationer eller to nye banesimulationer.

Det tidligere usikre globale maksimum for **kildeparrets elektronfraktion** er nu bestemt under disse præmisser. Q052 som helhed er stadig ACTIVE / INCONCLUSIVE: det realiserede globale Thomson-maksimum og den fulde native/kilde-fejlcertificering er ikke afgjort. V78's øvre Thomson-grænse 0,00092647 genberegnes ikke her. Resultatet afleveres til **Resultatindtag og routing 2.3.0**, som skal indtage den nye globale elektronkonklusion og afgrænse den resterende optiske/fejlmæssige opgave.
