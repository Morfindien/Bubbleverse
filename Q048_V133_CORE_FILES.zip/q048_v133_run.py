"""Frozen serial V133 runner: producer -> verifier -> acceptance/readback."""
from pathlib import Path
import json,hashlib,subprocess,sys,time,datetime
R=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def write_x(name,obj):
    with (R/name).open('x') as f: json.dump(obj,f,indent=2); f.write('\n')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main():
    freeze=read(R/'Q048_V133_FREEZE_V1.json')
    def unchanged(): return all(sha(R/k)==v for k,v in freeze['frozen_files'].items())
    rec={'schema':'bubbleverse.q048.v133.execution.v1','run_id':freeze['run_id'],'started_at_utc':now(),'status':'FAIL','retry_count':0,'postfreeze_edits':False,'historical_mains_executed':0,'native_integrations':0,'new_actual_cells':0,'new_proof_computations':1,'phases':[]}
    start=time.monotonic()
    try:
        if not unchanged(): raise ValueError('PREFREEZE_HASH')
        for phase,script in [('producer','q048_v133_proof.py'),('verifier','q048_v133_verify.py')]:
            t=time.monotonic(); cp=subprocess.run([sys.executable,str(R/script)],cwd=R,capture_output=True,text=True)
            rec['phases'].append({'phase':phase,'returncode':cp.returncode,'seconds':time.monotonic()-t,'stdout':cp.stdout,'stderr':cp.stderr})
            if cp.returncode: raise RuntimeError(phase.upper()+'_FAIL')
            if not unchanged(): raise ValueError('POST_PHASE_HASH:'+phase)
        raw=read(R/'Q048_V133_RAW_V1.json'); ver=read(R/'Q048_V133_VERIFICATION_V1.json'); task=read(R/'inputs/Q048_V133_NEXT_MATHEMATICS_TASK_870_860_V1.json'); parent=read(R/'inputs/Q048_V132_ACCEPTED_CHECKPOINT_V1.json')
        if raw['status']!='CANDIDATE_CONDITIONAL_CONNECTED_PROOF' or ver['status']!='PASS' or ver['checks_passed']!=ver['checks_total'] or ver['semantic_mutations_rejected']!=ver['semantic_mutations_total']: raise ValueError('VALIDATION_GATE')
        accept={'schema':'bubbleverse.q048.v133.acceptance.v1','status':'ACCEPTED_CONDITIONAL_SOURCE_REAL_CONNECTED_PROOF','accepted_at_utc':now(),'q':'Q048','target_q':'Q048','task_id':task['task_id'],'task_fingerprint':task['task_fingerprint'],'cell_z':[870,860],
          'raw_sha256':sha(R/'Q048_V133_RAW_V1.json'),'verification_sha256':sha(R/'Q048_V133_VERIFICATION_V1.json'),'freeze_sha256':sha(R/'Q048_V133_FREEZE_V1.json'),'spec_sha256':sha(R/'Q048_V133_SPEC_V1.json'),
          'K_upper':raw['comparison']['K_upper'],'connected_lower':raw['comparison']['h_connected_lower'],'h_upper':'99999/100000','thermal_domain':['-1/1000000','1/50'],'operators':['HMLA','SWIFT'],'q_branches':{'L':'1/1000000','R':'0'},
          'continuation':raw['continuation'],'guard_primary_sha256':raw['guard_primary_sha256'],'guard_control_sha256':raw['guard_control_sha256'],'guard_endpoint_crosscheck_only':task['guard']['expected_primary_endpoint_crosscheck_only'],
          'new_mathematical_proof_cells':1,'new_actual_cells':0,'actual_unchanged':parent['actual'],'frontiers_unchanged':parent['frontiers'],'consumer_authorization':'NOT_GRANTED_BY_MATHEMATICS','NativeP6':'UNRESOLVED','q_complete':False,'native_error_certificate':False,'exact_selector_existence_uniqueness':False,'trajectory_identity_claim':False,'return_route':'BUBBLEVERSE.RESULT_INGESTION_ROUTING2.1.0'}
        write_x('Q048_V133_ACCEPTANCE_V1.json',accept)
        if read(R/'Q048_V133_ACCEPTANCE_V1.json')!=accept: raise ValueError('ACCEPTANCE_READBACK')
        if not unchanged(): raise ValueError('POST_ACCEPT_HASH')
        rec['status']='PASS'
    except Exception as e: rec['error']=type(e).__name__+':'+str(e)
    finally:
        rec['finished_at_utc']=now(); rec['science_seconds']=time.monotonic()-start; rec['frozen_pins_unchanged']=unchanged(); write_x('Q048_V133_EXECUTION_V1.json',rec)
    print(json.dumps({'status':rec['status'],'science_seconds':rec['science_seconds'],'phases':[(x['phase'],x['returncode']) for x in rec['phases']]}))
    return 0 if rec['status']=='PASS' else 1
if __name__=='__main__': raise SystemExit(main())
