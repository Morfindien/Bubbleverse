from datetime import datetime, timezone
from fractions import Fraction as F
from hashlib import sha256, sha1
from math import isqrt
from pathlib import Path
import json, re, zipfile

root = Path.cwd()
work = root / 'work/intake100'
upload = root / 'upload'
source = 'Q052_OPTISK_VAEGTCERTIFIKAT_V99.zip'
parent_name = 'Q052_MATEMATIK_OG_SAMLET_JOURNAL_V99.md'
short99 = 'Q052_KORT_RESULTAT_V99.md'
journal = 'Q052_INGESTION_OG_SAMLET_JOURNAL_V100.md'
brief = 'Q052_KORT_RESULTAT_V100.md'
taskname = 'Q052_MATEMATIKOPGAVE_V100.json'
bundle = 'Q052_INGESTION_CERTIFICATE_V100.zip'
names = [brief, taskname, journal, bundle]
def digest(data):
    return sha256(data).hexdigest()
def encoded(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode()
def read(path):
    return json.loads(path.read_bytes())
def fingerprint(obj):
    return digest(encoded({k:v for k,v in obj.items() if k != 'fingerprint_sha256'}))

tree = read(work/'tree.json')
head = read(work/'head.json')
assert not tree['truncated'] and tree['sha'] == head['commit']['tree']['sha']
paths = {x['path']: x['sha'] for x in tree['tree']}
assert not set(names).intersection(paths)
root_hashes = {}
for name in [source, parent_name, short99]:
    data = (upload/name).read_bytes()
    blob = sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
    assert paths[name] == blob
    root_hashes[name] = digest(data)
parent = (upload/parent_name).read_bytes()
with zipfile.ZipFile(upload/source) as archive:
    def item(name):
        return json.loads(archive.read(name))
    manifest = item('manifest.json')
    assert set(archive.namelist()) == {'manifest.json', *manifest['members_sha256']}
    for n, h in manifest['members_sha256'].items():
        assert digest(archive.read(n)) == h, n
    for n, info in manifest['root_outputs_excluding_this_zip'].items():
        assert info['sha256'] == root_hashes[n]
    task99, handoff99, ledger, result, old, guard = map(item, [
        'Q052_RESULTATINDTAG_OPGAVE_V99.json','handoff99.json','activity_ledger.json',
        'result99.json','task98.json','guard.json'])
    for n,h in task99['inputs'].items():
        assert digest(archive.read(n)) == h
    for n,h in item('pins.json').items():
        assert digest(archive.read(n)) == h
    math_hash = digest(archive.read('ENGINE_MATHEMATICS_2.3.0.md'))
    assert math_hash == old['engine_prompt_sha256']
    assert sha1(f"blob {len(archive.read('ENGINE_MATHEMATICS_2.3.0.md'))}\0".encode() + archive.read('ENGINE_MATHEMATICS_2.3.0.md')).hexdigest() == paths['Bubbleverse_Matematikmotor_2.3.0.md']
    assert archive.testzip() is None

blocks = re.findall(rb'```json\s*\n(.*?)\n```',parent,re.S)
assert json.loads(blocks[-2]) == handoff99 and json.loads(blocks[-1]) == ledger
assert fingerprint(task99) == handoff99['next_task_fingerprint'] == task99['fingerprint_sha256']
assert fingerprint(old) == result['task_fingerprint']
for key in ('case_id','exact_question','source_commit','current_q','target_q'):
    assert task99[key] == handoff99[key] == old[key]
assert task99['target_q'] == 'Q052'
assert result['technical_state'] == 'PASS' and not result['target_met']
assert read(work/'v99/verification99.json')['replay']['byte_identical'] == {'result99.json':True,'control99.json':True}

# Counterfactual sensitivity with V99 geometry, upper weights, and electron boxes.
# Only the lower weight bound changes under a hypothetical upper energy cap.
def root_bounds(x):
    scale = 2**150
    lower = isqrt(x.numerator*scale**2//x.denominator)
    lo, hi = F(lower,scale), F(lower+1,scale)
    assert lo**2 <= x < hi**2
    return lo, hi
def projected_width(cap_for):
    lower = upper = F(0)
    for row in result['cells']:
        wl, wh = map(F,row['weight_intersection'])
        assert list(map(F,row['electron_interval'])) == [F(1,2000000),F(1,1000000)]
        cap = F(row['scalar_energy_cap'])
        h2 = F(row['H_squared_raw'][1]) + (cap_for(row,cap)-cap)/3
        hl, hh = root_bounds(h2)
        kl = F(result['optical_K_inverse_Mpc'][0])
        mass = F(row['cubic_mass'])*F(3,4000000)
        lower += (wh-max(wl,kl/hl))*mass
        upper += (wh-max(wl,kl/hh))*mass
    assert 0 < lower <= upper
    scale = 10**35
    return F((lower*scale).__floor__(),scale), F((upper*scale).__ceil__(),scale)
grows = guard['evaluators'][0]['rows']
ceiling = F(result['weight_width_ceiling'])
edge = projected_width(lambda row, cap:F(grows[row['guard_row']]['E_right']))
quarter = projected_width(lambda row, cap:cap*F(3,4))
assert edge[0] > ceiling > quarter[1]
assert result['original_cells'] == 101 and len(result['cells']) == 105
assert F(result['new_weight_width']) > ceiling
audit = {
    'root_input_sha256':root_hashes,
    'repository_base_commit':head['sha'],
    'replay':read(work/'v99/verification99.json'),
    'v99_result_sha256':task99['inputs']['result99.json'],
    'width_terms':result['width_accounting'],
    'pilot_interval':result['pilot_interval'],
    'global_interval':result['new_global_interval'],
    'weight_width_ceiling':str(ceiling),
    'sensitivity_only': {
        'optimistic_right_endpoint_cap_applied_to_entire_guard_cell':list(map(str,edge)),
        'hypothetical_three_quarters_of_each_v99_cap':list(map(str,quarter)),
        'scope':'Rational sensitivity calculation using only the H upper construction with a hypothetical changed cap, intersected with V99 W; W upper fixed. The old right caps are not premises for earlier redshifts. These calculations grant no new physical or source-real enclosures.'
    }
}
run = 'LOCAL-Q052-V99-INGESTION-SCALAR-ANCHOR-ROUTING-V100'
event_id = 'Q052-ACTIVITY-V99-INGESTION-SCALAR-ANCHOR-ROUTING-V100'
prior = ledger['total_points_after']
points = 65
total = prior+points
assert prior == 12825 and total == 12890
assert all(x.get('activity_event_id') != event_id for x in ledger['entries'])
assert len([x for x in ledger['entries'] if x.get('activity_event_id') == 'Q052-ACTIVITY-FIXED-BSTAR-WEIGHT-PILOT-V99']) == 1
assert not ledger['pending_packages']
now = datetime.now(timezone.utc).isoformat()
breakdown = {'analysis_and_route':20,'exact_sensitivity_calculation':15,'new_intake_validation':20,'source_and_repository_identity':10}
assert sum(breakdown.values()) == points
entry = {'activity_event_id':event_id,'run_id':run,'engine':task99['engine'],'run_points':points,
         'breakdown':breakdown,'counted_once':True,
         'basis':'Heuristic estimate of new intake and exact counterfactual cap analysis. V99 numerical trials, replays of its proofs, and packaging receive no separate scientific credit.'}
ledger.update(previous_ledger_ref=parent_name,previous_total_points=prior,
              total_points_after=total,cycle_progress=total%1000,next_publication_at=13000,
              points_to_next_publication=110,new_milestones=[],ledger_revision='V100',
              last_updated_utc=now,parent_ledger_sha256=task99['inputs']['activity_ledger.json'],
              reconciliation={'prior_total':prior,'new_unique_event_points':points,'current_total':total})
ledger['entries'].append(entry)
task = {
    'schema_version':'UNVALIDATED_LOCAL_CONTRACT',
    'task_id':'LOCAL-Q052-V100-SOURCE-REAL-SCALAR-ANCHOR-AT-800',
    'engine':'BUBBLEVERSE.MATHEMATICS 2.3.0','engine_prompt_sha256':math_hash,
    'state':'PREPARED_NOT_EXECUTED',
    **{k:task99[k] for k in ('case_id','current_q','target_q','exact_question','source_commit')},
    'objective':'Obtain a validated tight scalar energy anchor for the V73 fixed B-star at z=800, then use monotone scalar energy over the already admitted pilot to test whether the optical weight can meet the existing method target.',
    'archive_inputs':{'history/'+source:root_hashes[source]},
    'frozen':'V73 source-real IVP and captured binary64 convention, fixed B-star for both q arms, matched z810 thermodynamic start, Q051 criteria, V97 electron bounds, V99 K and 105 exact subcells.',
    'domain':{'anchor_z':'800','pilot_z':['750','800'],'guard_rows':[65,69]},
    'ordered_work':[
        'Recover an authenticated source-real joint phi,X enclosure on the V73 trajectory, with exact time, capture hash and proof of inclusion of B-star. If none is available, use the exact early V73 source initialization after checking its source binding. Energy/virial projections alone cannot justify a narrow independent state box. Stored native spline values are ineligible as initial data.',
        'Use a validated local Taylor/Picard or interval propagation of the V73 scalar-only IVP toward a=1/801. Preserve the fixed parameter dependency, show each step enclosure and exact endpoint connection, and certify e=X^2/2+A(1-cos(lambda*phi))^3 with directed rounding. Check the inherited source domain and guard identities. Return the last certified anchor if the target cannot be reached under the limit.',
        'If z=800 is certified, use de/dln(a)=-3X^2 and intersect the new energy cap with each old cap on [750,800]. Use the V99 B0/K boxes and intersections for H and W. Require strict identity and coverage checks; compute the V97 width decomposition with the same electron bounds and cubic mass.',
        'Check the state/energy anchor and propagated weight reduction independently. On a missing premise or empty intersection report the first exact witness and retain the last supported enclosure.'
    ],
    'scope_and_units':'u=ln(a), X=phi_prime/a, H in Mpc^-1 and e in Mpc^-2. The validated IVP is only the scalar background up to z=800. Its monotonic-energy transfer is confined to [750,800].',
    'success':'A validated B-star energy cap at z=800 and full 105-subcell weight contribution no greater than weight_width_ceiling. Report a technically valid anchor separately if the method screen fails.',
    'failure':'A validated cap that still exceeds the projected weight-width criterion, an invalid enclosure, or a first unresolvable premise. None closes Q052.',
    'weight_width_ceiling':str(ceiling),
    'full_precision_goal_provisional':old['full_precision_goal_provisional'],
    'execution_limits':{'prototype_wall_seconds':300,'new_native_pairs':0,'new_full_history_integrations':0},
    'stop_condition':'Stop after one bounded scalar-only prototype and at most one weight evaluation on [750,800], or at first missing premise/conflict or 300 seconds, whichever comes first.',
    'no_repeat':task99['no_repeat'],
    'return_engine':task99['engine'],
    'total_points':total,'next_milestone':13000,'points_to_next_publication':110
}
task['fingerprint_sha256'] = fingerprint(task)
print('Projection ranges',[(float(x),float(y)) for x,y in (edge,quarter)],'target',float(ceiling))
engine_path = upload/'Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0-38.md'
engine_bytes = engine_path.read_bytes()
repo = {'repository_url':'https://github.com/Morfindien/Bubbleverse','base_commit_sha':head['sha'],
        'source_freshness':'VERIFIED','journal_path':journal,'target_paths_status':'NEW_AT_VERIFIED_BASE',
        'sync_status':'USER_UPLOAD_PENDING','index_refs':[],'memory_update_ref':'github_memory_update.json',
        'upload_instructions_ref':'README.md'}
claims = {
    'weight':{'state':'REFINES','evidence':'history/'+source+'#result99.json',
              'scope':'V73 fixed source-real B-star, [750,800], conditional on inherited premises',
              'weight_width_reduction_fraction':result['weight_width_reduction_fraction'],
              'method_target':'FAIL','technical_certificate':'PASS'},
    'global_source_maximum':{'state':'REFINES','interval':result['new_global_interval'],
                            'maximum_location':result['maximum_location']},
    'native_error_and_reproducibility':{'state':'LEAVES UNCHANGED','status':'OPEN'}
}
memory = {'repository':repo,'new_root_files':names,'changes':'Append V100 to Q052 navigation if the operator updates an existing index after checking its current version.',
          'claim_map':claims,'completed_task':task99['fingerprint_sha256'],'next_task':task['fingerprint_sha256']}
handoff = {
    'schema_id':'bubbleverse.result_ingestion_handoff','schema_version':'3.0.0',
    'prompt_id':'bubbleverse.result_ingestion_routing','prompt_version':'2.3.0',
    'handoff_id':run,'created_at_utc':now,'engine_sha256':digest(engine_bytes),
    **{k:task[k] for k in ('case_id','current_q','target_q','exact_question','source_commit')},
    'evidence_cutoff':{'state_version':'V99','source_commit':task['source_commit']},
    'case_lifecycle':'ACTIVE','disposition':'CONTINUE','epistemic_status':'INCONCLUSIVE',
    'ingestion_state':'ACCEPTED_CONDITIONAL_RESULT','new_result_ids':[handoff99['run_id']],
    'source_state_version':'V99','target_state_version':'V100',
    'selected_next_engine_id':task['engine'],'engine_registry_ref':'Pinned repository root engine matched the V99 archive byte-for-byte',
    'execution_profile_ref':{'model':'gpt-6.1-sol','execution':'local Python exact rational arithmetic','next':'local validated interval propagation, subject to available anchor and bounded prototype'},
    'journal_ref':journal,'source_register_ref':'audit100.json','claim_evidence_map_ref':'claim_map.json',
    'result_provenance_ref':'manifest.json','completed_task_ledger_ref':'github_memory_update.json',
    'route_history_ref':journal,'integrity_manifest_ref':'manifest.json',
    'what_changed':claims,'frozen_configuration_refs':['history/'+source],
    'open_material_uncertainties':['Scalar energy on fixed B-star at z=800','Electron enclosure precision','Native configuration membership, trajectory, reproducibility and numerical error'],
    'missing_information':['No tight authenticated scalar state at the pilot entry established by intake'],
    'next_task':taskname,'next_task_fingerprint':task['fingerprint_sha256'],
    'success_condition':task['success'],'failure_or_falsification_condition':task['failure'],
    'stop_condition':task['stop_condition'],'completion_gate_satisfied':False,
    'completion_gate_reason':'Source precision and native validation remain open.',
    'handoff_completeness':'COMPLETE_FOR_BOUNDED_CONTINUATION','writeback_status':'USER_UPLOAD_PENDING',
    'delivery_status':'PREPARED','operator_gate':'No automatic dispatch or external publication',
    'output_file_refs':names,'output_manifest_ref':bundle+'::manifest.json','repository_memory':repo,
    'question_activity_points':{'policy_version':'2.0.0','ledger_ref':'activity_ledger.json',
                                'ledger_version':'V100','parent_ledger_version':'V99','run_id':run,
                                'activity_event_id':event_id,'parent_total_pts':prior,'assessed_run_points':points,
                                'assessment_breakdown':breakdown,'assessment_basis':entry['basis'],
                                'newly_applied_event_ids':[event_id],'total_pts':total},
    'some_milestones':{'interval_pts':1000,'highest_threshold_reached_pts':12000,'crossed_this_run':[],
                       'pending_milestones':[],'next_threshold_pts':13000,'points_to_next_threshold':110,
                       'package_creation_status':'NOT_DUE','scientific_route_changed_by_points':False}
}
report = '''# Q052 V100 · Resultatindtag og næste opgave

V99 er godkendt som en betinget indhylling for den fastholdte kildebaggrund B★. Vægtens bidrag til intervalbredden faldt med **10,50 %**. Metodekravet på 25 % blev ikke opfyldt. Det verificerede kildeinterval for det optiske maksimum ved z=810 er [1,43348504 × 10⁻⁶, 4,57064840 × 10⁻⁵], afrundet udad.

**Næste motor er Matematikmotor 2.3.0.** Den skal forsøge at certificere skalarenergien ved z=800 på den samme kildeløsning. Energien kan derefter kun falde frem til z=750, så ét gyldigt loft kan anvendes på hele pilotområdet.

Q052 er fortsat åbent. Kildeindhyllingen er cirka 11.068 gange bredere end det foreløbige præcisionsmål, og sammenligningen med den faktiske CLASS/P6-kørsel mangler.
'''
detail = f'''
## Begrundelse for næste opgave

Vi gentog V99's kontrol og fik byteidentiske beregnings- og kontrolresultater. Otte testfejl blev igen afvist. De 101 oprindelige celler er dækket af 105 delceller med samme elektroninterval. Kilde, capture og guard er hashbundet i det arkiverede certifikat. Kun V99's dokumenterede forbedring indgår i det optiske kildeinterval.

En eksakt følsomhedsberegning beholdt de øvre vægtgrænser, cellemasser og elektronintervaller fra V99. Med hver guard-celles højre endepunktsloft anvendt hypotetisk på hele cellen ville vægtbidraget være cirka {float(edge[0]):.6g}. Det er stadig over loftet {float(ceiling):.6g}. Med tre fjerdedele af hvert V99-energiloft ville bidraget være cirka {float(quarter[1]):.6g}. De to scenarier er regneprøver. Det højre endepunktsloft giver ingen ny grænse bagud i tiden, og reduktionen til tre fjerdedele skal have sit eget bevis.

V100 vælger derfor ét nyt afgrænset forsøg. Genskab en valideret skalartilstand på den tidlige V73-kildebane og propagér til z=800 inden for 300 sekunder. Ved z=800 kan et certificeret energiloft overføres fremad ved d e/d ln(a) = −3X². Brug derefter de eksisterende 105 delceller til én vægttest, hvis ankeret nås. Den gamle spline må kun bruges til sammenligning. Det nye energiloft skal følge den låste kildeinitialisering. Hvis prototypen må stoppe, aflever sidste certificerede tilstand og første manglende præmis.

Der er ikke kørt et nyt skalarforsøg under indtaget. De gemte native værdier og deres eksisterende fejldomæner ændrer status først efter særskilt validering.

## Journal og aflevering

Den fulde V99-journal er bevaret byte for byte som præfiks. De tre V99-filer matcher GitHub ved {head['sha']}. Upload de fire V100-filer som nye filer i repository-roden efter kontrol af basen. Henvis til V100 fra den eksisterende Q052-navigation, hvis den opdateres. GitHub-synkronisering af V100 afventer manuel upload.

RUN COST: 65 pts  
TOTAL WORK POINTS: 12890 pts  
SOME INTERVAL: 1000 pts  
NEWLY CROSSED SOME MILESTONES: []  
NEXT SOME MILESTONE: 13000 pts  
POINTS TO NEXT SOME MILESTONE: 110 pts  
SOME PACKAGE STATUS: NOT_DUE  
SCIENTIFIC STATUS: ACTIVE / INCONCLUSIVE  
NEXT SCIENTIFIC ENGINE: BUBBLEVERSE.MATHEMATICS 2.3.0

Pointbidraget er vurderet til 20 for analyse og routing, 15 for den eksakte følsomhedsberegning, 20 for nyt indtags- og identitetstjek samt 10 for kilde- og repository-kontrol. Den tidligere V99-beregning og dens point indgår kun én gang.
'''
(root/brief).write_text(report)
(root/taskname).write_bytes(encoded(task))
append = ('\n\n---\n\n'+report+'\n## Præcist Q052-spørgsmål\n\n'+task['exact_question']+
          '\n'+detail+'\n```json\n'+encoded(handoff).decode().rstrip()+'\n```\n\n```json\n'+encoded(ledger).decode().rstrip()+'\n```\n')
(root/journal).write_bytes(parent+append.encode())
members = {'README.md':(report+detail).encode(),'audit100.json':encoded(audit),
           'handoff100.json':encoded(handoff),'activity_ledger.json':encoded(ledger),
           'claim_map.json':encoded(claims),'github_memory_update.json':encoded(memory),
           taskname:encoded(task),'history/'+source:(upload/source).read_bytes(),
           'ENGINE_RESULT_INGESTION_ROUTING_2.3.0.md':engine_bytes,
           'build100.py':Path(__file__).read_bytes()}
out_manifest = {'schema':'Q052_V100_INGESTION_MANIFEST','version':'V100','target_q':'Q052',
                'case_id':task['case_id'],'parent_journal_sha256':root_hashes[parent_name],
                'members_sha256':{n:digest(b) for n,b in members.items()},
                'archive_output':{'name':bundle,'role':'Evidence and intake certificate','sha256_convention':'Excluded from internal manifest to avoid a recursive hash'},
                'root_outputs_excluding_this_zip':{n:{'sha256':digest((root/n).read_bytes()),
                    'bytes':(root/n).stat().st_size,'repository_path':n,'status':'NEW','role':role}
                    for n,role in [(brief,'Result'),(taskname,'Next bounded task'),(journal,'Complete cumulative journal')]}}
with zipfile.ZipFile(root/bundle,'w',zipfile.ZIP_DEFLATED) as out:
    for n,b in members.items():
        out.writestr(n,b)
    out.writestr('manifest.json',encoded(out_manifest))
with zipfile.ZipFile(root/bundle) as out:
    assert out.testzip() is None
    for n,h in out_manifest['members_sha256'].items():
        assert digest(out.read(n)) == h
assert (root/journal).read_bytes().startswith(parent)
assert fingerprint(read(root/taskname)) == task['fingerprint_sha256']
assert len(set([x.get('activity_event_id', x['run_id']) for x in ledger['entries']])) == len(ledger['entries'])
req = {'uploads':[{'local_path':str(root/n),'purpose':'create_library_file',
                   'library_artifact_type':'report' if n.endswith('.md') else 'other'} for n in names]}
(work/'upload_request.json').write_bytes(encoded(req))
print({n:(root/n).stat().st_size for n in names})
