"""Restore frozen source inputs only. Does not run scientific code."""
from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
from hashlib import sha256
import json
p=Path(__file__).resolve().parent;target=p/'calc';target.mkdir(exist_ok=True)
with ZipFile(p/'history/Q052_INGESTION_CERTIFICATE_V112.zip') as outer:
 task=json.loads(outer.read('Q052_MATEMATIKOPGAVE_V112.json'))
 with ZipFile(BytesIO(outer.read('history/Q052_GRENSKIFT_CERTIFIKAT_V87.zip'))) as old:
  for n,h in task['input_sha256'].items():
   b=old.read(n);assert sha256(b).hexdigest()==h
   if (target/n).exists():assert (target/n).read_bytes()==b
   else:(target/n).write_bytes(b)
print(json.dumps({'status':'PASS_RESTORED_PINNED_INPUTS','scientific_evaluations':0,'files':len(task['input_sha256'])}))
