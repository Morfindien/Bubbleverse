from pathlib import Path
from hashlib import sha256,sha1
from zipfile import ZipFile,ZIP_DEFLATED
from datetime import datetime,timezone
from io import BytesIO
import json,subprocess,sys
p=Path(__file__).resolve().parent;root=p.parents[1];u=root/'upload';old=p/'input112';c=p/'calc';out=root/'output/V113';out.mkdir(parents=True,exist_ok=True)
read=lambda f:json.loads(f.read_bytes())
dump=lambda x:(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()
sha=lambda b:sha256(b).hexdigest()
fp=lambda x:sha(json.dumps({k:v for k,v in x.items() if k!='fingerprint_sha256'},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
a=read(c/'task112.json');prior=read(old/'activity_ledger.json');ex=read(c/'execution113.json');repo=read(p/'repository113.json');pre=read(p/'backend_preflight113.json')
assert fp(a)==a['fingerprint_sha256']
assert ex['technical_state']=='FAIL' and ex['independent_controls']==0 and ex['output_sha256']=={}
assert ex['error']=="BackendError('MPFR_VERSION_GATE: 4.2.2')" and ex['wall_seconds']<300
assert not (c/'raw113.json').exists() and not (c/'control113.json').exists()
assert sum(e['run_points'] for e in prior['entries'])==a['total_points']==14005
for n,h in ex['code_sha256'].items():assert sha((c/n).read_bytes())==h
for n in ['Q052_INGESTION_CERTIFICATE_V112.zip','Q052_KORT_RESULTAT_V112.md','Q052_MATEMATIKOPGAVE_V112.json','Q052_INGESTION_OG_SAMLET_JOURNAL_V112.md']:
 b=(u/n).read_bytes();assert sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()==repo['paths'][n]
now=datetime.now(timezone.utc).isoformat();run=ex['run_id'];eid='Q052-ACTIVITY-MIXED-FACE-BACKEND-STOP-V113';total=14060
entry={'activity_event_id':eid,'run_id':run,'engine':'BUBBLEVERSE.MATHEMATICS 2.3.0','run_points':55,'breakdown':{'analysis':25,'implementation':15,'source_recovery':10,'validation':5},'basis':'Heuristic activity index: new half-q algebra and scope analysis; two drafted formulations and guarded runner; pinned source/commit inspection; package and backend diagnosis. No successful scientific evaluation or independent numerical control credited. Packaging, delivery, old proof and old point events excluded.','counted_once':True}
assert eid not in [x.get('activity_event_id') for x in prior['entries']]
receipt=read(root/'work/intake112/upload_receipt.json');m14=next(x for x in receipt['results'] if x['file_name']=='Q052_SOME_M014_R1.zip');assert m14['status']=='succeeded'
admin={'event_id':'Q052-M014-DELIVERY-RECONCILIATION-V113','event_type':'PACKAGE_DELIVERY_RECONCILIATION','run_points':0,'milestone_id':'Q052-SOME-M014','previous_state':'READY','state':'DELIVERED','evidence_ref':'delivery_receipt112.json','library_file_id':m14['library_file_id'],'external_publication_status':'NOT_VERIFIED'}
ledger={**prior,'entries':prior['entries']+[entry],'administrative_events':prior.get('administrative_events',[])+[admin],'previous_ledger_ref':'history/Q052_INGESTION_CERTIFICATE_V112.zip#activity_ledger.json','parent_ledger_sha256':sha((old/'activity_ledger.json').read_bytes()),'previous_total_points':14005,'total_points_after':total,'cycle_progress':60,'next_publication_at':15000,'points_to_next_publication':940,'ledger_revision':'V113','last_updated_utc':now,'new_milestones':[],'ready_milestone_ids':[],'delivered_milestone_ids':prior['delivered_milestone_ids']+['Q052-SOME-M014'],'pending_packages':[],'note':entry['basis'],'reconciliation':{'prior_total':14005,'new_unique_event_points':55,'current_total':total,'M014_delivery_reconciled_without_points':True}}
identity={k:a[k] for k in ['case_id','current_q','target_q','exact_question','source_commit','capture_sha256']}
short,journal,taskname,bundle=['Q052_KORT_RESULTAT_V113.md','Q052_MATEMATIK_OG_SAMLET_JOURNAL_V113.md','Q052_RESULTATINDTAG_OPGAVE_V113.json','Q052_BACKEND_FEJLPAKKE_V113.zip']
result={**identity,'result_id':run,'input_task_id':a['task_id'],'input_task_fingerprint':a['fingerprint_sha256'],'created_at_utc':now,'technical_state':'FAIL','scientific_state':'INCONCLUSIVE','workflow_state':'BLOCKED','result_class':'RUN_FAILURE_BEFORE_SCIENTIFIC_EVALUATION','blocker_id':'LOCAL-Q052-PINNED-MPFR-4.2.1-UNAVAILABLE','backend_required':'4.2.1','backend_observed':'4.2.2','producer_entries':1,'completed_face_evaluations':0,'independent_controls_started':0,'new_optical_evaluations':0,'new_scalar_integrations':0,'new_native_pairs':0,'new_full_history_integrations':0,'elapsed_seconds':ex['wall_seconds'],'new_face_sign':'NOT_EVALUATED','counterexample_state':'NOT_EVALUATED','completion_gate_satisfied':False,'historical_results_modified':False,'accepted_scientific_state_ref':'history/Q052_INGESTION_CERTIFICATE_V112.zip#audit112.json','strict_seed_ref':'calc/barrier111.json','source_draft_state':'SYNTAX_CHECKED_ONLY; numerical and domain applicability not validated','failure_receipt_ref':'calc/execution113.json','runtime_observation_ref':'backend_preflight113.json','scope_note':'Version gate failure is a technical execution result. It is neither a negative vector field nor a scientific falsification. The prepared relaxed-box diagnostic cannot establish membership in the exact B_star trajectory.'}
engine=(old/'prompts/Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0.md').read_bytes()
nexttask={**identity,'schema_version':'UNVALIDATED_LOCAL_CONTRACT','task_id':'LOCAL-Q052-V113-BACKEND-FAILURE-INTAKE','engine':'BUBBLEVERSE.RESULT_INGESTION_ROUTING 2.3.0','engine_prompt_sha256':sha(engine),'state':'PREPARED_NOT_EXECUTED','input_certificate':bundle,'input_result_ref':bundle+'#result113.json','input_result_sha256':sha(dump(result)),'objective':'Ingest the pre-evaluation MPFR version failure and prepare one explicitly versioned recovery of the still-unexecuted V112 half-q task.','required_actions':['Verify unchanged V112 source/task/journal identity and the original failure receipt. Record zero completed face evaluations and zero independent controls; do not infer any derivative sign from drafted code.','Recover the exact MPFR 4.2.1 runtime in a scoped environment and verify its identity, ABI and directed rounding before scheduling scientific evaluation. If unavailable, define an explicit backend-migration qualification task with new identities and meaningful interval/primitive tests; do not remove the historical version gate.','Review both prepared formulations against literal HMLA/SWIFT source. The proposed point uses a common H value from an archived interval, whose membership in the exact B_star function is unverified. Any later negative diagnostic must remain a relaxation-only result unless exact background and joint trajectory admission are established.','Freeze a new run ID and finite limit after the failed preflight has been resolved. Preserve run113.lock, failure outputs and original scripts. Reuse V111/V112 results and M014 package without replay or new points.','Update existing Q052 record and activity ledger; Q052 remains open.'],'execution_limits':{'new_face_evaluations':0,'new_optical_evaluations':0,'new_native_pairs':0,'new_scalar_integrations':0,'new_full_history_integrations':0},'acceptance_criteria':'Traceable technical failure admitted, no scientific promotion, one concrete backend recovery or qualification handoff with unchanged scientific problem and explicit preflight.','rejection_criteria':'Any claim that this attempt produced a derivative, passed independent control, or disproved the actual half-q trajectory.','inconclusive_criteria':'Required backend remains unavailable and not qualified; retain exact blocker.','stop_condition':'One ingestion and one bounded recovery handoff.','no_repeat':a['no_repeat']+['V113 failed backend attempt must not be silently rerun or credited as a numerical result.'],'continue_same_q':True,'total_points':total,'next_milestone':15000,'points_to_next_publication':940,'activity_ledger_ref':bundle+'#activity_ledger.json'}
nexttask['fingerprint_sha256']=fp(nexttask)
proof='''# V113 · Teknisk stop og matematisk arbejdsnotat

## Hvad kørslen dokumenterer

Den fastlåste v20-loader udpakker intervalmodulet med SHA-256 558592e20969dbfc063570f2224c36b4e8d7dca37db20009cb5dd2a993e0d160 fra v19.json. Modulet kræver MPFR_VERSION=4.2.1 og afviser den observerede 4.2.2. Fejlen kom ved import, før Context havde indlæst atomtabeller og før producentscriptets tilstands- eller rateberegning. Den separate kontrol blev ikke startet. Original fejllog og scripts er bevaret. Tælleren producer_runs=1 betyder én indgang i producentfunktionen, ikke én udført fladeberegning.

Preflight blev i dette forsøg nået inde i producentens Context-oprettelse. Næste forsøg skal placere denne kontrol før registrering af en videnskabelig evaluering. Ingen versionsgate er ændret, og ingen ny kørsel er foretaget efter stoppet.

## Algebra til faglig gennemgang før genoptagelse

Med a=q/2, h=h_R, h_L=h-a er X_L=h+a og X_R=h. Derfor h_L X_L=h²-a². På E=0-fladen i V87 var produktet h(h-q); V87's lineære q/h-margin kan ikke genbruges.

Skriv U_R=alpha_R h²-b(1-h), U_L=alpha_L(h²-a²)-b(1-h+a), b=alpha_eq*s, s=Saha(TR)/nH. Hvis den arvede temperaturorden og kolde rateorden giver alpha_L≤alpha_R, fås med k=1-a²/h²:

U_L≤k U_R-b[a+a²(1-h)/h²]≤k U_R.

På en fælles gren, hvor C_L≤C_R, giver dette formelt d'/|f_R|≥a²/h², forudsat U_R>0 og de øvrige arvede præmisser. Dette er en analytisk arbejdsudledning; den konkrete flades domæne og numeriske margin er ikke certificeret i V113.

Selectoren bruger rå escape e(h)=Lya H/[nH(1-h)]. Ved fælles H og h_L<h_R fås e_L<e_R og P_L>P_R. Den mulige blandede rækkefølge er SWIFT i L, HMLA i R. Med c=((1/p-1)B-Lambda)/3 er korridoren e_L≤c<e_R. Lighed skal behandles med relevante ensidige felter. Disse symboler, enheder og kildeformler følger V87 og hyrec.c linje 429–541 og 1065–1076 i den indlejrede pin-verificerede kilde.

## Planlagt diagnostik — ikke kørt

produce113.py er en kandidatimplementation med en helcellegrænse fra V77 og ét deterministisk punkt valgt ved samme relative z som V87's gamle dispatch-eksempel, med den nye q/2-flade. Der er ingen parameter- eller gitterjagt. Scriptet bruger positive-polynomielle C-tællere og nævnere samt fulde U-led. control113.py bruger de oprindelige indlejrede Gamma-formler og DAlpha/Dxe-led samt en bredere arkiveret DK-grænse. Begge deler kildedata, atomtabeller, v20-rateinterpolation og MPFR-primitiver. Koden er kun syntakskontrolleret; der foreligger intet output fra disse metoder.

V112 bad om feltets fortegn under den fastlåste fælles baggrund. Et H valgt inde i en arkiveret helcelleboks er ikke i sig selv dokumenteret som H_Bstar(z). Den forberedte punktdiagnostik ville derfor højst kunne afvise tilstrækkeligheden af intervalrelaksationen, selv hvis en negativ afledt senere valideres. Der foreligger heller ingen dokumentation for, at den matchede bane besøger punktet. Denne afgrænsning skal fastholdes i enhver genoptagelse.

## Konsekvens

Ingen udvidelse af halv-q-domænet, ingen ny optisk værdi og ingen konklusion om det blandede felts fortegn optages. Den videnskabelige tilstand fra V112 videreføres med dette tekniske stop som ny provenance. Q052 er INCONCLUSIVE, og den aktuelle beregningsopgave er BLOCKED af runtimekravet.
'''
profile={'current_setup':'Codex Work Mode / gpt-6-astra per runtime instructions / Python 3.12.14','recommended_setup':'Current environment for intake; scoped pinned MPFR 4.2.1 runtime for the next calculation','reasoning_level':'NOT VERIFIED','capability_classes':['H','A','C'],'observed_capabilities':['Python','local archive and hash validation','GitHub read'],'unavailable_requirement':'MPFR 4.2.1 through the observed default loader','fallback':'Explicit separately versioned qualification of another MPFR runtime','upgrade_trigger':'Only a concrete unresolved backend or mathematical obligation','downgrade_trigger':'Routine receipt ingestion','switch_performed':False}
summary=f'''# BUBBLEVERSE — OVERLEVERING

Q052 · V113 · Matematikmotor 2.3.0

**Halv-q-beregningen er teknisk blokeret.** Den fastlåste intervalkode kræver MPFR 4.2.1; miljøet indlæser 4.2.2. Versionskontrollen stoppede forsøget efter {ex['wall_seconds']:.6f} sekunder, før nogen ny afledt blev beregnet. Den separate kontrol blev ikke startet.

STATUS: FORTSÆTTER. WORKFLOW_STATE: BLOCKED. SCIENTIFIC_STATE: INCONCLUSIVE. TECHNICAL_STATE: FAIL. TARGET_Q: Q052. AUTHORIZED_Q_RANGE: Q001–Q052. CONTINUE_SAME_Q: true.

**Næste motor: Result Ingestion & Routing 2.3.0.** Den skal registrere fejlen og afgrænse genskabelse af den krævede MPFR-version eller en særskilt valideret backendændring. Det oprindelige V112-problem består. Et nyt forsøg får egen identitet efter en bestået preflight.

V112's betingede optiske interval og V111's halv-q-resultat består som historiske inputs. V113 har ikke valideret noget nyt fortegn, modeksempel eller native CLASS/P6-forløb. Den udarbejdede kode er syntakskontrolleret, men dens videnskabelige evaluering er ikke udført. Arbejdsnotatet forklarer forskellen mellem den nye kontaktflade og V87, samt hvorfor et punkt i en bred H-boks ikke automatisk ligger på den fastlåste baggrund eller bane.

RUN POINTS: 55. TOTAL POINTS: {total}. CYCLE PROGRESS: 60/1000. NEXT SOME MILESTONE: 15000. POINTS TO NEXT PUBLICATION: 940. POINTS_STATE: VERIFIED. PUBLICATION_STATE: NOT_DUE. PENDING SOME PACKAGES: NONE. M014's tidligere levering er afstemt med den gemte kvittering; pakken er ikke genskabt. Ekstern publicering er ikke verificeret.

Pointskøn: analyse 25, kodearbejde 15, kildegenfinding 10, validering/diagnose 5. Ingen gennemført numerisk fladekontrol er krediteret. RUN_ID: {run}. PREVIOUS_POINTS_ENTRY: LOCAL-Q052-V111-BRIDGE-INTAKE-V112.

CHATGPT-SETUPVURDERING: Nuværende Codex Work Mode og Python kan udføre resultatindtaget. Næste beregning kræver det verificerede MPFR-miljø. Klasser H/A/C. Reasoning-niveau er ikke verificeret; intet modelskift er udført. Fallback er en dokumenteret separat backendkvalifikation.

Hele V112-journalen er bevaret som eksakt præfiks. Pakken indeholder rå fejllog, kilde- og scriptidentiteter, ikke-eksekveret beregningskode, opgave, aktivitetstæller, historiske input og genoprettelsesscript. Lokale hash-, JSON-, journal- og regnskabskontroller er udført; ekstern formel schemavalidering er ikke udført.

GITHUB_READ_STATE: VERIFIED for V112 ved {repo['head']}. GITHUB_WRITE_STATE: READY_FOR_MANUAL_UPLOAD. Ingen repository-skrivning er udført.
'''
files={short:summary.encode(),taskname:dump(nexttask),'result113.json':dump(result),'activity_ledger.json':dump(ledger),'PROOF_AND_BLOCKER_V113.md':proof.encode(),'execution_profile113.json':dump(profile),'repository113.json':dump(repo),'backend_preflight113.json':dump(pre),'console113.log':(p/'console113.log').read_bytes(),'restore_inputs113.py':(p/'restore_inputs113.py').read_bytes(),'build113.py':Path(__file__).read_bytes(),'history/Q052_INGESTION_CERTIFICATE_V112.zip':(u/'Q052_INGESTION_CERTIFICATE_V112.zip').read_bytes(),'delivery_receipt112.json':dump({'results':[m14]}),'prompts/Bubbleverse_Matematikmotor_2.3.0.md':(u/'Bubbleverse_Matematikmotor_2.3.0-56.md').read_bytes(),'prompts/Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0.md':engine}
for n in ['run113.py','produce113.py','control113.py','execution113.json','run113.lock','task112.json','barrier111.json']:files['calc/'+n]=(c/n).read_bytes()
files['source_register.json']=dump({'inherited':'history/Q052_INGESTION_CERTIFICATE_V112.zip#source_register.json','literal_source':'history/Q052_INGESTION_CERTIFICATE_V112.zip#history/Q052_GRENSKIFT_CERTIFIKAT_V87.zip#v19.json','new_sources':['repository113.json','backend_preflight113.json','calc/execution113.json'],'claim_evidence_map':{'failure_before_science':'calc/execution113.json','runtime_version':'backend_preflight113.json','no_new_face_sign':'result113.json','symbolic_preparation_only':'PROOF_AND_BLOCKER_V113.md'}})
files['handoff113.json']=dump({**identity,'schema_version':'UNVALIDATED_LOCAL_CONTRACT','disposition':'BLOCKED_RUNTIME_WITH_INGESTION_HANDOFF','selected_next_engine':nexttask['engine'],'task_ref':taskname,'task_fingerprint':nexttask['fingerprint_sha256'],'result_ref':'result113.json','journal_ref':journal,'activity_ledger_ref':'activity_ledger.json','source_register_ref':'source_register.json','completion_gate_satisfied':False,'exact_blocker':result['blocker_id'],'recovery_condition':'Pinned runtime preflight passes or separately versioned backend qualification is completed. No silent replay of V113.','files_complete':True})
files['github_memory_update.json']=dump({'repository':'https://github.com/Morfindien/Bubbleverse','base_commit_sha':repo['head'],'state':'READY_FOR_MANUAL_UPLOAD','files':[short,journal,taskname,bundle],'run_id':run,'total_points':total,'status':result,'instructions':'Add these new versioned files. Preserve V112 and historical failed V113 receipt. Update existing Q052 pointers only after verifying current head and canonical schemas. No push/commit claimed.'})
files['README.md']=('V113 records a backend gate failure, not a successful science run.\n\nExtract the package. Run python restore_inputs113.py to restore hashed historical inputs without executing scientific code. calc/run113.lock intentionally prevents rerunning the recorded failed attempt. The next task must establish a qualified runtime and a separate run identity. Do not delete this historical lock or change the pinned backend gate.\n\nAll historical state is available in history/Q052_INGESTION_CERTIFICATE_V112.zip. Full journal is '+journal+'.\n').encode()
append='\n\n# V113 · MPFR-versionsgate før fladeberegning\n\n'+summary+'\n## EXACT CURRENT QUESTION (verbatim)\n\n'+a['exact_question']+'\n\n'+proof+'\n## Resultat, næste opgave og fuld aktivitetstæller\n\n```json\n'+dump({'result':result,'next_task':nexttask,'ledger':ledger,'execution_profile':profile}).decode()+'```\n'
files[journal]=(u/'Q052_INGESTION_OG_SAMLET_JOURNAL_V112.md').read_bytes()+append.encode()
for n in [short,journal,taskname]:(out/n).write_bytes(files[n])
files['manifest.json']=dump({'archive_members':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in files.items()],'external_deliverables':[short,journal,taskname],'result_state':'NO_NEW_SCIENTIFIC_EVALUATION'})
with ZipFile(out/bundle,'w',ZIP_DEFLATED) as z:
 for n,b in files.items():z.writestr(n,b)
with ZipFile(out/bundle) as z:
 assert z.testzip() is None
 for e in json.loads(z.read('manifest.json'))['archive_members']:
  assert sha(z.read(e['path']))==e['sha256']
  if e['path'].endswith('.json'):json.loads(z.read(e['path']))
 assert z.read(journal).startswith((u/'Q052_INGESTION_OG_SAMLET_JOURNAL_V112.md').read_bytes())
 assert ledger['entries'][:-1]==prior['entries'] and ledger['milestone_records']==prior['milestone_records']
 assert sum(e['run_points'] for e in ledger['entries'])==total
 assert len({e['activity_event_id'] for e in ledger['entries'] if 'activity_event_id' in e})==len([e for e in ledger['entries'] if 'activity_event_id' in e])
 assert fp(json.loads(z.read(taskname)))==nexttask['fingerprint_sha256']
 assert summary.count('BUBBLEVERSE — OVERLEVERING')==1
 for n in [short,journal,taskname]:assert z.read(n)==(out/n).read_bytes()
 names=[short,journal,taskname,bundle]
(p/'upload_request.json').write_bytes(dump({'uploads':[{'local_path':str(out/n),'purpose':'create_library_file','library_artifact_type':'report' if n.endswith('.md') else 'other'} for n in names]}))
validation={'status':'PASS_PACKAGE_AND_HISTORY','files':[{'filename':n,'sha256':sha((out/n).read_bytes()),'bytes':(out/n).stat().st_size} for n in names],'scientific_evaluations':0,'ledger_preserved':True,'journal_prefix_preserved':True}
(p/'delivery_validation113.json').write_bytes(dump(validation));print(json.dumps(validation,indent=2))
