"""Independent literal Gamma-form check at a producer-supplied rational point.
Shares pinned source, rate interpolation and MPFR primitives; no producer import.
Uses original source DAlpha/Dxe expression and archived whole-cell DK.
"""
from pathlib import Path
from fractions import Fraction as F
import json
import v20 as m
P=Path(__file__).resolve().parent
hx=lambda s:F(float.fromhex(s))
read=lambda n:json.loads((P/n).read_bytes())
def main(result):
 c=m.Context(P/'v19.json');w=result['witness'];q=F(1,1000000)
 z,hL,hR,vL,vR,H=[F(w[k]) for k in ['z','hL','hR','vL','vR','common_H_per_s']]
 assert hR-hL==q/2 and vL>vR
 L,R=[read('v62.json')['arms'][a]['records'][234] for a in 'LR']
 for row,h,v in [(L,hL,vL),(R,hR,vR)]:
  assert hx(row['z'][1])<z<hx(row['z'][0])
  assert hx(row['whole_source'][0][0])<h<hx(row['whole_source'][0][1])
  assert hx(row['whole_source'][1][0])<v<hx(row['whole_source'][1][1])
  assert hx(row['H_per_s'][0])<H<hx(row['H_per_s'][1])
 assert (hR+q)*(vL-vR)/(q*vL)<F(99,100)
 T,tr,n,_=c.background(m.enc(1+z));assert c.fit_first.hi<T.lo<T.hi<c.fit_last.lo
 t=tr/(10000*c.k)
 B=m.lit('4.309e-13')*t.power(m.lit('-0.6166'))/(1+m.lit('.6703')*t.power(m.lit('.5300')))*c.saha*tr*tr.sqrt()*(-c.EI/(4*tr)).exp()
 dk=m.enc(*map(hx,read('v77.json')['mixed_branch_checks'][0]['DK']))
 values=[];guards=[];channels=[]
 for h,v,helium,swift in [(hL,vL,q,True),(hR,vR,F(0),False)]:
  al,eq,_,rate=c.rates(tr,m.enc(v));bs,bp=[m.enc(*map(hx,a['hex'])) for a in rate['beta']];j=m.enc(*map(hx,rate['R2p2s']['hex']))
  e=c.lya*m.enc(H)/(n*m.enc(1-h));guard=B/(3*e+c.lam+B);guards.append(guard.hex())
  assert (guard.lo>m.lit('.01').hi) if swift else (guard.hi<m.lit('.01').lo)
  if swift:e=e/(1+dk)
  gs=bs+3*j+c.lam;gp=bp+j+e
  C=[(c.lam+3*j*e/gp)/(gs-3*j*j/gp),(e+j*c.lam/gs)/(gp-3*j*j/gs)]
  s=c.saha*tr*tr.sqrt()*(-c.EI/tr).exp()/n
  dx=m.enc(h)*m.enc(h+helium)-s*m.enc(1-h)
  U=[s*m.enc(1-h)*(al[k]-eq[k])+al[k]*dx for k in range(2)]
  assert all(x.lo>0 for x in U)
  values.append(-n/m.enc(H)*sum((U[k]*C[k] for k in range(2)),m.I(0)));channels.append([x.hex() for x in U])
 d=values[0]-values[1];norm=d/(-values[1])
 primary=list(map(hx,w['dprime']));assert max(primary[0],F(d.lo))<=min(primary[1],F(d.hi))
 return {'status':'PASS_RELAXATION_ONLY' if d.hi<0 else 'INCONCLUSIVE','dprime':d.hex(),'normalized':norm.hex(),'guards':guards,'channels':channels,'method':'Literal nested Gamma coefficients and DAlpha/Dxe expression; broader archived DK; independent point-domain and guard checks.','shared_dependencies':'v19/v20 sources, atom tables, MPFR interval primitives, supplied rational witness. No independent physical background admission.','fixed_background_membership':'NOT_VERIFIED','trajectory_counterexample':False}
