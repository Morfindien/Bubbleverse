from pathlib import Path
import json,time,datetime,hashlib,platform,traceback,signal
P=Path(__file__).resolve().parent
(P/'run113.lock').touch(exist_ok=False)
start=time.monotonic();stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt={'run_id':'LOCAL-Q052-MIXED-HALF-Q-FACE-V113','started_at_utc':stamp,'producer_runs':0,'independent_controls':0,'new_optical_evaluations':0,'new_native_pairs':0,'new_scalar_integrations':0,'python':platform.python_version()}
def save(n,x):(P/n).write_text(json.dumps(x,indent=2)+'\n')
def alarm(*args):raise TimeoutError('300 second limit')
signal.signal(signal.SIGALRM,alarm);signal.alarm(300)
try:
 import produce113,control113
 receipt['producer_runs']=1;result=produce113.main();save('raw113.json',result)
 receipt['independent_controls']=1;control=control113.main(result);save('control113.json',control)
 receipt['technical_state']='PASS'
 receipt['method_target']='NOT_ESTABLISHED_FOR_FIXED_BACKGROUND'
 receipt['result']='RELAXATION_COUNTEREXAMPLE' if result['status']=='RELAXED_FACE_COUNTEREXAMPLE_PENDING_CONTROL' and control['status']=='PASS_RELAXATION_ONLY' else 'INCONCLUSIVE'
except Exception as e:
 receipt['technical_state']='FAIL';receipt['error']=repr(e);receipt['traceback']=traceback.format_exc()
finally:
 signal.alarm(0);receipt['wall_seconds']=time.monotonic()-start
 receipt['completed_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 receipt['code_sha256']={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in ['run113.py','produce113.py','control113.py']}
 receipt['output_sha256']={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in ['raw113.json','control113.json'] if (P/n).exists()}
 save('execution113.json',receipt);print(json.dumps(receipt,indent=2))
