V113 records a backend gate failure, not a successful science run.

Extract the package. Run python restore_inputs113.py to restore hashed historical inputs without executing scientific code. calc/run113.lock intentionally prevents rerunning the recorded failed attempt. The next task must establish a qualified runtime and a separate run identity. Do not delete this historical lock or change the pinned backend gate.

All historical state is available in history/Q052_INGESTION_CERTIFICATE_V112.zip. Full journal is Q052_MATEMATIK_OG_SAMLET_JOURNAL_V113.md.
