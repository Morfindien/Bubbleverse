# V113 · Teknisk stop og matematisk arbejdsnotat

## Hvad kørslen dokumenterer

Den fastlåste v20-loader udpakker intervalmodulet med SHA-256 558592e20969dbfc063570f2224c36b4e8d7dca37db20009cb5dd2a993e0d160 fra v19.json. Modulet kræver MPFR_VERSION=4.2.1 og afviser den observerede 4.2.2. Fejlen kom ved import, før Context havde indlæst atomtabeller og før producentscriptets tilstands- eller rateberegning. Den separate kontrol blev ikke startet. Original fejllog og scripts er bevaret. Tælleren producer_runs=1 betyder én indgang i producentfunktionen, ikke én udført fladeberegning.

Preflight blev i dette forsøg nået inde i producentens Context-oprettelse. Næste forsøg skal placere denne kontrol før registrering af en videnskabelig evaluering. Ingen versionsgate er ændret, og ingen ny kørsel er foretaget efter stoppet.

## Algebra til faglig gennemgang før genoptagelse

Med a=q/2, h=h_R, h_L=h-a er X_L=h+a og X_R=h. Derfor h_L X_L=h²-a². På E=0-fladen i V87 var produktet h(h-q); V87's lineære q/h-margin kan ikke genbruges.

Skriv U_R=alpha_R h²-b(1-h), U_L=alpha_L(h²-a²)-b(1-h+a), b=alpha_eq*s, s=Saha(TR)/nH. Hvis den arvede temperaturorden og kolde rateorden giver alpha_L≤alpha_R, fås med k=1-a²/h²:

U_L≤k U_R-b[a+a²(1-h)/h²]≤k U_R.

På en fælles gren, hvor C_L≤C_R, giver dette formelt d'/|f_R|≥a²/h², forudsat U_R>0 og de øvrige arvede præmisser. Dette er en analytisk arbejdsudledning; den konkrete flades domæne og numeriske margin er ikke certificeret i V113.

Selectoren bruger rå escape e(h)=Lya H/[nH(1-h)]. Ved fælles H og h_L<h_R fås e_L<e_R og P_L>P_R. Den mulige blandede rækkefølge er SWIFT i L, HMLA i R. Med c=((1/p-1)B-Lambda)/3 er korridoren e_L≤c<e_R. Lighed skal behandles med relevante ensidige felter. Disse symboler, enheder og kildeformler følger V87 og hyrec.c linje 429–541 og 1065–1076 i den indlejrede pin-verificerede kilde.

## Planlagt diagnostik — ikke kørt

produce113.py er en kandidatimplementation med en helcellegrænse fra V77 og ét deterministisk punkt valgt ved samme relative z som V87's gamle dispatch-eksempel, med den nye q/2-flade. Der er ingen parameter- eller gitterjagt. Scriptet bruger positive-polynomielle C-tællere og nævnere samt fulde U-led. control113.py bruger de oprindelige indlejrede Gamma-formler og DAlpha/Dxe-led samt en bredere arkiveret DK-grænse. Begge deler kildedata, atomtabeller, v20-rateinterpolation og MPFR-primitiver. Koden er kun syntakskontrolleret; der foreligger intet output fra disse metoder.

V112 bad om feltets fortegn under den fastlåste fælles baggrund. Et H valgt inde i en arkiveret helcelleboks er ikke i sig selv dokumenteret som H_Bstar(z). Den forberedte punktdiagnostik ville derfor højst kunne afvise tilstrækkeligheden af intervalrelaksationen, selv hvis en negativ afledt senere valideres. Der foreligger heller ingen dokumentation for, at den matchede bane besøger punktet. Denne afgrænsning skal fastholdes i enhver genoptagelse.

## Konsekvens

Ingen udvidelse af halv-q-domænet, ingen ny optisk værdi og ingen konklusion om det blandede felts fortegn optages. Den videnskabelige tilstand fra V112 videreføres med dette tekniske stop som ny provenance. Q052 er INCONCLUSIVE, og den aktuelle beregningsopgave er BLOCKED af runtimekravet.
