

---

# Q052 V124 — V123 optaget og bevægelig HMLA-grænse afgrænset

UTC 2026-11-21T12:05:04.646883+00:00. Run `LOCAL-Q052-V124-SIGNED-OPTICAL-UPDATE-INTAKE-AND-PRECISION-ROUTING`. Evidensgrænse Q052 gennem V124.
Motor BUBBLEVERSE.RESULT_INGESTION_ROUTING 2.3.0.
WORKFLOW_STATE READY_FOR_HANDOFF. SCIENTIFIC_STATE INCONCLUSIVE. TECHNICAL_STATE PASS.

## Oprindeligt spørgsmål

Under the pinned hillipop-ede_n3 source/configuration, the same fixed admitted common background and matched validated z=810 start state used by Q051, does the actual native CLASS/P6 low-z implementation produce q=xHeII=10^-6 versus q=0 electron-fraction and Thomson-optical-depth histories that are reproducible, trajectory-consistent with the literal source-real dynamics, and contained within Q051's uniform analytic bounds; and what are the realized sup|Delta x_e| and sup|Delta tau_T| with a validated numerical error certificate?

## Optaget delresultat

LOCAL-Q052-V123-C1 er optaget under de arvede kilde-, B★-, start- og
baneforudsætninger. Det betingede signerede kildeoptiske interval er
`381845896508367207321097/79228162514264337593543950336` til `28908876046131453968421139/633825300114114700748351602688`.
Global bredde er `25854108874064516309852363/633825300114114700748351602688`. Forbedringen fra V112-baseline
er 1.993968033 %. Bredden er cirka
10197.647865 gange det foreløbige mål 4×10⁻⁹.

Alle 32 V123-manifestmedlemmer og 40
V122-medlemmer er verificeret. De to gemte V123-metoder er eksakt enige
på 1.304 bidrag fra 1.292 V66-rækker. Alle 17 øvre bin-endepunkter,
de 13 nedre opdateringer, det beskyttede V111-område og journalpræfikset
er afstemt. De oprindelige to subprocesser bestod på samlet
1.070418499 sekunder. V124 anvender deres gemte receipts.
Nye optiske evalueringer, vægt-/feltberegninger, native par og
historieintegrationer er 0.

## Restbredde og præcis næste test

Størst restbredde ligger i 600:650 og er cirka
3.646847486600e-06. Med den eksplicit valgte algebraiske
opdeling q·W_u−b·W_l=(q−b)·W_l+q·(W_u−W_l) bidrager de to led
cirka 60.566895 % og
39.433105 % før gitterafrunding.
Opdelingen følger gemte masser og vægte. Dens led deler fysiske afhængigheder.

Den nye opgave bruger en bevægelig nedre grænse b(u), med
u=ln(811/(1+z)), b(650)=q/16 og b′=k_i(q−2b) i hver celle.
HMLA-sammenligningen fra V121 giver på kontaktfladen
E′≥[(q−2b)/h+b(q−b)/h²]|f_R|. En ny certificering af
k_i≤inf |f_R|/h giver den nødvendige strenge indadretning for den
bevægelige grænse. Den analytiske recurrence og en efterfølgende
optisk erstatningssum skal udføres i næste matematikrunde.

102 lukkede HMLA-forældre dækker [600,650], med afskæring i begge
ender. V62-rækker 319–420, V66-rækker 4441–4542 og V77-grupper
4–6 er identificeret med eksakte koordinater. Indgangen ved z650
har E>q/16 fra V121 og arvede tilstandsbokse. De nye rategrænser
skal kontrolleres på hele domænet. Raten k er endnu ikke beregnet.

Den faste metodeprøve kræver en lokal gain på mindst én procent af
bin-bredden, cirka 3.646847486600e-08, for en materiel metode-PASS.
Dette metodekrav er valgt i V124 og ligger fast før execution.
Kontrakten tillader 102 celler per metode, højst otte faste delstykker
per celle og 300 kombinerede execution-sekunder. Den stopper ved
første uafklarede obligatoriske kontrol. Hvert bidrag erstatter det
allerede krediterede bidrag på samme støtte.

Næste motor BUBBLEVERSE.MATHEMATICS 2.3.0. `Q052_MATEMATIKOPGAVE_V124.json` er
PREPARED_NOT_EXECUTED med fingeraftryk `0adf9ba942ab37f4fe9b5c81d0b28c9467c3718c08bf087ee4dab3d956afcf39`.
Q052's native krav og den globale optiske præcision står åbne.
CONTINUE_SAME_Q true. Ingen accepted-model-ændring.

## Proveniens, setup og point

GitHub-base `4fa7d7da940222d93c7749bd7843eb7559682536` matcher V123-leverancen og de to motorer
på seks kontrollerede git-blobs. Efter workspace-genstart er den
oprindeligt leverede V123-pakke gendannet med identisk SHA-256.
Denne journal bevarer alle 9629522 V123-bytes som præfiks.
Python/arkiver/rationalaritmetik og GitHub-læsning er observeret
tilgængelige. Matematikopgaven kræver rettet intervalaritmetik til
nye rate/log/exp-beregninger. Backend skal verificeres inden execution.
Lokale kontraktfelter og referencer er kontrolleret. Formel ekstern
schema-validering er ikke udført. Github-write er USER_UPLOAD_PENDING.

RUN_ID `LOCAL-Q052-V124-SIGNED-OPTICAL-UPDATE-INTAKE-AND-PRECISION-ROUTING`. EVENT_ID `Q052-ACTIVITY-SIGNED-OPTICAL-INTAKE-V124`.
PREVIOUS_POINTS_ENTRY `Q052-ACTIVITY-Q16-SIGNED-OPTICAL-V123`.
Analyse 30, beregning 10, kildesporing 10, validering 25.
RUN POINTS 75. TOTAL POINTS 14955. CYCLE PROGRESS 955/1000.
NEXT SOME MILESTONE 15000. POINTS TO NEXT PUBLICATION 45.
POINTS_STATE VERIFIED. PUBLICATION_STATE NOT_DUE.
Ingen ny tærskel eller udestående pakke. M001–M014 videreføres som leveret.

Redaktionelt skøn for V123-indtag med fuld receipt- og hashafstemning, en algebraisk opdeling af den største restbredde, genfinding af 102 HMLA-cellers forudsætninger samt afgrænsning af en ændret bevægelig kontaktflade. V123-beregninger, V121-bevis, historiske feltkørsler, pakning og genlevering giver ingen nye point.
