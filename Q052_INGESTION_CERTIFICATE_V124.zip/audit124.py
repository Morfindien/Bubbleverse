from pathlib import Path
from fractions import Fraction as F
from zipfile import ZipFile
import json,hashlib,io,datetime
R=Path(__file__).resolve().parent
P=R/'parent123'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(n):return json.loads((P/n).read_bytes())
def put(n,x):(R/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
t=read('Q052_RESULTATINDTAG_OPGAVE_V123.json');f=dict(t);fp=f.pop('fingerprint_sha256');assert sha(json.dumps(f,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==fp
assert t['target_q']=='Q052' and t['source_state_version']=='V123'
m=read('manifest123.json')
for x in m['members']:
 b=(P/x['path']).read_bytes();assert len(b)==x['size_bytes'] and sha(b)==x['sha256'],x['path']
for n,h in t['input_refs'].items():assert sha((P/n).read_bytes())==h,n
z=ZipFile(P/'history/Q052_INGESTION_CERTIFICATE_V122.zip');jm=json.loads(z.read('manifest122.json'))
for x in jm['members']:
 b=z.read(x['path']);assert len(b)==x['size_bytes'] and sha(b)==x['sha256']
prefix=z.read('Q052_INGESTION_OG_SAMLET_JOURNAL_V122.md');journal=(P/'Q052_MATEMATIK_OG_SAMLET_JOURNAL_V123.md').read_bytes()
assert journal==prefix+(P/'journal_append123.md').read_bytes()
assert sha(prefix)==m['parent_journal_sha256']
wzip=ZipFile(io.BytesIO(z.read('history/Q052_THOMSON_CERTIFICATE_V66.zip')));wraw=wzip.read('receipt.json');weights=json.loads(wraw)['source_segments'];assert sha(wraw)=='9589668abd3d3570b93e9bd92634da5b418467c0f6182ae2994f87acf87338fd'
v121=ZipFile(io.BytesIO(z.read('history/Q052_Q16_HMLA_CERTIFIKAT_V121.zip')))
for n in ['v19.json','v62.json','v77.json']:
 assert (R/'input'/n).read_bytes()==v121.read('input/v91/'+n)
a=read('primary123.json');b=read('control123.json');assert a==b
baseline=json.loads(z.read('baseline122.json'));geom=json.loads(z.read('geometry122.json'));assert len(a['rows'])==len(geom)==1304
prev=F(50);counts={k:0 for k in baseline['current_bins']};exact=F(0);rounded=F(0)
for r,g in zip(a['rows'],geom,strict=True):
 assert all(r[k]==v for k,v in g.items())
 lo,hi=map(F,r['z_ascending']);assert lo==prev<hi;prev=hi
 w=weights[r['V66_row']];assert F(w['z'][0])<=lo<hi<=F(w['z'][1])
 assert F(r['weight_lower'])==F(w['K_over_H_exact'][0])>0
 e=F(r['unrounded_lower']);safe=F(r['rounded_lower']);assert 0<=e-safe<F(1,2**100)
 exact+=e;rounded+=safe;counts[r['bin']]+=1
assert prev==F(a['protected_support'][0]) and counts=={k:v['pieces'] for k,v in a['bin_changes'].items()}
assert str(exact)==a['unrounded_gain'] and str(rounded)==a['gain'] and str(exact-rounded)==a['rounding_loss']
for name,old in baseline['current_bins'].items():
 v=a['current_bins'][name];gain=sum((F(r['rounded_lower']) for r in a['rows'] if r['bin']==name),F(0))
 assert v[1:]==old[1:] and F(v[0])==F(old[0])+gain and F(v[0])<=F(v[1])
assert [sum((F(v[i]) for v in a['current_bins'].values()),F(0)) for i in [0,1]]==list(map(F,a['new_global_interval']))
assert a['new_global_interval']==t['expected_exact_interval']
assert str(F(a['new_global_interval'][1])-F(a['new_global_interval'][0]))==a['global_width']==t['expected_width']
ex=read('execution123.json');assert ex['status']=='PASS' and len(ex['subprocesses'])==2 and all(x['returncode']==0 for x in ex['subprocesses']) and ex['wall_seconds_combined']<=120
for n,h in read('freeze123.json')['files'].items():
 if n.startswith('input/'):
  names={'task122.json':'Q052_MATEMATIKOPGAVE_V122.json','weights66.json':None,'v62.json':None}
  base=Path(n).name
  if base=='weights66.json':raw=wraw
  elif base=='v62.json':raw=(R/'input/v62.json').read_bytes()
  elif base in names:raw=z.read(names[base])
  else:
   matches=[x for x in z.namelist() if Path(x).name==base];assert len(matches)==1,(base,matches);raw=z.read(matches[0])
 else:raw=(P/n).read_bytes()
 assert sha(raw)==h,n
v62=json.loads((R/'input/v62.json').read_bytes());rates=json.loads((R/'input/v77.json').read_bytes());selected=[r for r in a['rows'] if r['bin']=='600:650'];assert len(selected)==102
inventory=[]
for r in reversed(selected):
 i=r['V62_row'];left,right=[v62['arms'][arm]['records'][i] for arm in 'LR'];assert left['H_per_s']==right['H_per_s'] and left['z']==right['z'];assert left['allowed_branches']==right['allowed_branches']==['HMLA']
 high,low=[F(float.fromhex(x)) for x in right['z']];aa,cc=map(F,r['z_ascending']);assert low<=aa<cc<=high
 group=i//64;g=rates['elasticity_blocks'][group];assert F(g['z'][1])<=aa<cc<=F(g['z'][0]);assert F(g['saha_over_h_squared_upper'])<1
 assert all(0<F(float.fromhex(x)) for x in right['H_per_s'])
 inventory.append({'V62_row_zero_based':i,'V66_row':r['V66_row'],'z_ascending':r['z_ascending'],'V77_group_zero_based':group,'inherited_initial_boxes':{arm:v62['arms'][arm]['records'][i]['initial'] for arm in 'LR'},'inherited_whole_boxes':{arm:v62['arms'][arm]['records'][i]['whole_source'] for arm in 'LR'},'H_per_s_hex':right['H_per_s'],'existing_mass':r['mass'],'existing_weight_lower':r['weight_lower'],'existing_lower_piece':r['rounded_lower']})
assert len(set(r['V62_row_zero_based'] for r in inventory))==102
# Arithmetic of archived weights and already computed polynomial masses.
D_e=sum((F(r['mass'])*F(weights[r['V66_row']]['K_over_H_exact'][0])*F(15,16000000) for r in selected),F(0))
D_w=sum((F(r['mass'])*(F(weights[r['V66_row']]['K_over_H_exact'][1])-F(weights[r['V66_row']]['K_over_H_exact'][0]))*F(1,1000000) for r in selected),F(0))
binwidth=F(a['current_bins']['600:650'][1])-F(a['current_bins']['600:650'][0]);assert abs(D_e+D_w-binwidth)<F(204,2**100)
rank=sorted([{'bin':k,'width':str(F(v[1])-F(v[0]))} for k,v in a['current_bins'].items()],key=lambda x:F(x['width']),reverse=True);assert rank[0]['bin']=='600:650'
ledger=read('activity_ledger123.json');assert sum(x['run_points'] for x in ledger['entries'])==ledger['total_points_after']==14880
put('inventory124.json',inventory)
put('precision124.json',{'arithmetic_only':True,'largest_bin':'600:650','current_bin_width':str(binwidth),'ranked_bins':rank,'algebraic_split_definition':'q*Wu-b*Wl = (q-b)*Wl + q*(Wu-Wl), using existing mass receipts','electron_floor_part':str(D_e),'weight_enclosure_part':str(D_w),'electron_part_fraction':str(D_e/(D_e+D_w)),'weight_part_fraction':str(D_w/(D_e+D_w)),'rounding_difference':str(binwidth-D_e-D_w),'interpretation':'Algebraic enclosure-width allocation under this specified split. Shared physical dependencies remain.','changed_test_domain':['600','650'],'moving_floor_entry':'1/16000000','coverage_rows':102,'V62_rows_zero_based':[319,420],'V77_groups_zero_based':sorted({r['V77_group_zero_based'] for r in inventory}),'material_gain_target':str(binwidth/100),'new_optical_evaluations':0,'new_weight_evaluations':0,'new_field_evaluations':0})
put('audit124.json',{'status':'PASS','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task_id':t['task_id'],'V123_manifest_members':len(m['members']),'V122_manifest_members':len(jm['members']),'parent_archive_sha256':sha(Path('recovery124/Q052_Q16_OPTISK_CERTIFIKAT_V123.zip').read_bytes()),'journal_prefix_bytes':len(journal),'journal_sha256':sha(journal),'accepted_claim':'LOCAL-Q052-V123-C1','global_interval':a['new_global_interval'],'global_width':a['global_width'],'gain':a['gain'],'reduction_fraction':a['global_width_reduction_fraction'],'goal_ratio':a['global_width_goal_ratio'],'piece_count':1304,'distinct_V66_rows':1292,'affected_bins':13,'all_receipts_exactly_equal':True,'upper_endpoints_preserved':17,'V111_overlap':'SHARED_ENDPOINT_ONLY','execution_wall_seconds_reused':ex['wall_seconds_combined'],'new_optical_evaluations':0,'new_weight_evaluations':0,'new_field_evaluations':0,'new_native_pairs':0,'new_integrations':0,'total_points_before':14880,'new_contract_geometry':'102 common-HMLA rows at z600 to650, V77 groups4,5,6','restored_input_archive':'Original V123 delivered file recovered by its retained Library ID and exact SHA-256 after workspace restart.'})
print(json.dumps({'status':'PASS','pieces':1304,'bin_width':float(binwidth),'electron_part':float(D_e/(D_e+D_w)),'weight_part':float(D_w/(D_e+D_w)),'groups':sorted({r['V77_group_zero_based'] for r in inventory})}))
