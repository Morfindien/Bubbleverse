from pathlib import Path
from fractions import Fraction as F
from datetime import datetime,timezone
from zipfile import ZipFile,ZIP_DEFLATED,ZIP_STORED
import json,hashlib,shutil,ast
R=Path(__file__).resolve().parent;B=R.parent.parent;P=R/'parent123';O=B/'output/V124';O.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def read(n):return json.loads((R/n).read_bytes())
def put(n,x):(R/n).write_bytes(enc(x))
def fingerprint(x):return sha(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
a=read('audit124.json');d=read('precision124.json');repo=read('repository124.json');old=json.loads((P/'Q052_RESULTATINDTAG_OPGAVE_V123.json').read_bytes());res=json.loads((P/'result123.json').read_bytes());now=datetime.now(timezone.utc).isoformat()
SHORT='Q052_KORT_RESULTAT_V124.md';J='Q052_INGESTION_OG_SAMLET_JOURNAL_V124.md';NEXT='Q052_MATEMATIKOPGAVE_V124.json';ZIP='Q052_INGESTION_CERTIFICATE_V124.zip';files=[SHORT,J,NEXT,ZIP]
rid=old['task_id'];event='Q052-ACTIVITY-SIGNED-OPTICAL-INTAKE-V124';parts={'analysis_points':30,'computation_points':10,'search_points':10,'validation_points':25};points=sum(parts.values());total=14880+points
basis='Redaktionelt skøn for V123-indtag med fuld receipt- og hashafstemning, en algebraisk opdeling af den største restbredde, genfinding af 102 HMLA-cellers forudsætninger samt afgrænsning af en ændret bevægelig kontaktflade. V123-beregninger, V121-bevis, historiske feltkørsler, pakning og genlevering giver ingen nye point.'
lraw=(P/'activity_ledger123.json').read_bytes();ledger=json.loads(lraw);prior_event=ledger['entries'][-1]['activity_event_id'];assert ledger['total_points_after']==14880 and not ledger['pending_packages']
assert all(e['run_id']!=rid for e in ledger['entries'])
ledger['entries'].append({'run_id':rid,'activity_event_id':event,'engine':'BUBBLEVERSE.RESULT_INGESTION_ROUTING 2.3.0','run_points':points,'breakdown':parts,'basis':basis,'counted_once':True})
ledger.update({'ledger_revision':'V124','previous_ledger_ref':'history/Q052_Q16_OPTISK_CERTIFIKAT_V123.zip!activity_ledger123.json','parent_ledger_sha256':sha(lraw),'previous_total_points':14880,'total_points_after':total,'cycle_progress':total%1000,'next_publication_at':15000,'points_to_next_publication':15000-total,'new_milestones':[],'last_updated_utc':now,'reconciliation':{'prior_total':14880,'new_unique_event_points':points,'current_total':total,'old_entries_preserved':True},'note':'One V124 intake event added. M001–M014 delivery history inherited.'})
assert sum(e['run_points'] for e in ledger['entries'])==total==14955
put('activity_ledger124.json',ledger)
refs={n:sha((R/n).read_bytes()) for n in ['audit124.json','precision124.json','inventory124.json','activity_ledger124.json','input/v19.json','input/v62.json','input/v77.json']}
task={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','state':'PREPARED_NOT_EXECUTED','task_id':'LOCAL-Q052-V125-HMLA-MOVING-FLOOR-650-TO-600','engine':'BUBBLEVERSE.MATHEMATICS 2.3.0','case_id':old['case_id'],'current_q':'Q052','target_q':'Q052','continue_same_q':True,'exact_question':old['exact_question'],'source_state_version':'V124','evidence_boundary':'Q052 through V124','journal_ref':J,'input_archive':ZIP,'input_refs':refs,'parent_archive':'history/Q052_Q16_OPTISK_CERTIFIKAT_V123.zip','source_commit':old['source_commit'],'capture_sha256':old['capture_sha256'],'background_dependency_id':old['background_dependency_id'],'engine_prompt_sha256':'e2208bf1addc384fa9f8736584433038b568e20fefb775a1b61caa5a52e36ebc','objective':'Test one evolving HMLA comparison floor initialized from V121 at z650, then quantify its certified lower-bound gain on the largest remaining optical bin.','target':{'z_ascending':['600','650'],'q':'1/1000000','initial_b':'1/16000000','maximum_b':'1/2000000','V62_rows_zero_based':[319,420],'V66_rows_zero_based':[4441,4542],'pieces':102,'V77_groups_zero_based':[4,5,6],'traversal':'decreasing z, increasing u=ln(811/(1+z))','entry_certificate':'LOCAL-Q052-V121-C1 gives E>q/16 at z650 under inherited premises','entry_state_boxes':'inventory124.json first record contains inherited full-cell boxes covering z650. First parent begins above650 and is clipped at650. Entry E is a comparison-floor condition, not an attained point estimate.','exit':'z600 inside V62 row420, clipped at600','weight_receipt':'parent V123 archive!history/Q052_INGESTION_CERTIFICATE_V122.zip!history/Q052_THOMSON_CERTIFICATE_V66.zip!receipt.json','preserved_baseline_interval':a['global_interval'],'preserved_bin_interval':res['current_bins']['600:650'],'material_gain_target':d['material_gain_target'],'material_gain_definition':'At least one percent of the previous 600:650 bin width, approximately 3.64685e-8. This is a predeclared local method-success criterion.','provisional_global_width_goal':'1/250000000'},'equations':{'state':'E=h_L+q-h_R, h=h_R, u=ln(811/(1+z)), b0=q/16','HMLA':'f_R=-(n_H/H_s) sum_i C_R,i [alpha_R,i*h^2-sigma_i*(1-h)] < 0','contact':'For b in [q/16,q/2], P=(h-q+b)(h+b), D=(q-2b)*h+b*(q-b). Inherited full-Saha and common-HMLA comparison yields E_prime >= (D/h^2)*abs(f_R) >= (q-2b)*abs(f_R)/h.','rate':'Each closed parent cell must certify k_i <= inf[-f_R/h] over its applicable R source box. k_i must be positive and have units per dimensionless u.','barrier':'b_prime=k_i*(q-2b). b_next=q/2-(q/2-b_entry)*exp(-2*k_i*Delta_u). Delta_u=ln((1+z_high)/(1+z_low)).','strict_comparison':'At contact E=b, E_prime-b_prime >= b*(q-b)*abs(f_R)/h^2 >0 after certified rate inequality. Establish applicability over all b attained in that cell, including clipped endpoints.','local_optical_bound':'Use b_entry, the minimum b on the closed decreasing-z piece, as a constant local floor. L_new=floor(2^100*W_lower*mass*b_entry_lower)/2^100. The old per-piece L_old is in V123. Additional gain is max(0,L_new-L_old). Replace the old lower contribution on identical support.'},'units':{'E_h_q_b':'dimensionless fractions per hydrogen nucleus','z_u':'dimensionless','H_s':'s^-1','n_H':'cm^-3','alpha':'cm^3 s^-1','W_and_F':'dimensionless in original V66 convention'},'primary':['Verify all pins and exact geometry before execution. Reuse V121 global sign/temperature-order and HMLA premises, V77 rate/table domains and the original background.','Freeze implementation hashes and interval precision before new field evaluations. Use 256-bit MPFR directed rounding or a verified equivalent. Record the actual backend.','For all 102 closed parent boxes, validate positive common H, HMLA-only masks, positive recombination driving term, Saha bound, temperature/rate applicability, and equality of source and optical coordinates.','Compute a conservative lower bound on -f_R/h with the complete literal HMLA field and full Saha term. Treat h and v dependencies by enclosing the full box or a predeclared fixed partition. No point sample is a whole-box certificate.','Prove the moving-contact comparison for all b between its certified entry and exit bounds. Propagate b with directed log and exp across the clipped z-pieces. Verify positive continuity across each join.','After separate rate controls pass, use the agreed conservative k_i values, frozen V66 W_lower values and existing exact mass receipts for one lower-bound sum. Replace only the existing 102 lower contributions in bin600:650 and form the global interval. Report actual gain, rounding loss, bin/global width and material-gain criterion.'],'separate_control':['Run a separate process without primary code imports or producer output access while deriving rate bounds. Independently decode hexadecimal inputs and reconstruct the 102-row correspondence from full V62/V66 geometry.','Use a factored positive HMLA/Saha bound or a separately implemented directed interval evaluator for -f_R/h. The primary and control raw k bounds may differ. Freeze the usable k_i as the smaller certified bound after both passes, with explicit proof that each bounds the same domain.','Independently validate the moving-barrier recurrence with interval exponentials or an independently certified remainder bound, exact support replacement and final directed arithmetic. Check all primary local bounds are justified. If a lower safe bound must be substituted, record its exact identity before the one final sum.','Require both controls to certify the same final chosen lower contributions and updated bins. Shared source tables and backend limitations must be disclosed.'],'acceptance_criteria':'All 102 source/contact domains and independent rate/barrier controls pass, and the directed replacement gives a strictly positive lower gain. A material method PASS additionally requires gain at least the frozen one-percent bin-width target.','rejection_criteria':'A certified failed inward/rate premise or unattained material-gain criterion rejects this candidate method at the documented scope. Preserve any valid partial moving-floor prefix as such.','inconclusive_criteria':'A missing rate/table/domain input, nonpositive interval lower rate, unresolved control discrepancy or runtime limit prevents full-domain promotion. Record the first unresolved cell and any certified prefix.','execution_limits':{'wall_seconds_combined':300,'max_source_cells_per_method':102,'max_fixed_subpieces_per_cell':8,'primary_rate_passes':1,'independent_rate_controls':1,'final_optical_lower_sums':1,'independent_optical_arithmetic_controls':1,'new_weight_evaluations':0,'new_native_pairs':0,'new_scalar_trajectory_integrations':0,'new_full_history_integrations':0,'parameter_searches':0},'stop_condition':'Stop at the first unresolved mandatory source/control gate, after one full dual-method result and lower-sum agreement, or after 300 combined execution seconds.','expected_output':'Moving-floor proof and 102-cell rate receipts, independent control, actual lower-gain result or concrete obstruction, appended journal and one result-intake task.','return_engine':'BUBBLEVERSE.RESULT_INGESTION_ROUTING 2.3.0','no_repeat':old['no_repeat']+['V124 intake and algebraic width decomposition are completed.','Reuse V123 optical lower contributions and V121 constant-q/16 proof as baseline evidence.','The V125 change is a moving comparison floor. Its new field bounds and derived optical replacement require actual execution.','A new H or background convention requires a separate applicability proof.','Any counter for trajectory integrations must distinguish the analytic barrier recurrence from physical state integration.'],'total_points':total,'next_milestone':15000,'points_to_next_publication':45,'activity_ledger_ref':'activity_ledger124.json','publication_state':'NOT_DUE','max_deliverable_bytes':25000000}
task['fingerprint_sha256']=fingerprint(task);(O/NEXT).write_bytes(enc(task))
source={'target_q':'Q052','evidence_boundary':'Q052 through V124','repository_commit':repo['commit'],'repository_files':repo['files'],'accepted_claim_map':{'LOCAL-Q052-V123-C1':['history/Q052_Q16_OPTISK_CERTIFIKAT_V123.zip!PROOF_V123.md','history/Q052_Q16_OPTISK_CERTIFIKAT_V123.zip!primary123.json','history/Q052_Q16_OPTISK_CERTIFIKAT_V123.zip!control123.json','audit124.json']},'next_task_premises':['LOCAL-Q052-V121-C1','input/v62.json','input/v77.json','input/v19.json','inventory124.json'],'remaining_uncertainties':['Global source-optical precision','Actual native background admission, coordinate/trajectory consistency, reproducibility and validated whole-history error'],'new_external_physical_data':'NONE','new_execution':'Stored-receipt arithmetic and eligibility audit only'};put('source_register124.json',source)
memory={'repository':'Morfindien/Bubbleverse','branch':'main','verified_base':repo['commit'],'github_read_state':'VERIFIED','github_write_state':'READY_FOR_MANUAL_UPLOAD','sync_status':'USER_UPLOAD_PENDING','target_q':'Q052','journal':J,'next_task':NEXT,'upload_new_root_files':files,'instructions':'Upload the four new V124 files at repository root and update current Q052 journal/task pointers. Preserve historical versions.','proposed_index_updates':{'case':'Q052 ACTIVE / INCONCLUSIVE','journal':J,'accepted_result':'LOCAL-Q052-V123-C1','task':NEXT,'total_points':total,'publication_state':'NOT_DUE'},'hashes_ref':'manifest124.json','completed_intake':rid};put('github_memory_update124.json',memory)
append=f'''

---

# Q052 V124 — V123 optaget og bevægelig HMLA-grænse afgrænset

UTC {now}. Run `{rid}`. Evidensgrænse Q052 gennem V124.
Motor BUBBLEVERSE.RESULT_INGESTION_ROUTING 2.3.0.
WORKFLOW_STATE READY_FOR_HANDOFF. SCIENTIFIC_STATE INCONCLUSIVE. TECHNICAL_STATE PASS.

## Oprindeligt spørgsmål

{old['exact_question']}

## Optaget delresultat

LOCAL-Q052-V123-C1 er optaget under de arvede kilde-, B★-, start- og
baneforudsætninger. Det betingede signerede kildeoptiske interval er
`{a['global_interval'][0]}` til `{a['global_interval'][1]}`.
Global bredde er `{a['global_width']}`. Forbedringen fra V112-baseline
er {100*float(F(a['reduction_fraction'])):.9f} %. Bredden er cirka
{float(F(a['goal_ratio'])):.6f} gange det foreløbige mål 4×10⁻⁹.

Alle {a['V123_manifest_members']} V123-manifestmedlemmer og {a['V122_manifest_members']}
V122-medlemmer er verificeret. De to gemte V123-metoder er eksakt enige
på 1.304 bidrag fra 1.292 V66-rækker. Alle 17 øvre bin-endepunkter,
de 13 nedre opdateringer, det beskyttede V111-område og journalpræfikset
er afstemt. De oprindelige to subprocesser bestod på samlet
{a['execution_wall_seconds_reused']:.9f} sekunder. V124 anvender deres gemte receipts.
Nye optiske evalueringer, vægt-/feltberegninger, native par og
historieintegrationer er 0.

## Restbredde og præcis næste test

Størst restbredde ligger i 600:650 og er cirka
{float(F(d['current_bin_width'])):.12e}. Med den eksplicit valgte algebraiske
opdeling q·W_u−b·W_l=(q−b)·W_l+q·(W_u−W_l) bidrager de to led
cirka {100*float(F(d['electron_part_fraction'])):.6f} % og
{100*float(F(d['weight_part_fraction'])):.6f} % før gitterafrunding.
Opdelingen følger gemte masser og vægte. Dens led deler fysiske afhængigheder.

Den nye opgave bruger en bevægelig nedre grænse b(u), med
u=ln(811/(1+z)), b(650)=q/16 og b′=k_i(q−2b) i hver celle.
HMLA-sammenligningen fra V121 giver på kontaktfladen
E′≥[(q−2b)/h+b(q−b)/h²]|f_R|. En ny certificering af
k_i≤inf |f_R|/h giver den nødvendige strenge indadretning for den
bevægelige grænse. Den analytiske recurrence og en efterfølgende
optisk erstatningssum skal udføres i næste matematikrunde.

102 lukkede HMLA-forældre dækker [600,650], med afskæring i begge
ender. V62-rækker 319–420, V66-rækker 4441–4542 og V77-grupper
4–6 er identificeret med eksakte koordinater. Indgangen ved z650
har E>q/16 fra V121 og arvede tilstandsbokse. De nye rategrænser
skal kontrolleres på hele domænet. Raten k er endnu ikke beregnet.

Den faste metodeprøve kræver en lokal gain på mindst én procent af
bin-bredden, cirka {float(F(d['material_gain_target'])):.12e}, for en materiel metode-PASS.
Dette metodekrav er valgt i V124 og ligger fast før execution.
Kontrakten tillader 102 celler per metode, højst otte faste delstykker
per celle og 300 kombinerede execution-sekunder. Den stopper ved
første uafklarede obligatoriske kontrol. Hvert bidrag erstatter det
allerede krediterede bidrag på samme støtte.

Næste motor BUBBLEVERSE.MATHEMATICS 2.3.0. `{NEXT}` er
PREPARED_NOT_EXECUTED med fingeraftryk `{task['fingerprint_sha256']}`.
Q052's native krav og den globale optiske præcision står åbne.
CONTINUE_SAME_Q true. Ingen accepted-model-ændring.

## Proveniens, setup og point

GitHub-base `{repo['commit']}` matcher V123-leverancen og de to motorer
på seks kontrollerede git-blobs. Efter workspace-genstart er den
oprindeligt leverede V123-pakke gendannet med identisk SHA-256.
Denne journal bevarer alle {a['journal_prefix_bytes']} V123-bytes som præfiks.
Python/arkiver/rationalaritmetik og GitHub-læsning er observeret
tilgængelige. Matematikopgaven kræver rettet intervalaritmetik til
nye rate/log/exp-beregninger. Backend skal verificeres inden execution.
Lokale kontraktfelter og referencer er kontrolleret. Formel ekstern
schema-validering er ikke udført. Github-write er USER_UPLOAD_PENDING.

RUN_ID `{rid}`. EVENT_ID `{event}`.
PREVIOUS_POINTS_ENTRY `{prior_event}`.
Analyse 30, beregning 10, kildesporing 10, validering 25.
RUN POINTS 75. TOTAL POINTS {total}. CYCLE PROGRESS 955/1000.
NEXT SOME MILESTONE 15000. POINTS TO NEXT PUBLICATION 45.
POINTS_STATE VERIFIED. PUBLICATION_STATE NOT_DUE.
Ingen ny tærskel eller udestående pakke. M001–M014 videreføres som leveret.

{basis}
'''
(R/'journal_append124.md').write_text(append)
prefix=(P/'Q052_MATEMATIK_OG_SAMLET_JOURNAL_V123.md').read_bytes();(O/J).write_bytes(prefix+append.encode())
report=f'''# BUBBLEVERSE — OVERLEVERING

**V123 er optaget. Næste test skal skærpe elektronundergrænsen gennem 102 HMLA-celler.**

Q052 fortsætter med SCIENTIFIC_STATE INCONCLUSIVE og TECHNICAL_STATE PASS.
WORKFLOW_STATE READY_FOR_HANDOFF. Resultatindtag og routing 2.3.0.
Evidensgrænsen er Q052 gennem V124.

Det optagne betingede Thomson-interval er cirka
[4,81957×10⁻⁶, 4,56102×10⁻⁵]. Det er dimensionløst.
V123 indsnævrede bredden med 1,993968 %. Bredden er cirka
10.197,65 gange det foreløbige præcisionsmål. De faktiske native
baner og deres validerede numeriske fejl står fortsat åbne.

V124 har kontrolleret hashes, journalpræfiks, begge gemte V123-receipts,
1.304 bidrag, 13 ændrede nedre bins og de 17 øvre endepunkter.
De arvede kilde-, baggrunds- og baneforudsætninger følger resultatet.

Det største restinterval ligger ved z=600–650. En eksplicit algebraisk
opdeling fordeler dets bredde med cirka 60,6 % på elektronleddet og
39,4 % på vægtleddet. Beregningen bygger på gemte masser og vægte.

Næste matematikopgave starter med den certificerede q/16-grænse ved
z650 og tester en voksende sammenligningsgrænse gennem 102 celler.
Den skal certificere rekombinationsratens nødvendige undergrænser,
kontrollere dem med en separat metode og måle den optiske gain.
Jeg har fastlagt én procent af dette bins bredde som kriterium for
en materiel metodeforbedring. Kriteriet ligger fast før næste kørsel.
Kontrakten har en grænse på 300 kombinerede execution-sekunder.
Næste test er forberedt og afventer Matematikmotor 2.3.0.

Den fulde oprindelige Q-formulering, bevisafhængigheder, ligninger,
kontrolkrav og stopregel følger `{NEXT}`. `{J}` indeholder hele
V123-journalen og én ny V124-post. I pakken ligger også
`audit124.json`, `precision124.json`, `inventory124.json`, ledger,
kildeoversigt og den oprindelige V123-pakke.

GitHub-base er `{repo['commit']}`. V123-leverancen og begge motorer
matcher repositoryets bytes. De fire nye V124-filer er uploadklare
til repositoryets rod. GitHub-synkronisering af V124 afventer din upload.

Setup er lokal Python med eksakt rationalaritmetik og GitHub-læsning.
Næste opgave skal verificere sin rettede intervalbackend før rate-
og eksponentialberegninger. Samme setup er anbefalet, med konkret
backend-recovery hvis den nødvendige intervalaritmetik mangler.
Kilder og scope er fastholdt i `source_register124.json`.

Runden giver 75 point, begrundet i det nye indtag og metodeforberedelsen.
Totalen er **14.955**, og der er **45 point til næste SoMe-pakke**.
Ingen ny milepæl er nået. M001–M014 videreføres som leveret.
'''
(O/SHORT).write_text(report)
handoff={'schema_id':'bubbleverse.result_ingestion_handoff','schema_version':'3.0.0','schema_validation':'LOCAL_FIELD_AND_REFERENCE_CHECK','prompt_id':'bubbleverse.result_ingestion_routing','prompt_version':'2.3.0','handoff_id':rid,'created_at_utc':now,'case_id':old['case_id'],'current_q':'Q052','target_q':'Q052','exact_question':old['exact_question'],'evidence_cutoff':'Q052 through V124','case_lifecycle':'ACTIVE','disposition':'CONTINUE','epistemic_status':'INCONCLUSIVE','ingestion_state':'ACCEPTED_CONDITIONAL_SOURCE_REAL','new_result_ids':['LOCAL-Q052-V123-C1'],'source_state_version':'V123','target_state_version':'V124','selected_next_engine_id':task['engine'],'engine_registry_ref':'Bubbleverse_Matematikmotor_2.3.0.md at '+repo['commit'],'execution_profile_ref':'Python archive/rational audit observed; next rate/log/exp backend must be verified before execution.','journal_ref':J,'source_register_ref':'source_register124.json','claim_evidence_map_ref':'source_register124.json#accepted_claim_map','result_provenance_ref':'audit124.json','anomaly_tension_registry_ref':'source_register124.json#remaining_uncertainties','completed_task_ledger_ref':'github_memory_update124.json#completed_intake','route_history_ref':'github_memory_update124.json','integrity_manifest_ref':'manifest124.json','closure_snapshot_ref':None,'what_changed':['V123 conditional interval admitted','Largest-bin width allocation audited','One 102-cell moving-HMLA-floor test frozen'],'frozen_configuration_refs':['input/v19.json','input/v62.json','input/v77.json'],'open_material_uncertainties':source['remaining_uncertainties'],'missing_information':['Native whole-history numerical-error certificate','Actual rate lower bounds for the next moving comparison floor'],'next_task':NEXT,'success_condition':task['acceptance_criteria'],'failure_or_falsification_condition':task['rejection_criteria'],'stop_condition':task['stop_condition'],'completion_gate_satisfied':False,'completion_gate_reason':'Global source-optical precision and actual native certification obligations remain open.','handoff_completeness':'COMPLETE_FOR_BOUNDED_CONTINUATION','writeback_status':'USER_UPLOAD_PENDING','delivery_status':'FILES_PREPARED','operator_gate':'Same authorized Q052','output_file_refs':files,'output_manifest_ref':'manifest124.json','repository_memory':{'repository_url':'https://github.com/Morfindien/Bubbleverse','base_commit_sha':repo['commit'],'source_freshness':'VERIFIED','journal_path':J,'memory_update_ref':'github_memory_update124.json','target_paths_status':'EXISTING_ROOT_CONVENTION','sync_status':'USER_UPLOAD_PENDING'},'question_activity_points':{'policy_id':'bubbleverse.question_activity_some_milestones','policy_version':'2.0.0','ledger_id':'Q052','ledger_ref':'activity_ledger124.json','ledger_version':'V124','parent_ledger_version':'V123','run_id':rid,'activity_event_id':event,'parent_total_pts':14880,'assessed_run_points':points,'assessment_breakdown':parts,'assessment_basis':basis,'assessment_confidence':'HEURISTIC','inherited_event_ids':[prior_event],'newly_applied_event_ids':[event],'total_pts':total,'status':'VERIFIED'},'some_milestones':{'interval_pts':1000,'highest_threshold_reached_pts':14000,'crossed_this_run':[],'ready_package_ids':[],'pending_milestones':[],'next_threshold_pts':15000,'points_to_next_threshold':45,'milestone_ledger_ref':'activity_ledger124.json','package_file_refs':[],'package_creation_status':'NOT_DUE','external_publication_status':'NOT_REQUESTED','scientific_route_changed_by_points':False}}
put('handoff124.json',handoff)
(R/'LAES_MIG_V124.txt').write_text('Q052 V124\n\nStart med '+SHORT+'. Næste motor er Matematikmotor 2.3.0.\n'+NEXT+' er den ene nye opgave.\n\nDen komplette nye journal leveres separat som '+J+'.\nPakken indeholder V123-journalen i det oprindelige V123-arkiv og journal_append124.md.\npython verify124.py gendanner den nye journal i identiske bytes og kontrollerer alle pakkefiler.\nDenne kommando udfører fil- og receiptkontrol.\n\nUpload de fire V124-leverancer til repositoryets rod. Alle er under 25.000.000 bytes.\n')
validator='''from pathlib import Path
from zipfile import ZipFile
import json,hashlib
R=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((R/'manifest124.json').read_bytes())
for x in m['members']:
 b=(R/x['path']).read_bytes();assert len(b)==x['size_bytes'] and sha(b)==x['sha256'],x['path']
t=json.loads((R/'Q052_MATEMATIKOPGAVE_V124.json').read_bytes());fp=t.pop('fingerprint_sha256')
assert sha(json.dumps(t,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==fp
for n,h in t['input_refs'].items():assert sha((R/n).read_bytes())==h,n
z=ZipFile(R/'history/Q052_Q16_OPTISK_CERTIFIKAT_V123.zip')
prefix=z.read('Q052_MATEMATIK_OG_SAMLET_JOURNAL_V123.md')
assert sha(prefix)==m['parent_journal_sha256']
journal=prefix+(R/'journal_append124.md').read_bytes()
assert sha(journal)==m['journal_sha256']
p=R/'Q052_INGESTION_OG_SAMLET_JOURNAL_V124.md'
if p.exists():assert p.read_bytes()==journal
else:p.write_bytes(journal)
ledger=json.loads((R/'activity_ledger124.json').read_bytes());old=json.loads(z.read('activity_ledger123.json'))
assert ledger['entries'][:-1]==old['entries'] and sum(e['run_points'] for e in ledger['entries'])==14955
assert json.loads((R/'handoff124.json').read_bytes())['exact_question']==t['exact_question']
print(json.dumps({'status':'PASS','members':len(m['members']),'journal_bytes':len(journal),'total_points':14955,'new_field_or_optical_evaluations':0}))
'''
(R/'verify124.py').write_text(validator)
stage=R/'package';stage.mkdir(exist_ok=True);(stage/'history').mkdir(exist_ok=True);(stage/'input').mkdir(exist_ok=True)
for n in ['audit124.py','build124.py','audit124.json','precision124.json','inventory124.json','repository124.json','activity_ledger124.json','source_register124.json','github_memory_update124.json','handoff124.json','journal_append124.md','LAES_MIG_V124.txt','verify124.py']:
 shutil.copyfile(R/n,stage/n)
for n in ['v19.json','v62.json','v77.json']:shutil.copyfile(R/'input'/n,stage/'input'/n)
for n in [SHORT,NEXT]:shutil.copyfile(O/n,stage/n)
shutil.copyfile(B/'recovery124/Q052_Q16_OPTISK_CERTIFIKAT_V123.zip',stage/'history/Q052_Q16_OPTISK_CERTIFIKAT_V123.zip')
members=[{'path':str(f.relative_to(stage)),'size_bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in sorted(stage.rglob('*')) if f.is_file() and f.name!='manifest124.json']
manifest={'version':'V124','target_q':'Q052','run_id':rid,'created_utc':now,'parent_journal_sha256':sha(prefix),'parent_prefix_bytes':len(prefix),'append_sha256':sha(append.encode()),'journal_sha256':sha((O/J).read_bytes()),'journal_packaging':'Full V124 journal delivered separately and reconstructed from embedded original V123 journal plus one append by verify124.py.','members':members,'github_memory_update':memory,'max_deliverable_bytes':25000000,'self_hash_convention':'Manifest excludes itself. Archive hash recorded in detached delivery receipt.','external_deliverables':[{'name':n,'role':'journal' if n==J else 'next_task' if n==NEXT else 'report','size_bytes':(O/n).stat().st_size,'sha256':sha((O/n).read_bytes()),'repository_relative_path':n,'status':'NEW'} for n in [SHORT,J,NEXT]]}
(stage/'manifest124.json').write_bytes(enc(manifest))
for p in stage.glob('*.py'):ast.parse(p.read_text())
with ZipFile(O/ZIP,'w',compression=ZIP_DEFLATED,compresslevel=9,allowZip64=False) as z:
 for f in sorted(stage.rglob('*')):
  if f.is_file():z.write(f,str(f.relative_to(stage)),compress_type=ZIP_STORED if f.suffix=='.zip' else ZIP_DEFLATED)
with ZipFile(O/ZIP) as z:
 assert z.testzip() is None
 for x in members:assert sha(z.read(x['path']))==x['sha256']
 for n in z.namelist():
  if n.endswith('.json'):json.loads(z.read(n))
assert all((O/n).stat().st_size<25000000 for n in files)
put('delivery124.json',{'status':'PASS','files':[{'name':n,'path':str(O/n),'size_bytes':(O/n).stat().st_size,'sha256':sha((O/n).read_bytes())} for n in files],'zip_crc':'PASS','all_json_parse':'PASS','all_members_verified':True})
print((R/'delivery124.json').read_text())
