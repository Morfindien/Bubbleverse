from pathlib import Path
from zipfile import ZipFile
import json,hashlib
R=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((R/'manifest124.json').read_bytes())
for x in m['members']:
 b=(R/x['path']).read_bytes();assert len(b)==x['size_bytes'] and sha(b)==x['sha256'],x['path']
t=json.loads((R/'Q052_MATEMATIKOPGAVE_V124.json').read_bytes());fp=t.pop('fingerprint_sha256')
assert sha(json.dumps(t,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==fp
for n,h in t['input_refs'].items():assert sha((R/n).read_bytes())==h,n
z=ZipFile(R/'history/Q052_Q16_OPTISK_CERTIFIKAT_V123.zip')
prefix=z.read('Q052_MATEMATIK_OG_SAMLET_JOURNAL_V123.md')
assert sha(prefix)==m['parent_journal_sha256']
journal=prefix+(R/'journal_append124.md').read_bytes()
assert sha(journal)==m['journal_sha256']
p=R/'Q052_INGESTION_OG_SAMLET_JOURNAL_V124.md'
if p.exists():assert p.read_bytes()==journal
else:p.write_bytes(journal)
ledger=json.loads((R/'activity_ledger124.json').read_bytes());old=json.loads(z.read('activity_ledger123.json'))
assert ledger['entries'][:-1]==old['entries'] and sum(e['run_points'] for e in ledger['entries'])==14955
assert json.loads((R/'handoff124.json').read_bytes())['exact_question']==t['exact_question']
print(json.dumps({'status':'PASS','members':len(m['members']),'journal_bytes':len(journal),'total_points':14955,'new_field_or_optical_evaluations':0}))
