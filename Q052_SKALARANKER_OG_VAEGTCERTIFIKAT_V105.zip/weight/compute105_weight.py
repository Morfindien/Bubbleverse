"""V99: one bounded source-weight evaluation; Python standard library only."""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
import json, hashlib, time, sys

P = Path(__file__).resolve().parent
S = 1 << 160
T = 1 << 100
Q = F(1, 1000000)
def read(n): return json.loads((P/n).read_bytes())
def sha(n): return hashlib.sha256((P/n).read_bytes()).hexdigest()
def emit(n, x): (P/n).write_text(json.dumps(x, ensure_ascii=False, indent=2)+'\n')
def hx(x): return F.from_float(float.fromhex(x))
def down(x, s=S): return F((x*s).__floor__(), s)
def up(x, s=S): return F((x*s).__ceil__(), s)
def root(x):
    assert x >= 0
    k = isqrt(x.numerator*S*S // x.denominator)
    lo = F(k, S)
    hi = lo if lo*lo == x else F(k+1, S)
    assert lo*lo <= x <= hi*hi and hi-lo <= F(1,S)
    return lo, hi
def strings(xs): return list(map(str, xs))

def main():
    start = time.monotonic()
    anchor=read("anchor105.json")
    assert anchor["target_reached"] and anchor["certified_end_a"]=="1/801"
    anchor_cap=F(anchor["energy"][1])
    pins = read('pins.json')
    for n,h in pins.items(): assert sha(n)==h, n
    task, old, v66 = read('task98.json'), read('result97.json'), read('v66.json')
    bind, guard, valid, cp, v73 = [read(n) for n in ['binding.json','guard.json','guard_validation.json','checkpoint.json','v73.json']]
    cap = read('capture.json'); case = cap['cases']['hillipop-ede_n3']; bg = case['background']
    for obj in [bind,guard,cp,v73]: assert obj['capture_sha256']==sha('capture.json')
    for obj in [bind,cp,v73]: assert obj['guard_sha256']==sha('guard.json')
    assert bind['checkpoint_sha256']==v73['v151_sha256']==sha('checkpoint.json')
    assert valid['technical_state']=='PASS' and valid['phase']=='FINAL'
    assert valid['result_sha256']==sha('guard.json') and valid['checks_total']==valid['checks_passed']==6566
    assert valid['mutations_total']==valid['mutations_rejected']==24
    assert bind['source_commit']==guard['source_commit']==task['source_commit']==cap['source_commit']
    dep = bind['background_dependency_id']
    assert all(x['background_dependency_id']==dep for x in bind['q_branches'])
    assert [F(x['q']) for x in bind['q_branches']]==[Q,F(0)]
    fields = {k:hx(v) for k,v in bg['fields'].items()}
    assert fields['K']==fields['Omega0_lambda']==0
    assert bg['flags']=={'has_scf':1,'has_lambda':0,'has_cdm':1,'has_ncdm':1,'has_ur':1,'has_idm':0,'has_idr':0,'has_dcdm':0,'has_dr':0,'has_fld':0,'has_curvature':0}
    assert bg['N_ncdm']==len(bg['neutrinos'])==1
    nu=bg['neutrinos'][0]; nf={k:hx(v) for k,v in nu['fields'].items()}
    nodes=list(zip(map(hx,nu['q_ncdm_bg']),map(hx,nu['w_ncdm_bg'])))
    assert len(nodes)==len(nu['q_ncdm_bg'])==len(nu['w_ncdm_bg'])==11
    assert all(q>0 and w>0 for q,w in nodes) and nf['M_ncdm']>0 and nf['factor_ncdm']>0
    matter=fields['H0']**2*(fields['Omega0_b']+fields['Omega0_cdm'])
    radiation=fields['H0']**2*(fields['Omega0_g']+fields['Omega0_ur'])
    assert matter>0 and radiation>0
    B=hx(bg['scalar']['scf_parameters'][3]); floor0=F('3.968e-8'); floor1=F.from_float(3.968e-8)
    flo,fhi=B*min(floor0,floor1), B*max(floor0,floor1)
    assert flo==F(guard['source_intervals']['floorlo']) and fhi==F(guard['source_intervals']['floorhi'])
    constants=read('audit98.json')['optical_constant_inputs']
    n=F(constants['nH0_m_minus3_exact'])
    assert n==hx(case['thermal_starts'][0]['constants']['nH0_SI'])
    sig=list(map(F,constants['sigma_m2']['exact'])); mpc=list(map(F,constants['Mpc_m']['exact']))
    kl,ku=n*sig[0]*mpc[0], n*sig[1]*mpc[1]
    assert strings([kl,ku])==v66['summary']['kernel_constants_exact']['C_inverse_Mpc']
    grow=guard['evaluators'][0]['rows']; slabs={}
    for row in range(64,70):
        g=grow[row]; prev=grow[row-1]
        assert g['index']==row and g['committed'] and g['whole_cell_qualified'] and F(g['G_lower'])>0
        assert g['E_input_left']==prev['E_right'] and g['Y_left']==prev['Y_right'] and g['a0']==prev['a1']
    for cell in bind['cells']:
        i=cell['source_guard_index']
        if not 65<=i<=69: continue
        g=grow[i]
        assert hashlib.sha256(json.dumps(g,sort_keys=True,separators=(',',':')).encode()).hexdigest()==cell['source_row_sha256']
        assert cell['background_dependency_id']==dep and cell['source_energy_cap']==g['E_input_left']
        assert F(cell['source_scalar_floor_upper'])==fhi
        assert list(map(F,cell['z']))==[F(g['z0']),F(g['z1'])]
        slabs[i]=cell
    assert len(slabs)==5
    cache={}
    def b0(s):
        if s not in cache:
            nl=nuu=F(0)
            for q,w in nodes:
                rl,ru=root(q*q*s*s+nf['M_ncdm']**2)
                nl+=q*q*w*rl; nuu+=q*q*w*ru
            base=matter*s**3+radiation*s**4
            factor=nf['factor_ncdm']*s**3
            cache[s]=[down(base+factor*nl),up(base+factor*nuu)]
        return cache[s]
    bounds={F(750),F(760),F(770),F(780),F(790),F(800)}
    assert len(old['cells'])==101
    assert [c['V66_row'] for c in old['cells']]==list(range(4743,4844))
    rows=[]; low=high=weight=state=oldweight=F(0); cursor=F(750)
    caprange=[]; rawwidths=[]
    for c in old['cells']:
        idx=c['V66_row']; src=v66['source_segments'][idx]
        a,b=map(F,c['z']); sa,sb=map(F,src['z'])
        assert a==max(F(750),sa) and b==min(F(800),sb) and a==cursor
        assert c['electron_interval']==['1/2000000','1/1000000']
        wl0,wu0=map(F,c['weight_factor'])
        assert c['weight_factor']==src['K_over_H_exact']
        oldweight+=(3*Q/4)*(wu0-wl0)*((b+1)**3-(a+1)**3)/3
        cuts=sorted({a,b}|{x for x in bounds if a<x<b})
        for left,right in zip(cuts,cuts[1:]):
            assert time.monotonic()-start<300, 'prototype time limit'
            matches=[(i,g) for i,g in slabs.items() if F(g['z'][1])<=left<right<=F(g['z'][0])]
            assert len(matches)==1
            i,g=matches[0]; ec=min(F(g['source_energy_cap']),anchor_cap)
            bl,bu=b0(1+left)[0],b0(1+right)[1]
            h2l,h2u=bl+flo/3,bu+(ec+fhi)/3
            hl,hu=root(h2l)[0],root(h2u)[1]
            hl,hu=max(hl,F(g['H'][0])),min(hu,F(g['H'][1]))
            assert 0<hl<=hu
            rawlo,rawhi=down(kl/hu),up(ku/hl)
            wl,wu=max(wl0,rawlo),min(wu0,rawhi)
            assert wl<=wu, ('EMPTY_WEIGHT_INTERSECTION',idx,i,str(left),str(right))
            mass=((1+right)**3-(1+left)**3)/3
            il,iu=down(Q*wl*mass/2,T),up(Q*wu*mass,T)
            low+=il; high+=iu
            weight+=(3*Q/4)*(wu-wl)*mass
            state+=(Q/2)*(wu+wl)/2*mass
            caprange.append(ec/(3*bu)); rawwidths.append((rawhi-rawlo)/(wu0-wl0))
            rows.append({'V66_row':idx,'guard_row':i,'z':strings([left,right]),'B0_box':strings([bl,bu]),'scalar_energy_cap':str(ec),'H_squared_raw':strings([h2l,h2u]),'H_box':strings([hl,hu]),'weight_raw':strings([rawlo,rawhi]),'weight_intersection':strings([wl,wu]),'electron_interval':strings([Q/2,Q]),'cubic_mass':str(mass),'increment':strings([il,iu]),'background_dependency_id':dep})
        cursor=b
    assert cursor==800 and len(rows)==105
    assert oldweight==F(task['old_weight_width'])==F(old['width_accounting']['weight_factor_enclosure'])
    rounding=high-low-state-weight
    assert 0<=rounding<2*len(rows)*F(1,T)
    ol,ou=map(F,old['pilot_interval']); gl,gu=map(F,old['new_global_interval'])
    assert low>=ol and high<=ou
    newgl,newgu=gl-ol+low,gu-ou+high
    target=F(task['weight_width_ceiling']); assert target==oldweight*F(3,4)
    success=weight<=target
    result={'schema':'Q052_V105_ANCHORED_BSTAR_WEIGHT_PILOT','technical_state':'PASS','scientific_state':'INCONCLUSIVE','pilot_method_target':'PASS' if success else 'FAIL_25_PERCENT_WEIGHT_TARGET','scope':'Conditional source-real pair on the V73 fixed admitted B_star; inherited prefix and V97 electron certificate. No native trajectory/error certification.','task_fingerprint':anchor['task_fingerprint'], 'anchor_raw_sha256':anchor['raw_sha256'], 'anchor_energy_upper':str(anchor_cap),'source_commit':task['source_commit'],'domain':['750','800'],'original_cells':101,'integration_subcells':len(rows),'neutrino_nodes':11,'background_dependency_id':dep,'optical_K_inverse_Mpc':strings([kl,ku]),'scalar_floor_interval':strings([flo,fhi]),'pilot_interval':strings([low,high]),'pilot_width':str(high-low),'pilot_width_reduction_fraction':str(1-(high-low)/(ou-ol)),'old_weight_width':str(oldweight),'new_weight_width':str(weight),'weight_width_ceiling':str(target),'weight_width_reduction_fraction':str(1-weight/oldweight),'target_met':success,'width_accounting':{'electron_enclosure':str(state),'weight_factor_enclosure':str(weight),'outward_increment_rounding':str(rounding),'quadrature_remainder':'0','note':'160-bit outward sqrt/B0/W enclosures are included in weight contribution; final 100-bit increment rounding is separate. Electron interval fixed to V97.'},'new_global_interval':strings([newgl,newgu]),'global_width':str(newgu-newgl),'global_width_goal_met':newgu-newgl<=F(task['full_precision_goal_provisional']),'global_width_goal_ratio':str((newgu-newgl)/F(task['full_precision_goal_provisional'])),'maximum_location':'810 (inherited V95 source maximum)','limiting_input':'V105 z800 anchor energy cap intersected with inherited guard caps. Scalar lower bound remains e>=0.','scalar_cap_over_three_B0_range':strings([min(caprange),max(caprange)]),'stop_reason':'FIRST_BOUNDED_EVALUATION_COMPLETE','new_native_pairs':0,'new_full_history_integrations':0,'cells':rows}
    emit('result105_weight.json',result)
    emit('execution105_weight.json',{'prototype_wall_seconds':time.monotonic()-start,'prototype_limit_seconds':300,'bounded_evaluations':1,'new_native_pairs':0,'new_full_history_integrations':0,'python':sys.version,'stop_reason':result['stop_reason']})
    print(json.dumps({'status':result['pilot_method_target'],'cells':len(rows),'pilot':list(map(float,[low,high])),'weight_old':float(oldweight),'weight_new':float(weight),'weight_reduction_percent':float((1-weight/oldweight)*100),'pilot_reduction_percent':float((1-(high-low)/(ou-ol))*100),'global':list(map(float,[newgl,newgu])),'global_width_goal_ratio':float(F(result['global_width_goal_ratio'])),'elapsed':time.monotonic()-start},indent=2))

if __name__=='__main__': main()
