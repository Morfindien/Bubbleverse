# Q052 V73 · Ét fælles kildemål fra z = 810 til i dag

**Resultat.** Vælg baggrunden fra Q048's fastholdte startværdiproblem for `hillipop-ede_n3` som fælles reference B★. Med Q048's kvalificerede kildepræfiks opfylder den CLASS' strenge skalarbetingelse på hele intervallet 0 ≤ z ≤ 810. V12 dækker de første 69 celler frem til z = 120. Nedenstående bevis dækker resten med én ulighed. Begge heliumvalg bruger samme B★, fordi q kun ændrer termodynamikken. Usikkerheden om de observerede kurvers nøjagtighed langs referencebanen består.

## Hvilken løsning er valgt?

Q051 kvantificerer over hver fast, tilladt baggrund i familien. V40 valgte fælles hydrogen- og temperaturstart ved 810, og V72 verificerede de nøjagtige startdata for V69. De fastlægger alene de to termodynamiske koordinater. Vi vælger B★ ved det **tidlige** skalarstartpunkt i Q048. Brug de indfangede binary64-input som eksakte tal og de afrundede C-litteraler som eksakte konstanter i de kilde-reelle ligninger. De arvede parameterintervaller omfatter også de skrevne decimalkonstanter. Samme konvention fastholdes i hele forløbet.

Capturefilen låser de almindelige tætheder, de 11 positive neutrino-knuder og vægte, massen og faktoren, de indstillede skalarparametre og initialiseringen. Den deklarerede start har aᵢ = `0x1.6849b86a12b9bp-47`, φᵢ = `0x1.e25c1c67a810dp-3` og φ′η = 0. Q048's `source_initial` bruger startgrenens relativistiske neutrino- og strålingsprøver. Q048 tilordner de resulterende præfiksbeviser *conditional exact-real initialization* og lader flydende-komma-bindingen til den faktiske kørsel stå åben. Her arves præcis det første scope.

Sæt u = ln a, X = φ′η/a og θ = λφ. Med periodisk potential U = A(1−cos θ)³, konstant gulv f og den positive rod H har vi

    dφ/du = X/H
    dX/du = −3X − λ Uθ/H
    e = X²/2 + U,        de/du = −3X²
    H² = B₀ + (e+f)/3,  G = 3B₀ + e + f − 2U.

CLASS kræver U/(3H²) < 1/2, svarende til G > 0. På det kompakte interval aᵢ ≤ a ≤ 1 giver støv alene en positiv nedre grænse for H. Differentialmodellen uden stopbetingelsen er glat i (φ,X) og lokalt Lipschitz. Energien begrænser X, og X/H begrænser væksten i φ på endelig u-tid. Den sædvanlige entydige fortsættelse af startværdiproblemet eksisterer derfor til a = 1. Det særskilte spørgsmål er, hvor den opfylder den bogstavelige CLASS-betingelse.

Det tidligere Q048-præfiks fører det samme startproblem til de korrelerede virialgrænser. Math017 indtager skalaroverførslen til z = 1600. Guard V4 viderefører det samme endpoint til 1520. V6, V8 og V10 fører kæden frem til V12 ved 1450. V151 og Q050-bindingen refererer ved 810 til det samme V12-resultat, samme capture og række 63. I V12 bærer rækkerne 64–132 den samme tilstand fra 810 til 120. Begge historiske kontrolspor er committed dér. V12's række 133 ved 120→110 fik kun én godkendelse og indgår ikke. De 16 lokale Q050-celler dækker alene cirka 650,25665 ≤ z ≤ 810. Kildepræfikset er en eksplicit arvet præmis. V73 læser dets rapporter og verificerer dets låste endepunkter uden at genberegne det.

Ved 810 er (E,Y_upper,Vbar) projektioner af én bane med e ≤ E, Y ≤ Y_upper og |V| ≤ Vbar. Ved 120 giver det godkendte primære spor E = 0,057355947871695515 og Y_upper = 0,041396435430548226 (eksakte brøker i resultatfilen). Her er V = HXθ/λ og Y = e + αV. Det andet historiske spor er en løsere indeslutning af samme familie. Hverken her eller ved 810 foretages ny initialisering.

## Streng barriere fra 120 til 0

Sæt a★ = 1/121, x = a★/a, S = 2/25 og δ = 1/6. Fra det arvede centrale interval |θ| < 2, monoton energi og U(1) ≥ A_min(11/24)³ > 23,60 følger |θ| < 1 allerede ved a★ og fremover. Her bruges cos(1) ≤ 1−1/2+1/24 og monotonien af U på [0,2].

Den låste baggrund har nul kosmologisk konstant i B₀. For stråling aftager a³ρ med a, og for støv er det konstant. For hver massiv neutrino-knude er a³ρ proportional med q²w√((q/a)²+M²), som aftager. Derfor er B₀(a) ≤ B★₀ x³. Ved a★ bruges √(q²+(a★M)²) ≤ q+a★M. Den eksakte sum over knuder og almindelige arter giver B★₀ < 0,029859 Mpc⁻².

Antag indtil første kontakt, at e ≤ S x³. Da x ≥ 1/121, gælder H² ≤ C x³ med C = B★₀ + (S + 121³ f_max)/3 < 0,120719 Mpc⁻². Så følger

    |V| ≤ √(2CS) x³ / λ_min < δ S x³.

Den anden ulighed kontrolleres ved 2C < δ² S λ_min². Sæt α = 24/23, k = 90/23 og β = 1152/529. Det arvede virialbevis anvender ℓ = d ln H/d ln a ∈ [−3,0] og θUθ ≥ (15/4)U. Identiteten er

    Y′ + kY = (k/2−3+α)X² + kU − αθUθ + α(ℓ−3+k)V ≤ β |V|.

Med b = (1−αδ)S gælder E★ < S og Y★ ≤ Y_upper < b. Funktionen b x³ er en streng øvre sammenligningsløsning, fordi (k−3)(1−αδ) > βδ. Dermed følger Y < b x³, og e = Y−αV < S x³ også ved en formodet første kontakt. Kontinuitet udelukker første kontakt på hele intervallet.

Skriv M★ = H₀²(Ωb+Ωcdm)121³. Da U ≤ e og f ≥ 0, gælder

    G ≥ 3B₀−e > (3M★−S)x³,
    3M★−S > 0,00619964 Mpc⁻²,
    G > 3,49954 × 10⁻⁹ Mpc⁻²  for 0 ≤ z ≤ 120.

Det sidste tal er en nedre grænse for betingelsens margin. Det er ikke en afrundingsfejl. Den separate kontrol anvender S = 0,082 og δ = 1/5, grovere stof- og strålingsmajoranter samt W = Y/x³. Da W′ ≤ −(k−3)W + βδS, fås e/x³ ≤ max(Y_upper,βδS/(k−3))+αδS < S frem til en formodet første kontakt. Kontrollens uniforme nedre grænse er 1/442890250 Mpc⁻². Begge beviser bruger samme godkendte primære anker og samme fysiske ligninger.

## Kontrol mod den observerede V69-baggrund

V37-arkivet og V69's header-erstatning gendanner 40.000 datarækker i hver arm. Begge fulde filhash og størrelser stemmer med kapslen. Hele datadelen er byteidentisk mellem armene. Første række har præcis den indfangede φᵢ og nul φ′η. Tabellen har a = `0x1.6849b86a12b93p-47` efter rekonstruktion fra sin logaritmiske gitterkoordinat. Den deklarerede initialiseringskonstant står særskilt ovenfor. De otte fælles effektive felter i V69's identitetsfil matcher Q048 bit for bit.

Ved u = −ln 811 afgrænser rækkerne 31687 og 31688 den gemte spline. De kubiske koefficienter kommer fra værdier og andenafledte i ln a. Koden indeslutter logaritmen ved 80 decimalcifres præcision med én fuld ulp på hver side og bruger rationel intervalaritmetik videre. Den evaluerer H, φ, φ′η og den periodiske potentialkolonne U. θ bruger den fastholdte references λ-interval.

| Størrelse ved z = 810 | Gemt spline, afrundet | Arvet kildegrænse |
| --- | ---: | ---: |
| θ | −0,12039089746 | abs(θ) < 2 |
| e | 0,16610792479 | e ≤ 28,115681074 |
| V | −0,01813783243 | abs(V) ≤ 5,587227469 |
| Y | 0,14718149095 | Y ≤ 22,285530673 |

Det er et kompatibilitetstjek af de gemte projektioner. Optimeringsinputtet i `point.ini` har den oprindelige parametervektor før shooting. Den kompakte effektive identitetsfil indeholder de otte almindelige felter. En stærkere påstand om præcis lighed mellem Q048's tunede skalar-/neutrino-input og V69's faktiske runtime-værdier ville kræve en binding af bl.a. `scf_parameters[1:4]` og de effektive neutrino-knuder, vægte, masse og faktor. En direkte fejloverførsel til det valgte B★ kan foretages uden denne stærkere påstand. H måles i Mpc⁻¹. Native H′ er dH/dη i Mpc⁻². Den analytiske z-afledte er dH/dz = −(dH/dη)/H i Mpc⁻¹, fordi dz/dη = −H.

## Betydning for Q052

Q049 leverer grænser under forudsætning om fortsættelse. Q050's globale selectorresultat giver en absolut kontinuert fortsættelse for hver af de to q-værdier på hver fast admitted baggrund. Q051 begrænser parrets observabler uniformt under sine øvrige kilde- og domæneantagelser. Når B★ er valgt som ovenfor og V40-starten fastholdes, kan V31/V38 anvendes på deres lokale domæner og V71's signerede fejlgrænser anvendes på hele 0 ≤ z ≤ 810. Fortegnet er gemt L−R minus kilde L−R.

| Resultat for dette referencevalg | Elektronfraktion | Akkumuleret Thomson-dybde |
| --- | ---: | ---: |
| Hele V71-intervallet for signeret fejl, afrundet udad | [−0,001284233, +0,001284298] | [−0,03988620, +0,03993305] |
| Gemte maksimummer, tidligere certificeret | ≈ 1,10720467421 × 10⁻⁶ | ≈ 2,42210635864 × 10⁻⁵ |

Ved 810 giver V71 det konkrete vidne på en elektronfraktionsfejl med absolutværdi cirka 6,6136514324 × 10⁻⁷. Den tilbageværende opgave er en tilstrækkeligt smal tosidig indeslutning af de realiserede **parforskelle langs kildebanerne** og deres maksimummer. En mulighed er at afgrænse det korrelerede residual for L−R direkte på det interval, hvor en strammere totalfejl kræver det. Hverken punktet ved 810, ens baggrundstabeller eller en global guard-margin bestemmer disse maksimummer. Q052 forbliver ACTIVE / INCONCLUSIVE.
