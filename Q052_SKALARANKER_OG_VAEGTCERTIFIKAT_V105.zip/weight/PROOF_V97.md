# Q052 V97 · Halv-q-grænse og Thomson-pilot

Under det fastholdte kildegrundlag, den samme tilladte baggrund B★ og de matchede starttilstande bevises

\[
\frac{q}{2}<\Delta X_e(z)<q,\qquad q=10^{-6},\qquad750\le z\le800.
\]

Dette giver følgende dimensionsløse indhylling, afrundet udad,

\[
1{,}37885214\cdot10^{-6}\le I_{750,800}
=F(800)-F(750)\le3{,}92409794\cdot10^{-6}.
\]

Pilotens eksakte bredde er 2,545245791679548… × 10⁻⁶. Bredden er reduceret med 35,1380665576… %, og V96's krævede reduktion på mindst 25 % er opfyldt. Den samlede kildeindhylling bliver, efter kun at udskifte pilotbidraget,

\[
1{,}42468930\cdot10^{-6}\le F(810)\le4{,}58113700\cdot10^{-5}.
\]

De eksakte brøker står i result.json. De to viste decimalintervaller er rundet udad. V95's maksimumsted ved 810 anvendes. Den samlede bredde falder med cirka 3,01 %. Den resterende bredde er cirka 4,43866807 × 10⁻⁵, omkring 11.100 gange den foreløbige målbredde 4 × 10⁻⁹. Hele Q052 er fortsat ACTIVE/INCONCLUSIVE.

## 1. Identitet, start og domæne

V96-opgaven, dens fingerprint og alle leverede rodhashes er kontrolleret. V96-filerne matcher GitHub-blobs ved commit 738239662ee16ec0bc1214130808b8e3d016a8ce. V62-arkivet er hentet ved samme commit og matcher den bestilte SHA-256 7fb60289f13cfbb1721b6528bb4b57dfd369b8d1939e28fbb51923591878d137. Dets phase5_receipt.json er identisk med det historiske v62.json. V78's arkiverede V77-resultat matcher det anvendte V77-certifikat. V75-resultatet matcher V77's input, og V75-arkivet matcher repository-blobben. De konkrete kildefiler og den frosne konfiguration er kontrolleret mod V62's source_pins og V95/V77's fælles V19-grundlag.

Fysikkilden er hillipop-ede_n3 ved commit 5a131c91d657dd9a7c6364cc45b038710f8d0d97. Reionisationsstarten er 753585/65536, langt under pilotens domæne. Den offentlige elektronfraktion er derfor X_L=h_L+q og X_R=h_R på hele den anvendte strimmel. De arkiverede thermal_flags har ingen eksotisk injektion, varierende konstanter eller de kontrollerede mørk-stof-vekselvirkninger.

Sæt u=ln[811/(1+z)], h=h_R, d=h_L−h, E=d+q og t=v_L−v_R. V75 leverer ved

\[
z_*=1779416633043845/2199023255552\approx809{,}185
\]

startbetingelsen |d|≤ε, hvor

\[
\epsilon=177049176082186403/17816156562993970000000000<q/2.
\]

For at binde denne start til z=800 kontrolleres det nødvendige præfiks. De første 119 V62-rækker, nummereret 0–118, dækker fra z_* til under 750. Alle har udelukkende SWIFT som tilladt gren i begge arme. Række 18 krydser 800, og række 118 krydser 750. Selve pilotintegralet bruger V62-rækkerne 18–118 og V66-rækkerne 4743–4843, i alt 101 helcellebokse afskåret præcist ved 750 og 800. De 19 præfiksrækker 0–18 har alene rollen at transportere den allerede certificerede startbetingelse ind i piloten. Integralopdateringen er afgrænset til [750,800].

På hver nødvendig boks er q<h<1, 0<v<1 og H>0. De to arme bruger samme H-indhylling. Den fælles SWIFT-korrektion opfylder 1+DK>0. Der er ingen mulighed for et SWIFT/HMLA-skift på den kontrollerede strimmel. Kildekoden bestemmer DK ud fra fælles z, strålingstemperatur og kosmologiske parametre.

## 2. Temperatur- og rateorden

V95 giver E>0 på hele [0,810]. V83 giver E<q for z<810. Fra det fælles temperaturfelt

\[
g(X,v)=-v+A(X)(1-v),\qquad A(X)=kX/(a+X),\quad k>0,\ a=1+f_{He}>0
\]

følger

\[
t'=-(1+A_L)t+(A_L-A_R)(1-v_R).
\]

De matchede starter har t=0. E>0, A's monotoni og v_R<1 gør integralet i variation-af-konstanter-formlen ikke-negativt. Dermed t≥0 og v_L≥v_R på strimlen.

V77's certificerede kolde ratehældninger er negative for begge atomare niveauer på hele det nødvendige temperaturdomæne og dets interpolationstencils. Derfor α_L,i≤α_R,i. V77's Saha-loft under 1 sammen med α_i(v_R)≥α_i(1) giver U_R,i>0 i definitionen nedenfor. Disse historiske ratecertifikater er genbrugte præmisser.

## 3. Den nye barriere

Definér β_i=α_i(1)S med S≥0 ved samme z. Symbolet β_i i dette afsnit er dette Saha-produkt. Kildens fotoionisationsrate Beta[i], som indgår i C-faktorerne, betegnes B_i i afsnit 4.

Efter indsættelse af DAlpha_i=α_i(v)−α_i(1) i den faktiske SWIFT-kode er hydrogenfeltet

\[
f_{arm}=-\frac{n_H}{H_s}\sum_i C_{arm,i}U_{arm,i},\qquad
U_{arm,i}=\alpha_{arm,i}h_{arm}X_{arm}-\beta_i(1-h_{arm}).
\]

På fladen d=−q/2 er h_L=h−q/2 og X_L=h+q/2. Det positive rekombinationsprodukt bliver

\[
h_LX_L=h^2-q^2/4<h^2.
\]

Skriv δ_i=α_R,i−α_L,i≥0. Direkte algebra giver

\[
U_{R,i}-U_{L,i}
=\alpha_{R,i}q^2/4+\beta_i q/2
 +\delta_i(h^2-q^2/4)>0.
\]

Strengheden følger af α_R,i>0 og q>0. På fælles SWIFT-gren er C_i positiv og voksende med h, som vist nedenfor. Derfor C_L,i≤C_R,i. Hvis U_L,i≥0, følger C_L,i U_L,i<C_R,i U_R,i. Hvis U_L,i<0, følger samme strenge ulighed af C_i>0 og U_R,i>0. Altså

\[
d'=f_L-f_R=\frac{n_H}{H_s}\sum_i(C_{R,i}U_{R,i}-C_{L,i}U_{L,i})>0
\]

på fladen d=−q/2. Starten ligger strengt over fladen. En første kontakt fra indersiden modsiges af den strengt indadrettede afledte. Kildebanerne er kontinuerte og stykkevis absolut kontinuerte under de arvede præmisser. De mulige ensidige felter ved tabelknuder opfylder samme ulighed. Argumentet gælder også på cellegrænserne. Derfor d>−q/2 til pilotens nederste grænse 750. Sammen med E=d+q og V83 fås q/2<E<q på hele piloten.

## 4. Kontrol af C-monotonien

Ved fastholdt z er B_s, B_p, j og Λ positive fælles rater. Escape-raten

\[
e(h)=\frac{\mathrm{LYA\_FACT}\,H_s}{n_H(1-h)(1+DK)}
\]

vokser med h. Kildens to C-brøker kan skrives

\[
G=B_s+\Lambda+3j,\quad
D=(B_s+\Lambda)(B_p+j)+3jB_p+Ge,
\]
\[
N_s=\Lambda(B_p+j)+(\Lambda+3j)e,\qquad
N_p=\Lambda j+Ge,\qquad C_i=N_i/D.
\]

Med K=GB_p+jB_s>0 giver eksakt polynomiel reduktion

\[
N_s'D-N_sD'=3jK>0,\qquad N_p'D-N_pD'=GK>0,
\]

hvor afledte i dette afsnit er med hensyn til e. Derfor vokser begge C_i med e og h. Deres positive tællere og nævner giver C_i>0. control97.py kontrollerer disse to identiteter samt hele U_R−U_L-identiteten med særskilt sparse polynomiel aritmetik.

## 5. Kvadratur og usikkerhed

Den fastlåste optiske definition er

\[
F(Z)=\int_0^Z \frac{n_{H0}\sigma_T\,\mathrm{Mpc}_m}{H_B(z)}(1+z)^2 E(z)\,dz.
\]

Her er H_B i Mpc⁻¹, n_H0 i m⁻³, σ_T i m², og Mpc_m omregner Mpc til meter. F og E er dimensionsløse. V78/V66's positive W=[W_l,W_u] omslutter n_H0 σ_T Mpc_m/H_B. Den frosne fælles baggrund og start er præmisser for alle bounds.

For hvert afskåret interval [a,b] anvendes den eksakte positive masse M=((1+b)³−(1+a)³)/3. Elektronintervallet [q/2,q] skæres med den arvede V66-boks. Alle 101 skæringer giver netop [q/2,q]. Produktintervallet er [W_l qM/2, W_u qM]. De respektive bidrag rundes ned og op til gitteret 2⁻¹⁰⁰ før summation. Nulrestleddet gælder integrationen af omsluttende konstante bokse mod den eksakte polynomielle masse. Variation i den faktiske elektronforskel og H er indeholdt i boksernes bredde.

Den eksakte produktbredde før afrunding opdeles ved identiteten

\[
W_uE_u-W_lE_l
=\frac{W_u+W_l}{2}(E_u-E_l)
 +\frac{E_u+E_l}{2}(W_u-W_l).
\]

| Bidrag til pilotens intervalbredde | Tilnærmet værdi |
|---|---:|
| Fælles bidrag fra start- og dynamikindhyllingen for E | 1,6704505564 × 10⁻⁶ |
| Indhyllingen af den optiske vægt | 8,7479523527 × 10⁻⁷ |
| Udadrettet afrunding | 7,40893 × 10⁻²⁹ |
| Kvadraturrest for de omsluttende bokse | 0 |
| Grenusikkerhed inden for de verificerede SWIFT-rækker | 0 |

Starttilstands- og dynamikusikkerheden indgår samlet i den analytiske barriere. Der er ingen numerisk ODE-approksimation i denne nye beregning. En yderligere opsplitning mellem start og dynamik kan ikke udledes af den anvendte barriere alene. Tabellen er en matematisk opdeling af intervalbredde og angiver ikke statistiske standardfejl.

Kontrollen samler de 101 celler i 11 grupper med identiske vægtbokse og summerer masserne med det udvidede polynomium. Kontrolsummerne er eksakte rationelle tal og ligger inde i producentens afrundede interval. Afstanden ved hver ende er mindre end 101·2⁻¹⁰⁰. Begge programmer er genkørt i en frisk mappe med byteidentiske outputfiler.

## 6. Native-sammenligning og næste nødvendige afklaring

V71's ideelle lagrede primitive, dens returned/ideal-afskæring og dens globale signerede fejl er bevaret i v71_tau.json. Den globale fejlindhylling i det certifikat er omkring [−0,0398862, 0,0399331]. Den meget mindre returned-minus-ideal-forskel ved det øvre snit er omkring −2,26 × 10⁻²¹. De størrelser har forskellige domæner og fejlbetydninger.

Et lokalt native-minus-kilde-residual ved samme fysiske z kræver en verificeret binding mellem den native baggrund, det fælles B★ og koordinatafbildningen. Denne præmis er fortsat åben i det arvede Q052-grundlag. V97 certificerer derfor pilotens kildeintegral og bevarer den native sammenligning som ulukket. Den nye barriere kan ikke i sig selv godtgøre native-baggrundens medlemskab eller reproducerbarhed.

V96's pilotstop ved 750 er nået. Resultatindtag og routing skal indtage delresultatet én gang og vurdere næste arbejde ud fra de faktiske breddebidrag. En billig udvidelse af samme barriere på andre allerede certificerede fælles-gren-rækker kan undersøges. Et meget snævrere tal kræver samtidig en skarpere elektronindhylling og en skarpere vægt for det konkrete fælles baggrundsobjekt. Bredden fra den nuværende pilotvægt alene overstiger hele det foreløbige mål. Den viste vægtbredde dokumenterer en begrænsning ved den anvendte intervalmetode og afgør ikke, hvor meget den sande integralværdi varierer mellem tilladte baggrunde.

Ingen nye native par eller fulde historieintegrationer er udført. V97 giver et betinget matematisk delresultat. Lukning af Q052 kræver fortsat integralpræcision, native/kilde-fejl, native-reproducerbarhed og sammenhold med de frosne Q051-kriterier.
