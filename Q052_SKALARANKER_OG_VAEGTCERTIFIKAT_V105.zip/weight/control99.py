"""Independent V99 check: hex integers, a-coordinate densities, Decimal roots.

Does not import the producer. Root brackets are validated by exact squaring.
Reuses the same physical premises, not an independent validation of Q048/V97.
"""
from pathlib import Path
from fractions import Fraction as R
from decimal import Decimal, localcontext
from collections import defaultdict
import hashlib, json, sys

BASE=Path(__file__).resolve().parent
def load(n): return json.loads((BASE/n).read_bytes())
def hexrat(s):
    sign=-1 if s.startswith('-') else 1
    significand, power=s.lstrip('+-').lower().split('p')
    digits=significand[2:].split('.')
    fractional=digits[1] if len(digits)>1 else ''
    integer=int(digits[0]+fractional,16)
    exponent=int(power)-4*len(fractional)
    return sign*R(integer)*(R(2)**exponent)
def sqrtbox(x):
    with localcontext() as ctx:
        ctx.prec=100
        y=(Decimal(x.numerator)/Decimal(x.denominator)).sqrt()
        lo,hi=R(y-Decimal('1e-85')),R(y+Decimal('1e-85'))
    assert 0<=lo and lo*lo<=x<=hi*hi, 'square-root enclosure'
    return lo,hi

def validate(result=None):
    for f,h in load('pins.json').items():
        assert hashlib.sha256((BASE/f).read_bytes()).hexdigest()==h, ('input identity',f)
    r=load('result99.json') if result is None else result
    old=load('result97.json'); task=load('task98.json')
    bg=load('capture.json')['cases']['hillipop-ede_n3']['background']
    f={k:hexrat(v) for k,v in bg['fields'].items()}
    nu=bg['neutrinos'][0]; nf={k:hexrat(v) for k,v in nu['fields'].items()}
    qs=list(map(hexrat,nu['q_ncdm_bg'])); ws=list(map(hexrat,nu['w_ncdm_bg']))
    assert len(qs)==len(ws)==r['neutrino_nodes']==11
    assert all(x>0 for x in qs+ws)
    guard=load('guard.json')['evaluators'][0]['rows']; bind=load('binding.json')
    bindings={x['source_guard_index']:x for x in bind['cells']}
    floorlo,floorhi=map(R,r['scalar_floor_interval'])
    expected_floor=load('guard.json')['source_intervals']
    assert floorlo==R(expected_floor['floorlo']) and floorhi==R(expected_floor['floorhi'])
    c=load('audit98.json')['optical_constant_inputs']
    kl=R(c['nH0_m_minus3_exact'])*R(c['sigma_m2']['exact'][0])*R(c['Mpc_m']['exact'][0])
    ku=R(c['nH0_m_minus3_exact'])*R(c['sigma_m2']['exact'][1])*R(c['Mpc_m']['exact'][1])
    assert list(map(R,r['optical_K_inverse_Mpc']))==[kl,ku]
    # Unit dimensions: n_H0[m^-3] sigma[m^2] Mpc_m[m/Mpc] / H[Mpc^-1].
    dimensions=[-3+2+1, -1-(-1)]
    assert dimensions==[0,0]
    cache={}
    def density(a):
        if a not in cache:
            ordinary=f['H0']**2*((f['Omega0_b']+f['Omega0_cdm'])/a**3+(f['Omega0_g']+f['Omega0_ur'])/a**4)
            lo=hi=R(0)
            for node,weight in reversed(list(zip(qs,ws))):
                l,u=sqrtbox(node**2+(nf['M_ncdm']*a)**2)
                lo+=node**2*weight*l; hi+=node**2*weight*u
            factor=nf['factor_ncdm']/a**4
            cache[a]=ordinary+factor*lo,ordinary+factor*hi
        return cache[a]
    sources=load('v66.json')['source_segments']
    expected=[]
    for idx in range(4743,4844):
        sl,su=map(R,sources[idx]['z'])
        sl,su=max(sl,R(750)),min(su,R(800))
        for gidx in range(69,64,-1):
            gl,gu=R(guard[gidx]['z1']),R(guard[gidx]['z0'])
            left,right=max(sl,gl),min(su,gu)
            if left<right: expected.append((idx,gidx,left,right))
    expected.sort(key=lambda t:t[2])
    assert len(expected)==len(r['cells'])==r['integration_subcells']==105
    assert r['original_cells']==101
    groups=defaultdict(lambda:[R(0),R(0),R(0),R(0),R(0),R(0)])
    cursor=R(750); max_bgap=R(0); max_wgap=R(0); oldweight=R(0); capfractions=[]
    for expected_cell,row in zip(expected,r['cells']):
        idx,gidx,left,right=expected_cell
        assert (row['V66_row'],row['guard_row'],*map(R,row['z']))==expected_cell
        assert left==cursor; cursor=right
        assert row['background_dependency_id']==bind['background_dependency_id']
        ec=R(guard[gidx]['E_input_left'])
        assert R(row['scalar_energy_cap'])==ec
        bl,bu=map(R,row['B0_box'])
        dll,dlu=density(1/(1+left)); dul,duu=density(1/(1+right))
        assert bl<=dll<=dlu and dul<=duu<=bu
        max_bgap=max(max_bgap,dlu-bl,bu-dul)
        # Brackets must be close to the independently evaluated formula.
        assert dlu-bl<R(1,2**140) and bu-dul<R(1,2**140)
        hll,hlu=sqrtbox(dll+floorlo/3)
        hul,huu=sqrtbox(duu+(ec+floorhi)/3)
        guardlo,guardhi=map(R,bindings[gidx]['H'])
        ihl=max(hll,guardlo); ihu=min(huu,guardhi)
        hl,hu=map(R,row['H_box'])
        assert 0<hl<=ihl<=ihu<=hu
        assert ihl-hl<R(1,2**140) and hu-ihu<R(1,2**140)
        assert list(map(R,row['H_squared_raw']))==[bl+floorlo/3,bu+(ec+floorhi)/3]
        wrlo,wrhi=map(R,row['weight_raw'])
        assert wrlo<=kl/ihu and ku/ihl<=wrhi
        max_wgap=max(max_wgap,kl/ihu-wrlo,wrhi-ku/ihl)
        assert kl/ihu-wrlo<R(1,2**140) and wrhi-ku/ihl<R(1,2**140)
        oldlo,oldhi=map(R,sources[idx]['K_over_H_exact'])
        wl,wu=map(R,row['weight_intersection'])
        assert [wl,wu]==[max(wrlo,oldlo),min(wrhi,oldhi)] and 0<wl<=wu
        assert list(map(R,row['electron_interval']))==[R(1,2000000),R(1,1000000)]
        # Expanded primitive, independent of producer's cubic-difference expression.
        mass=(right-left)+(right**2-left**2)+(right**3-left**3)/3
        assert R(row['cubic_mass'])==mass
        exactlo=wl*mass/2000000; exacthi=wu*mass/1000000
        roundedlo,roundedhi=map(R,row['increment'])
        assert roundedlo<=exactlo<=exacthi<=roundedhi
        assert exactlo-roundedlo<R(1,2**100) and roundedhi-exacthi<R(1,2**100)
        assert (roundedlo*2**100).denominator==(roundedhi*2**100).denominator==1
        group=groups[gidx]
        group[0]+=exactlo;group[1]+=exacthi
        group[2]+=roundedlo;group[3]+=roundedhi
        group[4]+=(wu-wl)*mass*R(3,4000000)
        group[5]+=(wu+wl)*mass*R(1,4000000)
        oldweight+=(oldhi-oldlo)*mass*R(3,4000000)
        capfractions.append(ec/(3*bu))
    assert cursor==800 and len(groups)==5
    totals=[sum(g[i] for g in groups.values()) for i in range(6)]
    el,eu,lo,hi,ww,ew=totals
    assert eu-el==ww+ew
    assert list(map(R,r['pilot_interval']))==[lo,hi]
    assert R(r['pilot_width'])==hi-lo
    assert R(r['old_weight_width'])==oldweight==R(task['old_weight_width'])
    assert R(r['new_weight_width'])==ww and R(r['width_accounting']['weight_factor_enclosure'])==ww
    assert R(r['width_accounting']['electron_enclosure'])==ew
    assert R(r['width_accounting']['outward_increment_rounding'])==hi-lo-ww-ew
    ceiling=oldweight*R(3,4)
    assert R(r['weight_width_ceiling'])==ceiling==R(task['weight_width_ceiling'])
    assert r['target_met']==(ww<=ceiling)
    assert r['pilot_method_target']==('PASS' if ww<=ceiling else 'FAIL_25_PERCENT_WEIGHT_TARGET')
    assert R(r['weight_width_reduction_fraction'])==1-ww/oldweight
    oldlo,oldhi=map(R,old['pilot_interval']); globaloldlo,globaloldhi=map(R,old['new_global_interval'])
    assert R(r['pilot_width_reduction_fraction'])==1-(hi-lo)/(oldhi-oldlo)
    assert oldlo<=lo<hi<=oldhi
    globalnew=[globaloldlo-oldlo+lo,globaloldhi-oldhi+hi]
    assert list(map(R,r['new_global_interval']))==globalnew
    assert R(r['global_width'])==globalnew[1]-globalnew[0]
    assert R(r['global_width_goal_ratio'])==R(r['global_width'])/R(task['full_precision_goal_provisional'])
    assert not r['global_width_goal_met']
    assert list(map(R,r['scalar_cap_over_three_B0_range']))==[min(capfractions),max(capfractions)]
    assert r['source_commit']==task['source_commit'] and r['task_fingerprint']==task['fingerprint_sha256']
    assert r['new_native_pairs']==r['new_full_history_integrations']==0
    return {'status':'PASS','independence':'Separate hex parser, a-coordinate source density, reversed node order, Decimal-root brackets verified by exact squaring, exact guard-grouped sums and expanded polynomial masses. Shared historical physical premises.','subcells':105,'nodes_per_endpoint':11,'distinct_density_endpoints':len(cache),'guard_groups':5,'source_units_dimensionless':True,'max_B0_enclosure_slack':str(max_bgap),'max_weight_enclosure_slack':str(max_wgap),'exact_unrounded_pilot':list(map(str,[el,eu])),'exact_weight_width':str(ww),'exact_electron_width':str(ew),'method_target_met':ww<=ceiling,'grouped_sums':{str(k):list(map(str,v)) for k,v in sorted(groups.items())}}

if __name__=='__main__':
    checked=validate()
    (BASE/'control99.json').write_text(json.dumps(checked,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in checked.items() if k not in ['grouped_sums','exact_weight_width','exact_electron_width','exact_unrounded_pilot']},indent=2))
