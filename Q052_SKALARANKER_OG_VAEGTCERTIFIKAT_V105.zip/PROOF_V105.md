# Q052 V105 · Valideret z=800-anker og optisk vægttest

## Dokumenteret resultat

Den bestilte fortsættelse når præcis a=1/801, svarende til z=800, efter 142 nye accepterede celler og 27 afviste forslag. Sammen med de 1.250 arvede celler giver dette et betinget, sammenhængende præfiks på 1.392 celler. Det nye forsøg bruger 57,019964720 sekunder inklusive forprøver og løbende kontrol. Kørslens monotone ur starter før forprøverne. Det gamle stop er passeret med frisk defektberegning og fuld cellevalidering.

Skalarenergien e=X²/2+U ved målet er omsluttet af de følgende decimalgrænser, afrundet udad til visning:

\[
0,15149356148218\le e(800)\le0,15692069539820\quad\mathrm{Mpc}^{-2}.
\]

Bredden er cirka 0,00542713391601 Mpc⁻². Certifikatets `result_raw105.json` indeholder de autoritative eksakte rationale endepunkter, det fælles (φ,X)-interval og alle nye celler. Uafhængig energiindhylling er kontrolleret på hver accepteret celle. Det tilstrækkelige designloft i opgaven var cirka 17,03422473 Mpc⁻²; den faktiske optiske beslutning bygger på de 105 delcellers beregnede vægtbredde.

## Ligninger og arvede præmisser

Kildecommit, parametercapture, B★ og fortolkningen af indfangede binary64-tal som eksakte reelle værdier er bundet til V104-opgaven. Den betingede initialisering og fælles baggrund stammer fra V73 og de tidligere certifikater. De arvede beviser for elektroninterval og maksimumlokation anvendes på deres hidtidige domæne.

\[
U=A(1-\cos(\lambda\phi))^3,\qquad
H^2=B_0(a)+(X^2/2+U+f)/3,
\]
\[
\frac{d\phi}{d\ln a}=X/H,\qquad
\frac{dX}{d\ln a}=-3X-U_\phi/H.
\]

B₀ indeholder stof, stråling og samtlige 11 indfangede massive-neutrino-punkter. A, λ og f er de eksakte kildeparametre beskrevet i `PROOF_V103.md`. X og H har enheden Mpc⁻¹, e og f har enheden Mpc⁻². Opgavens lokale tid er t=(a−a₀)/a₀, så feltet divideres med 1+t.

V103's grad-12-referencepolynomium, validerede helcelle-Picard-boks, restled for defekten og fortegnsbevarede Metzler-sammenligning bruges igen. Samme bevis gælder, når den nye trigonometri-evaluator leverer gyldige indhyllinger. Den per-komponent absolutte defektgrænse er 10⁻⁸ per lokal t, med X-komponenten i Mpc⁻¹. Diagonalernes fortegn bevares. De udadrettede matricer og seriehaler er kontrolleret før accept.

## Trigonometriske intervaller ved vendepunkter

Den separate evaluator starter med en rationel Taylor-indhylling omkring intervalmidtpunktet, et eksakt Lagrange-restled og den globale 1-Lipschitz-grænse. Den håndhæver domænet |θ|<4. Resultater skæres med det universelle interval [−1,1].

Hvis cos(θ)>0 er bevist over hele intervallet, er sinus voksende; hvis cos(θ)<0 er bevist, er sinus aftagende. Tilsvarende afgør fortegnet af −sin(θ), om cosinus er voksende eller aftagende. I disse tilfælde anvendes udadrettede evalueringer af de korrekte endepunkter.

For både f=sin og f=cos gælder f″=−f. Et bevist positivt f på hele intervallet giver konkavitet, så minimum ligger i et endepunkt og maksimum er højst 1. Et bevist negativt f giver konveksitet, så minimum er mindst −1 og maksimum ligger i et endepunkt. Hver forbedring skæres med en allerede gyldig indhylling. Når fortegnene er uafklarede, beholdes den gyldige grove indhylling.

`trig105.py` implementerer disse regler. Otte forprøver dækker nul, positiv og negativ monotoni, sinusmaksimum, sinusminimum, cosinusmaksimum, cosinusminimum og et interval med uafklarede fortegn. Deres rationelle indhyllinger omslutter mpmath-intervalresultater ved 100 decimaler. Den gemte V103-fejlcelle består også den nye separate kontrol som forprøve. Den første nye celle genberegnes derefter fra checkpointet og accepteres først med frisk polynomium, defekt og alle kontrolkrav.

## Validering af fremføringen

Producenten bruger mpmath.iv ved 50 decimaler med genberegning af defekt og sammenligning ved 80 decimaler. Denne del deler jet- og polynomiumkode og beholder de omsluttende 50-decimalers parameterintervaller. Ved ikke-indlejrede endepunktsintervaller bruges den omsluttende union før skæring med den validerede helcelleboks.

Den separate rationelle 240-bit-evaluator kontrollerer på hver af de 142 celler felt, Picard-inklusion, positiv H², kildeguarden G=3B₀+X²/2−U+f>0, Jacobidomination, sammenligningseksponential og endepunktsenergi. Dertil kontrolleres referencepolynomiets plads i boksen, eksakt midtpunkt og radius, endepunktsskæring og eksakt seriehale før accept.

Den afsluttende record-audit har 994 kontroller fordelt over de 142 celler. Den efterprøver også controller, afvisninger, dækning og forbindelsen til V103. Der er ingen huller, indgangsboksene er identiske med foregående udgang, og den sidste skaleringsfaktor er eksakt 1/801. Audit og kildekode ligger i `verify105.py` og `verification105.json`.

Valideringen er delvist uafhængig. En separat Taylor-defektimplementering og en ny kontrol af hele den historiske initialisering er fortsat uden for denne runde. Alle nye resultater er betinget af de fastholdte kilde- og B★-præmisser.

## Energiens transport til pilotområdet

På den samme kildegren følger

\[
\frac{de}{d\ln a}=X(-3X-U_\phi/H)+U_\phi X/H=-3X^2\le0.
\]

Dermed er den validerede øvre energi ved z=800 et loft på hele det efterfølgende område 750≤z≤800. På hver af de 105 frosne delceller anvendes

\[
E_{\mathrm{cap,new},i}=\min\{E_{\mathrm{cap,V99},i},e_{\mathrm{upper}}(800)\}.
\]

De samme baggrundsgrænser, guard-skæringer, optiske konstanter og elektroninterval [q/2,q] med q=10⁻⁶ indgår som i V99. Der bruges de samme 101 kildeceller delt ved de fem guard-områder, i alt 105 delceller.

Med K=n_H0 σ_T Mpc_m og de validerede H-grænser er vægten W=K/H. For hver delcelle [a,b] i z er den eksakte integrationsmasse m=((1+b)³−(1+a)³)/3. Intervalbidraget er [q W_l m/2,q W_u m], afrundet udad. Den nye pilot erstatter den gamle pilot i det allerede godkendte globale interval.

## Resultat af én vægttest

| Størrelse | V99 | V105 |
|---|---:|---:|
| Vægtens bidrag til pilotbredde | 7,82937135878×10⁻⁷ | 1,09133872409×10⁻⁸ |
| Pilotens samlede bredde | 2,43156406973×10⁻⁶ | 1,91688157064×10⁻⁶ |
| Global intervalbredde | 4,42729989346×10⁻⁵ | 4,37583164355×10⁻⁵ |

Vægtbidraget falder med cirka **98,6061 % fra V99**. Mod opgavens frosne V97-reference er reduktionen **98,7525 %**, hvor kravet var mindst 25 %. Det faktiske vægtbidrag 1,09133872409×10⁻⁸ er under det frosne loft 6,56096426452×10⁻⁷. Metodetesten består.

Pilotens samlede bredde falder med cirka **21,1667 % fra V99**. Det globale intervals bredde falder med cirka **1,16252 % fra V99**. Den globale bredde er stadig cirka 10.939,58 gange det hidtidige fulde præcisionsmål.

Den nye pilot er omtrent [1,90233038765×10⁻⁶; 3,81921195830×10⁻⁶]. Det globale interval er omtrent [1,94816754668×10⁻⁶; 4,57064839822×10⁻⁵]. Eksakte grænser findes i `weight/result105_weight.json`; tallene i tabellen er afrundet til læsning.

Vægtproducenten bruger heltalskvadratrødder og udadrettede rationale grænser. Den separate kontrol bruger en anden parser af hex-flydetal, a-koordinat for baggrundsdensiteten, omvendt rækkefølge af neutrino-punkterne og Decimal-kvadratrødder, hvis grænser kontrolleres ved eksakt kvadrering. Den reproducerer alle 105 delceller, deres 106 densitetsendepunkter, fem guard-grupper og eksakte vægt- og elektronbredder. Kontrollen består. V105 foretager én ny vægtevaluering og dens kontrol.

## Hvad der fortsat begrænser svaret

Efter denne forbedring er cirka 4,18414348648×10⁻⁵ af den globale bredde knyttet til området uden for pilotintervallet. Inde i piloten er elektronbidraget cirka 1,90596818340×10⁻⁶, mens vægtbidraget er cirka 1,09133872409×10⁻⁸. Disse er bidrag til intervalbredder under den valgte indhylling, ikke målte fysiske variationer.

Resultatindtag skal kontrollere og optage ankeret og den forbedrede optiske indhylling, vurdere denne breddefordeling og vælge den næste konkrete opgave med betydning for Q052. Den forbedrede skalar- og optiske indhylling ændrer ikke, at native reproducerbarhed, banekonsistens og det efterspurgte numeriske fejlcertifikat mangler. Kørslens status er ACTIVE / CONTINUE / INCONCLUSIVE, med både den bestilte ankertest og vægttest bestået.
