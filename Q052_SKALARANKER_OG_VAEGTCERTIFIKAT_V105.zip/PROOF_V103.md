# Q052 V103 · Dokumenteret skalarfortsættelse

## Resultat og gyldighed

V103 tilføjer 179 sammenhængende celler til V101's 1.071 celler, under samme kilde-, initialiserings- og B★-præmisser. Det samlede betingede præfiks omfatter dermed 1.250 celler. De nye celler løber fra z ≈ 868.538,175 til z ≈ 5.481,051. De eksakte rationelle endepunkter står i `result_raw103.json`. Der er ikke nået et anker ved z=800 og ikke udført en ny optisk vægttest. Dette er et delresultat for en kilde-reel skalar-IVP, ikke et certifikat for native CLASS/P6's flydende-komma-historier.

## Ligning og frosne input

Alle indfangede binary64-tal fortolkes som deres eksakte reelle værdier. De numeriske literaler 4152.39, 2.435e27 og 3.968e-8 behandles ligeledes som deres binary64-værdier. Sæt

\[
U(\phi)=A(1-\cos(\lambda\phi))^3,\quad
A=\operatorname{binary64}(4152.39)m^2F^2,\quad
\lambda=\operatorname{binary64}(2.435\cdot10^{27})/F,
\quad f=B\operatorname{binary64}(3.968\cdot10^{-8}).
\]

Her er F og B kildeparametre, ikke vektorfeltet eller Picard-boksen. Med X i Mpc⁻¹ og H i Mpc⁻¹ er

\[
H^2=B_0(a)+(X^2/2+U+f)/3,\qquad
\frac{d}{d\ln a}(\phi,X)=(X/H,-3X-U_\phi/H).
\]

B₀ indeholder stof, stråling og samtlige 11 indfangede massive-neutrino-kvadraturpunkter. Konfigurationens udeladte komponentflag er arvet og frosset som i V101. I en celle anvendes t=(a−a₀)/a₀, h=(a₁−a₀)/a₀; højresiden divideres med 1+t. Energifunktionen er e=X²/2+U, i Mpc⁻², uden det konstante f.

## Eksistens, referencekurve og defekt

En konveks helcelleboks B valideres med Picard-inklusionen

\[
y_0+[0,h]F([0,h],B)\subseteq B.
\]

H²>0 gør feltet glat på boksen. Den frosne kildegren kontrolleres ved G=3B₀+X²/2−U+f>0. Både producenten og den separate rationelle evaluator kontrollerer felt og guard på alle accepterede celler. Polynomet P af grad 12 har eksakt rationelle koefficienter og starter i indgangsboksens eksakte midtpunkt. Efterauditten kontrollerer P([0,h])⊆B ved rationel interval-Horner samt midtpunkt og startradius på alle celler.

For d(t)=F(t,P(t))−P′(t) beregnes koefficienterne til orden 11 ved t=0. For orden 12 beregnes normaliserede afledte på hele intervallet [0,h] med interval-Taylor-algebra og den translaterede polynomium-jet. Taylors restled giver

\[
|d_i(t)|\le r_i=
\sum_{k=0}^{11}|c_{ik}|h^k+
\sup_{\xi\in[0,h]}\left|\frac{(F(\cdot,P(\cdot)))_i^{(12)}(\xi)}{12!}\right|h^{12}.
\]

P′ har grad 11 og intet yderligere restled. r afrundes op til et 2⁻²⁰⁰-gitter. Hver accepteret celle opfylder rᵢ≤10⁻⁸ per enhed lokal t (X-komponenten i Mpc⁻¹). Dette er en defektgrænse, ikke en påstand om samme globale endepunktsfejl.

## Sammenligning med fortegnsbevarede diagonaler

I lokal tid er Jacobimatricen

\[
J=\frac1{1+t}\begin{pmatrix}
-XU_\phi/(6H^3)&1/H-X^2/(6H^3)\\
-U_{\phi\phi}/H+U_\phi^2/(6H^3)&-3+U_\phi X/(6H^3)
\end{pmatrix},
\]

hvor

\[
U_{\phi\phi}=3A\lambda^2\{\cos\theta(1-\cos\theta)^2+2\sin^2\theta(1-\cos\theta)\},\quad\theta=\lambda\phi.
\]

Vælg konstant M med Mᵢᵢ≥sup Jᵢᵢ og Mᵢⱼ≥sup|Jᵢⱼ| for i≠j, afrundet op til 2⁻¹⁴⁴. Middelværdiintegralet mellem y og P ligger i B. For e=y−P fås derfor den øvre Dini-ulighed

\[
D^+|e_i|\le M_{ii}|e_i|+\sum_{j\ne i}M_{ij}|e_j|+r_i.
\]

M er Metzler. Løsningen w′=Mw+r med indgangsboksens komponentradier som w(0) dominerer |e|. Det er afgørende, at diagonalerne ikke erstattes af deres absolutværdi.

Med L=[[M,r],[0,0]], s=max(0,−M₀₀,−M₁₁) og N=L+sI≥0 gælder exp(hL)=exp(−sh)exp(hN). Den positive matrixserie til orden k beregnes udadrettet. For b≥h‖N‖∞ og b/(k+2)<1 er den resterende vektornorm højst

\[
\max(1,\|w(0)\|_\infty)
\frac{b^{k+1}}{(k+1)!}\frac1{1-b/(k+2)}.
\]

b afrundes op til 2⁻²⁰⁰; den valgte hale er under 2⁻¹⁹⁰ før oprunding til 2⁻²⁴⁰. Endepunktet omsluttes af P(h)±w(h) og skæres med B. Efterauditten kontrollerer de eksakte norm-, hale-, forbindelses- og skæringsuligheder på alle 179 celler.

## Hvad er uafhængigt kontrolleret?

Producenten anvender mpmath.iv ved 50 decimaler. Samme polynomium og boks genberegnes ved 80 decimaler; parameterintervaller fra 50-decimalers initialiseringen beholdes. Denne genberegning deler jet- og defektkode med producenten og er ikke en uafhængig Taylor-implementering. Hvor endepunktsindhyllingerne ikke er indlejrede, bruges deres omsluttende union før skæring med B.

En separat evaluator med eksakte Fraction-operationer og udadrettet 240-bit-dyadisk afrunding kontrollerer Picard-feltet, guard, Jacobidomination og sammenligningseksponentialen på samtlige accepterede celler. Den bruger heltalskvadratrødder og sinus/cosinus-Taylor-serier med eksakt restled. Efterauditten tilføjer uafhængige energigrænser for alle 179 endepunkter. Samtlige 3.261 efterauditkontroller består. Indgang og foregående udgang er identiske som gemte rationelle bokse; ingen ekstra udvidelser blev nødvendige mellem cellerne.

Det er et reproducerbart, betinget numerisk certifikat. Det er ikke et maskinformaliseret bevis, en uafhængig validering af hele den historiske initialisering eller et native trajectory-certifikat.

## Delmål og stop

Ved a=2a_start er energibredden cirka 1,385913668×10⁻⁷ Mpc⁻², mod den tilladte 6,644263717×10⁻⁷. Bredden er 2,085879981 gange V101-bredden og holder sig dermed under grænsen på 10 gange. Dette delmål nås ved den registrerede aktive tid 47,5514 s.

Efter 179 accepterede celler og 33 afviste forslag stopper den uændrede stopregel ved første uafklarede valideringsfejl. Den næste celle, med højre kandidatpunkt z≈5.410,521, er ikke accepteret. X-komponenten i den separate Picard-evaluering overskrider producentens helcelleboks med cirka 0,0997747 nedad og 0,0691719 opad. Det beviser ikke, at den sande løsning forlader boksen; to korrekte intervaludtryk kan have forskellig overestimering.

På den gemte fejlcelle spænder θ over cirka [1,56268048; 1,67870722]. Den grove Lipschitz-evaluator giver sin θ i [0,94074201; 1,05676874]. En simpel skæring med [−1,1] er stadig for bred til Picard-kontrollen. Den grove nedre grænse er dog positiv, så sin″θ=−sinθ<0 på hele intervallet. Konkavitet giver derfor minimum i et endepunkt; sammen med sin≤1 fås den skarpere, rationelt indhyldede grænse omtrent [0,99418327; 1].

En isoleret efterdiagnose med denne begrundede grænse består den gemte kandidats separate Picard-, guard-, Jacobi- og sammenligningskontroller. Der udføres ingen ny fremføring eller defektgenberegning, og kandidaten bliver ikke promoveret. Det leverede checkpoint forbliver efter celle 179. Næste motor skal vurdere diagnosen og forberede en ny afgrænset fortsættelse.

## Kørselshistorik og afvigelser

Før første accepterede celle blev et serialiseringsproblem med meget lange rationale tal løst ved udadrettet afrunding af defekt, norm og hale. En efterfølgende første-cellekontrol viste Jacobigab på cirka 3,53×10⁻⁶⁸, 3,90×10⁻⁵⁶ og 1,25×10⁻⁵⁰. Sammenligningsmatricen blev derefter afrundet op på 2⁻¹⁴⁴-gitteret. Begge tidligere kodeversioner og deres diagnostik er bevaret. Ingen ligning, fysisk parameter eller accepteret historisk celle blev ændret.

Jim genoptog arbejdet efter en natlig pause. Runtime er derfor registreret som akkumuleret aktiv forløbstid: 41,084710831 s fra første forløb plus 0,267714756 s til første-celle-diagnosen blev bevaret ved genoptagelsen. Inaktiv suspension er udeladt. Dette er en eksplicit fortolkning af den oprindelige 300-sekunders grænse, ikke en påstand om et sammenhængende forløb under 300 sekunder. Slutloggen viser 103,749777559 aktive sekunder inkl. fremføring og løbende cellekontroller. Efterdiagnoser og efteraudit føres separat; deres registrerede tider bringer det samlede registrerede aktive beregningsarbejde til cirka 110,20 sekunder. Pakning og journalføring er ikke integrationstid.

V101's 1.071 gamle celler blev ikke integreret igen. Der er nul nye native par, nul nye fulde historier og nul nye vægtevalueringer. V99's optiske resultater og V95's maksimumlokation er uændret arvet evidens. Q052 forbliver ACTIVE / CONTINUE / INCONCLUSIVE.
