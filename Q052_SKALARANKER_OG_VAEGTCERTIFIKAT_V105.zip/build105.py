"""Package completed scalar and weight evidence without executing new research."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256,sha1
from zipfile import ZipFile,ZIP_DEFLATED
import json,copy
P=Path(__file__).resolve().parent;ROOT=P.parents[1];S=ROOT/'upload';O=ROOT/'output/V105';O.mkdir(parents=True,exist_ok=True)
def read(n):return json.loads((P/n).read_bytes())
def h(b):return sha256(b).hexdigest()
def dump(o):return (json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode()
def fingerprint(o):return h(json.dumps({k:v for k,v in o.items() if k!='fingerprint_sha256'},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
r,t,v,w,wc,old=map(read,['result_raw105.json','task104.json','verification105.json','weight/result105_weight.json','weight/control105_weight.json','result103.json'])
audit=read('input_audit105.json');head=audit['repository_head'];tree=read('repository_tree.json');paths={x['path']:x['sha'] for x in tree['tree']}
repo='https://github.com/Morfindien/Bubbleverse';stamp=datetime.now(timezone.utc).isoformat()
J='Q052_MATEMATIK_OG_SAMLET_JOURNAL_V105.md';T='Q052_RESULTATINDTAG_OPGAVE_V105.json';A='Q052_KORT_RESULTAT_V105.md';Z='Q052_SKALARANKER_OG_VAEGTCERTIFIKAT_V105.zip';names=[A,J,T,Z]
assert not any(n in paths for n in names)
parentjournal='Q052_INGESTION_OG_SAMLET_JOURNAL_V104-1.md';parentcert='Q052_INGESTION_CERTIFICATE_V104.zip';scalarparent=t['input_certificate']
run='LOCAL-Q052-Z800-ANCHOR-AND-WEIGHT-V105';event='Q052-ACTIVITY-Z800-ANCHOR-AND-WEIGHT-V105'
assert v['status']=='PASS_CONDITIONAL' and r['target_reached'] and w['target_met'] and wc['status']=='PASS'
assert t['fingerprint_sha256']==fingerprint(t)==r['task_fingerprint']==w['task_fingerprint']
assert r['certified_end_a']=='1/801' and r['certified_end_z']=='800'
assert w['anchor_raw_sha256']==h((P/'result_raw105.json').read_bytes())
intake=(S/'Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0-109.md').read_bytes();math=(S/'Bubbleverse_Matematikmotor_2.3.0-49.md').read_bytes()
blob=lambda b:sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
assert blob(intake)==paths['Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0.md']
assert blob(math)==paths['Bubbleverse_Matematikmotor_2.3.0.md']
prior=read('parent_activity_ledger.json');assert sum(x['run_points'] for x in prior['entries'])==prior['total_points_after']==13360
assert event not in [x.get('activity_event_id',x['run_id']) for x in prior['entries']]
breakdown={'mathematical_analysis':40,'implementation_and_computation':60,'independent_validation':60,'source_and_repository_audit':20}
basis='Rounded heuristic for the new trigonometric enclosure, 142-cell continuation, exact z800 anchor, one 105-subcell weight screen and independent controls. Historical replay, copying, packaging and publication are not credited.'
ledger=copy.deepcopy(prior);ledger['entries'].append({'activity_event_id':event,'run_id':run,'engine':t['engine'],'run_points':180,'breakdown':breakdown,'basis':basis,'counted_once':True,'assessment_type':'HEURISTIC_DOCUMENTED_ACTIVITY_INDEX','uncertainty':'Subjective activity estimate, not scientific confidence, completion percentage, measured tokens or money.'})
ledger.update(previous_ledger_ref=f'{parentcert}#activity_ledger.json',previous_total_points=13360,total_points_after=13540,cycle_progress=540,next_publication_at=14000,points_to_next_publication=460,new_milestones=[],pending_packages=[],ledger_revision='V105',parent_ledger_sha256=h((P/'parent_activity_ledger.json').read_bytes()),last_updated_utc=stamp,reconciliation={'prior_total':13360,'new_unique_event_points':180,'current_total':13540},note=basis)
assert sum(x['run_points'] for x in ledger['entries'])==13540 and ledger['entries'][:-1]==prior['entries']
assert ledger['milestone_records']==prior['milestone_records'] and not prior['pending_packages']
checkpoint={'certified_end_a':r['certified_end_a'],'certified_end_z':r['certified_end_z'],'endpoint':r['endpoint'],'energy_endpoint':r['energy']}
result={'schema':'Q052_V105_Z800_ANCHOR_AND_WEIGHT_RESULT','created_at_utc':stamp,'result_id':run,'task_id':t['task_id'],'task_fingerprint':t['fingerprint_sha256'],'exact_question':t['exact_question'],'source_commit':t['source_commit'],'capture_sha256':t['capture_sha256'],'engine':t['engine'],'scientific_state':'INCONCLUSIVE','technical_state':'PASS_CONDITIONAL_Z800_ANCHOR_AND_WEIGHT_TARGET','workflow_state':'READY_FOR_HANDOFF','scope':'Fixed source-real scalar IVP and optical enclosure under inherited B-star, captured-real and initialization premises.','checkpoint':checkpoint,'anchor_z800_gate':'PASS','weight_screen':'PASS_FROZEN_25_PERCENT_WEIGHT_TARGET','accepted_new_cells':142,'rejected_candidates':27,'inherited_prefix_cells':1250,'total_conditional_prefix_cells':1392,'prototype_wall_seconds':r['wall_seconds'],'prototype_limit_seconds':300,'preflight_cases':8,'verification_ref':'verification105.json','verification_scope':v['higher_precision_scope'],'new_native_pairs':0,'new_full_history_integrations':0,'new_weight_evaluations':1,'weight_result_ref':'weight/result105_weight.json','weight_verification_ref':'weight/control105_weight.json','new_energy_cap_at_z800':r['energy'][1],'optical_result':{k:w[k] for k in ['pilot_interval','new_weight_width','weight_width_ceiling','target_met','width_accounting','new_global_interval','global_width','global_width_goal_met','global_width_goal_ratio','maximum_location']},'metrics':v['metrics'],'q052_completion_gate':False,'remaining_uncertainties':['Full global precision goal remains unmet','Native pair trajectory consistency and numerical error','Native reproducibility and requested realized suprema with error certificate'],'limitations':['Historical source-real initialization and common B-star remain inherited conditional premises.','50/80-digit Taylor-defect checks share implementation. Independent rational checks cover field, Picard, guard, Jacobian, comparison and endpoint energy.','The weight-control implementation shares historical physical premises while recomputing the arithmetic separately.'],'next_engine':t['return_engine'],'continue_same_q':True}
nexttask={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','task_id':'LOCAL-Q052-V105-ANCHOR-WEIGHT-RESULT-INGESTION','engine':t['return_engine'],'engine_prompt_sha256':h(intake),'state':'PREPARED_NOT_EXECUTED','case_id':t['case_id'],'current_q':'Q052','target_q':'Q052','exact_question':t['exact_question'],'source_commit':t['source_commit'],'capture_sha256':t['capture_sha256'],'parent_result_id':run,'input_certificate':Z,'input_result_ref':f'{Z}#result105.json','input_result_sha256':h(dump(result)),'input_checkpoint':checkpoint,'objective':'Ingest the conditional exact z800 anchor and passed frozen weight screen. Reconcile optical width accounting and select one finite next task that materially advances Q052.','required_actions':['Verify manifest, V104 task identity, the exact 142-cell connection from V103 and the independent-check scope.','Accept the exact a=1/801 anchor and the single 105-subcell weight result within their declared conditional scope. Preserve the frozen electron interval, B-star and source configuration.','Verify the global replacement against V99, distinguish the frozen V97 target baseline from the additional V99 improvement, and preserve exact fractions.','Review the remaining width budget: outside-pilot width, pilot electron width and pilot weight width. Compare the unresolved native-error prerequisites and choose one specific material next test with recoverable inputs and explicit acceptance/stop criteria.','Keep Q052 open until its complete native-history question is answered or its non-identifiability is established. Carry forward the cumulative point and delivery ledger.'],'execution_limits':{'new_scalar_integrations_in_this_intake':0,'new_native_pairs':0,'new_full_history_integrations':0,'new_weight_evaluations':0},'acceptance_criteria':'Authentic contiguous anchor, valid source link, independently controlled optical result and exact width accounting. One concrete next-task contract targets a material remaining uncertainty.','rejection_criteria':'An input identity, chain, common-background, arithmetic or proof conflict prevents promotion of the affected result. Preserve unaffected evidence.','stop_condition':'Finish one ingestion decision and one finite next-task handoff, or record the first unresolved material premise.','no_repeat':t['no_repeat']+['V105 142-cell z800 continuation and passed 105-subcell weight screen on identical inputs. Reuse their certificates; rerun only for a documented validation issue or changed premise.'],'continue_same_q':True,'total_points':13540,'next_milestone':14000,'points_to_next_publication':460}
nexttask['fingerprint_sha256']=fingerprint(nexttask)
claims=[{'id':'Q052-V105-C1','statement':'The exact z800 anchor is reached after 142 new accepted cells. The combined conditional prefix has 1392 cells.','evidence':['result_raw105.json','verification105.json','preflight105.json']},{'id':'Q052-V105-C2','statement':'The new anchored weight screen passes its frozen 25 percent reduction target and reduces weight width 98.6061 percent relative to V99.','evidence':['weight/result105_weight.json','weight/control105_weight.json','verification105.json']},{'id':'Q052-V105-C3','statement':'The global width decreases 1.16252 percent relative to V99; it remains 10939.58 times the provisional global precision goal.','evidence':['weight/result105_weight.json','verification105.json']},{'id':'Q052-V105-C4','statement':'Q052 remains open; native reproducibility, trajectory consistency and the requested numerical error certificate are unresolved.','evidence':['result105.json','task104.json']},{'id':'Q052-V105-C5','statement':'One research event adds 180 points to 13360, giving 13540. M001-M013 delivery is retained; next milestone at 14000.','evidence':['activity_ledger.json','history/activity_ledger_v104.json']}]
ref=lambda n:f'{Z}#{n}'
memory={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','q':'Q052','prompt_id':'BUBBLEVERSE.MATHEMATICS','prompt_version':'2.3.0','run_id':run,'repository_url':repo,'base_commit_sha':head,'branch':'main','source_journal':parentjournal,'proposed_journal_path':J,'GITHUB_READ_STATE':'FOUR_V104_INPUTS_AND_ENGINE_BLOBS_VERIFIED','GITHUB_WRITE_STATE':'NOT_PERFORMED_USER_UPLOAD_PENDING','commit_sha':None,'pull_request_url':None,'exact_question':t['exact_question'],'scientific_state':'INCONCLUSIVE','technical_state':result['technical_state'],'workflow_state':'READY_FOR_HANDOFF','new_claims':[x['id'] for x in claims],'run_points':180,'total_points':13540,'points_basis':basis,'ledger_ref':ref('activity_ledger.json'),'delivered_milestone_ids':ledger['delivered_milestone_ids'],'pending_some_packages':[],'next_some_threshold':14000,'points_to_next_publication':460,'external_publication_status':'NOT_REQUESTED','resolved_blocker':'Q052-V103-INDEPENDENT-TRIGONOMETRIC-RANGE-LOSS','next_engine':t['return_engine'],'next_task':T,'resume_condition':'Ingest the completed anchor and optical screen; select a material remaining native or global-error dependency.','proposed_files':[{'path':n,'operation':'ADD','hash_ref':ref('manifest.json')} for n in names],'current_state_path':None,'index_refs':[],'index_update_instruction':'Identify the canonical Q052 pointer before changing it. Once all four new files resolve, update the existing pointer to V105 and retain older versions.','filename_aliases_from_parent':audit['filename_aliases'],'completed_do_not_repeat':nexttask['no_repeat'],'upload_instructions_ref':ref('README.md')}
handoff={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','prompt_id':'BUBBLEVERSE.MATHEMATICS','prompt_version':'2.3.0','handoff_id':run,'created_at_utc':stamp,'case_id':t['case_id'],'current_q':'Q052','target_q':'Q052','exact_question':t['exact_question'],'authorized_evidence_boundary':'Q052 and necessary predecessors only','source_commit':t['source_commit'],'capture_sha256':t['capture_sha256'],'case_lifecycle':'ACTIVE','disposition':'CONTINUE','scientific_state':'INCONCLUSIVE','technical_state':result['technical_state'],'workflow_state':'READY_FOR_HANDOFF','selected_next_engine_id':t['return_engine'],'engine_registry_ref':{'path':'Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0.md','git_blob':blob(intake),'sha256':h(intake)},'journal_ref':J,'journal_completeness':'Entire available V104 journal retained as exact byte prefix','result_ref':ref('result105.json'),'verification_ref':ref('verification105.json'),'source_register_ref':ref('source_register.json'),'claim_evidence_map_ref':ref('claim_map.json'),'integrity_manifest_ref':ref('manifest.json'),'completed_tests':['8 trigonometric cases and stored-candidate preflight','142 new accepted scalar cells with in-run independent checks','Exact z800 anchor','One anchored 105-subcell optical screen and separate arithmetic control','Final exact chain/controller/weight reconciliation'],'new_information':['Validated endpoint energy at z800','Frozen weight test passes','Remaining global interval width is predominantly outside the pilot'],'checkpoint':checkpoint,'next_task':T,'next_task_fingerprint':nexttask['fingerprint_sha256'],'acceptance_criteria':nexttask['acceptance_criteria'],'rejection_criteria':nexttask['rejection_criteria'],'inconclusive_criteria':'Full native error certificate and global precision are still unresolved','completion_gate_satisfied':False,'completion_gate_reason':'Remaining native-history and global-error requirements have not been discharged.','contract_validation':'Manual local contract fields, identities, fingerprints, JSON and archive integrity; no external formal schema asserted.','repository_memory':memory,'setup_assessment':{'observed_python':v['python'],'mpmath':v['mpmath'],'recommended':'Same local environment for audit and finite next-task preparation','reasoning_setting':'No external runtime measurement asserted','fallback':'Inspect exact stored certificate records','upgrade_trigger':'A specific material proof gap requires another independent implementation'},'question_activity_points':{'run_id':run,'event_id':event,'run_points':180,'parent_total':13360,'total_points':13540,'breakdown':breakdown,'basis':basis,'ledger_ref':ref('activity_ledger.json'),'points_state':'VERIFIED'},'some_milestones':{'next_threshold':14000,'points_to_next_threshold':460,'crossed_this_run':[],'pending_packages':[],'delivered_milestone_ids':ledger['delivered_milestone_ids'],'package_creation_status':'NOT_DUE','external_publication_status':'NOT_REQUESTED'},'continue_same_q':True,'output_file_refs':names}
proof=(P/'PROOF_V105.md').read_text()
primary=f'''# BUBBLEVERSE — OVERLEVERING

**Ankeret ved z=800 og den bestilte optiske vægttest er bestået under de fastholdte kildepræmisser. Q052 fortsætter til Resultatindtag 2.3.0.**

STATUS: FORTSÆTTER  
WORKFLOW_STATE: READY_FOR_HANDOFF  
SCIENTIFIC_STATE: INCONCLUSIVE  
TECHNICAL_STATE: PASS_CONDITIONAL_Z800_ANCHOR_AND_WEIGHT_TARGET  
TARGET_Q: Q052  
AUTHORIZED_Q_RANGE / EVIDENCE_BOUNDARY: Q052 og nødvendige forgængere.  
PROMPT_ID: BUBBLEVERSE.MATHEMATICS  
PROMPT_VERSION: 2.3.0  
VALGT NÆSTE MOTOR: {t['return_engine']}

## Afgjort og ny information

142 nye validerede celler fører beregningen fra z≈5.481,051 til præcis **z=800**. Hele det betingede præfiks har nu 1.392 celler. Fremføring, forprøver og nye cellekontroller tog **57,02 sekunder**. Ved målet er skalarenergien omsluttet af [0,15149356148218; 0,15692069539820] Mpc⁻², vist udad afrundet. Eksakte grænser findes i certifikatet.

Den efterfølgende vægttest på de 105 frosne delceller består. Vægtens bidrag til pilotens usikkerhedsbredde falder **98,61 % fra V99**. Reduktionen er 98,75 % mod den frosne V97-reference, hvor kravet var mindst 25 %. Pilotens samlede bredde falder 21,17 % fra V99. Den globale bredde falder **1,16 %** og er stadig cirka 10.940 gange det foreløbige fulde præcisionsmål.

Q052's fulde CLASS/P6-spørgsmål er stadig åbent. Native reproducerbarhed, banekonsistens og det efterspurgte numeriske fejlcertifikat udestår.

## Aktuel overlevering

Det tidligere stop ved sinusindhyllingen er passeret med frisk cellevalidering. Resultatindtag skal nu optage ankeret og den forbedrede optiske indhylling, kontrollere den resterende breddefordeling og vælge én konkret næste opgave med betydning for Q052. Området uden for piloten bidrager cirka 4,18414×10⁻⁵ til den globale bredde. Inden for piloten bidrager elektronindhyllingen cirka 1,90597×10⁻⁶, mens vægten bidrager cirka 1,09134×10⁻⁸.

Opgaven, acceptance-, rejection- og stopkriterier findes i `{T}`. Samme B★, kildeparametre og elektronkontrakt er grundlaget. De beståede forsøg genbruges som evidens. Den næste motor skal være færdig med ét indtag og én afgrænset næste opgave, eller dokumentere den første uafklarede materielle præmis.

## Validering og forbehold

Otte trigonometri-forprøver bestod. På alle 142 nye celler blev felt, Picard-boks, kildeguard, Jacobigrænse, sammenligning og endepunktsenergi kontrolleret med separate rationelle intervalprimitiver. Den afsluttende record-audit har 994 beståede cellekontroller. Den optiske kontrol reproducerer de 105 delceller med en separat densitetsformel og kvadratrodskontrol.

Defektgenberegningen ved 50 og 80 decimaler deler kode. Den oprindelige initialisering og kilde-reelle fortolkning er arvede betingelser. Runden omfatter én ny skalarprototype og én vægttest med kontrol; native par og fulde native historier er fortsat uden for denne udførelse. Resultaterne er betingede matematiske indhyllinger.

## Point- og udgivelsesstatus

RUN POINTS: 180 pts  
TOTAL POINTS: 13.540 pts  
CYCLE PROGRESS: 540/1000 pts  
NEXT SOME MILESTONE: 14.000 pts  
POINTS TO NEXT PUBLICATION: **460 pts**  
RUN_ID: {run}  
PREVIOUS_POINTS_ENTRY: {parentcert}#activity_ledger.json  
POINTS_STATE: VERIFIED  
PUBLICATION_STATE: NOT_DUE  
PENDING SOME PACKAGES: Ingen. M001–M013 er allerede leveret.

Fordeling 40 matematisk analyse, 60 implementering/beregning, 60 validering og 20 kilde-/repositoryaudit. Vurderingen er et afrundet aktivitetsindeks. Pakning og historisk arbejde giver ingen nye point.

## ChatGPT-setupvurdering for næste trin

AKTUELT SETUP: Python {v['python'].split()[0]} og mpmath {v['mpmath']}, verificeret ved kørsel.  
ANBEFALET PRIMÆRT SETUP: Samme lokale miljø til indtag og kontrol af eksakte resultater.  
TILGÆNGELIGHED: Verificeret i denne runde.  
KAPABILITETSKLASSE: Kode, intervalregning og kilde-/artefaktaudit.  
REASONING-NIVEAU: Ingen ekstern måling af indstillingen bruges som evidens.  
BEGRUNDELSE: Næste opgave kræver kontrol af gemte certifikater og valg af den resterende afgørende test.  
FALLBACK: Læs de eksakte gemte brøker og bevisreferencer.  
UPGRADE-TRIGGER: En konkret bevismangel kræver en anden uafhængig implementering.  
DOWNGRADE-TRIGGER: Ren fil- og referencekontrol.  
PLUGIN-/TOOLBEHOV: Python og læseadgang til de hashbundne kildearkiver.

## Samlet journal og kildegrundlag

Den fulde journal leveres som `{J}`. Den vedhæftede V104-journal er bevaret byte for byte som præfiks. Uploadnavnene med `-1` er registreret som navnealiaser med identisk indhold.

Fysikkilden er commit `{t['source_commit']}`. Capture er SHA-256 `{t['capture_sha256']}`. Den observerede GitHub-base er `{head}`. De fire V104-filer og motorversionerne matcher denne bases blobs. Kilde-, bevis- og valideringsreferencer samt den fulde eksakte opgave står i `{Z}`. [Projektets verificerede base]({repo}/tree/{head}).

## Kontraktvalidering og checkpoint

Hovedspørgsmålet er uændret og er gengivet ordret i overleveringen og opgaven. JSON, identiteter, fingerprints, filreferencer, arkivintegritet og journalpræfiks er kontrolleret lokalt. Den anvendte kontrakt er mærket UNVALIDATED_LOCAL_CONTRACT, og ingen ekstern formel schema-validation påstås.

V105-filerne er klar til upload. GitHub-write afventer Jim. README og den strukturerede memory-update i arkivet angiver de fire nye rodfiler og kontrol for nyere Q052-versioner før upload.
'''
append=f'''# Q052 · V105 · {stamp}

RUN_ID: {run}  
INPUT_TASK: {t['task_id']}  
INPUT_FINGERPRINT: {t['fingerprint_sha256']}  
STATUS: ACTIVE / CONTINUE / INCONCLUSIVE  
NÆSTE MOTOR: {t['return_engine']}

Hovedspørgsmålet er fastholdt:

> {t['exact_question']}

{proof}

## Termination-gates

| Gate | Resultat |
|---|---|
| G1 | PASS, samme Q052 og frosne domæne. |
| G2 | PASS_CONDITIONAL, sporbar kilde/capture og præcis forbindelse til V103, med arvede initialiseringspræmisser. |
| G3 | PASS for den bestilte anker- og vægttest. Fuldt native fejlcertifikat udestår. |
| G4 | Forprøver, 50/80-decimalers replay og separate intervalkontroller inden for den frosne konfiguration. |
| G5 | Delvist uafhængige numeriske kontroller. Taylor-defektkoden er delt. |
| G6 | ÅBEN, globalt præcisionsmål og native historiekrav er uafklarede. |
| G7 | PASS, fuld V104-præfiks og nye resultater samt ledger bevares. |

## Ny aktivitetsregistrering og projektstatus

Event `{event}` tilføjer 180 point til 13.360 og giver **13.540**. Fordelingen er 40 analyse, 60 implementering/beregning, 60 validering og 20 kildeaudit. {basis}

M001–M013 er bevaret som leveret. Næste SoMe-milepæl er 14.000 med 460 point dertil. Dette er en aktivitetsafstand og giver ingen procentvis afstand til Q052's afslutning.

Den observerede projektbase er `{head}`. Fire V104-input matcher GitHub. V104's markdownfiler er lagt på GitHub med `-1`; deres bytes matcher manifestets oprindelige filnavne. V105 er klargjort som fire nye rodfiler. Ingen GitHub-skrivning eller offentlig post er udført.

## Næste konkrete opgave

Resultatindtag skal kontrollere og optage ankeret og vægttesten og vælge én materiel næste opgave efter den globale breddefordeling og de uafklarede native fejlkrav. Den præcise kontrakt er `{T}`. De beståede V105-forsøg genbruges.
'''
(O/A).write_text(primary);(O/T).write_bytes(dump(nexttask));parentbytes=(S/parentjournal).read_bytes()
(O/J).write_bytes(parentbytes+b'\n\n---\n\n'+append.encode()+b'\n## Maskinlaesbar overlevering V105\n\n```json\n'+dump(handoff)+b'```\n\n## Kumulativt aktivitetsledger V105\n\n```json\n'+dump(ledger)+b'```\n')
assert (O/J).read_bytes()[:len(parentbytes)]==parentbytes
readme=f'''# Q052 V105 · Anker- og vægtcertifikat

Læs `{A}` først. Den fulde journal er `{J}` og næste indtagsopgave er `{T}`. Certifikatet omfatter 142 nye skalarceller, det eksakte z800-anker og én optisk vægttest på 105 delceller under de arvede kildepræmisser.

Efter udpakning kan `python verify105.py` kontrollere gemte forbindelser, controller og vægtregnskab. `python weight/control105_weight.py` udfører den separate vægtkontrol. De to scripts fremfører ingen nye skalarceller. Kørsel af `continuation105.py` eller `weight/compute105_weight.py` starter en ny beregning og skriver deres outputfiler; de er medtaget som den faktisk udførte metode. Det faste reproduktionsgrundlag er de gemte eksakte celler og inputhashes. Python 3.12.14 og mpmath 1.3.0 blev anvendt.

`result105.json` samler rundens resultat. `result_raw105.json` er den uændrede skalarlog. Dens vægttæller er 0, fordi vægttesten blev udført bagefter; den samlede tæller i resultat og audit er 1. `weight/` indeholder frosne V99-input, pins, den afledte beregningskode og den separate kontrol. `PROOF_V105.md` forklarer både trigonometri, valideringsomfang og transport af energiloftet.

Tidligere scalar-evidens findes i [V103-arkivet]({repo}/blob/{head}/{scalarparent}) med SHA-256 `{t['input_certificate_sha256']}`. Inputindtaget findes i [V104-arkivet]({repo}/blob/{head}/{parentcert}). Parentarkivet er også medtaget i `history/`.

Upload `{A}`, `{J}`, `{T}` og `{Z}` som fire nye rodfiler til {repo}. Kontrollér først for en nyere Q052-version end den observerede base `{head}`. Find den korrekte eksisterende Q052-henvisning og opdatér den, når alle fire filer kan åbnes. Bevar ældre versioner. GitHub er ikke ændret i denne runde.

Manifestet indeholder medlems- og ledsagefilhashes; manifestets og ZIP-containerens selvhash er udeladt for at undgå cirkler. JSON og alle tilgængelige interne referencer er kontrolleret lokalt.
'''
payload={'README.md':readme.encode(),'result105.json':dump(result),'handoff105.json':dump(handoff),'github_memory_update.json':dump(memory),'activity_ledger.json':dump(ledger),'claim_map.json':dump(claims),A:(O/A).read_bytes(),T:(O/T).read_bytes(),'build105.py':Path(__file__).read_bytes(),'inputs/ENGINE_MATHEMATICS_2.3.0.md':math,'inputs/ENGINE_RESULT_INGESTION_2.3.0.md':intake,'history/activity_ledger_v104.json':(P/'parent_activity_ledger.json').read_bytes(),'history/'+parentcert:(S/parentcert).read_bytes()}
keep=['PROOF_V105.md','PROOF_V103.md','task104.json','result_raw105.json','verification105.json','continuation105.py','trig105.py','prototype101.py','verify101.py','verify105.py','prepare105.py','prepare_weight105.py','make_continuation105.py','continuation103_source.py','prototype105.log','preflight105.json','input_audit105.json','repository_head.json','repository_tree.json','capture.json','result99.json','result103.json','source_register.json','v73.json','initial.json','last_unaccepted_candidate103.json','criticalpoint_diagnostic103.json','parent_handoff104.json','parent_audit104.json']
for name in keep:payload[name]=(P/name).read_bytes()
for path in sorted((P/'weight').iterdir()):
 if path.is_file():payload['weight/'+path.name]=path.read_bytes()
manifest={'schema':'Q052_V105_OUTPUT_MANIFEST','q':'Q052','case_id':t['case_id'],'version':'V105','run_id':run,'created_at_utc':stamp,'repository':repo,'base_commit':head,'parent_artifacts':audit['canonical_files'],'parent_scalar_certificate':{'filename':scalarparent,'sha256':t['input_certificate_sha256'],'url':f'{repo}/blob/{head}/{scalarparent}'},'parent_journal':{'filename':parentjournal,'bytes':len(parentbytes),'sha256':h(parentbytes),'preservation':'Exact byte prefix'},'result_snapshot_sha256':h(dump(result)),'raw_scalar_result_sha256':h(payload['result_raw105.json']),'archive_members':[{'path':n,'bytes':len(b),'sha256':h(b)} for n,b in sorted(payload.items())],'external_deliverables':[{'filename':n,'role':role,'target_path':n,'operation':'ADD','bytes':(O/n).stat().st_size,'sha256':h((O/n).read_bytes())} for n,role in [(A,'primary_handoff'),(J,'full_cumulative_journal'),(T,'next_intake_task')]],'container':{'filename':Z,'target_path':Z,'self_hash_omitted':True},'contract_check':'PASS_MANUAL_LOCAL'}
payload['manifest.json']=dump(manifest)
with ZipFile(O/Z,'w',compression=ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in sorted(payload.items()):z.writestr(n,b)
with ZipFile(O/Z) as z:
 assert z.testzip() is None and set(z.namelist())==set(payload)
 for n,b in payload.items():
  assert z.read(n)==b
  if n.endswith('.json'):json.loads(b)
for value in handoff.values():
 if isinstance(value,str) and value.startswith(Z+'#'):assert value.split('#',1)[1] in payload
assert nexttask['fingerprint_sha256']==fingerprint(nexttask)==handoff['next_task_fingerprint']
assert nexttask['input_result_sha256']==manifest['result_snapshot_sha256']
assert primary.count('# BUBBLEVERSE — OVERLEVERING')==1 and 'BUBBLEVERSE — AFSLUTTET SAG' not in primary
receipt={'status':'PASS','created_at_utc':stamp,'archive_members':len(payload),'parent_prefix_bytes':len(parentbytes),'new_points':180,'total_points':13540,'files':[{'path':str(O/n),'bytes':(O/n).stat().st_size,'sha256':h((O/n).read_bytes())} for n in names]}
(P/'build_receipt105.json').write_bytes(dump(receipt));(P/'upload_request.json').write_bytes(dump({'uploads':[{'local_path':str(O/n),'purpose':'create_library_file','library_artifact_type':'report' if n.endswith('.md') else 'other'} for n in names]}))
print(json.dumps(receipt,indent=2))
