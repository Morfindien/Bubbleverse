"""Rational trigonometric range refinement with proved sign conditions."""
from fractions import Fraction
from verify101 import I

def intersect(first, second):
    return I(max(first.l,second.l),min(first.h,second.h))

def enclose(argument):
    # sincos enforces |argument|<4 and provides outward Taylor/Lipschitz bounds.
    sine,cosine=argument.sincos()
    sine=intersect(sine,I(-1,1));cosine=intersect(cosine,I(-1,1))
    left_sine,left_cosine=I(argument.l).sincos()
    right_sine,right_cosine=I(argument.h).sincos()
    if cosine.l>0:
        sine=intersect(sine,I(left_sine.l,right_sine.h))
    elif cosine.h<0:
        sine=intersect(sine,I(right_sine.l,left_sine.h))
    if sine.l>0:
        cosine=intersect(cosine,I(right_cosine.l,left_cosine.h))
    elif sine.h<0:
        cosine=intersect(cosine,I(left_cosine.l,right_cosine.h))
    # f''=-f gives concavity for f>0 and convexity for f<0.
    if sine.l>0:
        sine=intersect(sine,I(min(left_sine.l,right_sine.l),1))
    elif sine.h<0:
        sine=intersect(sine,I(-1,max(left_sine.h,right_sine.h)))
    if cosine.l>0:
        cosine=intersect(cosine,I(min(left_cosine.l,right_cosine.l),1))
    elif cosine.h<0:
        cosine=intersect(cosine,I(-1,max(left_cosine.h,right_cosine.h)))
    return sine,cosine
