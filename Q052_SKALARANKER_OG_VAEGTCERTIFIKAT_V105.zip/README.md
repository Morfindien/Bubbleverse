# Q052 V105 · Anker- og vægtcertifikat

Læs `Q052_KORT_RESULTAT_V105.md` først. Den fulde journal er `Q052_MATEMATIK_OG_SAMLET_JOURNAL_V105.md` og næste indtagsopgave er `Q052_RESULTATINDTAG_OPGAVE_V105.json`. Certifikatet omfatter 142 nye skalarceller, det eksakte z800-anker og én optisk vægttest på 105 delceller under de arvede kildepræmisser.

Efter udpakning kan `python verify105.py` kontrollere gemte forbindelser, controller og vægtregnskab. `python weight/control105_weight.py` udfører den separate vægtkontrol. De to scripts fremfører ingen nye skalarceller. Kørsel af `continuation105.py` eller `weight/compute105_weight.py` starter en ny beregning og skriver deres outputfiler; de er medtaget som den faktisk udførte metode. Det faste reproduktionsgrundlag er de gemte eksakte celler og inputhashes. Python 3.12.14 og mpmath 1.3.0 blev anvendt.

`result105.json` samler rundens resultat. `result_raw105.json` er den uændrede skalarlog. Dens vægttæller er 0, fordi vægttesten blev udført bagefter; den samlede tæller i resultat og audit er 1. `weight/` indeholder frosne V99-input, pins, den afledte beregningskode og den separate kontrol. `PROOF_V105.md` forklarer både trigonometri, valideringsomfang og transport af energiloftet.

Tidligere scalar-evidens findes i [V103-arkivet](https://github.com/Morfindien/Bubbleverse/blob/5d5d11929af2a4360e497508fa1e284c3513b5a9/Q052_SKALAR_FORTSAETTELSESCERTIFIKAT_V103.zip) med SHA-256 `0ef72c12aa2f9bcc58c7963089454eac1b6c1f3512bbdaa5878e68545fb3b75c`. Inputindtaget findes i [V104-arkivet](https://github.com/Morfindien/Bubbleverse/blob/5d5d11929af2a4360e497508fa1e284c3513b5a9/Q052_INGESTION_CERTIFICATE_V104.zip). Parentarkivet er også medtaget i `history/`.

Upload `Q052_KORT_RESULTAT_V105.md`, `Q052_MATEMATIK_OG_SAMLET_JOURNAL_V105.md`, `Q052_RESULTATINDTAG_OPGAVE_V105.json` og `Q052_SKALARANKER_OG_VAEGTCERTIFIKAT_V105.zip` som fire nye rodfiler til https://github.com/Morfindien/Bubbleverse. Kontrollér først for en nyere Q052-version end den observerede base `5d5d11929af2a4360e497508fa1e284c3513b5a9`. Find den korrekte eksisterende Q052-henvisning og opdatér den, når alle fire filer kan åbnes. Bevar ældre versioner. GitHub er ikke ændret i denne runde.

Manifestet indeholder medlems- og ledsagefilhashes; manifestets og ZIP-containerens selvhash er udeladt for at undgå cirkler. JSON og alle tilgængelige interne referencer er kontrolleret lokalt.
