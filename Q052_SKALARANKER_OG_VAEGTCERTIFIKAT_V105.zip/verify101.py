"""Verify recorded cells, without advancing or selecting any new step.

Independent rational dyadic interval arithmetic checks every Picard box and
endpoint energy. The Taylor recurrence is separately replayed at 80 digits,
but this part shares the prototype implementation and is labelled accordingly.
"""
from pathlib import Path
from fractions import Fraction as F
from math import isqrt, factorial
import json, time, hashlib, sys
P = Path(__file__).resolve().parent
Q = 2**240

def down(x): return F((x*Q).__floor__(),Q)
def up(x): return F((x*Q).__ceil__(),Q)

class I:
    def __init__(self,l,h=None):
        if isinstance(l,I): self.l,self.h=l.l,l.h; return
        self.l,self.h=down(F(l)),up(F(l if h is None else h))
        assert self.l<=self.h
    def __add__(s,o):
        o=I(o);return I(s.l+o.l,s.h+o.h)
    __radd__=__add__
    def __neg__(s):return I(-s.h,-s.l)
    def __sub__(s,o):return s+-I(o)
    def __rsub__(s,o):return I(o)+-s
    def __mul__(s,o):
        o=I(o);v=[a*b for a in (s.l,s.h) for b in (o.l,o.h)];return I(min(v),max(v))
    __rmul__=__mul__
    def __truediv__(s,o):
        o=I(o);assert not o.l<=0<=o.h;return s*I(1/o.h,1/o.l)
    def __rtruediv__(s,o):return I(o)/s
    def __pow__(s,n):
        assert isinstance(n,int) and n>=0
        if n==0:return I(1)
        v=[s.l**n,s.h**n]
        return I(0 if n%2==0 and s.l<=0<=s.h else min(v),max(v))
    def sqrt(s):
        assert s.l>=0
        lo=isqrt((s.l*Q*Q).__floor__()); hi=isqrt((s.h*Q*Q).__floor__())
        return I(F(lo,Q),F(hi if F(hi*hi,Q*Q)==s.h else hi+1,Q))
    def sincos(s):
        assert max(abs(s.l),abs(s.h))<4
        # Taylor at midpoint with an exact Lagrange bound. Both sine and
        # cosine are globally 1-Lipschitz, so widening by radius is valid.
        mid=(s.l+s.h)/2;radius=(s.h-s.l)/2
        x=I(mid);xx=x*x; sn=I(0);cs=I(0);ct=I(1);st=x
        for k in range(65):
            cs+=ct;sn+=st
            ct=ct*(-xx)/((2*k+1)*(2*k+2))
            st=st*(-xx)/((2*k+2)*(2*k+3))
        tail=max(abs(mid)**129/F(factorial(129)),abs(mid)**130/F(factorial(130)))
        pad=radius+tail
        return I(sn.l-pad,sn.h+pad),I(cs.l-pad,cs.h+pad)
    def monotone_cos(s):
        # The coarse bound certifies sin > 0 on this entire tiny interval.
        # Therefore cosine is decreasing; point Taylor values at the two
        # exact endpoints avoid the unnecessary global Lipschitz widening.
        assert s.sincos()[0].l>0
        left=I(s.l).sincos()[1];right=I(s.h).sincos()[1]
        return I(right.l,left.h)
    def contained(s,row):return F(row[0])<=s.l<=s.h<=F(row[1])
    def saved(s):return [str(s.l),str(s.h)]

def binary(s):return F.from_float(float.fromhex(s))
def read(n):return json.loads((P/n).read_text())

def main():
    started=time.monotonic();r=read('prototype_result.json');c=read('capture.json')['cases']['hillipop-ede_n3'];bg=c['background']
    sc=list(map(binary,bg['scalar']['scf_parameters']));assert sc[0]==3
    assert all(bg['flags'][k]==0 for k in ['has_lambda','has_curvature','has_idm','has_idr','has_dcdm','has_dr','has_fld'])
    assert len(bg['neutrinos'])==1
    b={k:binary(v) for k,v in bg['fields'].items()}
    A=F.from_float(4152.39)*sc[2]**2*sc[1]**2;lam=F.from_float(2.435e27)/sc[1];floor=sc[3]*F.from_float(3.968e-8)
    matter=b['H0']**2*(b['Omega0_b']+b['Omega0_cdm']);rad=b['H0']**2*(b['Omega0_g']+b['Omega0_ur'])
    nu=bg['neutrinos'][0];mass=binary(nu['fields']['M_ncdm']);factor=binary(nu['fields']['factor_ncdm'])
    qs=list(map(binary,nu['q_ncdm_bg']));ws=list(map(binary,nu['w_ncdm_bg']))
    assert len(qs)==len(ws)==11 and all(v>0 for v in [A,lam,floor,matter,rad,mass,factor,*qs,*ws])
    end=F(r['certified_end_a']);guard=3*(matter/end**3+rad/end**4)-8*A+floor;assert guard>0
    # All omitted neutrino density and X^2/2 terms are nonnegative.
    ns={'__file__':str(P/'prototype101.py'),'__name__':'verification_replay'}
    exec(compile((P/'prototype101.py').read_text().replace('iv.dps = 50','iv.dps = 80'),str(P/'prototype101.py'),'exec'),ns)
    init=read('initial.json');now=F(init['a'][0]);previous=init['scalar_state'];failures=[];checks=0
    def check(ok,idx,label):
        nonlocal checks
        checks+=1
        if not ok:failures.append({'cell':idx,'gate':label})
    for idx,cell in enumerate(r['cells']):
        a0,a1=map(F,[cell['a0'],cell['a1']]);h=F(cell['h'])
        check(now==a0 and a1>a0 and h==(a1-a0)/a0,idx,'exact_time_connection')
        check(cell['initial']==previous,idx,'exact_endpoint_connection')
        state=[I(*row) for row in cell['initial']];whole=[I(*row) for row in cell['picard_box']]
        scale=I(1,1+h);a=I(a0)*scale
        B0=I(matter)/a**3+I(rad)/a**4
        B0+=I(factor)/a**4*sum((I(q*q*w)*(I(q*q)+(a*mass)**2).sqrt() for q,w in zip(qs,ws)),I(0))
        sn,cs=(whole[0]*lam).sincos();U=(1-cs)**3*A;H=(B0+(whole[1]**2/2+U+floor)/3).sqrt()
        rhs=[whole[1]/H/scale,(-3*whole[1]-3*A*lam*sn*(1-cs)**2/H)/scale]
        im=[x+I(0,h)*v for x,v in zip(state,rhs)]
        check(all(x.contained(y) for x,y in zip(im,cell['picard_box'])),idx,'independent_rational_Picard_inclusion')
        check(all(I(*x).contained(y) for x,y in zip(cell['endpoint'],cell['picard_box'])),idx,'endpoint_in_whole_box')
        ep=[I(*v) for v in cell['endpoint']];ee=ep[1]**2/2+(1-(ep[0]*lam).monotone_cos())**3*A
        check(ee.contained(cell['energy_endpoint']),idx,'independent_rational_energy_inclusion')
        nstate=[ns['box'](*map(F,row)) for row in cell['initial']]
        nwhole=[ns['box'](*map(F,row)) for row in cell['picard_box']]
        coeff=ns['coefficients'](a0,ns['iv'].mpf(0),nstate,12)
        rem=ns['coefficients'](a0,ns['box'](0,h),nwhole,13)
        hh=ns['rat'](h)
        for j in range(2):
            v=coeff[j][-1]
            for term in reversed(coeff[j][:-1]):v=v*hh+term
            tail=rem[j][-1]*hh**13;v+=tail
            check(ns['inside'](v,ns['box'](*map(F,cell['endpoint'][j]))),idx,f'Taylor_replay_80_digits_endpoint_{j}')
            check(ns['inside'](tail,ns['box'](*map(F,cell['remainder'][j]))),idx,f'Taylor_replay_80_digits_remainder_{j}')
        now=a1;previous=cell['endpoint']
        if (idx+1)%100==0: print(json.dumps({'verified_cells':idx+1,'failures':len(failures),'elapsed':time.monotonic()-started}),flush=True)
    check(now==end and r['endpoint']==previous,-1,'final_checkpoint')
    check(len(r['cells'])==r['accepted_cells'],-1,'cell_count')
    check(r['energy_endpoint']==r['cells'][-1]['energy_endpoint'],-1,'final_energy')
    check(end<F(1,801) and not r['target_reached'],-1,'target_not_reached')
    out={'schema':'Q052_V101_VERIFICATION','status':'PASS_CONDITIONAL' if not failures else 'FAIL','checked_cells':len(r['cells']),'checks':checks,'failures':failures,'wall_seconds':time.monotonic()-started,
         'independent_components':['exact cell and endpoint connection','rational 240-bit outward Picard field inclusion','rational sin/cos Taylor with exact Lagrange and Lipschitz bounds','integer-square-root outward bounds','energy at every recorded endpoint','uniform source EDE guard and positive H squared'],
         'shared_component':'Order12/13 Taylor recurrence replay at 80 digits uses prototype code; it is not an independent Taylor implementation.',
         'uniform_guard_G_lower':str(guard),'uniform_H_squared_lower':str(matter/end**3+rad/end**4),
         'source_guard_identity':'G=3H^2-2U=3B0+X^2/2-U+floor >=3(matter/a_end^3+radiation/a_end^4)-8A+floor>0',
         'last_energy_independent':ee.saved(),'prototype_sha256':hashlib.sha256((P/'prototype101.py').read_bytes()).hexdigest(),'prototype_result_sha256':hashlib.sha256((P/'prototype_result.json').read_bytes()).hexdigest(),
         'scope':'Recorded scalar prefix only; same inherited exact-real source initialization and B-star premises. No new steps and no native trajectories.'}
    (P/'verification101.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['uniform_guard_G_lower','uniform_H_squared_lower','last_energy_independent']},indent=2))

if __name__=='__main__':main()
