from pathlib import Path
P=Path(__file__).resolve().parent
s=(P/'continuation103_source.py').read_text().split('def main():')[0]
s=s.replace('from verify101 import I as RationalInterval','from verify101 import I as RationalInterval\nfrom trig105 import enclose as trig_enclose')
start=s.index('    sine,cosine = argument.sincos()');end=s.index('    delta = 1-cosine',start)
s=s[:start]+'    sine,cosine = trig_enclose(argument)\n'+s[end:]
s=s.replace('    independent_check(record)\n',"    (P/'candidate105.json').write_text(json.dumps(record,indent=2)+'\\n')\n    independent_check(record)\n    structure_check(record)\n")
s=s.replace("record['independent_check']='PASS_RATIONAL_FIELD_GUARD_JACOBIAN_COMPARISON'","record['independent_check']='PASS_RATIONAL_FIELD_GUARD_JACOBIAN_COMPARISON_ENERGY'")
s+='''
    phi_end,velocity_end=[R(*row) for row in cell['endpoint']]
    energy=velocity_end**2/2+AA*(1-trig_enclose(phi_end*LL)[1])**3
    assert energy.contained(cell['energy']), 'INDEPENDENT_ENERGY_NOT_CONTAINED'
    cell['independent_energy']=energy.saved()

def structure_check(cell):
    a0,a1,h=map(F,[cell['a0'],cell['a1'],cell['h']])
    assert 0<h<=F(1,16) and a1==a0*(1+h)
    for j in range(2):
        coefficients=list(map(F,cell['polynomial'][j]))
        lo,hi=map(F,cell['initial'][j])
        assert coefficients[0]==(lo+hi)/2
        assert F(cell['comparison']['initial_radius'][j])==(hi-lo)/2
        curve=R(coefficients[-1])
        for coefficient in reversed(coefficients[:-1]):curve=curve*R(0,h)+coefficient
        assert curve.contained(cell['picard_box'][j]), 'POLYNOMIAL_OUTSIDE_BOX'
        for inner in ['endpoint','initial','picard_image']:
            assert R(*cell[inner][j]).contained(cell['picard_box'][j])
        assert R(*cell['endpoint'][j]).contained(cell['raw_endpoint'][j])
    record=cell['comparison'];matrix=[[F(x) for x in row] for row in record['matrix']]
    shift=F(record['shift']);defect=list(map(F,record['defect']));beta=F(record['beta'])
    augmented=[[matrix[0][0]+shift,matrix[0][1],defect[0]],
               [matrix[1][0],matrix[1][1]+shift,defect[1]],[F(0),F(0),shift]]
    assert all(x>=0 for row in augmented for x in row)
    assert beta>=h*max(map(sum,augmented))
    k=record['terms'];term=F(1)
    for i in range(1,k+1):term*=beta/i
    assert beta/(k+2)<1
    tail=term*beta/(k+1)/(1-beta/(k+2))*max(F(1),*map(F,record['initial_radius']))
    assert tail<=F(record['tail'])
    assert max(defect)<=BUDGET and max(map(F,cell['defect_80']))<=BUDGET
    cell['structure_check']='PASS_EXACT_POLYNOMIAL_BOX_RADIUS_TAIL'

def preflight():
    cases=[('zero','0','0'),('positive_monotone','0.1','0.2'),('negative_monotone','-0.2','-0.1'),
           ('sine_maximum','1.5','1.7'),('sine_minimum','-1.7','-1.5'),('cosine_maximum','-0.1','0.1'),
           ('cosine_minimum','3.1','3.2'),('uncertain_signs','-2','2')]
    report=[]
    iv.dps=100
    try:
        for name,lo,hi in cases:
            argument=R(lo,hi);sn,cs=trig_enclose(argument)
            reference=[iv.sin(box(argument.l,argument.h)),iv.cos(box(argument.l,argument.h))]
            for bound,value in zip([sn,cs],reference):
                left,right=edges(value)
                assert bound.l<=left<=right<=bound.h, name
            report.append({'case':name,'argument':argument.saved(),'sine':sn.saved(),'cosine':cs.saved(),'mpmath100_enclosed':True})
    finally:iv.dps=50
    previous=json.loads((P/'last_unaccepted_candidate103.json').read_text())
    independent_check(previous);structure_check(previous)
    output={'status':'PASS','tests':report,'stored_candidate_checks':'PASS_DIAGNOSTIC_ONLY','new_accepted_cells':0,
            'independence':'Rational Taylor/Lipschitz plus sign-conditioned refinement compared against mpmath interval trigonometry at 100 digits.'}
    (P/'preflight105.json').write_text(json.dumps(output,indent=2)+'\\n')

def main():
    import traceback
    task=json.loads((P/'task104.json').read_text())
    start=time.monotonic()
    now=F(task['coverage']['a_start']);target=F(1,801)
    state=[box(*map(F,row)) for row in task['input_checkpoint']['endpoint']]
    proposed_ratio=F(task['input_last_relative_step'])
    cells=[];rejections=[];streak=0;failure=None;stop='TIME_LIMIT'
    try:
        preflight()
    except Exception:
        failure=traceback.format_exc();stop='PREFLIGHT_FAILURE'
    while failure is None and time.monotonic()-start<LIMIT-3 and now<target:
        proposed=F(task['diagnostic_candidate']['a1']) if not cells else min(target,F((now*(1+proposed_ratio)*2**120).__floor__(),2**120))
        accepted=None
        for retry in range(13):
            if time.monotonic()-start>=LIMIT-3:break
            if proposed<=now:stop='NONADVANCING_GRID';break
            try:
                accepted,reason=attempt(now,proposed,state)
            except Exception:
                failure=traceback.format_exc();stop='FIRST_UNRESOLVED_VALIDATION';break
            if accepted:break
            rejections.append({'a':str(now),'a1':str(proposed),'reason':reason})
            proposed=F(((now+(proposed-now)/2)*2**120).__floor__(),2**120)
        if accepted is None:
            if failure is None and time.monotonic()-start<LIMIT-3 and stop=='TIME_LIMIT':stop='RETRY_CAP'
            break
        if time.monotonic()-start>LIMIT:
            stop='TIME_LIMIT_UNCOMMITTED_CELL';break
        expected=cells[-1]['endpoint'] if cells else task['input_checkpoint']['endpoint']
        assert accepted['initial']==expected, 'EXACT_ENDPOINT_CONNECTION'
        cells.append(accepted);now=F(accepted['a1']);state=[box(*map(F,row)) for row in accepted['endpoint']]
        proposed_ratio=F(accepted['h'])
        streak=streak+1 if retry==0 and max(map(F,accepted['comparison']['defect']))<=BUDGET/4 else 0
        if streak>=2:proposed_ratio=min(F(1,16),proposed_ratio*F(3,2));streak=0
        if len(cells)%10==0:print(json.dumps({'cells':len(cells),'z':float(1/now-1),'seconds':time.monotonic()-start}),flush=True)
    if now==target:stop='TARGET_REACHED'
    result={'schema':'Q052_V105_TRIG_SCALAR_CONTINUATION','task_fingerprint':task['fingerprint_sha256'],'source_commit':task['source_commit'],
            'capture_sha256':task['capture_sha256'],'start_a':task['coverage']['a_start'],'certified_end_a':str(now),'certified_end_z':str(1/now-1),
            'endpoint':[saved(x) for x in state],'energy':saved(base.energy(state)),'accepted_cells':len(cells),'rejected_candidates':len(rejections),
            'target_reached':now==target,'stop_reason':stop,'first_validation_failure':failure,
            'wall_seconds':time.monotonic()-start,'limit_seconds':LIMIT,'new_native_pairs':0,'new_full_history_integrations':0,'new_weight_evaluations':0,
            'cells':cells,'rejections':rejections}
    (P/'result_raw105.json').write_text(json.dumps(result,indent=2)+'\\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['cells','rejections','endpoint','energy','certified_end_a','certified_end_z']},indent=2))

if __name__=='__main__':main()
'''
(P/'continuation105.py').write_text(s)
