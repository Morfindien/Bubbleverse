"""Final stored-record audit; no new propagation or weight evaluation."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import json,sys,mpmath
P=Path(__file__).resolve().parent
def read(n):return json.loads((P/n).read_bytes())
r=read('result_raw105.json');t=read('task104.json');old=read('result103.json');w=read('weight/result105_weight.json');wc=read('weight/control105_weight.json');oldw=read('result99.json')
now=F(t['coverage']['a_start']);previous=t['input_checkpoint']['endpoint'];checks=0;reject=0;streak=0;ratio=F(t['input_last_relative_step'])
for i,c in enumerate(r['cells']):
 a0,a1,h=map(F,[c['a0'],c['a1'],c['h']]);assert now==a0 and a1==a0*(1+h) and a1>a0
 assert previous==c['initial']
 proposed=F(t['diagnostic_candidate']['a1']) if i==0 else min(F(1,801),F((a0*(1+ratio)*2**120).__floor__(),2**120))
 retries=0
 while reject<len(r['rejections']) and F(r['rejections'][reject]['a'])==a0:
  assert F(r['rejections'][reject]['a1'])==proposed
  proposed=F(((a0+(proposed-a0)/2)*2**120).__floor__(),2**120);retries+=1;reject+=1
 assert proposed==a1 and retries<=12 and h<=F(1,16)
 assert a1==F(1,801) or (a1*2**120).denominator==1
 assert c['independent_check']=='PASS_RATIONAL_FIELD_GUARD_JACOBIAN_COMPARISON_ENERGY'
 assert c['structure_check']=='PASS_EXACT_POLYNOMIAL_BOX_RADIUS_TAIL'
 assert F(c['energy'][0])<=F(c['independent_energy'][0])<=F(c['independent_energy'][1])<=F(c['energy'][1])
 ratio=h;streak=streak+1 if retries==0 and max(map(F,c['comparison']['defect']))<=F(1,4*10**8) else 0
 if streak>=2:ratio=min(F(1,16),ratio*F(3,2));streak=0
 now=a1;previous=c['endpoint'];checks+=7
assert now==F(1,801)==F(r['certified_end_a']) and previous==r['endpoint'] and r['energy']==r['cells'][-1]['energy']
assert r['target_reached'] and r['accepted_cells']==len(r['cells'])==142 and reject==r['rejected_candidates']==27
assert r['wall_seconds']<300 and r['first_validation_failure'] is None
assert r['source_commit']==w['source_commit']==t['source_commit']
assert w['task_fingerprint']==r['task_fingerprint']==t['fingerprint_sha256']
assert w['anchor_raw_sha256']==sha256((P/'result_raw105.json').read_bytes()).hexdigest()
assert w['target_met'] and wc['status']=='PASS' and wc['method_target_met']
assert F(w['weight_width_ceiling'])==F(t['decision_gates']['weight_width_ceiling'])
assert [(x['V66_row'],x['guard_row'],x['z']) for x in w['cells']]==[(x['V66_row'],x['guard_row'],x['z']) for x in oldw['cells']]
for a,b in zip(w['cells'],oldw['cells']):
 assert a['electron_interval']==b['electron_interval'] and a['background_dependency_id']==b['background_dependency_id']
 assert F(a['scalar_energy_cap'])==min(F(b['scalar_energy_cap']),F(r['energy'][1]))
 assert F(b['weight_intersection'][0])<=F(a['weight_intersection'][0])<=F(a['weight_intersection'][1])<=F(b['weight_intersection'][1])
 assert F(a['increment'][0])>=F(b['increment'][0]) and F(a['increment'][1])<=F(b['increment'][1])
oldp=list(map(F,oldw['pilot_interval']));newp=list(map(F,w['pilot_interval']));oldg=list(map(F,oldw['new_global_interval']));newg=list(map(F,w['new_global_interval']))
assert newg==[oldg[0]-oldp[0]+newp[0],oldg[1]-oldp[1]+newp[1]]
metrics={'anchor_energy_width':str(F(r['energy'][1])-F(r['energy'][0])),
 'weight_reduction_vs_V99':str(1-F(w['new_weight_width'])/F(oldw['new_weight_width'])),
 'weight_reduction_vs_frozen_V97_baseline':w['weight_width_reduction_fraction'],
 'pilot_width_reduction_vs_V99':str(1-F(w['pilot_width'])/F(oldw['pilot_width'])),
 'global_width_reduction_vs_V99':str(1-F(w['global_width'])/F(oldw['global_width'])),
 'global_width':w['global_width'],'global_width_goal_ratio':w['global_width_goal_ratio'],
 'outside_pilot_width':str((newg[1]-newg[0])-(newp[1]-newp[0])),
 'pilot_electron_width':w['width_accounting']['electron_enclosure'],'pilot_weight_width':w['new_weight_width']}
report={'status':'PASS_CONDITIONAL','record_checks':checks,'cells':142,'exact_connections':142,'total_inherited_and_new_cells':1392,
 'inrun_independent_field_picard_guard_jacobian_comparison_energy_checks':142,'inrun_structure_checks':142,
 'preflight_cases':len(read('preflight105.json')['tests']),'weight_subcells':105,'new_native_pairs':0,'new_full_history_integrations':0,'new_weight_evaluations':1,
 'raw_scalar_record_weight_counter_scope':'raw scalar log has zero weight evaluations because it predates the separate conditional screen; this combined audit records one.',
 'higher_precision_scope':'50/80 decimal directed interval defect replay shares polynomial/jet code and retained 50-digit parameter intervals. Independent rational checks use separate interval primitives. Original source initialization remains inherited.',
 'metrics':metrics,'python':sys.version,'mpmath':mpmath.__version__}
(P/'verification105.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='metrics'},indent=2));print({k:float(F(v)) for k,v in metrics.items()})
