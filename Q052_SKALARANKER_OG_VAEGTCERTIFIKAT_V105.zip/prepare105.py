from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256,sha1
import json
P=Path(__file__).resolve().parent;S=P.parents[1]/'upload'
h=lambda b:sha256(b).hexdigest()
def dump(n,x):(P/n).write_text(json.dumps(x,indent=2)+'\n')
def fp(x):return h(json.dumps({k:v for k,v in x.items() if k!='fingerprint_sha256'},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
t=json.loads((S/'Q052_MATEMATIKOPGAVE_V104.json').read_bytes());assert fp(t)==t['fingerprint_sha256']
tree=json.loads((P/'repository_tree.json').read_bytes());paths={x['path']:x['sha'] for x in tree['tree']};assert not tree['truncated']
alias={'Q052_KORT_RESULTAT_V104.md':'Q052_KORT_RESULTAT_V104-1.md','Q052_INGESTION_OG_SAMLET_JOURNAL_V104.md':'Q052_INGESTION_OG_SAMLET_JOURNAL_V104-1.md'}
canonical={}
for n in [*alias.values(),'Q052_MATEMATIKOPGAVE_V104.json','Q052_INGESTION_CERTIFICATE_V104.zip']:
 b=(S/n).read_bytes();assert sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()==paths[n]
 canonical[n]={'sha256':h(b),'bytes':len(b),'git_blob':paths[n]}
with ZipFile(S/'Q052_INGESTION_CERTIFICATE_V104.zip') as z:
 assert z.testzip() is None
 m=json.loads(z.read('manifest.json'))
 for row in m['archive_members']:assert h(z.read(row['path']))==row['sha256']
 for row in m['external_deliverables']:assert h((S/alias.get(row['filename'],row['filename'])).read_bytes())==row['sha256']
 for n in ['activity_ledger.json','handoff104.json','audit104.json']:(P/('parent_'+n)).write_bytes(z.read(n))
assert h((S/t['input_certificate']).read_bytes())==t['input_certificate_sha256']
with ZipFile(S/t['input_certificate']) as z:
 assert z.testzip() is None
 m=json.loads(z.read('manifest.json'))
 for row in m['archive_members']:assert h(z.read(row['path']))==row['sha256']
 assert h(z.read('result103.json'))==t['input_result_sha256']
 r=json.loads(z.read('result103.json'));assert r['checkpoint']==t['input_checkpoint']
 for n in ['prototype101.py','verify101.py','capture.json','result99.json','result103.json','source_register.json','PROOF_V103.md','last_unaccepted_candidate103.json','criticalpoint_diagnostic103.json','v73.json','initial.json']:(P/n).write_bytes(z.read(n))
 (P/'continuation103_source.py').write_bytes(z.read('continuation103.py'))
assert h((P/'capture.json').read_bytes())==t['capture_sha256']
assert h((S/'Bubbleverse_Matematikmotor_2.3.0-49.md').read_bytes())==t['engine_prompt_sha256']
(P/'task104.json').write_bytes((S/'Q052_MATEMATIKOPGAVE_V104.json').read_bytes())
dump('input_audit105.json',{'status':'PASS','canonical_files':canonical,'filename_aliases':alias,'task_fingerprint':fp(t),'prior_checkpoint_matched':True,'repository_head':json.loads((P/'repository_head.json').read_bytes())['commit']['sha'],'no_existing_Q052_V105':not any(x.startswith('Q052_') and 'V105' in x for x in paths)})
print('PASS input identity and exact checkpoint')
