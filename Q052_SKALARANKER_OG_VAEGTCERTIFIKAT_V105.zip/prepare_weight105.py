from pathlib import Path
from hashlib import sha256
import json,shutil
P=Path(__file__).resolve().parent;source=P.parent/'cert99';W=P/'weight';W.mkdir(exist_ok=True)
pins=json.loads((source/'pins.json').read_bytes())
for name,digest in pins.items():
 b=(source/name).read_bytes();assert sha256(b).hexdigest()==digest,name
 (W/name).write_bytes(b)
(W/'pins.json').write_bytes((source/'pins.json').read_bytes())
for name in ['result99.json','compute99.py','control99.py']:(W/name).write_bytes((source/name).read_bytes())
assert (W/'result99.json').read_bytes()==(P/'result99.json').read_bytes()
r=json.loads((P/'result_raw105.json').read_bytes());assert r['target_reached'] and r['certified_end_a']=='1/801'
anchor={k:v for k,v in r.items() if k not in ['cells','rejections']};anchor['raw_sha256']=sha256((P/'result_raw105.json').read_bytes()).hexdigest()
(W/'anchor105.json').write_text(json.dumps(anchor,indent=2)+'\n')
s=(W/'compute99.py').read_text()
s=s.replace('    start = time.monotonic()','    start = time.monotonic()\n    anchor=read("anchor105.json")\n    assert anchor["target_reached"] and anchor["certified_end_a"]=="1/801"\n    anchor_cap=F(anchor["energy"][1])')
s=s.replace("i,g=matches[0]; ec=F(g['source_energy_cap'])","i,g=matches[0]; ec=min(F(g['source_energy_cap']),anchor_cap)")
s=s.replace("'Q052_V99_FIXED_BSTAR_WEIGHT_PILOT'","'Q052_V105_ANCHORED_BSTAR_WEIGHT_PILOT'")
s=s.replace("'task_fingerprint':task['fingerprint_sha256']","'task_fingerprint':anchor['task_fingerprint'], 'anchor_raw_sha256':anchor['raw_sha256'], 'anchor_energy_upper':str(anchor_cap)")
s=s.replace("emit('result99.json',result)","emit('result105_weight.json',result)")
s=s.replace("emit('execution99.json'","emit('execution105_weight.json'")
s=s.replace("'Inherited guard scalar energy caps; no positive scalar-energy lower bound beyond e>=0. These projection boxes limit this method; they do not quantify actual B_star variation.'","'V105 z800 anchor energy cap intersected with inherited guard caps. Scalar lower bound remains e>=0.'")
(W/'compute105_weight.py').write_text(s)
s=(W/'control99.py').read_text().replace("r=load('result99.json') if result is None else result","r=load('result105_weight.json') if result is None else result\n    anchor=load('anchor105.json')\n    assert anchor['target_reached'] and anchor['certified_end_a']=='1/801'\n    assert r['anchor_raw_sha256']==anchor['raw_sha256'] and R(r['anchor_energy_upper'])==R(anchor['energy'][1])")
s=s.replace("ec=R(guard[gidx]['E_input_left'])","ec=min(R(guard[gidx]['E_input_left']),R(anchor['energy'][1]))")
s=s.replace("r['task_fingerprint']==task['fingerprint_sha256']","r['task_fingerprint']==anchor['task_fingerprint']")
s=s.replace("(BASE/'control99.json')","(BASE/'control105_weight.json')")
(W/'control105_weight.py').write_text(s)
print('Prepared one anchored weight evaluation; pinned V99 inputs verified')
