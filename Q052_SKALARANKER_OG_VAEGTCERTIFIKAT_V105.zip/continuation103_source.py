"""One bounded, checked scalar continuation from the fixed V101 endpoint."""
from pathlib import Path
from fractions import Fraction as F
import json, time, hashlib
import prototype101 as base
from verify101 import I as RationalInterval

P = Path(__file__).resolve().parent
iv = base.iv
rat, box, edges, saved, inside = base.rat, base.box, base.edges, base.saved, base.inside
Jet = base.Jet
ORDER = 12
LIMIT = 300
BUDGET = F(1,10**8)

def dyadic_upper(value,bits=200):
    return F((value*2**bits).__ceil__(),2**bits)

def magnitude(value):
    return max(map(abs,edges(value)))

def midpoint(value):
    lower, upper = edges(value)
    return (lower+upper)/2

def polynomial(coefficients, argument):
    value = rat(coefficients[-1])
    for coefficient in reversed(coefficients[:-1]):
        value = value*argument + rat(coefficient)
    return value

def polynomial_jet(coefficients, time_box):
    from math import comb
    return Jet([polynomial([F(comb(j,k))*coefficients[j] for j in range(k,len(coefficients))],time_box)
                for k in range(len(coefficients))])

def source_terms(phi, velocity, density, scale_inverse):
    sine, cosine = iv.sin(base.lam*phi), iv.cos(base.lam*phi)
    delta = 1-cosine
    potential = base.A*delta**3
    gradient = 3*base.A*base.lam*sine*delta**2
    curvature = 3*base.A*base.lam**2*(cosine*delta**2+2*sine**2*delta)
    hubble = iv.sqrt(density+(velocity**2/2+potential+base.floor)/3)
    h3 = 6*hubble**3
    jacobian = [[-velocity*gradient/h3*scale_inverse,(1/hubble-velocity**2/h3)*scale_inverse],
                [(-curvature/hubble+gradient**2/h3)*scale_inverse,(-3+gradient*velocity/h3)*scale_inverse]]
    guard = 3*density+velocity**2/2-potential+base.floor
    return jacobian,guard

def comparison(matrix, defect, radii, h):
    shift = max(F(0),-matrix[0][0],-matrix[1][1])
    augmented = [[matrix[0][0]+shift,matrix[0][1],defect[0]],
                 [matrix[1][0],matrix[1][1]+shift,defect[1]], [F(0),F(0),shift]]
    assert all(x>=0 for row in augmented for x in row)
    beta = dyadic_upper(h*max(map(sum,augmented)))
    initial = [rat(radii[0]),rat(radii[1]),rat(1)]
    term = initial[:]
    total = initial[:]
    scalar_term = F(1)
    tail = None
    for k in range(1,600):
        term = [sum((rat(augmented[i][j])*term[j] for j in range(3)),iv.mpf(0))*rat(h)/k for i in range(3)]
        total = [x+y for x,y in zip(total,term)]
        scalar_term *= beta/k
        if beta/(k+2)<1:
            tail = scalar_term*beta/(k+1)/(1-beta/(k+2))*max(F(1),*radii)
            if tail<F(1,2**190):
                break
    else:
        raise ValueError('COMPARISON_SERIES_LIMIT')
    tail = dyadic_upper(tail,240)
    factor = iv.exp(-rat(shift*h))
    radius = [(value+box(0,tail))*factor for value in total[:2]]
    return radius, {'shift':str(shift),'beta':str(beta),'terms':k,'tail':str(tail),
                    'matrix':[[str(x) for x in row] for row in matrix],'defect':list(map(str,defect)),
                    'initial_radius':list(map(str,radii))}

def certify_fixed_polynomial(a0, h, state, whole, coefficients):
    tb = box(0,h)
    time_zero, inv_zero = base.time_jets(a0,iv.mpf(0),ORDER)
    rhs_zero = base.field([Jet([rat(x) for x in row]) for row in coefficients],time_zero,inv_zero)
    time_whole, inv_whole = base.time_jets(a0,tb,ORDER)
    rhs_whole = base.field([polynomial_jet(row,tb) for row in coefficients],time_whole,inv_whole)
    defect = []
    for j in range(2):
        low = [rhs_zero[j].c[k]-(k+1)*rat(coefficients[j][k+1]) for k in range(ORDER)]
        remainder = rhs_whole[j].c[ORDER]*rat(h)**ORDER
        bound = sum((magnitude(c)*h**k for k,c in enumerate(low)),F(0))+magnitude(remainder)
        defect.append(dyadic_upper(bound))
    density, inverse = base.time_jets(a0,tb,0)
    jac,guard = source_terms(*whole,density.c[0],inverse.c[0])
    assert edges(guard)[0]>0
    matrix = [[dyadic_upper(edges(jac[i][j])[1] if i==j else magnitude(jac[i][j]),144) for j in range(2)] for i in range(2)]
    radii = [(edges(y)[1]-edges(y)[0])/2 for y in state]
    radius,comparison_record = comparison(matrix,defect,radii,h)
    endpoint = [polynomial(row,rat(h))+box(-edges(rr)[1],edges(rr)[1]) for row,rr in zip(coefficients,radius)]
    return endpoint,defect,matrix,guard,comparison_record

def attempt(a0,a1,state):
    h = (a1-a0)/a0
    tb = box(0,h)
    center = [rat(midpoint(y)) for y in state]
    original = base.coefficients(a0,iv.mpf(0),center,ORDER)
    coefficients = [[midpoint(x) for x in row] for row in original]
    polynomial_box = [polynomial(row,tb) for row in coefficients]
    density,inverse = base.time_jets(a0,tb,0)
    rhs = base.field([Jet([x]) for x in state],density,inverse)
    first_image = [x+tb*f.c[0] for x,f in zip(state,rhs)]
    whole = [base.inflated(box(min(edges(x)[0],edges(y)[0]),max(edges(x)[1],edges(y)[1]))) for x,y in zip(first_image,polynomial_box)]
    for _ in range(16):
        rhs = base.field([Jet([x]) for x in whole],density,inverse)
        picard = [x+tb*f.c[0] for x,f in zip(state,rhs)]
        if all(inside(x,y) for x,y in zip(picard,whole)):
            break
        whole = [base.inflated(box(min(edges(x)[0],edges(y)[0]),max(edges(x)[1],edges(y)[1]))) for x,y in zip(picard,whole)]
    else:
        return None,'PICARD_NOT_CLOSED'
    endpoint,defect,matrix,guard,comparison_record = certify_fixed_polynomial(a0,h,state,whole,coefficients)
    if max(defect)>BUDGET:
        return None,'DEFECT_BUDGET'
    clipped = []
    for x,b in zip(endpoint,whole):
        lo,hi = max(edges(x)[0],edges(b)[0]),min(edges(x)[1],edges(b)[1])
        if lo>hi:
            raise ValueError('EMPTY_ENDPOINT_INTERSECTION')
        clipped.append(box(lo,hi))
    # Recheck the SAME polynomial and enclosure at increased precision.
    iv.dps = 80
    try:
        replay = certify_fixed_polynomial(a0,h,state,whole,coefficients)
        # Shared parameter intervals remain enclosing 50-digit input constants.
        if not all(inside(x,y) for x,y in zip(replay[0],endpoint)):
            # Algebraically equivalent interval paths can differ by final ulps.
            # Their union is still enclosing and avoids a false precision claim.
            endpoint = [box(min(edges(x)[0],edges(y)[0]),max(edges(x)[1],edges(y)[1])) for x,y in zip(replay[0],endpoint)]
            clipped = [box(max(edges(x)[0],edges(y)[0]),min(edges(x)[1],edges(y)[1])) for x,y in zip(endpoint,whole)]
        assert max(replay[1])<=BUDGET
    finally:
        iv.dps = 50
    record = {'a0':str(a0),'a1':str(a1),'h':str(h),'initial':[saved(x) for x in state],
              'polynomial':[[str(x) for x in row] for row in coefficients],'polynomial_box':[saved(x) for x in polynomial_box],
              'picard_box':[saved(x) for x in whole],'picard_image':[saved(x) for x in picard],
              'comparison':comparison_record,'raw_endpoint':[saved(x) for x in endpoint],
              'endpoint':[saved(x) for x in clipped],'energy':saved(base.energy(clipped)),
              'guard':saved(guard),'higher_precision_replay':'PASS_WITH_ENCLOSING_UNION',
              'defect_80':list(map(str,replay[1]))}
    independent_check(record)
    record['independent_check']='PASS_RATIONAL_FIELD_GUARD_JACOBIAN_COMPARISON'
    return record,None

R = RationalInterval
cap = json.loads((P/'capture.json').read_text())['cases']['hillipop-ede_n3']['background']
binary = lambda x:F.from_float(float.fromhex(x))
params = list(map(binary,cap['scalar']['scf_parameters']))
AA = F.from_float(4152.39)*params[2]**2*params[1]**2
LL = F.from_float(2.435e27)/params[1]
FF = params[3]*F.from_float(3.968e-8)
bf = {k:binary(v) for k,v in cap['fields'].items()}
MM = bf['H0']**2*(bf['Omega0_b']+bf['Omega0_cdm'])
RR = bf['H0']**2*(bf['Omega0_g']+bf['Omega0_ur'])
nu = cap['neutrinos'][0]
mass,factor = binary(nu['fields']['M_ncdm']),binary(nu['fields']['factor_ncdm'])
nodes,weights = list(map(binary,nu['q_ncdm_bg'])),list(map(binary,nu['w_ncdm_bg']))

def independent_check(cell):
    a0,h = F(cell['a0']),F(cell['h'])
    scale = R(1,1+h)
    aa = R(a0)*scale
    density = R(MM)/aa**3+R(RR)/aa**4
    density += R(factor)/aa**4*sum((R(q*q*w)*(R(q*q)+(aa*mass)**2).sqrt() for q,w in zip(nodes,weights)),R(0))
    phi,vel = [R(*row) for row in cell['picard_box']]
    argument = phi*LL
    sine,cosine = argument.sincos()
    left_sine,left_cosine = R(argument.l).sincos()
    right_sine,right_cosine = R(argument.h).sincos()
    if cosine.h<0:sine=R(right_sine.l,left_sine.h)
    elif cosine.l>0:sine=R(left_sine.l,right_sine.h)
    if sine.l>0:cosine=R(right_cosine.l,left_cosine.h)
    elif sine.h<0:cosine=R(left_cosine.l,right_cosine.h)
    delta = 1-cosine
    U = AA*delta**3
    Up = 3*AA*LL*sine*delta**2
    Upp = 3*AA*LL**2*(cosine*delta**2+2*sine**2*delta)
    H = (density+(vel**2/2+U+FF)/3).sqrt()
    assert (3*density+vel**2/2-U+FF).l>0
    rhs = [vel/H/scale,(-3*vel-Up/H)/scale]
    image = [R(*x)+R(0,h)*f for x,f in zip(cell['initial'],rhs)]
    assert all(x.contained(b) for x,b in zip(image,cell['picard_box']))
    J = [[-vel*Up/(6*H**3)/scale,(1/H-vel**2/(6*H**3))/scale],
         [(-Upp/H+Up**2/(6*H**3))/scale,(-3+Up*vel/(6*H**3))/scale]]
    M = [[F(x) for x in row] for row in cell['comparison']['matrix']]
    assert all((J[i][j].h if i==j else max(abs(J[i][j].l),abs(J[i][j].h)))<=M[i][j] for i in range(2) for j in range(2))
    # Separate rational positive-series enclosure of exp(hL) acting on radii.
    cr = cell['comparison'];s=F(cr['shift']);beta=F(cr['beta']);rr=list(map(F,cr['defect']))
    N = [[M[0][0]+s,M[0][1],rr[0]],[M[1][0],M[1][1]+s,rr[1]],[F(0),F(0),s]]
    term = [R(x) for x in cr['initial_radius']]+[R(1)]
    total = term[:]
    for k in range(1,cr['terms']+1):
        term = [sum((N[i][j]*term[j] for j in range(3)),R(0))*h/k for i in range(3)]
        total = [x+y for x,y in zip(total,term)]
    x=s*h;et=R(1);es=R(1);k=0
    while True:
        k+=1;et=et*x/k;es+=et
        if x/(k+2)<1:
            tail=et.h*x/(k+1)/(1-x/(k+2))
            if tail<F(1,2**220):break
        assert k<600
    negexp=1/R(es.l,es.h+tail)
    radius=[(t+R(0,cr['tail']))*negexp for t in total[:2]]
    for j in range(2):
        row=list(map(F,cell['polynomial'][j]));value=R(row[-1])
        for c in reversed(row[:-1]):value=value*h+c
        predicted=value+R(-radius[j].h,radius[j].h)
        assert predicted.contained(cell['raw_endpoint'][j])

def main():
    task=json.loads((P/'task102.json').read_text())
    origin=json.loads((P/'run_origin.json').read_text())['wall_origin']
    start=time.monotonic()-(time.time()-origin)
    now=F(task['coverage']['a_start']);waypoint=F(task['coverage']['a_waypoint']);target=F(1,801)
    state=[box(*map(F,row)) for row in task['input_checkpoint']['endpoint']]
    proposed_ratio=F(task['input_last_relative_step']);cells=[];rejections=[];streak=0;waypoint_result=None
    stop='TIME_LIMIT';failure=None
    while time.monotonic()-start<LIMIT-3 and now<target:
        boundary=waypoint if now<waypoint else target
        proposed=min(boundary,F((now*(1+proposed_ratio)*2**120).__floor__(),2**120))
        accepted=None
        for retry in range(13):
            if time.monotonic()-start>=LIMIT-3:break
            if proposed<=now:stop='NONADVANCING_GRID';break
            try:
                accepted,reason=attempt(now,proposed,state)
            except (AssertionError,ValueError,ZeroDivisionError,OverflowError) as err:
                import traceback
                failure=traceback.format_exc();stop='FIRST_UNRESOLVED_VALIDATION';break
            if accepted:break
            rejections.append({'a':str(now),'a1':str(proposed),'reason':reason})
            proposed=F(((now+(proposed-now)/2)*2**120).__floor__(),2**120)
        if accepted is None:
            if failure is None and time.monotonic()-start<LIMIT-3 and stop=='TIME_LIMIT':stop='RETRY_CAP'
            break
        if time.monotonic()-start>LIMIT:
            stop='TIME_LIMIT_UNCOMMITTED_CELL';break
        cells.append(accepted);now=F(accepted['a1']);state=[box(*map(F,row)) for row in accepted['endpoint']]
        proposed_ratio=F(accepted['h'])
        streak=streak+1 if retry==0 and max(map(F,accepted['comparison']['defect']))<=BUDGET/4 else 0
        if streak>=2:proposed_ratio=min(F(1,16),proposed_ratio*F(3,2));streak=0
        if now==waypoint:
            ew=F(accepted['energy'][1])-F(accepted['energy'][0]);passed=ew<=F(task['decision_gates']['waypoint_max_energy_width_Mpc_minus_2'])
            waypoint_result={'a':str(now),'energy':accepted['energy'],'width':str(ew),'passed':passed,'wall_seconds':time.monotonic()-start}
            if not passed:stop='WAYPOINT_TIGHTNESS_FAILURE';break
        if len(cells)%10==0:print(json.dumps({'cells':len(cells),'z':float(1/now-1),'seconds':time.monotonic()-start}),flush=True)
    if now==target:stop='TARGET_REACHED'
    result={'schema':'Q052_V103_CENTERED_SCALAR_CONTINUATION','task_fingerprint':task['fingerprint_sha256'],'source_commit':task['source_commit'],
            'capture_sha256':task['capture_sha256'],'start_a':task['coverage']['a_start'],'certified_end_a':str(now),'certified_end_z':str(1/now-1),
            'endpoint':[saved(x) for x in state],'energy':saved(base.energy(state)),'accepted_cells':len(cells),'rejected_candidates':len(rejections),
            'target_reached':now==target,'waypoint':waypoint_result,'stop_reason':stop,'first_validation_failure':failure,
            'wall_seconds':time.monotonic()-start,'limit_seconds':LIMIT,'new_native_pairs':0,'new_full_history_integrations':0,'new_weight_evaluations':0,
            'cells':cells,'rejections':rejections}
    (P/'result_raw103.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['cells','rejections','endpoint','energy','certified_end_a','certified_end_z']},indent=2))

if __name__=='__main__':main()
