"""Bounded interval Taylor integration of the pinned scalar-only source IVP.

Uses mpmath's directed interval primitives. Endpoint fractions are exact
representations of binary interval endpoints. No native trajectory is input.
"""
from pathlib import Path
from fractions import Fraction
import json, time, sys, hashlib
from mpmath import iv

P = Path(__file__).resolve().parent
iv.dps = 50
ORDER = 12
LIMIT = 300

def rat(value):
    value = Fraction(value)
    return iv.mpf(value.numerator) / value.denominator

def endpoint(value):
    sign, mantissa, exponent, bits = value
    assert bits >= 0
    return Fraction((-1)**sign * mantissa) * Fraction(2)**exponent

def edges(value):
    return tuple(endpoint(v) for v in value._mpi_)

def box(lo, hi):
    return iv.mpf([rat(lo).a, rat(hi).b])

def saved(value):
    return list(map(str, edges(value)))

def inside(inner, outer):
    lo, hi = edges(inner)
    lower, upper = edges(outer)
    return lower <= lo <= hi <= upper

class Jet:
    def __init__(self, coefficients):
        self.c = coefficients
        self.n = len(coefficients)
    def constant(self, other):
        return other if isinstance(other, Jet) else Jet([iv.mpf(other)] + [iv.mpf(0)]*(self.n-1))
    def __add__(self, other):
        other = self.constant(other)
        return Jet([x+y for x,y in zip(self.c, other.c)])
    __radd__ = __add__
    def __neg__(self):
        return Jet([-x for x in self.c])
    def __sub__(self, other):
        return self + (-self.constant(other))
    def __rsub__(self, other):
        return self.constant(other) - self
    def __mul__(self, other):
        other = self.constant(other)
        return Jet([sum((self.c[j]*other.c[k-j] for j in range(k+1)),iv.mpf(0)) for k in range(self.n)])
    __rmul__ = __mul__
    def inverse(self):
        values = [1/self.c[0]]
        for k in range(1,self.n):
            values.append(-sum((self.c[j]*values[k-j] for j in range(1,k+1)),iv.mpf(0))/self.c[0])
        return Jet(values)
    def __truediv__(self, other):
        return self * self.constant(other).inverse()
    def __rtruediv__(self, other):
        return self.constant(other) * self.inverse()
    def __pow__(self, power):
        if power < 0:
            return self.inverse()**(-power)
        result = self.constant(1)
        for _ in range(power):
            result = result*self
        return result
    def sqrt(self):
        values = [iv.sqrt(self.c[0])]
        for k in range(1,self.n):
            values.append((self.c[k]-sum((values[j]*values[k-j] for j in range(1,k)),iv.mpf(0)))/(2*values[0]))
        return Jet(values)
    def sincos(self):
        sine, cosine = [iv.sin(self.c[0])], [iv.cos(self.c[0])]
        for k in range(1,self.n):
            sine.append(sum((j*self.c[j]*cosine[k-j] for j in range(1,k+1)),iv.mpf(0))/k)
            cosine.append(-sum((j*self.c[j]*sine[k-j] for j in range(1,k+1)),iv.mpf(0))/k)
        return Jet(sine), Jet(cosine)

def load(name):
    return json.loads((P/name).read_bytes())

capture = load('capture.json')['cases']['hillipop-ede_n3']
bg = capture['background']
def binary(s):
    return Fraction.from_float(float.fromhex(s))
fields = {k:rat(binary(v)) for k,v in bg['fields'].items()}
scalar = list(map(binary,bg['scalar']['scf_parameters']))
A = rat(Fraction.from_float(4152.39)*scalar[2]**2*scalar[1]**2)
lam = rat(Fraction.from_float(2.435e27)/scalar[1])
floor = rat(scalar[3]*Fraction.from_float(3.968e-8))
nu = bg['neutrinos'][0]
node = list(map(lambda x:rat(binary(x)),nu['q_ncdm_bg']))
weight = list(map(lambda x:rat(binary(x)),nu['w_ncdm_bg']))
mass = rat(binary(nu['fields']['M_ncdm']))
factor = rat(binary(nu['fields']['factor_ncdm']))
matter = fields['H0']**2*(fields['Omega0_b']+fields['Omega0_cdm'])
radiation = fields['H0']**2*(fields['Omega0_g']+fields['Omega0_ur'])
assert bg['flags']['has_curvature'] == bg['flags']['has_lambda'] == 0
assert len(node) == len(weight) == 11

def time_jets(a0, time_box, degree):
    t = Jet([time_box,iv.mpf(1)]+[iv.mpf(0)]*max(0,degree-1)) if degree else Jet([time_box])
    scale = 1+t
    a = scale*rat(a0)
    density = (a**-3)*matter + (a**-4)*radiation
    neutrinos = density.constant(0)
    for q,w in zip(node,weight):
        neutrinos += ((a*mass)**2+q*q).sqrt()*(q*q*w)
    density += neutrinos*factor/a**4
    return density, scale.inverse()

def field(y, b0, invscale):
    phi, velocity = y
    sine, cosine = (phi*lam).sincos()
    delta = 1-cosine
    potential = delta**3*A
    derivative = sine*delta**2*(3*A*lam)
    H = (b0+(velocity**2/2+potential+floor)/3).sqrt()
    return [velocity/H*invscale,(-3*velocity-derivative/H)*invscale]

def coefficients(a0, tbox, initial, degree):
    full_b, full_i = time_jets(a0,tbox,degree-1)
    coeff = [[x] for x in initial]
    for k in range(degree):
        b0 = Jet(full_b.c[:k+1])
        invscale = Jet(full_i.c[:k+1])
        rhs = field([Jet(row) for row in coeff],b0,invscale)
        for j in range(2):
            coeff[j].append(rhs[j].c[k]/(k+1))
    return coeff

def inflated(value):
    lower,upper = edges(value)
    pad = max((upper-lower)/8,Fraction(1,10**45))
    return box(lower-pad,upper+pad)

def energy(state):
    phi,velocity = state
    return velocity**2/2 + A*(1-iv.cos(lam*phi))**3

def attempt(a0, a1, state):
    h = (a1-a0)/a0
    tbox = box(0,h)
    b0, invscale = time_jets(a0,tbox,0)
    rhs0 = field([Jet([y]) for y in state],b0,invscale)
    whole = [inflated(y+tbox*r.c[0]) for y,r in zip(state,rhs0)]
    for _ in range(12):
        rhs = field([Jet([y]) for y in whole],b0,invscale)
        image = [y+tbox*r.c[0] for y,r in zip(state,rhs)]
        if all(inside(x,y) for x,y in zip(image,whole)):
            break
        whole = [inflated(box(min(edges(x)[0],edges(y)[0]),max(edges(x)[1],edges(y)[1]))) for x,y in zip(image,whole)]
    else:
        return None,'PICARD_BOX_NOT_CLOSED'
    coeff = coefficients(a0,iv.mpf(0),state,ORDER)
    remainder = coefficients(a0,tbox,whole,ORDER+1)
    step = rat(h)
    result = []
    residual = []
    for j in range(2):
        value = coeff[j][-1]
        for term in reversed(coeff[j][:-1]):
            value = value*step+term
        tail = remainder[j][-1]*step**(ORDER+1)
        result.append(value+tail)
        residual.append(tail)
    if not all(inside(x,y) for x,y in zip(result,whole)):
        return None,'TAYLOR_ENDPOINT_OUTSIDE_PICARD_BOX'
    # Adaptive local remainder control is a numerical work choice.
    for rem, value in zip(residual,result):
        lo,hi = edges(rem)
        mag = max(map(abs,edges(value)))
        if max(abs(lo),abs(hi)) > Fraction(1,10**22)*(1+mag):
            return None,'LOCAL_REMAINDER_TARGET'
    return {'a0':str(a0),'a1':str(a1),'h':str(h),'initial':[saved(x) for x in state],
            'picard_box':[saved(x) for x in whole],'picard_image':[saved(x) for x in image],
            'endpoint':[saved(x) for x in result],'remainder':[saved(x) for x in residual],
            'energy_endpoint':saved(energy(result))}, None

def main():
    started = time.monotonic()
    initial = load('initial.json')
    now = Fraction(initial['a'][0])
    state = [rat(Fraction(row[0])) for row in initial['scalar_state']]
    target = Fraction(1,801)
    cells = []
    rejected = 0
    reason = None
    step_ratio = Fraction(1,32)
    while now < target and time.monotonic()-started < LIMIT-1:
        proposed = min(target,Fraction(((now*(1+step_ratio))*2**120).__floor__(),2**120))
        accepted = None
        for halving in range(24):
            if time.monotonic()-started >= LIMIT-1:
                reason = 'PROTOTYPE_TIME_LIMIT'
                break
            try:
                accepted,reason = attempt(now,proposed,state)
            except (ValueError,ZeroDivisionError,OverflowError) as err:
                reason = type(err).__name__+': '+str(err)
            if accepted:
                break
            rejected += 1
            proposed = (now+proposed)/2
        if not accepted:
            break
        cells.append(accepted)
        now = Fraction(accepted['a1'])
        state = [box(*map(Fraction,row)) for row in accepted['endpoint']]
        if len(cells)%25 == 0:
            print(json.dumps({'cells':len(cells),'z':float(1/now-1),'wall_seconds':time.monotonic()-started,
                              'phi_width':float(edges(state[0])[1]-edges(state[0])[0])}),flush=True)
    reached = now == target
    elapsed = time.monotonic()-started
    if not reached and elapsed >= LIMIT-1:
        reason = 'PROTOTYPE_TIME_LIMIT'
    result = {'schema':'Q052_V101_INTERVAL_TAYLOR_SCALAR_PROTOTYPE','method':'Order12 interval Taylor with order13 whole-Picard-box remainder, mpmath.iv 50 decimal digits',
              'status':'TARGET_REACHED' if reached else 'PARTIAL_VALIDATED_PREFIX',
              'target_reached':reached,'target_a':str(target),'certified_end_a':str(now),'certified_end_z':str(1/now-1),
              'endpoint':[saved(x) for x in state],'energy_endpoint':saved(energy(state)),
              'accepted_cells':len(cells),'rejected_candidates':rejected,'stop_reason':reason,
              'prototype_wall_seconds':elapsed,'limit_seconds':LIMIT,'new_native_pairs':0,'new_full_history_integrations':0,
              'cells':cells}
    (P/'prototype_result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='cells'},indent=2),flush=True)

if __name__=='__main__':
    main()
