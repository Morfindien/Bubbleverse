"""New signed face comparison, using already certified source boxes. No ODE integration."""
import json,hashlib,time
from pathlib import Path
from fractions import Fraction as F
P=Path(__file__).resolve().parent
q=F(1,1000000)
def load(n):return json.loads((P/n).read_bytes())
def hx(x):return F(float.fromhex(x))
def main():
 start=time.monotonic()
 for n,x in load('pins.json').items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==x['sha256']
 task=load('task84.json');a=load('v75.json');b=load('v77.json');v=load('v62.json');t=load('task76.json')
 assert task['target_q']==task['current_q']=='Q052'
 assert b['status']=='PASS_UNDER_FROZEN_PREMISES' and F(b['thermal_cap'])==F(99,100)
 assert 0<min(map(F,t['interface']['Delta_Xe'])) and a['source_argmax_unique_z']=='810'
 assert -1<float.fromhex(b['cold_log_elasticity_hex'][0])<=float.fromhex(b['cold_log_elasticity_hex'][1])<0
 assert F(b['saha_over_h_squared_max'])<1
 prev=F(t['interface']['z']);rows=[];ob=None
 for i,(L,R) in enumerate(zip(v['arms']['L']['records'],v['arms']['R']['records'])):
  assert L['z']==R['z'] and L['allowed_branches']==R['allowed_branches']
  za,zb=map(hx,R['z']);assert za==prev;prev=zb
  hlow=min(hx(x['whole_source'][0][0]) for x in [L,R]);hhigh=max(hx(x['whole_source'][0][1]) for x in [L,R]);assert q<hlow<hhigh<1
  if len(R['allowed_branches'])>1:
   j=next(x for x in b['mixed_branch_checks'] if x['z']==R['z']);exlo,exhi=map(hx,j['relative_C_excess'])
   threshold=q/(hhigh-q);lower=q/hhigh-exhi*(1-q/hhigh)
   assert exhi>threshold and lower<0
   ob={'row_zero_based':i,'row_one_based':i+1,'z_exact':list(map(str,[za,zb])),'z_display':list(map(float,[za,zb])),'branch_pair':'L SWIFT / R HMLA','h_upper':str(hhigh),'archived_C_excess_interval':list(map(str,[exlo,exhi])),'sufficient_C_excess_upper_threshold':str(threshold),'ratio_upper_to_threshold':str(exhi/threshold),'normalized_dprime_lower_bound':str(lower),'lower_bound_is_inconclusive_not_counterexample':True}
   break
  assert R['allowed_branches']==['SWIFT']
  rows.append({'row_zero_based':i,'z':list(map(str,[za,zb])),'h_upper':str(hhigh),'same_branch_dprime_over_abs_fR_lower':str(q/hhigh)})
 assert len(rows)==234 and ob['row_zero_based']==234
 assert time.monotonic()-start<300
 optical=load('transfer78.json')
 return {'schema':'Q052_V85_SIGNED_PREFIX_AND_FIRST_OBSTRUCTION','technical_status':'PASS','scientific_status':'PARTIAL_SIGN_PROOF_GLOBAL_INCONCLUSIVE','signed_source_electron_positive_z':[ob['z_exact'][0],'810'],'new_single_branch_cells':len(rows),'same_branch_normalized_margin_min':str(min(F(x['same_branch_dprime_over_abs_fR_lower']) for x in rows)),'thermal_difference':'vL-vR>0 for 0<u<=u(z_stop), from positive forcing and zero matched start','obstruction':ob,'optical_definition':'Delta_tau(0,Z)=integral_0^Z [sigma_T*nH0*Mpc*(1+z)^2/H_CLASS(z)]*Delta_Xe(z) dz','optical_zero_boundary':'Delta_tau(0,0)=0','optical_source_offset':'NONE','optical_prefix_result':'Strictly increasing as a function of upper redshift Z on [z_stop,810]; unknown accumulated offset at z_stop prevents choosing one absolute endpoint. Global extremum unresolved.','existing_global_abs_tau_enclosure_reused':optical['global_sup_abs_delta_tau'],'late_suffix_sign':'NOT_PROVED; not inferred from V79 absolute cap','new_native_pairs':0,'new_full_history_integrations':0,'rows':rows}
if __name__=='__main__':print(json.dumps(main(),indent=2))
