# V85 · Positiv elektronforskel frem til første uafgjorte grenskift

**BEREGNET / MODELINFERERET.** På det fastholdte B★ og med de samme matchede start- og kildepræmisser som V83 er elektronforskellen positiv på

\[
z_c\le z\le810,\qquad z_c=1523417340748759/2199023255552\approx692,77.
\]

Dette er et nyt fortegnsresultat. V83's absolutte maksimum på hele [0,810] består. Global positivitet og det globale Thomson-maksimum er fortsat uafgjort. Opgavens stopregel anvendes ved den første præcise uafsluttede ulighed; den resterende historie er ikke kontrolleret for det nye fortegn.

## Optisk definition og enheder

Q051's fastholdte kildebevis, afsnit6, giver

\[
F(Z)=\Delta\tau_T(0,Z)=\int_0^Z w(z)\Delta X_e(z)\,dz,\qquad
w(z)=\frac{\sigma_T n_{H0}\,\mathrm{Mpc}\,(1+z)^2}{H_{CLASS}(z)}>0.
\]

Her er H_CLASS i Mpc⁻¹, nH0 i m⁻³, σT i m² og Mpc konverteringen i meter. F og X_e er dimensionsløse. Den ækvivalente SI-form er cσT nH0(1+z)²/H_s. Ingen ekstra c må lægges til CLASS-formen. Definitionen er L minus R og har F(0)=0, uden en fri additiv konstant. Den dynamiske fremadrettede tid u=ln[811/(1+z)] går mod faldende z, mens F's øvre grænse Z går mod stigende z.

V71's lagrede opacitetskurve bruger en integreret spline i konform tid. Dens allerede integrerede præfiks er en integrationsværdi, ikke en fri kildekonstant. Lagret spline og kildeløsning bevares som forskellige observabler. V78's eksisterende kildeindeslutning for sup|F| genbruges uden genberegning: omtrent [2,29185795×10⁻⁸; 9,26465661×10⁻⁴]. De eksakte rationelle ender står i result.json; decimalerne her er illustrative.

## Stærkere fortegnsargument

Sæt q=10⁻⁶, h=h_R, d=h_L−h, E=d+q og t=v_L−v_R. Før reionisation er ΔX_e=E. V83 giver allerede −2q<d<0 efter starten; vi undersøger den stærkere nedre flade d=−q. V75 beviser E>0 på de første to celler. Begge arme starter med samme temperatur, t(0)=0.

På temperaturfeltet g(X,v)=−v+A(X)(1−v), A(X)=kX/(a+X), a=1+fHe>0, k>0, er

\[
t'=-(1+A_L)t+(A_L-A_R)(1-v_R).
\]

Så længe E≥0, er A_L≥A_R, og de arvede bokse giver v_R<1. Variationen-af-konstanten-formlen giver t≥0. På den første strimmel er E>0 og v_R<1, så t>0 for positiv tid. Derfor v_L≥v_R, og de arvede negative ratehældninger giver α_L≤α_R. Dette erstatter et symmetrisk temperaturloft i det nye nedre-flade-argument; det antager ikke temperaturordenen uden bevis.

På d=−q har h_L=h−q og X_L=X_R=h. Skriv β_i=α_i(1)S≥0, og

\[
U_R=\alpha_R h^2-\beta(1-h),\qquad
U_L=\alpha_L(h-q)h-\beta(1-h+q).
\]

Med κ=1−q/h∈(0,1) fås

\[
U_L\le\kappa U_R-\beta q/h\le\kappa U_R.
\]

Identiteten ved α_L=α_R er kontrolleret ved separat heltalspolynomiel udvidelse. V77 har allerede bevist U_R,i>0 og positive C_i. På fælles gren er C_L≤C_R, fordi C vokser med escape-raten og dermed med h. For en negativ U_L hjælper fortegnet direkte. Ellers anvendes C-monotonien. Derfor

\[
d'=f_L-f_R\ge(q/h)|f_R|>0.
\]

Dette gælder alle kanaler, og det er en streng indadrettet nedre flade. V83's øvre d-grænse genbruges. Ved første muligt E=0 kommer t≥0 fra integralformlen; den strengt positive E'=d' modsiger en første kontakt fra E>0. Der er således ingen cirkelslutning mellem temperatur- og elektronfortegn.

## Det nye beviste interval

Efter V75-strimlen har V62's første234 hele celler i begge arme alene SWIFT som tilladt gren. Fælles SWIFT-escape er monotont voksende i h for samme DK(z); V77's dokumenterede rate- og C-egenskaber gælder på disse bokse. Temperaturstencils og parameterpræmisser genbruges kun på deres beviste domæne. De234 celler er sammenhængende fra V75's slutpunkt til z_c; alle h-gulve er større end q. Den mindste numeriske nedre margin q/h_upper står eksakt i result.json.

Første-kontakt-argumentet gælder gennem de234 cellegrænser, fordi tilstandene er kontinuerte, og de ensidige felter opfylder samme fladeulighed. Det giver E>0 også ved z_c. Sammen med V75 og V83 gælder 0<ΔX_e<q på z_c≤z<810 og ΔX_e=q ved810.

## Første uafsluttede ulighed

Celle235, nulbaseret234, har eksakte ender

\[
[761161663339561/1099511627776,\;1523417340748759/2199023255552]
\]

eller cirka [692,2725;692,77]. Begge arkivmasker tillader HMLA og SWIFT. Under h_L≤h_R er den relevante blandede kombination SWIFT i L og HMLA i R. V77's certifikat giver et øvre loft j_up for C_SWIFT(h)/C_HMLA(h)−1. Monotonien giver C_SWIFT(h−q)≤C_SWIFT(h).

Det tilstrækkelige nye nedre-flade-kriterium bliver

\[
(1+j_{up})(1-q/h_{up})<1
\quad\Longleftrightarrow\quad
j_{up}<\frac{q}{h_{up}-q}.
\]

Den faktiske kontrol bruger det største hydrogenloft på begge arme, ikke en valgt referencetilstand. Her giver de eksisterende helcellegrænser

- h_up = 696217790271347/288230376151711744;
- j_up = 2471961721460691/4611686018427387904;
- tilladt loft = 4503599627370496/10873899373362426379;
- forhold mellem eksisterende og tilladt loft ≈1,294218327;
- den resulterende nedre grænse for d′/|f_R| ≈−0,0001218047862.

**En negativ nedre grænse er ikke en negativ observeret afledt.** Intervaltesten kan ikke udelukke et udadrettet felt, men den producerer heller ikke et kildetilladt tilstandsvidne eller et fortegnsskift på den faktiske bane. Der er ikke bevist en fysisk modsigelse. Det gamle V77-bevis på d=−2q har en større margin og berøres ikke.

Den konkrete mangel er et skarpere, fælles og selector-betinget loft på C_SWIFT(h−q)/C_HMLA(h), eventuelt sammen med faktisk temperatur/ratekorrelation. Arkivets grenuafhængige helcelleloft er utilstrækkeligt til denne stærkere flade. Vi stopper her efter V84-opgavens stopregel. Den sene hale dækkes ikke af dette fortegnsbevis; dens absolutte loft beviser ikke positivitet.

## Hvad følger for Thomson-maksimum?

F′(Z)=w(Z)E(Z)>0 på [z_c,810]. Derfor er F strengt voksende med Z på dette delinterval, og F(810)−F(z_c)>0. Absolutværdien på delintervallet har maksimum i et af de to endepunkter. F(z_c) indeholder den endnu fortegnsuafgjorte lav-z-historie; den er ikke nul, blot fordi vi starter delbeviset der. Det globale maksimumsted og den realiserede globale værdi kan derfor ikke vælges ud fra dette delresultat.

Et fremtidigt globalt fortegnsbevis ville sammen med F(0)=0 reducere maksimum til F(810). Det ville stadig kræve en valideret evaluering af det signerede integral for at bestemme værdien skarpere. Dette er en betinget konsekvens, ikke en V85-konklusion.

## Kontrol og rækkevidde

certify85.py bruger eksakte brøker og de pin-verificerede V75/V77/V62-data. control85.py bruger separat sparse heltalspolynomiel algebra og heltalskrydsmultiplikation. Kontrollerne deler de arvede kilder og intervaldata. De er ikke uafhængige observationer eller nye ODE-baner. Begge består. En oprindeligt planlagt SymPy-kontrol kunne ikke importeres; den blev erstattet med standardbibliotekets eksplicitte heltalspolynomier.

V78-transferen er en verificeret cache: dens SHA-256 og eksakte ender matcher den uploadede samlede journal. De øvrige pin-input er fundet byteidentisk i det uploadede V84-arkivs indlejrede historik. Ingen nye native par eller fulde historieintegrationer er udført. Ingen model- eller konfigurationsændring er foretaget. Hele Q052 er ACTIVE/INCONCLUSIVE. Resultatet afleveres til Resultatindtag og routing2.3.0 med den nye konkrete selector-/grenskiftshindring.
