# Q051 V7 — Global q-regulæritet og observable transfer

RUN_ID: LOCAL-Q051-MATHEMATICS-GLOBAL-HYBRID-TRANSFER-20261026-V7  
PROMPT_ID / VERSION: BUBBLEVERSE.MATHEMATICS / 2.3.0  
EVIDENCE_BOUNDARY: Q001–Q051; indgående V6 og præcist låste afhængigheder. Ingen Q052+.  
TYPE: Ny betinget analytisk udledning og ny finite kontrol; ingen observationsmåling eller kosmologisk baneintegration.

## 1. Præcis konklusion og kvantorer

Fasthold én vilkårlig allerede admitted fælles baggrund fra den frosne hillipop-ede_n3-familie, defineret på 0≤z≤810. Fasthold ét valideret startpar (h0,v0), identisk for alle q∈[0,10⁻⁶]. Den oprindelige fysiske sammenligning er q=0 mod q=10⁻⁶. De tidligere reachable-/invariant-domain- og kildeforudsætninger videreføres; dette bevis skaber ikke en ny kosmologisk baggrund.

Under disse forudsætninger er den bogstavelige kildeflows q-afhængighed lokalt Lipschitz på hele det faste interval. De nedenfor begrundede grænser gælder enhver admitted AC-fortsættelse. For alle q0,q1 i hjælpeintervallet:

\[
\sup_{0\le z\le810}|X(z;q_1)-X(z;q_0)|
\le {11907\over5}|q_1-q_0|,
\]

\[
\sup_{0\le z\le810}|\tau_T(0,z;q_1)-\tau_T(0,z;q_0)|
<42100|q_1-q_0|.
\]

Alle størrelser er dimensionsløse. X er kildeflowets elektronfraktion pr. hydrogenkerne, inklusive den samme frosne reionisationsmap. For ε=10⁻⁶ fås derfor

\[
\boxed{\sup|\Delta X|\le0.0023814,\qquad
\sup|\Delta\tau_T|<0.0421.}
\]

Den skarpere beregnede optiske envelope er 0.04209103698658. Den er en øvre grænse på en fejl, ikke en nedre grænse eller en beregnet faktisk baneforskel. Der påstås ikke, at en fejl tæt ved grænsen kan realiseres. Den første ulighed er 0,23814 procentpoint i elektronfraktion; den er ikke en relativ procentfejl i en lille restionisation. Den anden er en absolut optisk dybde og er for grov til at dokumentere observationsmæssig negligibilitet. Specifikt er den sammenlignelig med konfigurationens reionisationsdybdeskala, cirka 0,0515.

Resultatet afgør det formulerede spørgsmål om en uniform lineær perturbationsgrænse inden for det betingede kilde-real-domæne. Det udelukker absolutte forskelle på 1 i begge observabler for dette ε. Udtrykket “order unity” erstattes her af de eksplicitte tal; ingen ukendt strengere præcisionstolerance erklæres bestået. Konstanterne er faste og vælges ikke som en funktion af den faktiske endpointafstand.

## 2. Genbrugt viden, ikke nye kørsler

Sæt

\[
u=\log {811\over1+z},\quad h=x_{HII},\quad
v=T_m/T_\gamma,\quad x=h+q,\quad
\delta=10^{-7},\quad m=x+\delta.
\]

De fulde V2-, V4-, V5- og V6-bevistekster og deres nødvendige certifikater ligger uændrede i Q051_GLOBAL_TRANSFER_INPUT_BUNDLE_V7.json. V6-inputbundlen indeholder yderligere V3-certifikatet og de seks frosne fysiske tekster. Alle genbrugte bytes og hashes kontrolleres; deres gamle producenter køres ikke igen.

Følgende præmisser er genbrug:

| Kilde | Præmis, som bruges her |
|---|---|
| Q049, bevaret journalpost | h forbliver i et kompakt deldomæne af [0,1), v≥.98e⁻ᵘ, v≤1.000001, positive kilde-denominatorer og den positive matter-floor for samme baggrund. |
| Q050 og V2–V6 | De frosne kildeoperatorer er definerede på de reachable rails; PEEBLES dispatch bruges ved ratio-/TR-grænsen. |
| V2 §§2,5–7 | Begge HMLA/SWIFT-normaler på den tidlige Pion-flade er >2.7×10⁶ s⁻¹ i u-normalens kildeenheder; cold og warm rater er begge omfattet. Højst én tidlig Pion-event, med faktor <90. |
| V2 §6 | Præcis én senere Pion-event på 685≤z≤695, med begge normaler <−180 s⁻¹ og faktor <3. Ingen øvrige reachable Pion-events. |
| V4 §2 | Warm→cold-join ved v=1 har fælles normal −1, højst én event og u<10⁻⁶, altså z>809. Vægtet faktor <21/20. |
| V5 §§2–4 | Den ikke-singulære rectangle-comparison, med L0=3 og samlet smooth-exponent <3/20, giver smooth-only faktor 3e^(3/20)<7/2. |
| V3 / V6 | Højst én aktiv PEEBLES-ratio-event. Dens reachable normal er <−1/30, kontaktens z≤4006/49, og den vægtede eventfaktor er <12/5. Den faste TR-fallback og dens sammenfald er dækket. |

Normalen dF/du for Pion har enhed s⁻¹, fordi guard F er bygget af fysiske rater. u er dimensionsløs. Temperaturguardens normal og alle eventfaktorforhold er dimensionsløse. Der divideres kun mellem normaler for samme guard, state og baggrund.

Disse er betingede source-real analytiske/certificerede præmisser, ikke observerede kosmologiske data. V7 genbruger deres domæne og claimstyrke; ingen native/P6-identitet importeres.

## 3. Det tidlige warm/Pion-hjørne

### 3.1 To eventfunktioner og fire kildegrene

Brug den udvidede state (u,h,v,q) med u′=1 og q′=0. Ved et muligt sammenfald er eventfunktionerne

\[
e_1=F(u,h)=99B(u)-L-3R_\alpha(u,h),\qquad e_2=1-v.
\]

Her har F ingen direkte v- eller q-afhængighed. Dens tidlige orientering er HMLA→SWIFT. Den anden orientering er warm→cold. De fire mulige lokale kildegrene er HMLA/warm, HMLA/cold, SWIFT/warm og SWIFT/cold. Den termiske kilde er fælles:

\[
g=-v+A(u,h,q)(1-v).
\]

På v=1 er −g=1 præcist for alle fire grene. V2's normale separation omfatter begge atomare kanalsæt og begge Pion-grene. Derfor er, ved hjørnet,

\[
de_1/du>2.7\times10^6,\qquad de_2/du=1
\]

for hver af de fire branchegerms. Det er en samtidig fortegnskontrol; to normaler fra forskellige uafhængige worst-case-tilstande bruges ikke til at postulere en ny bane.

Hvert branchefelt har en lokal Lipschitz-germ: denominatorerne er positive, h<1 og v>0, og tabelstykkerne er endeligt mange kontinuerte polynomielle log-interpolanter. Den faste baggrund er et admitted glat kilde-real medlem. Ved kontinuitet kan et lokalt hjørnenabolag vælges, hvor begge eventfunktioner fortsat vokser strengt for alle fire germs, eksempelvis med mindre positive lokale marginer. Der behøves ikke samme størrelse nabolag for alle baggrunde; koefficientgrænserne, som bruges senere, er allerede uniforme.

### 3.2 Lokal konstruktion, skiftende eventorden og kontinuitet

Følg det aktuelle brancheflow indtil den første af de to positive eventklokker eller den faste outputsektion. Den uniforme lokale normalmargin gør hver tilstødende hitting time Lipschitz: en ændring af eventresidualen flytter nulpunktet højst med residualændringen divideret med marginen. Det følger af den monotone inversestimate og brancheflowets Lipschitz-kontrol. Efter den første event følges den passende anden branchegerm til næste event eller output. Da begge eventfunktioner vokser, kan ingen af dem krydses tilbage i dette nabolag.

Der er endeligt mange lokale eventord: ingen event, kun én af dem, eller de to ord warm→Pion og Pion→warm. Hvis deres orden ændres, går varigheden af den mellemliggende branche mod nul. De to state-selektioner mødes derfor i den samme hjørnetilstand og samme efterfølgende kildegren. Dette giver en kontinuert finite selection, med de sædvanlige clipped clocks ved initial- og outputtid. Et sammenfald betyder ikke, at de to derivative matricer skal kommutere.

På hvert glat tabelstykke kan denne konstruktion differentieres med de oprindelige saltationsmatricer. Ved et kontinuerligt tabelknudepunkt bruges lokale Lipschitz-flows, one-sided difference quotients og grænser af de samme hittekonstruktioner. De glatte estimates er uniforme op til knuden, og limitpassagen bevarer dem. Ingen tabelknudetransversalitet antages. En event-germ udenfor sin fysiske sektor er kun et lokalt matematisk redskab til hitteklokken; ingen faktisk bane eller selector forlænges forkert.

En kontinuert finite selection af lokalt Lipschitz-selektioner er lokalt Lipschitz. Restriktion til en q-kurve og en endelig lokal cover på det kompakte q-interval giver absolut kontinuitet. Eventorden kan skifte mange gange som funktion af q; der antages ikke et endeligt antal q-underdelinger. Der er kun endeligt mange mulige lokale ord, og den lokale finite-selection-egenskab er tilstrækkelig. Afledte findes næsten overalt; en enkelt klassisk afledt ved selve hjørnet kræves ikke.

Til metodekontrol blev Burden et al. (2016), §§3.2,4.1–4.3, læst: deres eventorientering og finite-selection-konstruktion beskriver samme geometri. Deres globale glathedshypoteser anvendes ikke ukritisk på atomtabellerne. De konkrete fælles normaler, branchegerms, sammenfaldskontinuitet og håndtering af kontinuerte knuder er argumentet ovenfor. Papiret leverer hverken de kosmologiske koefficienter eller dette Q051-resultat.

### 3.3 Vægtede variationer og de to ord

Sæt H=∂q h, W=(m/v)∂q v. Ved en kontinuerlig state-event er m/v det samme fra begge sider. De allerede udledte operatorer i denne samme vægt er

\[
P=\operatorname{diag}(\nu_{out}/\nu_{in},1),\qquad
J=\begin{pmatrix}1&\gamma_1\\0&1\end{pmatrix}.
\]

Pion har ∂qF=0; warm-guard har heller ingen direkte q-afhængighed. Der er derfor ikke skjult ekstra direkte guard-forcing. Forcing i brancheflowet bevares i næste afsnits +1-led. Ved hjørnet er de mulige følsomhedsoperatorer de fysisk korrekte ord P_cold J_HMLA og J_SWIFT P_warm, samt deres endpoint-subord. Der hævdes ikke lighed mellem ordene. Begge er dækket af produktet 90×21/20. Finite-selection-gluing tilføjer ingen ekstra multiplikativ eventfaktor.

Hvis |H|≤L−1 og |W|≤L, kan en shear med |γ|≤G−1 dækkes med L_out=G L_in. En positiv diagonalratio k dækkes med G=max(1,k), fordi k(L−1)≤G L−1. De samme regler gælder de næsten-overalt afledte i de forskellige lokale selektioner.

## 4. Globale parameterfamilier, endpoints og alle fortsættelser

Branchefelterne er lokalt Lipschitz i h,v,q på de kildefinerede rails. Kontinuerte tabel- og fitknuder giver ingen physical saltation. u-bestemte brancheskift har en fælles fast tid og dermed ingen parameterafhængig eventtidskorrektion; branchevariationsgrænsen gælder på hvert tidsstykke.

V2 afgrænser begge Pion-events og udelukker grazing og ophobning. V4 afgrænser warm-eventen. Afsnit 3 løser det eneste mulige tidlige state-event-sammenfald. Den sene Pion-event er isoleret fra warm-eventen og PEEBLES-strippen. V6's clipped map dækker PEEBLES-ratioens event eller fravær og sammenfald med fast TR-fallback. Den samme konstruktion kan klippes ved en vilkårlig outputtid i intervallet; ved den aktive ratio-event er vækstfaktoren højst 12/5, på fikstidssiden er den 1.

For initiale states på en eventflade bruges den fremadrettede gren med den beviste krydsningsretning. Equality-reglen beholdes præcis, men værdien på et enkelt transversalt tidspunkt ændrer ingen AC-state. Ingen ventetid eller sliding er mulig med de strenge normale marginer. Når en event ligger præcis på outputsektionen, er kortet den kontinuerte grænse af ingen event eller allerede passeret event. Deres subord er allerede inkluderet. Ved q=0 og q=10⁻⁶ er kun ensidige parametergrænser nødvendige. Initial h=0,q=0 kræver ingen division med x: m≥δ, og den indadrettede hydrogenkilde og de glatte branchegerms giver samme ensidige konstruktion.

De gamle invariant-bounds gælder alle q i hjælpeintervallet: den negative q-rekombination styrker hydrogenets øvre barriere, den nedre grænse følger ved h=0, og den termiske rail bruger alene A≥0. De genbrugte kildedenominatorer og dispatch-domæner er ligeledes uniforme i dette interval. Lokale fortsættelser kan derfor sammensættes til u=ln811 uden at ramme en kildepol, v=0 eller h=1. Der er højst fire state-events; kontinuerte interpolationknuder ændrer ikke branchefeltets lokale Lipschitz-unikhed.

Dette giver en regelmæssig q-familie fra de identiske starts. Det beskriver også enhver anden admitted AC-fortsættelse med samme start: lokal brancheunikhed, de fælles eventretninger og de faste efterfølgende selektioner tvinger samme concatenation. Uniformitetsclaimet bygger således ikke på at vælge én bekvem repræsentant blandt flere ukontrollerede fortsættelser. Denne kilde-real konklusion udvider hverken baggrundsfamilien eller en native numerisk implementation.

## 5. Én smooth-vækstkonto og den globale envelope

V5 gav, uden at kræve x>0 eller h′≤0,

\[
H'=f_hH+f_v{v\over m}W+f_q,
\quad W'=\left({f\over m}-{A\over v}\right)W+B_\delta(H+1),
\]

\[
|B_\delta|\le {A\over v}+{R_\gamma\delta\over av},\qquad
f_+\le rbs,\qquad a=1+fHe.
\]

Den ekspanderende rectangle |H|≤L−1, |W|≤L, L≥3 er invariant mellem events med

\[
L'=\kappa L,\qquad \kappa={rbs\over\delta}+{R_\gamma\delta\over av},
\quad\int_0^{\log811}\kappa\,du<3/20.
\]

Matched starts har H(0)=W(0)=0. Variationsregulariteten, som var betinget i V5, er nu begrundet ovenfor. De kontinuerte knuders one-sided derivative estimates og deres konvekse grænsematricer opfylder de samme lineære face-uligheder; det er en afledningsmetode, ikke en konveksificering af de diskontinuerte selectors.

Derfor kan eventfaktorerne sammensættes med den samlede smooth-konto anvendt præcis én gang:

\[
L\le3\exp\!\left(\int\kappa du\right)
\,90\,{21\over20}\,3\,{12\over5}
<{7\over2}\,90\,{21\over20}\,3\,{12\over5}
={11907\over5}=2381.4.
\]

Vi anvender **ikke** derudover V6's fulde 243/100-mapfaktor, da den allerede indeholder sit eget smooth-interval. Her genbruges kun V6's eventfaktor 12/5 og hjørneargument; V5's hele smooth-integral indeholder z100→15 én gang. Herved undgås dobbelttælling.

Alle prefixer af et eventord giver mindre faktorer. Med eventlokationerne kan elektron-envelope også afgrænses stykkevist:

| Redshiftbånd | Gyldig L-envelope |
|---|---:|
| 695<z≤810 | (7/2)×90×(21/20)=330.75 |
| 4006/49<z≤695 | 330.75×3=992.25 |
| 0≤z≤4006/49 | 992.25×(12/5)=2381.4 |

Hvert bånd får konservativt hele 7/2 smooth-envelopen som et punktvist loft. Det er ikke en produktmæssig gentagelse af smooth-vækst langs banen: de tre punktvise lofter integreres over disjunkte z-intervaller. Ved fælles endpoints vælges det større loft.

## 6. Elektroner og Thomson-integral

Den pin-verificerede kilde thermodynamics.c, linjer4090–4110 og4152–4179, bruger x=h+q som xe_before og den frosne reio_camb-map

\[
X=\lambda(z)(h+q)+d(z),\qquad0\le\lambda\le1,\quad d\ge0.
\]

Før reionisation er λ=1,d=0. Under reionisation er λ=(1−tanh(argument))/2, og d og helium-additionen er identiske i begge arme. Ingen ny tau-shooting tillades. Derfor

\[
\partial_qX=\lambda(H+1),\qquad
|\Delta X(z)|\le |q_1-q_0|\lambda(z)L(z).
\]

Hydrogen-følsomheden kan vælges K_h=11902/5. Det direkte helium-led +1 er bevaret, så K_x=K_h+1=11907/5. Ved z810 er den faktiske initiale elektronforskel ε, selv om h og v er matchede.

Med H_CLASS i Mpc⁻¹ (c=1-konvention), nH0 i m⁻³ og σT i m² er den frosne positive kernel

\[
w(z)={\sigma_T n_{H0}\,\mathrm{Mpc}\,(1+z)^2\over H_{CLASS}(z)},\quad
\Delta\tau_T(0,Z)=\int_0^Z w(z)\Delta X(z)\,dz.
\]

Dette følger direkte af den pinned opacity i thermodynamics.c og dτ_conformal/dz=−1/H_CLASS. Hvis H angives i s⁻¹, er det ækvivalente udtryk cσT nH0(1+z)²/H_s. Man må ikke sætte en ekstra c-faktor ind i Mpc⁻¹-udtrykket.

Q049's allerede beviste fælles matter-floor genbruges:

\[
H_{CLASS}(z)\ge H_{0,CLASS}\sqrt{\Omega_b+\Omega_c}\,(1+z)^{3/2}.
\]

Den gælder samme admitted flat baggrund med positivt baryon/CDM-bidrag og ikke-negativ øvrig energi. Dermed, med Ωm=Ωb+Ωc og D=σT nH0 Mpc/H0,

\[
\sup_Z|\Delta\tau_T(0,Z)|
\le |q_1-q_0|{D\over\sqrt{\Omega_m}}
\sum_i L_i\int_{a_i}^{b_i}\sqrt{1+z}\,dz.
\]

Ingen korrelation mellem to forskellige baggrunde antages: derivation og ΔX er på samme medlem; den universelle floor er blot et fælles øvre integralloft. λ≤1 bruges konservativt. Positiviteten gør også grænsen gyldig for enhver delhale i intervallet.

Konstanterne er netop kildeværdierne σT=6.6524616×10⁻²⁹ m² og Mpc=3.085677581282×10²² m. H0, Ωb, Ωc og nH0 er de eksakte rationelle værdier af de frosne capture-hex-tal, ikke nye afrundede cosmologifits. H0≈0.00022919563365907353 Mpc⁻¹, Ωm≈0.3087560339193072 og nH0≈0.188062406330 m⁻³; exact-rational værdier ligger i certifikatet.

Med antiderivativet (2/3)(1+z)^(3/2) fås:

| Redshiftbånd | Kernel-integralloft, uden L | Bidrag til K_tau, afrundet |
|---|---:|---:|
| 695→810 | 9.56653815935 | 3164.13249620 |
| 4006/49→695 | 35.5846163973 | 35308.8356202 |
| 0→4006/49 | 1.51930329645 | 3618.06887016 |
| Samlet | — | 42091.03698658 <42100 |

Tabellens decimaler er læsevenlige afrundinger; de rettede intervalendpoints i certifikatet er autoritative. K_tau er en deterministisk matematisk koefficient. Den er ikke et optisk signal, et konfidensinterval eller en empirisk errorbar.

## 7. Faktisk validering og dens rækkevidde

Producenten q051_v7_global_transfer_certificate.py udfører **82/82 PASS**. Den bruger eksakte Fraction-tal, integer-square-root-enclosures med 65 decimalers skala, genbrugs-/pin-kontrol, begge ikke-kommuterende eventord i et præcist løst metodeeksempel, 40 eksakte par-kontroller og alle16 endpoint-event-subsets. Der integreres ingen kosmologisk IVP, og de afsluttede gamle tests udføres ikke igen.

Den separate kontrol q051_v7_separate_control.py udfører **38/38 PASS** uden import af producenten. Den parser capture-hex direkte, bruger rettet Decimal-aritmetik og et selvstændigt monotont højre-Riemann-loft over **12288 hele z-celler**. Den bruger ikke antiderivativet til sin kernelkontrol. Dens lidt grovere K_tau-loft er42095.54129813<42100. Desuden kontrollerer den hjørneeksemplet ved separat eksakt event-stepping, inklusive initialtid, output ved event og begge eventord.

Metodeeksemplet har guards x=0,y=0, positive sektorhastigheder (1,1),(2,1),(1,3),(4,5) og start (−1+q,−1). Ved outputtid2 er den præcise output (4+2q,5) for q≥0 og (4+4q,5+2q) for q<0. Det er kontinuert ved samtidigheden, selv om de to derivative ord er forskellige. Dette tester den relevante algebra og endpointlogik; det er ikke et simuleret kosmologisk forløb eller et bevis for, at source-præmisserne gælder.

Fælles fejlmuligheder: begge kontroller deler de fysiske tekster, de arvede V2–V6-præmisser og det skrevne regulæritetsargument. Der er ingen uafhængig menneskelig review, formel teoremprover eller ny uafhængig fysisk replikation. R2 dækker dokumenteret ny finite execution; det må ikke kaldes R3 for den globale analytiske konklusion. Gennemført alternativ aritmetik styrker tal- og metodedelen, men erstatter ikke argumentet i §§3–5.

Reproduktion med standard Python3 fra denne mappe:

```bash
python3 q051_v7_global_transfer_certificate.py
python3 q051_v7_separate_control.py
```

## 8. Kilder, proveniens og historisk grænse

- Projektread: Morfindien/Bubbleverse@51f8320245cde021d98da16699a85fc486330be6, nontruncated4612-entry tree. Indgående V6-journal, rapport og indeks matcher deres aktuelle Git-blobs. Repositoriet har rapport/journal/indeks, men ikke de fulde Q051-støttebeviser; disse er målrettet genfundet som eksisterende gemte artefakter og indlejret byteidentisk i den nye bundle. README er ældre navigation og tilsidesætter ikke journalen. Ingen AGENTS.md i det inspicerede tree.
- Fysikpin: [mwt5345/class_ede@5a131c91d657dd9a7c6364cc45b038710f8d0d97](https://github.com/mwt5345/class_ede/tree/5a131c91d657dd9a7c6364cc45b038710f8d0d97). Nye fulde bytekontroller: source/thermodynamics.c, gitblob c1683f56b43e0f2ec24a8ba6120133f604cb947c; include/thermodynamics.h, f02f2591077ee11f3bc9481a4491b0feb83cf26d; include/background.h,742e4f19d738b1c60467a81aadc8db4b28eb001c. Disse tekster inkluderer kernel, reionisationsmap, σT og Mpc-konstant. De gamle seks fysiske tekster bevarer V6's eksakte hashes.
- Metode: S.A.Burden,S.S.Sastry,D.E.Koditschek,S.Revzen (2016), *Event–Selected Vector Field Discontinuities Yield Piecewise–Differentiable Flows*, SIAM J.Applied Dynamical Systems15(2),1227–1267, [DOI10.1137/15M1016588](https://doi.org/10.1137/15M1016588), §§3.2,4.1–4.3. [Forfatter-hostet primærtekst](https://faculty.washington.edu/sburden/_papers/BurdenSastry2016siads.pdf). Metodekontekst; de source-specifikke præmisser er kontrolleret ovenfor.
- Q049's matter-floor og invariant-argument er genbrug fra den indgående journals post LOCAL-Q049-GLOBAL-INVARIANT-TAUTAIL-CAP-V2. Q049's gamle46.67050453-cap køres ikke igen eller omskrives.

[INCOMPLETE_JOURNAL] Den tidligere oplyste originale rå M14/Mikami-mellemversionspost er stadig ikke rekonstrueret. Hele den faktisk tilgængelige V6-journal bevares byte-for-byte. Dette påvirker fuldstændig workflowhistorik, men den nye betingede matematiske konklusion bruger det eksplicit leverede hovedspørgsmål, starts, kildepins og genfundne beviser og ingen information fra den manglende post. Derfor kan den matematiske Q051-opgave afsluttes inden for denne udtrykkelige scope, mens det historiske hul forbliver synligt. Canonical registry-/model-adoption udføres ikke ved denne vurdering.

MODEL_DIFF: Nyt foreslået betinget stabilitetsclaim; ingen ændring af kilde, equality-regler eller accepted model. Q048 actual127/frontier810 og native/P6-status ændres ikke. Ingen ny Q aktiveret. Næste destination er Motor14 til indtagelse og integration af det betingede resultat, ikke en genkørsel af de afsluttede grids.
