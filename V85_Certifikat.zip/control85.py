"""Separate algebraic control: symbolic face identity and integer margin comparison."""
import json
from pathlib import Path
from decimal import Decimal,localcontext
P=Path(__file__).resolve().parent
# Sparse multivariate integer polynomials (h,q,alpha,beta,j), no producer import.
def add(a,b):
 out=dict(a)
 for k,v in b.items():out[k]=out.get(k,0)+v
 return {k:v for k,v in out.items() if v}
def neg(a):return {k:-v for k,v in a.items()}
def sub(a,b):return add(a,neg(b))
def mul(a,b):
 out={}
 for k,v in a.items():
  for l,w in b.items():
   m=tuple(x+y for x,y in zip(k,l));out[m]=out.get(m,0)+v*w
 return {k:v for k,v in out.items() if v}
one={(0,0,0,0,0):1}
h,q,alpha,beta,j=[{tuple(int(k==i) for k in range(5)):1} for i in range(5)]
UR=sub(mul(alpha,mul(h,h)),mul(beta,sub(one,h)))
UL=sub(mul(alpha,mul(sub(h,q),h)),mul(beta,add(sub(one,h),q)))
assert add(sub(mul(h,UL),mul(sub(h,q),UR)),mul(beta,q))=={}
assert sub(sub(h,mul(add(one,j),sub(h,q))),sub(q,mul(j,sub(h,q))))=={}
v=json.loads((P/'v62.json').read_bytes());old=json.loads((P/'v77.json').read_bytes());r=json.loads((P/'result.json').read_bytes())
L,R=v['arms']['L']['records'],v['arms']['R']['records']
idx=next(i for i,x in enumerate(R) if x['allowed_branches']!=['SWIFT'])
assert idx==234 and all(x['allowed_branches']==['SWIFT'] for x in L[:idx])
for k in range(idx):
 assert L[k]['z']==R[k]['z']
 if k:assert R[k-1]['z'][1]==R[k]['z'][0]
 assert float.fromhex(R[k]['z'][0])>float.fromhex(R[k]['z'][1])
H=max(float.fromhex(x['whole_source'][0][1]) for x in [L[idx],R[idx]])
hn,hd=H.as_integer_ratio();jn,jd=float.fromhex(old['mixed_branch_checks'][0]['relative_C_excess'][1]).as_integer_ratio()
# j > q/(h-q) iff jn*(10^6*hn-hd)>jd*hd, all integers positive.
left=jn*(10**6*hn-hd);right=jd*hd
assert left>right>0
with localcontext() as ctx:
 ctx.prec=45
 ratio=Decimal(left)/Decimal(right)
 lo=(Decimal(1)/Decimal(10**6))/(Decimal(hn)/Decimal(hd))-(Decimal(jn)/Decimal(jd))*(1-(Decimal(1)/Decimal(10**6))/(Decimal(hn)/Decimal(hd)))
 assert Decimal('1.29')<ratio<Decimal('1.30') and lo<0
 print(json.dumps({'status':'PASS','checked_symbolic_identities':2,'single_branch_cells':idx,'integer_cross_product_exceeds_threshold':True,'C_excess_over_threshold_decimal':str(ratio),'normalized_lower_bound_decimal':str(lo),'global_sign_conclusion':'INCONCLUSIVE','independence':'Sparse integer-polynomial face simplification and integer cross multiplication separate from Fraction producer; same inherited source certificates. Symbolic identities check the derivation, not physical trajectory independence.'},indent=2))
