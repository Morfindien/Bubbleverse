# V85 reproduction
Python3 standard library only. Run without -O:

    python3 certify85.py > replay.json
    cmp replay.json result.json
    python3 control85.py > replay_control.json
    cmp replay_control.json control.json

The producer checks new signed-face arithmetic and234 archived cells, not new trajectories. The separate control uses integer polynomials and cross multiplication. Shared inherited source/trajectory assumptions remain. PROOF_V85.md contains the analytical argument and scope. The nested V84 archive preserves earlier evidence; pins.json records which inputs were recovered from it and the V78 cache verified against the cumulative journal. manifest.json hashes all files except itself.

Upload all four new V85 root deliverables, including Q052_SOME_M011_R1.zip, to Morfindien/Bubbleverse. Preserve all earlier records. Update existing Q052 navigation only after current branch reconciliation. No push or social-platform posting was performed.
