# Contradictions and falsification
PROPOSED / NOT_RUN: independently reproduce black-hole mass estimates using their measurement uncertainties; vary accretion assumptions and line-width calibrations.
PROPOSED / NOT_RUN: test LRD continuum-selection sensitivity to dust and alternative central engines.
PROPOSED / NOT_RUN: quantify metallicity-gradient changes under matched stellar-parameter selection.
No verified Bubbleverse model predictions or comparable Q observables available; no SUPPORT or FAIL assigned.
