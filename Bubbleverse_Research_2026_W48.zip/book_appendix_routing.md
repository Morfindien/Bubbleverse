# Proposed routing (not applied)
- DOI:10.1051/0004-6361/202662243: HOVEDBOG + APPENDIX. Source and interpretation must remain separate.
- DOI:10.3847/2041-8213/aea901: HOVEDBOG + APPENDIX. Source and interpretation must remain separate.
- arXiv:2611.28209: APPENDIX + FUTURE_Q. Source and interpretation must remain separate.
- DOI:10.1093/mnras/stag2006: APPENDIX + WATCHLIST. Source and interpretation must remain separate.
- ALMA-2026-11-20: HOVEDBOG + APPENDIX; DATE_BOUNDARY_UNVERIFIED. Source and interpretation must remain separate.
