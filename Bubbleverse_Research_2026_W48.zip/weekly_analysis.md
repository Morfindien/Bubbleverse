# Evidensanalyse
## DOI:10.1051/0004-6361/202662243 — Euclid: Discovery of a quasar at z=8.13 hosting a 360-million-solar-mass black hole
- Dato: 2026-11-24; status: peer-reviewed A&A
- OBSERVED redshift; INFERRED mass
- Resultat: z=8.13; BH mass ~3.6e8 solar masses; 630 Myr after Big Bang
- Metode: Euclid selection, Keck/Hubble/LBT/JWST spectroscopy
- Bias/begrænsninger: Mass depends on line-width/luminosity calibrations; selection of rare luminous objects
- Routingforslag: HOVEDBOG + APPENDIX
- Modstridende undersøgelser: ikke systematisk verificeret; ingen konsensus påstået.

## DOI:10.3847/2041-8213/aea901 — Cassiopeia A dust composition and shell mixing (Temim et al.)
- Dato: 2026-11-23; status: peer-reviewed ApJ Letters (NASA reported)
- OBSERVED dust spectra; INFERRED shell merger
- Resultat: Spatially resolved dust chemistry supports pre-explosion shell mixing; hours-before-explosion timing model-dependent
- Metode: JWST MIRI mid-infrared; Spitzer comparison
- Bias/begrænsninger: Not direct observation of progenitor hours before explosion
- Routingforslag: HOVEDBOG + APPENDIX
- Modstridende undersøgelser: ikke systematisk verificeret; ingen konsensus påstået.

## arXiv:2611.28209 — Quasi-hostless LRDs with intrinsically red, faint UV continua
- Dato: 2026-11-20; status: preprint submitted to A&A
- OBSERVED spectra; INFERRED central-engine model
- Resultat: 132 LRDs; 3 new candidates with L1500/L5100<0.03; betaUV ~-1.8 to -0.5
- Metode: Spectroscopic sample and continuum ratio selection
- Bias/begrænsninger: Selection effects; multiple central-engine interpretations
- Routingforslag: APPENDIX + FUTURE_Q
- Modstridende undersøgelser: ikke systematisk verificeret; ingen konsensus påstået.

## DOI:10.1093/mnras/stag2006 — Age dependence of the radial metallicity gradient in the Galactic disc with LAMOST and Gaia
- Dato: 2026-11-21; status: peer-reviewed MNRAS
- OBSERVED stellar survey; INFERRED age-gradient relation
- Resultat: 580037 FGK stars; broad strongest negative gradient at 4–8 Gyr; flattening for older stars
- Metode: LAMOST DR7, Gaia DR3, StarHorse ages, APOGEE cross-check
- Bias/begrænsninger: Selection on stellar parameters changes gradient amplitudes
- Routingforslag: APPENDIX + WATCHLIST
- Modstridende undersøgelser: ikke systematisk verificeret; ingen konsensus påstået.

## ALMA-2026-11-20 — Resolving the black hole sphere of influence in a hyperluminous obscured quasar at redshift 4.6
- Dato: 2026-11-20; status: Science Advances (reported by ALMA)
- OBSERVED gas kinematics; INFERRED dynamical mass
- Resultat: z~4.6; M_BH ~6.5e9 solar masses; resolution ~700 light years
- Metode: ALMA [CII] and CO velocity field, outflow modeling
- Bias/begrænsninger: Publication hour unverified relative to 7-day window boundary; model dependence of gas dynamics
- Routingforslag: HOVEDBOG + APPENDIX; DATE_BOUNDARY_UNVERIFIED
- Modstridende undersøgelser: ikke systematisk verificeret; ingen konsensus påstået.
