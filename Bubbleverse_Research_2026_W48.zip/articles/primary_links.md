# Primary sources
- DOI:10.1051/0004-6361/202662243: https://doi.org/10.1051/0004-6361/202662243 (2026-11-24)
- DOI:10.3847/2041-8213/aea901: https://doi.org/10.3847/2041-8213/aea901 (2026-11-23)
- arXiv:2611.28209: https://arxiv.org/abs/2611.28209 (2026-11-20)
- DOI:10.1093/mnras/stag2006: https://arxiv.org/abs/2611.28456 (2026-11-21)
- ALMA-2026-11-20: https://www.almaobservatory.org/en/press-releases/alma-resolves-the-gravitational-reach-of-a-black-hole-in-the-early-universe/ (2026-11-20)
- NASA Cassiopeia A: https://science.nasa.gov/missions/webb/nasas-webb-shows-how-supernova-dust-chronicles-star-evolution/
- ESA Euclid: https://www.esa.int/articles/about-us/directorates/science/euclid/euclid-breaks-own-quasar-record-by-40-million-years
