# Ugentlig oversigt
4 verificerede dato-kvalificerede studier; 1 grænsetilfælde. Autoriseret Q kan ikke fastslås. Alle tests NOT_RUN. Ingen SoMe eller Q-afslutning.
