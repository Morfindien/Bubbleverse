from pathlib import Path
from fractions import Fraction as F
import json,hashlib,zipfile
P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def run():
 raw=(P/'Q052_TEMPERATURCERTIFIKAT_V81.zip').read_bytes()
 assert sha(raw)=='4b1fe866e018f5ec91000e658a0fbba135635539c7754ec65793ed2db3e0a1b2'
 with zipfile.ZipFile(P/'Q052_TEMPERATURCERTIFIKAT_V81.zip') as z:
  assert z.testzip() is None;m=json.loads(z.read('manifest.json'))
  for n,h in m['members_sha256'].items():assert sha(z.read(n))==h
  get=lambda n:json.loads(z.read(n))
  r,c,v,g,d=get('result.json'),get('control.json'),get('verification.json'),get('guard80.json'),get('v62.json')
  assert c['primary_result_sha256']==sha(z.read('result.json'))
  for n,h in r['input_sha256'].items():assert sha(z.read(n))==h
  for x in v['replays']:
   assert x['byte_identical'] and x['output_sha256']==sha(z.read(x['output'])) and x['script_sha256']==sha(z.read(x['script']))
  threshold=F(g['certified_v50_must_exceed_for_sufficient_test']['through_common_radiation_switch']);arms={}
  for arm,floor in [('L',F(327901,10**6)),('R',F(327899,10**6))]:
   t=r['trace'][arm];assert len(t)==len(d['arms'][arm]['records'])==1526
   for i,(row,old) in enumerate(zip(t,d['arms'][arm]['records'])):
    assert row['i']==i and row['z']==old['z']
    assert all(F(x)>0 for x in row['end_lower'])
    if i:assert t[i-1]['end_lower']==row['initial_lower'] and t[i-1]['z'][1]==row['z'][0]
   a=r['arms'][arm];b=F(a['v50_lower_exact']);bc=F(c['arms'][arm]['v50_lower_exact'])
   assert t[-1]['end_lower'][1]==a['v50_lower_exact']
   assert b>=floor>threshold and bc>=floor
   assert b-threshold==F(a['strict_threshold_margin'])
   saved=F(d['arms'][arm]['z50_saved'][1]);assert saved-b==F(a['native_saved_v50_minus_source_v50_upper'])<=F(13,200)
   transition=F(g['radiation_transition_enclosure'][0]);cool=floor*(1+transition)/51
   assert cool>F(g['ratio_threshold_safe'])
   arms[arm]={'accepted_v50_lower':str(floor),'strict_margin':str(floor-threshold),'at_lower_common_radiation_edge_lower':str(cool)}
 return {'schema':'Q052_V82_INTAKE_AUDIT','status':'PASS_CONDITIONAL_ACCEPTANCE','V81_archive_sha256':sha(raw),'members_checked':len(m['members_sha256']),'trace_rows_checked':3052,'arms':arms,'scientific_producer_rerun_this_intake':False,'prior_fresh_replay_receipt_verified':True,'independence_scope':'V81 independent arithmetic/interpolation; shared source data and analytic premises. Intake checks identities, continuity and exact threshold margins.','global_Q052_resolved':False,'new_native_pairs':0,'new_full_history_integrations':0}
if __name__=='__main__':print(json.dumps(run(),indent=2)+'\n',end='')
