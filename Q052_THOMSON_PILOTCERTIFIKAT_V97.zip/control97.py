"""Separate sparse-polynomial algebra and grouped exact quadrature control."""
import json,re
from fractions import Fraction as F
from pathlib import Path
from collections import defaultdict
P=Path(__file__).resolve().parent

def read(n):return json.loads((P/n).read_bytes())
def binary(s):
 m=re.fullmatch(r'(-?)0x([0-9a-f]+)\.([0-9a-f]+)p([+-]?\d+)',s)
 sign,whole,frac,power=m.groups();value=F(int(whole+frac,16),16**len(frac))*F(2)**int(power)
 return -value if sign else value
# Small exact multivariate polynomials, variables supplied explicitly per identity.
N=8
one={(0,)*N:F(1)}
def var(i):return {tuple(int(k==i) for k in range(N)):F(1)}
def add(a,b):
 out=dict(a)
 for k,v in b.items():out[k]=out.get(k,F(0))+v
 return {k:v for k,v in out.items() if v}
def scale(a,c):return {k:v*c for k,v in a.items() if v*c}
def sub(a,b):return add(a,scale(b,-1))
def mul(a,b):
 out={}
 for k,v in a.items():
  for j,w in b.items():
   exponent=tuple(x+y for x,y in zip(k,j));out[exponent]=out.get(exponent,F(0))+v*w
 return {k:v for k,v in out.items() if v}
def deriv(a,i):
 out={}
 for k,v in a.items():
  if k[i]:
   kk=list(k);kk[i]-=1;out[tuple(kk)]=v*k[i]
 return out
h,q,alpha,beta,delta=[var(i) for i in range(5)]
hl=sub(h,scale(q,F(1,2)));xl=add(h,scale(q,F(1,2)))
right=sub(mul(alpha,mul(h,h)),mul(beta,sub(one,h)))
left=sub(mul(sub(alpha,delta),mul(hl,xl)),mul(beta,sub(one,hl)))
gap=add(add(scale(mul(alpha,mul(q,q)),F(1,4)),scale(mul(beta,q),F(1,2))),mul(delta,mul(hl,xl)))
assert sub(sub(right,left),gap)=={}
# C_s' numerator = 3 j K and C_p' numerator = G K, positive for positive rates.
bs,bp,j,lam,e=[var(i) for i in range(5)]
G=add(add(bs,lam),scale(j,3))
D=add(add(mul(add(bs,lam),add(bp,j)),scale(mul(j,bp),3)),mul(G,e))
Ns=add(mul(lam,add(bp,j)),mul(add(lam,scale(j,3)),e))
Np=add(mul(lam,j),mul(G,e))
K=add(mul(G,bp),mul(j,bs))
for num,factor in [(Ns,scale(j,3)),(Np,G)]:
 assert sub(sub(mul(deriv(num,4),D),mul(num,deriv(D,4))),mul(factor,K))=={}
v62=read('v62.json');v75=read('v75.json');v77=read('v77.json');q=F(1,1000000)
assert F(v75['epsilon_upper'])<q/2 and binary(v62['one_plus_DK_range'][0])>0
assert binary(v77['cold_log_elasticity_hex'][1])<0 and F(v77['saha_over_h_squared_max'])<1
prev=F(v75['z'][0]);checked=0
for L,R in zip(v62['arms']['L']['records'],v62['arms']['R']['records']):
 a,b=map(binary,R['z']);assert a==prev and b<a and L['z']==R['z']
 for arm in [L,R]:
  assert arm['allowed_branches']==['SWIFT'] and q<binary(arm['whole_source'][0][0])<binary(arm['whole_source'][0][1])<1
  assert 0<binary(arm['whole_source'][1][0])<=binary(arm['whole_source'][1][1])<1
 checked+=1;prev=b
 if b<=750:break
assert checked==119
# Group identical weight boxes before summing exact cubic masses.
groups=defaultdict(lambda:F(0));previous=F(750);count=0
for row in read('v66.json')['source_segments']:
 a,b=map(F,row['z'])
 if a>=800 or b<=750:continue
 a,b=max(F(750),a),min(F(800),b)
 assert a==previous and a<b;previous=b
 lo,hi=map(F,row['dx_exact']);assert lo<=q/2 and hi>=q and row['origin']=='V62'
 w=tuple(map(F,row['K_over_H_exact']));assert 0<w[0]<=w[1]
 groups[w]+=(b-a)+(b*b-a*a)+(b*b*b-a*a*a)/3
 count+=1
assert count==101 and previous==800
lower=sum(lo*mass*q/2 for (lo,hi),mass in groups.items())
upper=sum(hi*mass*q for (lo,hi),mass in groups.items())
assert upper-lower<F(read('task96.json')['tolerances']['pilot_width_ceiling'])
print(json.dumps({'status':'PASS','symbolic_identities':3,'guard_rows':checked,'pilot_cells':count,'weight_groups':len(groups),
 'exact_unrounded_pilot':[str(lower),str(upper)],'independence':'Independent hex parser, sparse exact polynomial identities, weight-grouped integration of expanded cubic masses. Shared historical source and trajectory premises.'},indent=2))
