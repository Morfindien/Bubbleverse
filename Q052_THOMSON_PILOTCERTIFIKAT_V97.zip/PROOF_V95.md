# Q052 V95 · Fortegn på hele historien og optisk maksimumsted

## Dokumenteret resultat

For det fastholdte kildepar, samme baggrund B★ og de matchede starttilstande ved z = 810 er

\[
0<\Delta X_e(z)<10^{-6}\quad(0\le z<810),\qquad
\Delta X_e(810)=10^{-6}.
\]

V95 beviser den nye strenge nedre grænse på [0,z_B], hvor z_B = 787504997847845/140737488355328. Alle 373 V64-rækker fra 2963 til 3335 består. Sammenføjningen bruger V93's beviste E>0 og v_L−v_R≥0 ved z_B. Den øvre grænse og det unikke elektronmaksimum ved 810 er det arvede V83-resultat.

For den akkumulerede kilde-reelle Thomson-forskel

\[
F(Z)=\Delta\tau_T(0,Z)=\int_0^Z w(z)\Delta X_e(z)\,dz
\]

med den samme positive Thomson-vægt w følger

\[
F(0)=0,\quad F(Z)>0\ (Z>0),\qquad
\max_{0\le Z\le810}|F(Z)|=F(810).
\]

Maksimumstedet er entydigt. Maksimumværdien skal stadig evalueres med valideret integral- og fejlkontrol. Q052 forbliver ACTIVE / INCONCLUSIVE, fordi integralværdien og den fulde native/kilde-fejl fortsat står åbne.

## Fastlagt kilde og variable

Physics-commit er 5a131c91d657dd9a7c6364cc45b038710f8d0d97, og konfigurationen er hillipop-ede_n3. Venstre arm har q = 1/1000000 og højre arm q = 0. Alle øvrige baggrunds-, kilde- og startforudsætninger er de samme som i det hashverificerede V93-resultat. Der er ingen eksotisk energiinjektion, variation af fundamentalkonstanter eller ekstra mørk-sektor-temperaturled i den fastlagte konfiguration.

Sæt u = ln[811/(1+z)], h = h_R, E = h_L−h_R+q og t = v_L−v_R, hvor v = T_m/T_γ. u vokser mod lavere z. Fraktionerne og u er dimensionsløse. Elektronfraktionen angives pr. hydrogenkerne. H er i s⁻¹, n_H er i cm⁻³ i HyRec, T_γ er i K, og T_R = k_B T_γ er i eV. Den fælles baggrund giver

\[
T_\gamma=T_0(1+z),\qquad n_H=10^{-6}n_{H0,\mathrm{SI}}(1+z)^3.
\]

Kildekopier og konstanter er bevaret i v19.json og hashkontrolleret mod V64's source_pins. De relevante primære kildefiler ved den fastlåste revision er følgende.

- [HyRec hydrogen.c](https://github.com/mwt5345/class_ede/blob/5a131c91d657dd9a7c6364cc45b038710f8d0d97/external/HyRec2020/hydrogen.c), alphaB_PPB og rec_TLA_dxHIIdlna, linje 68–107.
- [HyRec hydrogen.h](https://github.com/mwt5345/class_ede/blob/5a131c91d657dd9a7c6364cc45b038710f8d0d97/external/HyRec2020/hydrogen.h), EI, kBoltz og TR_MIN.
- [wrap_hyrec.c](https://github.com/mwt5345/class_ede/blob/5a131c91d657dd9a7c6364cc45b038710f8d0d97/external/HyRec2020/wrap_hyrec.c), den fælles Peebles-vælger og enhedskonverteringen.
- [thermodynamics.c](https://github.com/mwt5345/class_ede/blob/5a131c91d657dd9a7c6364cc45b038710f8d0d97/source/thermodynamics.c), n_H-skaleringen, temperaturfeltet og thermodynamics_reionization_function.

Kildeteksterne er indlejrede, tidligere hentede primærkilder, som er genlæst i V95. De numeriske banebokse og tidligere fortegnsresultater er AI-assisterede interne certifikater under deres dokumenterede præmisser. V95's konklusion har samme betingede kilde-reelle domæne.

## Hele halen bruger fælles Peebles og CAMB

V94's opgave og V93's slutbokse matcher begge armes startbokse ved række 2963. De følgende tilstandsbokse er sammenhængende gennem række 3335 med slutpunkt præcis z = 0. Rækkenumrene er nulbaserede positioner i arkivet. V64's oprindelige index er tre mindre, fordi tidligere hændelsesgrænser har opdelt originalceller.

På hele halen er T_R<0,002 eV<TR_MIN, så Peebles vælges i begge arme uanset temperaturforholdets placering relativt til 0,1. Hele halen ligger under det faste reionisationsstartpunkt 753585/65536 og bruger samme CAMB-kort, også i slutpunkterne.

Skriv s_H=(1+tanh A_H)/2 og s_He=(1+tanh A_He)/2. Kilden giver

\[
M_z(X)=(1-s_H)X+s_H(1+f_{He})+s_{He}f_{He}
       =\lambda X+b.
\]

De fastlagte bredder er positive, og argumenterne er endelige. Derfor er b≥0 og λ>0. Den numeriske arkivkontrol verificerer samme λ-boks for begge arme i alle helceller og endepunkter, med

\[
\lambda\ge\frac{6936925106346909}{19342813113834066795298816}
>3,58\times10^{-10}.
\]

Den offentlige forskel er ΔX_e=λE. Hydrogenfeltet anvender X_L=h_L+q og X_R=h_R. Temperaturfeltet anvender den fælles reioniserede fraktion M_z(X).

De nye helceller opfylder de konservative ydre grænser

\[
10^{-5}<h_L,h_R<0,002,\qquad 0,001<v_L,v_R<0,5.
\]

Begge kontrolprogrammer kontrollerer også, at de relevante start- og slutbokse er indeholdt i helcelle-/gruppeboksene. Det sikrer dækning ved grænsen z = 0.

## To forskellige Saha-kontroller

Peebles-feltet bruger

\[
S=\mathcal S\frac{T_R^{3/2}}{n_H}\exp(-E_I/T_R),
\]

hvor \(\mathcal S>0\) er SAHA_FACT ved de fastholdte konstanter. Målet er S<h_R² i hver celle, så højre arms netto-rekombinationsled er positivt.

Primærkontrollen bruger V83's allerede indhyllende PPB-ratio og dens dokumenterede minimale hydrogengulv til at rekonstruere et øvre loft for S ved z_B. Med s=1+z følger

\[
\frac{d\log S}{d\log s}=-\frac32+\frac{E_I}{T_R}.
\]

De kildekonstanter, som omslutter både decimal- og binary64-repræsentationen, giver en nedre grænse større end 8776 for denne logafledte på hele [0,z_B]. S vokser dermed med z, og V83-loftet ved z_B dækker også den nye hale. Division med hver celles faktiske nedre V64-grænse for h_R giver

\[
\max_j\frac{S_{\rm upper}}{h_{R,j,\rm lower}^2}
<10^{-291}.
\]

Den separate kontrol bruger en direkte grov grænse uden V83's ratecertifikat. De kontrollerede konstanter giver T_0<3 K, 1+z<7, k_B<9×10⁻⁵ eV/K, E_I>13 eV, n_H>10⁻⁷ cm⁻³ og \(\mathcal S<4\times10^{21}\). Derfor er T_R<1/500 eV og E_I/T_R>6500>1000. Fordi e>2,

\[
\exp(-E_I/T_R)<2^{-1000},\qquad
S<4\times10^{28}\,2^{-1000}.
\]

Sammen med h_R>10⁻⁵ fås den særskilte grænse

\[
S/h_R^2<4\times10^{38}\,2^{-1000}<10^{-260}<1.
\]

Begge beregninger bruger eksakte brøker. Den anden undgår evaluering af meget små eksponentialfunktioner og afprøver et andet matematisk grundlag for den afgørende Saha-ulighed.

## PPB-rate og temperaturorden

Den positive PPB-rate har formen

\[
\alpha_B(T_m)=c_0\frac{t_4^{-a}}{1+c t_4^b},\quad
t_4=T_m/(10000\,\mathrm K),\quad a,b,c,c_0>0.
\]

Den eksakte kildeform har a=0,6166, b=0,5300 og c=0,6703 med de dokumenterede talrepræsentationer. Dens loghældning i v er

\[
\frac{\partial\log\alpha_B}{\partial\log v}
=-a-\frac{bY}{1+Y}<0,\qquad Y=c t_4^b>0.
\]

Kontrollen får også |∂logα/∂logv|<587/700<1 på det relevante domæne. Kun det negative fortegn er nødvendigt for den nye nedre flade.

Temperaturfeltet er v′=−v+A(M_z(X))(1−v), hvor A(x)=kx/(1+f_He+x), k>0. Indtil en mulig første kontakt med E=0 har vi M_z(X_L)≥M_z(X_R) og A_L≥A_R. Subtraktion giver

\[
t'=-(1+A_L)t+(A_L-A_R)(1-v_R).
\]

V93 giver t≥0 ved z_B. Variationen-af-konstanten-formlen og v_R≤1 bevarer t≥0 indtil kontakten. Derfor er α_L≤α_R, mens α_R≥α(1).

## Det positive randfelt

På E=0 er h_L=h−q og X_L=X_R=h. Sæt γ=α(1)S og

\[
U_R=\alpha_R h^2-\gamma(1-h),\qquad
U_L=\alpha_L(h-q)h-\gamma(1-h+q).
\]

Saha-kontrollen giver U_R>0. Da h>q er κ=1−q/h mellem nul og én, og

\[
U_L\le\kappa U_R-\gamma q/h\le\kappa U_R.
\]

Peebles-faktoren er C(e)=(3e+Λ)/(3e+Λ+B_β), hvor B_β>0 er kildens four_betaB. Dens afledte er 3B_β/(3e+Λ+B_β)²>0. Escape-raten e er proportional med H/[n_H(1−h)] og vokser med h. Dermed er C_L≤C_R på kontaktfladen. Når U_L≥0 følger C_LU_L≤κC_RU_R ved multiplikation. Når U_L<0 gælder samme ulighed direkte, fordi højresiden er positiv.

Med f=−(n_H/H)CU og det fælles positive n_H/H fås

\[
E'=f_L-f_R\ge(q/h)|f_R|>0\quad\text{på }E=0.
\]

Dette udelukker første kontakt fra E>0 ved integration i et indre nabointerval. Tilstanden er kontinuert gennem alle cellegrænser. Samme feltargument gælder helt til slutpunktet z = 0. Den strenge offentlige positivitet følger af λ>0.

Primærprogrammets mindste normaliserede margin er

\[
\frac{72057594037927936}{93921034555706796875}.
\]

Kontrollen bruger ydre h-bokse i 12 grupper og giver

\[
\frac{36028797018963968}{46960517592206859375}.
\]

Begge er større end 0,00076721. Disse tal er nedre grænser for E′/|f_R| på kontaktfladen. En numerisk minimumsamplitude for ΔX_e på banen er fortsat uberegnet.

## Global optisk konsekvens

Det accepterede V93-bevis dækker [z_B,810], og V95 dækker [0,z_B]. Den fælles positive vægt w og den stykkevis kontinuerte, strengt positive ΔX_e giver F(Z₂)−F(Z₁)>0 for alle 0≤Z₁<Z₂≤810. Ved tidligere kildekonventioners kortskift gælder dette gennem integralet, som er kontinuert. F(0)=0 fastlægger fortegnet for hele den akkumulerede forskel.

Derfor er F strengt voksende, og |F| opnår sit unikke globale maksimum ved Z=810. Påstanden vedrører præcis det akkumuleringsinterval og det kildepar, der er defineret ovenfor. Det realiserede tal F(810) og sammenligningen med native CLASS-output kræver en særskilt valideret beregning.

## Kontrol, reproduktion og aflevering

certify95.py kontrollerer alle 373 celler og bruger det arvede Saha-loft med en ny monotonicitetsudledning. control95.py bruger en særskilt parser for hexadecimale intervalendepunkter, 12 ydre gruppebokse og den direkte eksponentialgrænse. Kontrollen læser hverken V95's primæroutput eller V83's ratecertifikat. Begge spor deler de fastlåste kilder, de arvede V64-banebokse og V93's positive indgang. De deler også det analytiske første-kontakt-argument.

Begge programmer er genkørt fra en frisk mappe med nøjagtigt samme outputbytes som de afleverede resultater. verification.json indeholder kommandoidentitet, runtime, exit-status og outputhashes. De nye checks kræver kun Python-standardbiblioteket. Der er udført nul nye native simulationspar og nul nye fuldhistorieintegrationer.

V94-opgavens slutbetingelse er opfyldt ved z=0. Resultatindtag og routing 2.3.0 skal indtage det globale fortegn og det optiske maksimumsted én gang, videreføre den fulde journal og afgrænse en valideret evaluering af F(810). Den skal samtidig bevare Q052's åbne krav om native/kilde-fejl og den tidligere absolutte elektrongrænse.
