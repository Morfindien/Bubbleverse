# V77 · Elektronmaksimum fra rødforskydning 810 til 50

**Resultat.** For det fælles, fastholdte B★ og det matchede startpar giver kildeligningerne
$$
\max_{50\le z\le810}|\Delta X_e(z)|=10^{-6}.
$$
Lighed indtræffer alene ved 810. V75 viste det på de første to celler. Her bevises en streng grænse på resten af fase 5. Alle konklusioner arver de angivne Q048-, V62- og V73-kildeforudsætninger. Det numeriske output fra CLASS og de to modelbaner er forskellige sammenligningsobjekter.

## Variabler og start

Brug tiden u = ln[811/(1+z)], q=10⁻⁶ og h=h_R. Sæt d=h_L−h, X_R=h, X_L=h_L+q, E=X_L−h=d+q, og t=v_L−v_R. Elektronfraktionen er per hydrogenkerne. Fase 5 ligger før aktivering af den frosne reionisationsmap. V62's 1.526 sammenhængende celler per arm dækker hele intervallet fra V75's slutknude til 50. På alle celler er h>2q og 0,1<v<1. Begge arme deler strålingstemperatur, baggrund og heliumkonstanter.

Indfør y=(h+q)t/(q v_L). Det område, som skal bevares, er −2q≤d≤0 og |y|≤B med B=0,99. Så er |E|≤q. V75's eksakte slutboks giver −q<E<q. Den oprindelige usikkerhed på t bæres med begge fortegn og giver |y|<0,001762 ved starten.

## De to temperaturgrænser

Skriv a=1+fHe, A(X)=k X/(a+X) med fælles k>0 ved hver tid. Fra g(X,v)=−v+A(X)(1−v) følger ved direkte differentiation

    y′ = [f_R/(h+q) − A(X_L)/v_L]y + [A(X_L)/v_L] J
    J  = (h+q) a (E/q)(1−v_R) / [X_L(a+h)].

På det foreslåede område er X_L≥h−q. Dermed er |J|≤[(h+q)/(h−q)](1−v_R)≤0,981841<B. Dette er kontrolleret i alle 1.526 højre tilstandsbokse. Nedenfor vises f_R<0. Derfor peger begge temperaturgrænser strengt indad, også når hydrogenfeltet skifter gren.

## Den temperaturafhængige atomrate

Ved fastholdt z er α_i(v) den effektive rekombinationsrate til niveau i. De stykvist kubiske logtabeller i den fastholdte HyRec-kilde giver −1 < ∂log α_i / ∂log v < 0 på hver nødvendig v-strimmel helt op til 1. Den første kontrol bruger udadrettet MPFR og 24 grupper af arkiverede helcellebokse. Den giver intervallet [−0,91294,−0,49323]. Den anden kontrol omskriver selve Lagrange-basis til Bernstein-kontrolpunkter med rationelle vægte. Dens 93.248 kontrolpunkter dækker 1.457 hele tabelstykker for begge niveauer og de to ender af konstantens interval. Begge metoder inkluderer endestencils. Polynomierne mødes kontinuert ved knuderne, så integration i log v giver raternes endelige forhold på tværs af knuderne.

Sæt S til det lokale Saha-led, så U_i=α_i(v)h_arm X_arm−α_i(1)S(1−h_arm), og f_arm=−(n_H/H_s)Σ C_i U_i. For højre arm er S/h²<9,154×10⁻⁷ på de kontrollerede grupper. Da α_i(v_R)≥α_i(1), er U_R,i>0 og f_R<0.

Sæt x=q/(h+q). Hvis v_L≥v_R, ligger α_L/α_R mellem v_R/v_L og 1. Hvis v_L≤v_R, ligger det mellem 1 og v_R/v_L. Dette følger for hvert niveau af den verificerede loghældning. Da v_R/v_L=1−xy, fås 1−Bx≤α_L/α_R≤1+Bx.

## De to hydrogengrænser

På d=0 er h_L=h og X_L=h+q. Da (h+q)(1−Bx)>h, er U_L,i>U_R,i. På samme gren er de to C-faktorer identiske ved denne flade. Følgelig er d′<0.

På d=−2q er h_L=h−2q og X_L=h−q. Uligheden (h−q)(1+Bx)<h giver U_L,i≤(1−2q/h)U_R,i, hvor fotoionisationsleddet på venstre side også hjælper. På samme gren vokser C_i med den effektive escape-rate og dermed med h. C_L,i≤C_R,i medfører d′>0. Hvis U_L,i er negativt, er denne kanals indadrettede fortegn allerede sikret.

## Muligt skift mellem SWIFT og HMLA

Der er 234 hele rækker med alene SWIFT, 1.281 med alene HMLA og 11 med mulighed for begge. I de 11 rækker ligger T over fitgrænsen, og Pion falder med h ved fastholdt baggrund og temperatur. Så længe h_L≤h_R, er den eneste mulige blandede kombination SWIFT i L og HMLA i R. Ved fælles h kan ensidige grænser fra denne kombination forekomme. På de 11 rækker viser fitinterpolationen −1<DK<0. Dermed er den korrigerede escape-rate E_s=e/(1+DK) større end HMLA-raten e. På den øvre flade understøtter det d′<0, fordi begge U_R,i er positive.

Til den nedre flade sammenlignes først C_SWIFT(h_R) med C_HMLA(h_R). Skriv j for 2p→2s-raten, λ for tofotonraten, G=β_s+λ+3j, K=Gβ_p+jβ_s og D(e)=(β_s+λ)(β_p+j)+3jβ_p+Ge. De to tællere er N_s(e)=λ(β_p+j)+(λ+3j)e og N_p(e)=λj+Ge. Direkte subtraktion af C_i=N_i/D giver

    C_i(E_s)/C_i(e) − 1 = (E_s−e) η_i K / [D(E_s) N_i(e)]
    η_s=3j,   η_p=G.

Samme identitet for to positive escape-rater viser monotonien brugt ovenfor. Den udadrettede relative forøgelse er mindre end 2q/h på alle 11 rækker. Største forhold mellem det beviste springloft og den tilladte margen er under 0,694. Derfor er (C_SWIFT/C_HMLA)(1−2q/h)<1. Ved h_L=h−2q gælder også C_SWIFT(h_L)≤C_SWIFT(h). Dette giver d′>0 for den blandede gren.

## Første kontakt og maksimum

Tilstandene er kontinuerte og absolut kontinuerte stykkevis i fremadrettet u under de arvede kildeforudsætninger. Ved en første kontakt med en af de fire flader peger samtlige tilladte ensidige grenfelter fra indersiden strengt indad. Der er endeligt mange lokale grene og kontinuerte tabelstykker. Fortegnet holder derfor i et indre nabolag af kontaktpunktet for de grene, der kan nærme sig det. Integration over det sidste korte tidsinterval modsiger første kontakt. Dette gælder også ved sammenfald af en flade og en grænse mellem to celler. Bokse er kun domæner til kontrol af ulighederne.

Indeslutningen holder dermed strengt til og med 50. V75 leverer lighed ved 810 og streng ulighed derfra til V77's start. Tilsammen afgør det maksimum og maksimumsted på [50,810]. Ved 50 følger den korrelerede startbetingelse til næste fase direkte af de to bevarede uligheder. De faktiske fortegn på E gennem hele intervallet og det fulde maksimum under 50 er stadig åbne.
