# V97-certifikat

Kør python3 certify97.py og python3 control97.py i den udpakkede mappe. Sammenlign med result.json og control.json. De to scripts bruger alene Python-standardbiblioteket og de vedlagte, hashbundne inputfiler.

PROOF_V97.md indeholder den analytiske barriere og dens præmisser. verification.json dokumenterer genkørsel i en frisk mappe. return_task.json er overdragelsen til Resultatindtag og routing 2.3.0. activity_ledger.json bevarer tidligere poster og tilføjer én ny hændelse.

Manifestet har SHA-256 for alle arkivmedlemmer undtagen sig selv. Rodfilernes hashes står separat. De historiske inputmanifester og GitHub-blobs dokumenterer proveniens. Den fulde samlede journal leveres som selvstændig Markdown-fil. Uploadvejledningen er journalens sidste menneskeligt læsbare afsnit.
