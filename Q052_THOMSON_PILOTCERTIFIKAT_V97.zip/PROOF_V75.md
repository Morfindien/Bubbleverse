# Q052 V75 · Det lokale elektronmaksimum

## Resultat

På det faste B★, med det fælles startpunkt fra V40 og de kildepræmisser, som V73 og V74 har antaget, er det lokale maksimum af |ΔXₑ,kilde| **præcis 10⁻⁶ ved z = 810**. Det er det eneste maksimumsted på de to undersøgte celler. Den lagrede spline når sit maksimum længere nede i rødforskydning. På det sted ligger dens parforskel bevisligt over kildeparrets.

| Størrelse | Certificeret resultat på strimlen |
| --- | --- |
| Område i z | Fra 1779416633043845/2199023255552 (ca. 809,185) til 810 |
| Største absolutte ændring fra kildeparrets begyndelsesværdi | Mellem 6,3322 × 10⁻⁹ og 9,9376 × 10⁻⁹. En særskilt kontrol sænker loftet til 9,9126 × 10⁻⁹. |
| Maksimal punktvis bredde af den z-afhængige indeslutning | Under 3,6054 × 10⁻⁹ |
| Kildeparrets forskel ved den lagrede top, z ≈ 809,4943918357898 | [9,93837 × 10⁻⁷, 9,96072 × 10⁻⁷] |
| Lagret minus kilde ved samme top | **[1,11133 × 10⁻⁷, 1,13368 × 10⁻⁷]** |
| Største absolutte fejl i den lagrede parforskel på strimlen | **ca. 6,613651432385767 × 10⁻⁷** ved z = 810. Den eksakte brøk står i result.json. |

I den sidste række er decimalen en tilnærmelse. Alle tosidede intervaller i tabellen er rundet udad. Enheden er elektroner pr. hydrogenkerne i en dimensionsløs fraktion. En parforskel er hele vejen L(q=10⁻⁶) minus R(q=0). Fejlens fortegn er værdien af den lagrede parforskel minus værdien af kildeparforskellen ved samme z.

## Fælles start og gyldigt kildefelt

Sæt q = 10⁻⁶, u = ln[811/(1+z)], d = h_L − h_R og t = v_L − v_R. Her er h den ioniserede hydrogenfraktion og v forholdet mellem stof- og strålingstemperatur. Begge baner starter med samme h og v ved u=0. På strimlen er ΔXₑ = q+d. Den frosne reionisationsmap har start ved 753585/65536, og begge celler ligger i fase 5.

V22/V24 placerer begge baner i deres fulde Hermite-indeslutninger. Deres kontrolpunkter og certifikatradier giver 0,00395 ≤ h ≤ 0,00407 og 0,9987 ≤ v ≤ 0,9999. Den fælles rektangel indeholder også hvert linjestykke mellem banernes tilstande ved samme tid. V52 og V54 har 64 sammenhængende paneler i hver celle og viderefører parfejlen gennem knuden. Samme tilladte H(z) optræder i begge arme. Q050's baggrundscelle fra 810 til 800 omfatter begge termiske celler.

Kildens SWIFT-selector opfylder 0,2026 < Pion < 0,2310 på hele rektanglet, over omslagstærsklen 0,01. Temperaturforholdet ligger inde i den kolde gren. Den atomare rateinterpolation bruger udelukkende stencil (83,37), inklusive kildekodens klemning ved tabellens kant. Strålingstemperaturen ligger mellem 2208,15 og 2210,39 K. Hele intervallet ligger inden for samme SWIFT-fitstykke mellem 2205 og 2215 K, indeks 43. Det frosne fit benytter den verificerede V62-indeslutning for 1+DK på hele det nødvendige temperaturdomæne. Ved V52/V54-knuden er tilstanden kontinuert. Ingen af de undersøgte selectors krydser en grænse på strimlen. Disse kontroller gælder hele bokse.

## Fortegn og størrelse af den direkte q-afledte

Middelværdiformlen langs det fælles tilstands- og parametersegment giver d′ = f̄_h d + f̄_v t + f̄_q q, hvor prim betegner d/du. Den tilsvarende temperaturforskel opfylder t′ = ḡ_h(d+q) + ḡ_v t. Den positive heliumforskel kommer dermed kun én gang ind i elektronparrets definition. V52/V54 leverer |f_h| ≤ 25,4, |f_v| ≤ 0,057 og |t| ≤ 4,36 × 10⁻⁷, også gennem sammenføjningen. De oprindelige tilstands- og koefficientkvitteringer er vedlagt.

Ved fastholdt h, v og z er kun leddet h(h+q) i hydrogenfeltet direkte q-afhængigt. Sæt N = n_H/H_s og skriv s,p for de to atomare niveauer. Så er −f_q = hN(α_s C_s + α_p C_p). I HyRec-kilden er j den positive 2p→2s-rate, β_s,β_p fotoionisationsraterne, λ to-fotonraten og e den korrigerede Lyman-α-escape-rate. Med G_s = β_s+λ+3j fås ved at gange kildens to brøker op

    D = (β_s+λ)(β_p+j) + 3j β_p + G_s e
    C_s = 1 − [β_s(β_p+j+e) + 3j β_p]/D
    C_p = 1 − [G_s β_p + j β_s]/D.

Nævneren er positiv. Beregningen indeslutter e = LYA_FACT·H_s/[n_H(1−h)(1+DK)] med samme H-delinterval som N. Otte z-intervaller og seksten sammenhængende H-intervaller dækker hele den tilladte boks. Den eksisterende MPFR-backend anvender nedad- og opadrettet afrunding til de positive tabelrater. Alle 128 rateindeslutninger ligger i 6,58 ≤ −f_q ≤ 9,60. Dermed gælder grænserne også for segmentgennemsnittet.

## Første kontakt og z-afhængig indeslutning

Prøv |d| ≤ 10⁻⁸. På prøverøret har feedbacken |f̄_h d + f̄_v t| højst 25,4·10⁻⁸ + 0,057·4,36·10⁻⁷. Sæt a = 9,878852 × 10⁻⁶ og b = 6,301148 × 10⁻⁶. Så gælder −a ≤ d′ ≤ −b < 0. For x = 810−z fås x/811 ≤ u ≤ x/(1+z) ved at integrere 1/(1+z). Selv ved den nedre intervalgrænse er a·x/(1+z) < 9,9376 × 10⁻⁹ < 10⁻⁸. Da d(0)=0, kan en første kontakt med prøverørets rand derfor ikke forekomme. Denne slutning bruger ingen antagelse om fortegnet af d undervejs.

Hele vejen gælder

    q − a(810−z)/(1+z) ≤ ΔXₑ,kilde(z) ≤ q − b(810−z)/811.

Den nedre grænse er positiv. Parforskellen falder strengt med u. Dermed findes det entydige maksimum ved startpunktet. Både V74's absolutte mål 10⁻⁸ og dens alternative punktvise breddemål 2 × 10⁻⁸ er opfyldt.

## Fejlen på den lagrede spline

S(z) betegner den lagrede parforskel. Fra V71 genbruges de positive værdier ved den isolerede top, topcellens kubiske polynomium og det korte øverste splineinterval. Grænserne for kilden og S evalueres ved den samme isolerede toplokation. For den ukendte rod bruges begge ender af dens redshiftinterval med monotone z-grænser. Dette giver det positive fejlinterval i tabellen.

V71's øverste celle har sin mindste værdi ved 810. Alle fire Bernstein-kontrolpunkter i nabocellen ligger strengt over S(810), så S(z) ≥ S(810) på hele strimlen. Sammen med ΔXₑ,kilde ≤ q giver dette S−ΔXₑ,kilde ≥ S(810)−q, med lighed ved 810. Den positive side har S−ΔXₑ,kilde < 1,17143 × 10⁻⁷, ved V71's øvre splinegrænse og V75's nedre kildegrænse. Det er mindre end q−S(810). Absolutfejlens maksimum er derfor præcis q−S(810), og den strenge ændring af kildekurven sikrer entydighed. Ved 810 er fejlen negativ, fordi S(810) ≈ 3,38634856761 × 10⁻⁷.

## Kontrol og rækkevidde

En separat kontrol bruger de to positive, direkte C-brøker. Ved fastholdte øvrige variable er hver vægtet sum af de to brøker lineær-brøkformet i hver af β_s, β_p, j, λ og e. Den fælles nævner er positiv, og numeratoren og nævneren er multiaffine efter bortfald af 3j². Ekstremerne over en rektangel kan derfor indhegnes ved hjørnerne. Kontrollen evaluerer 4.096 hjørner i eksakt rationel aritmetik. Den anvender også den integrerede ulighed M ≤ U(25,4M + 0,057·4,36·10⁻⁷ + q max(−f_q)), hvor M er supremum af |d| og U er øvre grænse for tiden på strimlen. Løsning for M giver M < 9,9126 × 10⁻⁹. Kontrollen deler atomtabeller, udadrettede atomare rateinput og historiske certifikater med hovedberegningen.

V75 bestemmer kilde- og fejlmaksimum for elektronparret på denne strimmel. De tidligere certificerede maksimummer for de lagrede kurver på [0,810] består. V75 fastlægger hverken kildeparrets globale elektronmaksimum eller det globale maksimum for den akkumulerede Thomson-dybde. De kræver yderligere kontrol af det øvrige interval og af den signerede integrerede forskel. Den videnskabelige status for hele Q052 er fortsat åben.
