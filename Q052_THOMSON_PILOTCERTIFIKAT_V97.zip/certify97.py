"""Validate the half-q barrier premises and integrate the bounded pilot exactly."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,time
P=Path(__file__).resolve().parent
Q=F(1,10**6)
SCALE=2**100
def read(n):return json.loads((P/n).read_bytes())
def hx(s):return F(float.fromhex(s))
def main():
 start=time.monotonic()
 for n,h in read('pins.json').items():assert hashlib.sha256((P/n).read_bytes()).hexdigest()==h
 task=read('task96.json');v62=read('v62.json');v75=read('v75.json');v77=read('v77.json');v95=read('v95.json')
 assert task['current_q']==task['target_q']=='Q052'
 assert v95['combined_positive_z']==['0','810'] and v95['status']=='ALL_373_PASS'
 assert read('v83.json')['global_sup_abs_Delta_Xe']==str(Q)
 assert v77['status']=='PASS_UNDER_FROZEN_PREMISES' and F(v77['saha_over_h_squared_max'])<1
 assert -1<hx(v77['cold_log_elasticity_hex'][0])<=hx(v77['cold_log_elasticity_hex'][1])<0
 assert v62['case_id']==task['case_id'] and v62['conditional']
 assert hx(v62['one_plus_DK_range'][0])>0
 cfg=read('q048_prefix_config_v1.json')['cases']['hillipop-ede_n3']
 assert cfg['background']['thermal_flags']=={'has_varconst':0,'has_exotic_injection':0,'has_idm_b':0,'has_idm_g':0,'has_idm_dr':0,'recombination':1}
 assert F(cfg['frozen_reionization']['fixed_reio_start_exact'])<750
 epsilon=F(v75['epsilon_upper']);assert 0<epsilon<Q/2
 previous=F(v75['z'][0]);seed_rows=[];pilot_rows=[]
 assert previous>800
 for i,(L,R) in enumerate(zip(v62['arms']['L']['records'],v62['arms']['R']['records'])):
  za,zb=map(hx,R['z'])
  assert L['z']==R['z'] and za==previous and zb<za
  assert L['H_per_s']==R['H_per_s'] and hx(R['H_per_s'][0])>0
  for arm in [L,R]:
   assert arm['allowed_branches']==['SWIFT']
   h0,h1=map(hx,arm['whole_source'][0]);v0,v1=map(hx,arm['whole_source'][1])
   assert Q<h0<h1<1 and 0<v0<=v1<1
  rec={'row':i,'z':list(map(str,[za,max(zb,F(750))]))}
  if za>800:seed_rows.append(rec)
  if zb<800:pilot_rows.append(rec)
  previous=zb
  if zb<=750:break
 assert previous<=750 and len(pilot_rows)==101
 # V75 supplies d > -epsilon at the V62 entry. The same-branch first-contact
 # inequality keeps d > -q/2. V95 supplies E>0 and hence t>=0.
 cells=read('v66.json')['source_segments'];selected=[];lower=upper=F(0);rounded_low=rounded_high=F(0)
 state_width=weight_width=F(0)
 for i in range(task['source_data']['V66_rows_zero_based_inclusive'][0],task['source_data']['V66_rows_zero_based_inclusive'][1]+1):
  r=cells[i];a,b=map(F,r['z']);a=max(a,F(750));b=min(b,F(800))
  assert a<b and r['origin']=='V62'
  if selected:assert a==F(selected[-1]['z'][1])
  matches=[j for j in pilot_rows if hx(v62['arms']['R']['records'][j['row']]['z'][1])<=a<b<=hx(v62['arms']['R']['records'][j['row']]['z'][0])]
  assert len(matches)==1
  xlo,xhi=map(F,r['dx_exact']);elo,ehi=max(xlo,Q/2),min(xhi,Q)
  assert elo<=ehi and elo==Q/2 and ehi==Q
  wlo,whi=map(F,r['K_over_H_exact']);assert 0<wlo<=whi
  mass=((1+b)**3-(1+a)**3)/3
  l,u=elo*wlo*mass,ehi*whi*mass
  lower+=l;upper+=u
  dl=F((l*SCALE).__floor__(),SCALE);du=F((u*SCALE).__ceil__(),SCALE)
  rounded_low+=dl;rounded_high+=du
  # Exact symmetric product-width identity, before outward rounding.
  state_width+=(wlo+whi)/2*(ehi-elo)*mass
  weight_width+=(elo+ehi)/2*(whi-wlo)*mass
  selected.append({'V66_row':i,'V62_row':matches[0]['row'],'z':list(map(str,[a,b])),
    'electron_interval':list(map(str,[elo,ehi])),'weight_factor':list(map(str,[wlo,whi])),
    'increment':list(map(str,[dl,du]))})
 assert len(selected)==101 and selected[0]['z'][0]=='750' and selected[-1]['z'][1]=='800'
 oldlo,oldhi=map(F,task['tolerances']['prior_pilot_interval'])
 assert rounded_high==oldhi
 assert state_width+weight_width==upper-lower
 rounding=(rounded_high-rounded_low)-(upper-lower);assert 0<=rounding<F(2*len(selected),SCALE)
 width=rounded_high-rounded_low;assert width<=F(task['tolerances']['pilot_width_ceiling'])
 oldfull=list(map(F,task['tolerances']['prior_full_interval']))
 full=[oldfull[0]-oldlo+rounded_low,oldfull[1]-oldhi+rounded_high]
 assert full[0]>oldfull[0] and full[1]==oldfull[1]
 assert time.monotonic()-start<task['execution_limits']['first_prototype_wall_seconds']
 return {'schema':'Q052_V97_HALF_Q_SWIFT_OPTICAL_PILOT','status':'PASS_PILOT_UNDER_INHERITED_PREMISES',
 'domain':['750','800'],'source_commit':task['source_commit'],'source_electron_interval':[str(Q/2),str(Q)],
 'barrier':'d > -q/2; strict interior on [750,800]','entry_epsilon_upper':str(epsilon),
 'seed_premise_rows':seed_rows,'pilot_V62_rows':[r['row'] for r in pilot_rows],
 'auxiliary_barrier_domain':['750',v75['z'][0]],'auxiliary_scope':'Only required to transport the accepted V75 seed to and through the pilot. Integral update restricted to [750,800].',
 'pilot_interval':list(map(str,[rounded_low,rounded_high])),'pilot_width':str(width),
 'width_reduction_fraction':str(1-width/(oldhi-oldlo)),
 'new_global_interval':list(map(str,full)),'global_width':str(full[1]-full[0]),
 'global_width_goal_met':full[1]-full[0]<=F(task['tolerances']['absolute_source_full_width_goal']),
 'width_accounting':{'incoming_and_flow_enclosure':str(state_width),'weight_factor_enclosure':str(weight_width),
 'outward_rounding':str(rounding),'quadrature_remainder':'0','branch_uncertainty':'0 within certified SWIFT cells',
 'note':'The analytical incoming-state and flow bound jointly supplies E in [q/2,q]. State and weight contributions use the exact symmetric product-width identity. No numerical ODE truncation error is introduced.'},
 'native_comparison':{'status':'OPEN','local_same_z_native_residual':'NOT_CERTIFIED',
 'reason':'Native background membership and source/returned-coordinate alignment remain inherited open premises. V71 stored-primitive and rounding certificates retain their original scopes.',
 'V71_global_signed_error':read('v71_tau.json')['signed_error'],'V71_returned_minus_ideal_cut':read('v71_tau.json')['returned_minus_ideal']},
 'new_native_pairs':0,'new_full_history_integrations':0,'cells':selected}
if __name__=='__main__':print(json.dumps(main(),indent=2))
