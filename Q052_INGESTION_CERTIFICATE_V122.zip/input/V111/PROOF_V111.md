# Q052 V111 · Halv-q-bro frem til den første blandede celle

## Domæne og konklusion

Sæt z_b=1523417340748759/2199023255552≈692,77 og q=10^-6. Under den samme fastholdte hillipop-ede_n3-kilde, fælles tilladte baggrund B★ og matchede z810-start bekræftes

q/2 < ΔX_e(z) < q for z_b ≤ z ≤ 700.

Sammen med de arvede V107/V97-resultater gælder den samme strenge grænse på [z_b,800]. Det nye arbejde dækker V62-rækker 219–233, hvor række 219 afskæres ved 700. De 15 optiske delceller matcher V66-rækker 4628–4642. Der startes ingen nye dynamiske baner ved cellegrænserne.

V62-række 234, historisk celle 235, tillader HMLA og SWIFT i begge arme. Dens øvre grænse er z_b og dens nedre grænse er 761161663339561/1099511627776≈692,2725. Dette dokumenterer en grænse for det anvendte SWIFT-bevis. Arkivets grenindhylling bestemmer endnu ikke det præcise fysiske skift.

## Arvet argument og nye præmiskontroller

Med u=ln[811/(1+z)], d=h_L−h_R, E=d+q og t=v_L−v_R giver den fælles temperaturdynamik t'=−(1+A_L)t+(A_L−A_R)(1−v_R). V95's positive E, den stigende kobling A og den matchede start giver t≥0. V77's negative kolde ratehældninger giver α_L,i≤α_R,i. Det arvede Saha-loft sikrer U_R,i>0.

SWIFT-feltet har formen f_arm=−(n_H/H_s)Σ_i C_arm,i U_arm,i, med U_arm,i=α_arm,i h_arm X_arm−β_i(1−h_arm) og β_i=α_i(1)S≥0. På d=−q/2 er h_L=h_R−q/2 og X_L=h_R+q/2. Derfor

U_R,i−U_L,i=α_R,i q²/4+β_i q/2+(α_R,i−α_L,i)(h_R²−q²/4)>0.

V97's positive C-faktorer vokser med h på den fælles SWIFT-gren. Derved C_L,i≤C_R,i, og C_R,i U_R,i−C_L,i U_L,i>0 både for U_L,i≥0 og U_L,i<0. Det giver d'>0 på kontaktfladen. Den strenge z700-start fra V107 kan derfor ikke få en første kontakt med d=−q/2 på den nye sammenhængende strimmel. Kontinuiteten og det indadrettede venstresidige felt medtager den nedre grænse. V83 leverer den arvede øvre grænse E<q.

De nye kontroller efterviser i begge arme eksklusiv SWIFT, q<h<1, 0<v<1, identisk positiv H-indhylling, tilstandsforbindelser mellem cellerne og sammenfald mellem kilde- og optiske koordinater. De kontrollerer også, at V77's certificerede domæne dækker strimlen, at 1+DK er positiv, at reionisationen starter under z_b, samt at konfigurationens thermal_flags og den fælles baggrundsidentitet matcher opgaven. V97's symbolske identiteter og de tidligere ratecertifikater genbruges som arvede præmisser. De eksakte minimumsmarginer fremgår af calc/barrier111.json.

## Optisk nedre bidrag og enheder

Den fastlåste størrelse er F(Z)=∫₀ᶻ W(z)(1+z)²E(z) dz, hvor W=n_H0 σ_T Mpc_m/H_B. Med n_H0 i m^-3, σ_T i m² og både K=n_H0 σ_T Mpc_m og H_B i Mpc^-1 er W, E, z og F dimensionsløse.

På hvert af de 15 intervaller [a_i,b_i] genbruges V66's positive vægtindhylling [W_l,i,W_u,i]. Den polynomielle masse er M_i=((1+b_i)³−(1+a_i)³)/3. Det sikre nedre bidrag er

L_i = floor(2^100 W_l,i q M_i/2) / 2^100.

Summen er eksakt

L = 121641189594869038201543/633825300114114700748351602688
  ≈ 1,919159578719382·10^-7.

På resten af [650,700] giver den arvede positive elektronforskel en gyldig nedre optisk grænse nul. Derfor bliver den nye samlede nedre endpoint for [650,700] netop L. Den eksisterende øvre endpoint rekonstrueres fra alle 101 afskårne V66-rækker med q, den arvede øvre vægt og udadrettet afrunding. Summen matcher præcis den fastholdte værdi 4694970658217480052362703/1267650600228229401496703205376.

## Resultat

Alle viste decimaler i tabellen er tilnærmelser. De autoritative intervaller og relative forbedringer er eksakte brøker i result111.json.

| Størrelse | Tidligere | V111 |
|---|---:|---:|
| Nedre endpoint for [650,700] | 0 | 1,919159578719·10^-7 |
| Øvre endpoint for [650,700] | 3,703678803428·10^-6 | 3,703678803428·10^-6 |
| Globalt nedre endpoint | 3,797757554802·10^-6 | 3,989673512674·10^-6 |
| Globalt øvre endpoint | 4,561016425335·10^-5 | 4,561016425335·10^-5 |
| Global intervalbredde | 4,181240669854·10^-5 | 4,162049074067·10^-5 |

Bredden af [650,700] falder 5,18176569994 %. Den globale bredde falder 0,458992851705 %. Opgavens på forhånd fastlagte metodekrav var en strengt positiv certificeret forbedring. Det krav består. Den separate kontrol rekonstruerer alle bins og efterviser, at kun det nye nedre endpoint ændrer den globale sum.

## Kontrol, usikkerhed og begrænsning

Den separate kontrol importerer ingen producentkode. Den parser hex-tal med heltalsaritmetik, traverserer kilde- og optiske arkiver i omvendt rækkefølge, finder selv korrespondancen mellem rækkerne og bruger den faktoriserede masse (b−a)[(1+b)²+(1+b)(1+a)+(1+a)²]/3. Den kontrollerer gitterafrundingen med divmod og samler den globale sum i modsat rækkefølge. Den giver de samme eksakte 15 bidrag og samme øvre sum fra 101 rækker.

Begge programmer deler arkivets fysik, Python-rationel aritmetik og det arvede V97-argument. Uafhængigheden gælder traversal, parsing, masseudtryk, rækkeafbildning og summering. Den omfatter ikke en ny empirisk validering af baggrundsantagelserne.

Det samlede nedadrettede afrundingstab er ca. 4,26401666694·10^-30, mindre end 15·2^-100. Den polynomielle integration af de omsluttende konstante bokse er eksakt. Usikkerhed om elektronforløb og vægt ligger i indhyllingerne, og nulgrænsen på den ubehandlede del af [650,700] begrænser forbedringen. Intervallet er deterministisk og betinget af inputpræmisserne.

Den globale bredde er stadig ca. 10.405,12 gange det foreløbige mål 4·10^-9. Forholdet beskriver præcisionsafstanden. Det giver ingen dokumenteret prognose for antal runder eller resterende tid. Native baggrundsbinding, koordinatsammenfald, reproducerbarhed og fejlcertifikat for hele CLASS/P6-forløbet er fortsat åbne krav.

## Fortsættelse og bevaring

Resultatindtag skal optage broen og dens optiske nedre grænse. Det næste konkrete bevisproblem er kontaktfladen d=−q/2 i den første blandede celle. Den historiske V87-kontrol ved E=0 kan levere kilde- og korrelationsoplysninger, men en ny halv-q-konklusion kræver en kontrol på den relevante flade og for samtlige faktisk tilladte fælles grenkombinationer.

Der blev udført én optisk evaluering og én separat kontrol inden for opgavens tidsgrænse. Kvitteringen viser faktisk miljø, UTC-tider, varighed og filhashes. Vægtdataene er genbrugt, og antallet af nye vægt-, skalar-, native- og fuldhistorieevalueringer er nul. Den oprindelige kandidat og rå før-kontrol-status bevares sammen med kontrolkvitteringen. result111.json giver den kontrollerede sammenfatning.
