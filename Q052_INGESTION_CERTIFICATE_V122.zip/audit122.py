"""Validate stored evidence and freeze the geometry of the next optical calculation."""
from fractions import Fraction as F
from hashlib import sha1, sha256
from io import BytesIO
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
UPLOAD=ROOT.parents[1]/'upload'
H=ROOT/'history'
P='Q052_Q16_HMLA_CERTIFIKAT_V121.zip'
P119='Q052_Q16_BLOK_CERTIFIKAT_V119.zip'
P112='Q052_INGESTION_CERTIFICATE_V112.zip'
P111='Q052_SWIFT_BRO_CERTIFIKAT_V111.zip'
P110='Q052_INGESTION_CERTIFICATE_V110.zip'
P109='Q052_OPTISK_RECOVERYCERTIFIKAT_V109.zip'
P66='Q052_THOMSON_CERTIFICATE_V66.zip'
T='Q052_RESULTATINDTAG_OPGAVE_V121.json'
J='Q052_MATEMATIK_OG_SAMLET_JOURNAL_V121.md'
S='Q052_KORT_RESULTAT_V121.md'
sha=lambda b:sha256(b).hexdigest()
def read(z,n):return json.loads(z.read(n))
def dump(n,obj):
    (ROOT/n).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def copy(z,ns,dest):
    d=ROOT/'input'/dest
    d.mkdir(parents=True,exist_ok=True)
    for n in ns:
        p=d/n
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(z.read(n))
def members(z,n='manifest.json'):
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
    manifest=read(z,n)
    rows=manifest.get('members',manifest.get('archive_members'))
    pins={r['path']:r['sha256'] for r in rows} if rows is not None else manifest['files']
    assert set(z.namelist())==set(pins)|{n}, (n,set(z.namelist())-set(pins)-{n})
    for path,h in pins.items():
        assert sha(z.read(path))==h,path
    for row in rows or []:
        assert z.getinfo(row['path']).file_size==row.get('size_bytes',row.get('bytes'))
    return pins

repo=json.loads((ROOT/'repository122.json').read_bytes())
assert not repo['truncated']
index={e['path']:e for e in repo['files']}
verified={}
def match(name,raw):
    blob=sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert (blob,len(raw))==(index[name]['sha'],index[name]['size']),name
    verified[name]={'blob':blob,'sha256':sha(raw),'bytes':len(raw)}
for name in [P,T,J.replace('.md','-1.md'),S.replace('.md','-1.md')]:
    match(name,(UPLOAD/name).read_bytes())
for name in [P112,P66]:
    match(name,(H/name).read_bytes())
for name,local in [('Bubbleverse_Matematikmotor_2.3.0.md','Bubbleverse_Matematikmotor_2.3.0-50.md'),
                   ('Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0.md','Bubbleverse_Result_Ingestion_Routing_Engine_v2.3.0-59.md')]:
    match(name,(UPLOAD/local).read_bytes())
with ZipFile(UPLOAD/P) as z,ZipFile(UPLOAD/P119) as z119,ZipFile(H/P112) as z112,ZipFile(H/P111) as z111,ZipFile(H/P66) as z66:
    mp=members(z,'manifest121.json')
    t=read(z,T)
    unsigned={k:v for k,v in t.items() if k!='fingerprint_sha256'}
    assert sha(json.dumps(unsigned,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==t['fingerprint_sha256']==read(z,'manifest121.json')['next_task_fingerprint']
    assert t['target_q']==t['current_q']=='Q052' and t['source_state_version']=='V121'
    for name in [T,J,S]:
        local=name.replace('.md','-1.md') if name.endswith('.md') else name
        assert z.read(name)==(UPLOAD/local).read_bytes()
    for n,h in t['input_refs'].items():
        assert mp[n]==h
    manifest=read(z,'manifest121.json')
    with ZipFile(BytesIO(z.read('history/Q052_INGESTION_CERTIFICATE_V120.zip'))) as parent:
        n=manifest['parent_prefix_bytes']
        assert z.read(J)[:n]==parent.read('Q052_INGESTION_OG_SAMLET_JOURNAL_V120.md')
    assert sha(z.read(J)[:n])==manifest['parent_journal_sha256']
    assert z.read(J)[n:]==z.read('journal_append121.md') and sha(z.read(J)[n:])==manifest['append_sha256']
    run=read(z,'execution121.json')
    assert run['code_sha256_before']==read(z,'freeze121.json')['code_sha256_before']
    assert run['run_id']==read(z,'input/Q052_MATEMATIKOPGAVE_V120.json')['task_id']==manifest['run_id']
    assert 0<run['wall_seconds']<300 and len(run['attempts'])==42
    assert run['primary_passes']==run['separate_control_passes']==1
    assert all(run[k]==0 for k in ['new_native_pairs','new_optical_evaluations','new_scalar_integrations','new_full_history_integrations','phase6_cells','parameter_searches'])
    # This previously authored receipt validator uses only hashes and saved rational data.
    with TemporaryDirectory() as temp:
        w=Path(temp)
        names=set(run['code_sha256_after'])|set(run['output_sha256'])|{
            'execution121.json','freeze121.json','inputs121.json','validate121.py',
            'input/Q052_MATEMATIKOPGAVE_V120.json','input/input/V119/result119.json'}
        for name in names:
            p=w/name
            p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes(z.read(name))
        subprocess.run([sys.executable,str(w/'validate121.py')],cwd=w,check=True,capture_output=True,timeout=30)
        assert (w/'validation121.json').read_bytes()==z.read('validation121.json')
    r=read(z,'result121.json')
    assert all(r[k]==v for k,v in t['result_to_ingest'].items())
    assert r['status']=='ALL_1281_PASS' and r['scientific_state']=='INCONCLUSIVE'
    fold=F(r['b'])
    assert r['target_q']=='Q052' and fold==F(1,16000000)
    assert sha((UPLOAD/P119).read_bytes())==read(z,'input/Q052_MATEMATIKOPGAVE_V120.json')['inputs']['V119_full_archive']['sha256']
    assert z119.read('result119.json')==z.read('input/input/V119/result119.json')
    r119=read(z119,'result119.json')
    r117=read(z119,'input/v117/result117.json')
    seed117=read(z119,'input/v117/primary117.json')
    chain=[(r['exact_z_ascending'],r['claim_id']),
           (r119['domain_z_ascending'],r119['claim_id']),
           (r117['domain_z_ascending'],r117['claim_id'])]
    assert r['entry_claim']==r119['claim_id']
    for x in [r,r119,r117]:
        assert F(x['exit_E_strictly_greater_than'])==fold and x['exact_question']==t['exact_question']
    for x in [r,r119,seed117]:
        for k in ['source_commit','background_dependency_id']:
            assert x[k]==t[k]
    cursor=F(50)
    for span,_ in chain:
        a,b=map(F,span)
        assert a==cursor<b
        cursor=b
    assert F(r117['entry_E_lower'])==F(1,2000000)>fold

    m112=members(z112)
    m111=members(z111)
    m66=members(z66)
    assert z112.read('history/'+P111)==(H/P111).read_bytes()
    audit112=read(z112,'audit112.json')
    historical111=read(z111,'result111.json')
    old=read(z111,'calc/result_raw111.json')
    old_control=read(z111,'calc/control111.json')
    old_run=read(z111,'calc/execution111.json')
    bridge=read(z111,'calc/barrier111.json')
    assert historical111['optical_result']==old
    assert audit112['ingestion_state']=='ACCEPTED_CONDITIONAL_SOURCE_REAL'
    assert historical111['technical_state']==old_control['status']==old_run['technical_state']=='PASS'
    assert all(m111['calc/'+n]==h for n,h in old_run['output_sha256'].items())
    for x in [historical111,audit112]:
        for k in ['exact_question','source_commit','capture_sha256']:
            assert x[k]==t[k]
    assert bridge['background_dependency_id']==t['background_dependency_id'] and bridge['strict_interior']
    assert F(bridge['domain'][0])==cursor==F(r117['entry_z'])
    assert old['domain']==bridge['domain']==[str(cursor),'700']
    assert audit112['accepted_electron_domain']==[str(cursor),'800']
    bins=audit112['current_bins']
    assert old['current_bins']==bins and old['new_global_interval']==audit112['global_interval']
    totals=[sum(F(x[i]) for x in bins.values()) for i in (0,1)]
    assert totals==list(map(F,audit112['global_interval']))
    assert totals[1]-totals[0]==F(audit112['global_width'])==F(old['global_width'])
    budget=read(z111,'calc/width_budget110.json')
    assert all(bins[k]==v for k,v in budget['current_bins'].items() if k!='650:700')
    assert bins['650:700'][1:]==budget['current_bins']['650:700'][1:]
    assert budget['current_bins']['650:700'][0]=='0'
    raw110=z111.read('history/'+P110)
    match(P110,raw110)
    with ZipFile(BytesIO(raw110)) as z110:
        assert z110.read('width_budget110.json')==z111.read('calc/width_budget110.json')
        match(P109,z110.read('history/'+P109))
        copy(z110,['audit110.json'],'V110')

    receipt=read(z66,'receipt.json')
    pins=read(z111,'input_pins111.json')
    sign_archive=z111
    sign_path=[P110,P109,'Q052_INGESTION_CERTIFICATE_V108.zip',
        'Q052_DELCERTIFIKAT_OG_FEJLDIAGNOSE_V107.zip','Q052_INGESTION_CERTIFICATE_V106.zip',
        'Q052_THOMSON_PILOTCERTIFIKAT_V97.zip']
    for name in sign_path:
        sign_archive=ZipFile(BytesIO(sign_archive.read('history/'+name)))
    assert sha(sign_archive.read('v95.json'))==pins['v95.json']
    sign=read(sign_archive,'v95.json')
    assert sign['status']=='ALL_373_PASS' and sign['combined_positive_z']==['0','810']
    copy(sign_archive,['v95.json','PROOF_V95.md'],'V95')
    assert m66['receipt.json']==pins['v66.json']==read(z66,'control.json')['receipt_sha256']
    assert read(z66,'control.json')['status']=='PASS'
    assert sha(z.read('input/v91/v62.json'))==pins['v62.json']
    assert sha(z.read('input/v91/v19.json'))==receipt['input_hashes']['V19']
    assert receipt['summary']['source_domain_z']==['0','810']
    segments=receipt['source_segments']
    assert len(segments)==4990
    edges=[tuple(map(F,row['z'])) for row in segments]
    assert edges[0][0]==0 and edges[-1][1]==810
    assert all(a<b and (i==0 or edges[i-1][1]==a) for i,(a,b) in enumerate(edges))
    v62=read(z,'input/v91/v62.json')
    hx=lambda s:F(float.fromhex(s))
    old_cursor=cursor
    for item in old['cells']:
        lo,hi=map(F,item['z'])
        assert lo==old_cursor<hi
        seg=segments[item['V66_row']]
        assert edges[item['V66_row']][0]<=lo<hi<=edges[item['V66_row']][1]
        assert seg['K_over_H_exact']==item['weight']
        old_cursor=hi
    assert old_cursor==700 and len(old['cells'])==15
    assert sum(F(x['lower']) for x in old['cells'])==F(old_control['new_lower'])==F(old['new_lower'])==F(bins['650:700'][0])
    for n in range(50,650,50):
        assert F(bins[f'{n}:{n+50}'][0])==0

    # Geometry and positivity checks only. No masses, products, or new optical sums.
    lookup={tuple(reversed(tuple(map(hx,r['z'])))):i for i,r in enumerate(v62['pair_records'])}
    cut={F(n) for n in range(100,700,50)} | {F(row[0][1]) for row in chain[:-1]}
    geometry=[]
    last=F(50)
    for i,((a,b),seg) in enumerate(zip(edges,segments,strict=True)):
        lo,hi=max(F(50),a),min(cursor,b)
        if lo>=hi:
            continue
        assert lo==last and seg['origin']=='V62' and (a,b) in lookup
        index62=lookup[(a,b)]
        weight=list(map(F,seg['K_over_H_exact']))
        assert 0<weight[0]<=weight[1]
        ends=[lo]+sorted(x for x in cut if lo<x<hi)+[hi]
        for left,right in zip(ends,ends[1:]):
            refs=[ref for span,ref in chain if F(span[0])<=left<right<=F(span[1])]
            assert len(refs)==1
            binlo=int(left//50)*50
            assert right<=binlo+50
            geometry.append({'V66_row':i,'V62_row':index62,'z_ascending':list(map(str,[left,right])),
                'bin':f'{binlo}:{binlo+50}','floor_claim':refs[0]})
        last=hi
    assert last==cursor
    assert all(F(x['z_ascending'][1])<=F(old['domain'][0]) for x in geometry)
    copy(z,[T,'result121.json','validation121.json','execution121.json','PROOF_V121.md','activity_ledger121.json','manifest121.json'],'V121')
    copy(z119,['result119.json','input/v117/result117.json','input/v117/PROOF_V117.md'],'V119')
    copy(z112,['audit112.json','manifest.json'],'V112')
    copy(z111,['result111.json','calc/control111.json','calc/execution111.json','calc/barrier111.json',
               'calc/width_budget110.json','input_pins111.json','PROOF_V111.md','manifest.json'],'V111')
    ledger=read(z,'activity_ledger121.json')
    assert sum(x['run_points'] for x in ledger['entries'])==ledger['total_points_after']==14720
    assert not any(x.get('run_id')==t['task_id'] for x in ledger['entries'])
    assert 'Q052-SOME-M014' in ledger['delivered_milestone_ids'] and not ledger['pending_packages']
    dump('geometry122.json',geometry)
    audit={'status':'PASS','run_id':t['task_id'],'conditional_claim_admitted':r['claim_id'],'repository_commit':repo['head'],
       'repository_files':verified,'V121_manifest_members':len(mp),'V121_journal_prefix':'BYTE_IDENTICAL',
       'V121_stored_validation':'BYTE_IDENTICAL_NO_FIELD_REPLAY','V121_cells':1281,'V121_control_groups':21,
       'V121_exact_margins':[r['primary_normalized_lower'],r['control_normalized_lower']],
       'V121_successful_subprocesses':42,'V121_wall_seconds':run['wall_seconds'],
       'floor_chain':chain,'V111_archive_sha256':sha((H/P111).read_bytes()),'V111_identity':'Exact embedded V112 archive',
       'V111_member_count':len(m111),'V112_member_count':len(m112),'V66_member_count':len(m66),
       'V66_receipt_sha256':m66['receipt.json'],'V66_source_segments':len(segments),
       'global_sign_premise':{'member':'input/V95/v95.json','sha256':pins['v95.json'],'source_path':sign_path,
          'positive_source_domain':['0','810'],'scope':'Prior archived source-real conditional evidence'},
       'baseline':{'current_bins':bins,'global_interval':audit112['global_interval'],'global_width':audit112['global_width'],
          'credited_V111_support':old['domain'],'credited_V111_lower':old['new_lower'],'provisional_width_goal':'1/250000000'},
       'geometry':{'new_domain':['50',str(cursor)],'pieces':len(geometry),'V66_rows':len({x['V66_row'] for x in geometry}),
          'bins':len({x['bin'] for x in geometry}),'old_support_intersection':'SHARED_ENDPOINT_ONLY'},
       'new_optical_evaluations':0,'new_physical_evaluations':0,'new_native_pairs':0,'new_integrations':0}
    dump('audit122.json',audit)
    print(audit['geometry'],audit['baseline']['global_interval'])
