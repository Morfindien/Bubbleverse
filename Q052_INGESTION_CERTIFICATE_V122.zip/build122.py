"""Assemble verified V122 intake and one frozen V123 optical-update task."""
from datetime import datetime,timezone
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[1]
UPLOAD=BASE/'upload'
OUT=BASE/'output/V122'
OUT.mkdir(parents=True,exist_ok=True)
ZIP='Q052_INGESTION_CERTIFICATE_V122.zip'
SHORT='Q052_KORT_RESULTAT_V122.md'
JOURNAL='Q052_INGESTION_OG_SAMLET_JOURNAL_V122.md'
NEXT='Q052_MATEMATIKOPGAVE_V122.json'
P121='Q052_Q16_HMLA_CERTIFIKAT_V121.zip'
P66='Q052_THOMSON_CERTIFICATE_V66.zip'
OLDJ='Q052_MATEMATIK_OG_SAMLET_JOURNAL_V121.md'
LIMIT=25_000_000
sha=lambda b:sha256(b).hexdigest()
enc=lambda v:(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode()
def read(n):return json.loads((ROOT/n).read_bytes())
def save(n,v):(ROOT/n).write_bytes(enc(v))
def fingerprint(v):
    return sha(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
a=read('audit122.json')
t=read('input/V121/Q052_RESULTATINDTAG_OPGAVE_V121.json')
r=read('input/V121/result121.json')
assert a['status']=='PASS' and a['run_id']==t['task_id']
repo=a['repository_commit']
rid=a['run_id']
event='Q052-ACTIVITY-Q16-PHASE5-OPTICAL-INTAKE-V122'
now=datetime.now(timezone.utc).isoformat()
baseline=a['baseline']
domain=a['geometry']['new_domain']
counts=a['geometry']
kernel_ref='history/'+P66
claim=r['claim_id']
engine='BUBBLEVERSE.MATHEMATICS 2.3.0'
prefix=(UPLOAD/OLDJ.replace('.md','-1.md')).read_bytes()
with ZipFile(UPLOAD/P121) as previous:
    assert prefix==previous.read(OLDJ)
previous_entries=(ROOT/'input/V121/activity_ledger121.json').read_bytes()
ledger=json.loads(previous_entries)
previous_event=ledger['entries'][-1]['activity_event_id']
prior=ledger['total_points_after']
parts={'analysis_points':24,'computation_points':8,'search_points':10,'validation_points':18}
points=sum(parts.values())
total=prior+points
next_threshold=ledger['next_publication_at']
basis='Redaktionelt skøn for indtag af V121, genfinding og identitetskontrol af V66/V111/V112, kontrol af de arvede optiske bins samt eksakt afgrænsning af 1.304 nye delintervaller. Ingen ny felt- eller integralberegning og ingen point for pakning.'
assert prior==14720 and total<next_threshold==15000
assert all(x.get('run_id')!=rid for x in ledger['entries'])
ledger['entries'].append({'run_id':rid,'activity_event_id':event,'engine':t['engine'],'run_points':points,
    'breakdown':parts,'basis':basis,'counted_once':True})
ledger.update({'previous_ledger_ref':P121+'!activity_ledger121.json','previous_total_points':prior,
    'parent_ledger_sha256':sha(previous_entries),'total_points_after':total,'cycle_progress':total%1000,
    'points_to_next_publication':next_threshold-total,'ledger_revision':'V122','last_updated_utc':now,
    'new_milestones':[],'pending_packages':[],'scientific_state':'INCONCLUSIVE','workflow_state':'READY_FOR_HANDOFF',
    'point_state':'VERIFIED','note':'Only the V122 intake was added. M014 delivery is inherited.'})
assert sum(x['run_points'] for x in ledger['entries'])==total
save('activity_ledger122.json',ledger)
save('baseline122.json',baseline)
refs={n:sha((ROOT/n).read_bytes()) for n in ['audit122.json','baseline122.json','geometry122.json','activity_ledger122.json',
    'input/V121/result121.json','input/V119/result119.json','input/V119/input/v117/result117.json',
    'input/V112/audit112.json','input/V111/result111.json','input/V111/calc/control111.json',
    'input/V111/calc/barrier111.json','input/V95/v95.json',kernel_ref]}
no_repeat=t['no_repeat']+[
    'V122 archived identity and partition audit is completed.',
    'V111 already credited strip and V109/V105 optical reductions are frozen baseline entries. Preserve their existing contributions.',
    'The new V123 exact sum uses only the newly covered disjoint support. It is a conditional numerical-bound update, with no new dynamical histories.']
nexttask={'schema_version':'UNVALIDATED_LOCAL_CONTRACT','state':'PREPARED_NOT_EXECUTED',
    'task_id':'LOCAL-Q052-V123-Q16-SIGNED-OPTICAL-LOWER-50-TO-BRIDGE',
    'engine':engine,'case_id':t['case_id'],'current_q':'Q052','target_q':'Q052','continue_same_q':True,
    'exact_question':t['exact_question'],'source_state_version':'V122','evidence_boundary':'Q052 through V122',
    'journal_ref':JOURNAL,'input_archive':ZIP,'input_refs':refs,
    'engine_prompt_sha256':a['repository_files']['Bubbleverse_Matematikmotor_2.3.0.md']['sha256'],
    'source_commit':t['source_commit'],'capture_sha256':t['capture_sha256'],'background_dependency_id':t['background_dependency_id'],
    'objective':'Measure the increase in the conditional source-real signed Thomson lower endpoint using the newly certified q/16 floor and previously certified positive V66 weights.',
    'target':{'domain_z_ascending':domain,'Q':'1/1000000','floor':'1/16000000','floor_chain':a['floor_chain'],
        'partition_ref':'geometry122.json','pieces':counts['pieces'],'distinct_V66_rows':counts['V66_rows'],
        'affected_bins':counts['bins'],'existing_V111_support':baseline['credited_V111_support'],
        'baseline_ref':'baseline122.json','provisional_global_width_goal':baseline['provisional_width_goal']},
    'frozen':{'weight_archive':kernel_ref,'original_weight_receipt':'receipt.json','weight_receipt_sha256':a['V66_receipt_sha256'],
        'weight_interval_key':'K_over_H_exact','source_segment_coordinate_order':'ascending exact z',
        'kernel':'W(z)(1+z)^2, W=K/H_B, same V66 convention and admitted common background',
        'grid':'2^-100','unchanged_upper_endpoints':True,'gain_must_be_positive':True},
    'primary':[
        'Verify task fingerprint and member hashes, exact proof joins, global positivity premise of the baseline, and all V112 baseline bins before execution.',
        'Read the frozen geometry and the original V66 receipt. Check each closed child interval is contained in its V66 parent, unique floor claim and bin. Check complete contiguous support with no interior overlap with the prior credited V111 strip.',
        'For each child [a,c] use its parent W_lower>0. Evaluate exact rational mass M=((1+c)^3-(1+a)^3)/3 and l=(q/16)*W_lower*M. Record l and round each local l downward to the 2^-100 grid.',
        'Sum the new local grid lower amounts per bin. Add only the new support contribution to that bin’s prior lower endpoint. For 650:700 explicitly show the new support ends at the first endpoint of the already credited V111 strip. If positive-length overlap is detected, stop rather than add; reuse would require splitting support and taking the maximum certified local lower bound on a shared piece.',
        'Sum bin intervals to the new global conditional signed interval. Check each resulting lower endpoint is no larger than its preserved upper endpoint. Report exact gain, downward rounding loss, new global width, fractional reduction relative to V112, and ratio to the provisional 4e-9 width goal.'],
    'separate_control':[
        'Use a separate process and no producer code or receipts. Independently derive the partition from full V66 rows, exact claim endpoints, signed baseline bin cuts and V111 protected strip. Traverse in reverse order and compare exact ordered membership only after computing.',
        'Use the factorized mass M=(c-a)*((1+a)^2+(1+a)*(1+c)+(1+c)^2)/3 and use integer divmod for directed local rounding. Independently aggregate the global interval and bin changes.',
        'Require exact equality of final sums, rounded and unrounded contributions, protected support, upper endpoints and baseline coverage. Record first inconsistent row or bin, if any.'],
    'acceptance_criteria':'Both implementations yield identical exact bounds with a strictly positive global lower improvement, no double counting, unchanged prior upper endpoints and complete coverage of all 1304 pieces.',
    'rejection_criteria':'A verified input/domain mismatch, duplicated positive-length support or a new lower endpoint exceeding its existing upper endpoint invalidates the affected candidate update.',
    'inconclusive_criteria':'Any missing mandatory provenance, unverified range, incomplete control or unclosed arithmetic mismatch prevents promoting a new global interval.',
    'stop_condition':'One fixed primary sum and one independent control, then stop at dual agreement, first failed mandatory gate, or 120 combined wall seconds. Preserve earlier accepted results on failure.',
    'execution_limits':{'wall_seconds_combined':120,'primary_optical_evaluations':1,'independent_controls':1,
        'max_pieces_per_method':counts['pieces'],'new_weight_evaluations':0,'new_scalar_integrations':0,
        'new_full_history_integrations':0,'new_native_pairs':0,'parameter_searches':0},
    'expected_output':'Exact signed source-optical contribution receipts, a validated interval update or concrete blocker, appended journal and one Result Ingestion task.',
    'return_engine':t['engine'],'no_repeat':no_repeat,'total_points':total,'next_milestone':next_threshold,
    'points_to_next_publication':next_threshold-total,'activity_ledger_ref':'activity_ledger122.json',
    'publication_state':'NOT_DUE','max_deliverable_bytes':LIMIT}
nexttask['fingerprint_sha256']=fingerprint(nexttask)
(OUT/NEXT).write_bytes(enc(nexttask))
files=[SHORT,JOURNAL,NEXT,ZIP]
memory={'repository':'Morfindien/Bubbleverse','branch':'main','verified_base':repo,'source_freshness':'VERIFIED',
    'sync_status':'USER_UPLOAD_PENDING','upload_new_root_files':files,
    'target_paths':'Existing root-file convention','instructions':'Upload these four new V122 files at root. Preserve past versions.',
    'proposed_index_updates':{'case':'Q052 ACTIVE / INCONCLUSIVE','journal':JOURNAL,'task':NEXT,
        'claim':claim,'completed_intake':rid,'total_points':total,'publication_state':'NOT_DUE'}}
save('github_memory_update122.json',memory)
source={'target_q':'Q052','evidence_boundary':'Q052 through V122','repository_commit':repo,'verified_repository_files':a['repository_files'],
    'history':{'V121':P121,'V66':kernel_ref,
        'V111_identity':{'sha256':a['V111_archive_sha256'],'inside':'Q052_INGESTION_CERTIFICATE_V112.zip!history/Q052_SWIFT_BRO_CERTIFIKAT_V111.zip'}},
    'claim_map':{claim:['input/V121/result121.json','input/V121/PROOF_V121.md','audit122.json'],
        'V112-OPTICAL-BASELINE':['input/V112/audit112.json','input/V111/result111.json','baseline122.json','input/V95/v95.json'],
        'V123-PREPARED-GEOMETRY':['geometry122.json',NEXT,kernel_ref]},
    'open_uncertainties':['Global conditional optical width','Native background admission, trajectory identity, reproducibility and validated whole-history numerical error']}
save('source_register122.json',source)
handoff={'schema_id':'bubbleverse.result_ingestion_handoff','schema_version':'3.0.0','schema_validation':'LOCAL_FIELDS_AND_REFS_ONLY',
    'prompt_id':'bubbleverse.result_ingestion_routing','prompt_version':'2.3.0','handoff_id':rid,'created_at_utc':now,
    'case_id':t['case_id'],'current_q':'Q052','target_q':'Q052','exact_question':t['exact_question'],
    'evidence_cutoff':'Q052 through V122','case_lifecycle':'ACTIVE','disposition':'CONTINUE','epistemic_status':'INCONCLUSIVE',
    'ingestion_state':'PASS_CONDITIONAL_RESULT_ADMITTED','new_result_ids':[claim],'source_state_version':'V121','target_state_version':'V122',
    'selected_next_engine_id':engine,'engine_registry_ref':'Bubbleverse_Matematikmotor_2.3.0.md at '+repo,
    'execution_profile_ref':'Python standard library rational arithmetic. Two separately coded passes, archive reader and SHA-256.',
    'journal_ref':JOURNAL,'source_register_ref':'source_register122.json','claim_evidence_map_ref':'source_register122.json#claim_map',
    'result_provenance_ref':'audit122.json','anomaly_tension_registry_ref':'source_register122.json#open_uncertainties',
    'completed_task_ledger_ref':'github_memory_update122.json#proposed_index_updates',
    'route_history_ref':'github_memory_update122.json#proposed_index_updates','integrity_manifest_ref':'manifest122.json',
    'closure_snapshot_ref':None,'what_changed':['Accepted V121 q/16 phase-5 result and froze one optical-update task with 1304 pieces.'],
    'frozen_configuration_refs':[kernel_ref,'baseline122.json'],'open_material_uncertainties':source['open_uncertainties'],
    'missing_information':['Actual native error certificate and realized error-certified suprema.'],
    'next_task':NEXT,'success_condition':nexttask['acceptance_criteria'],'failure_or_falsification_condition':nexttask['rejection_criteria'],
    'stop_condition':nexttask['stop_condition'],'completion_gate_satisfied':False,
    'completion_gate_reason':'Conditional source-real optical precision and actual native evidence remain open.',
    'handoff_completeness':'COMPLETE_FOR_BOUNDED_CONTINUATION','writeback_status':'USER_UPLOAD_PENDING',
    'delivery_status':'FILES_PREPARED_FOR_DELIVERY','operator_gate':'Same authorized Q052',
    'output_file_refs':files,'output_manifest_ref':'manifest122.json','repository_memory':memory,
    'question_activity_points':{'policy_id':'bubbleverse.question_activity_some_milestones','policy_version':'2.0.0','ledger_id':'Q052',
        'ledger_ref':'activity_ledger122.json','ledger_version':'V122','parent_ledger_version':'V121','run_id':rid,'activity_event_id':event,
        'parent_total_pts':prior,'estimated_run_points':points,'assessed_run_points':points,'assessment_breakdown':parts,
        'assessment_basis':basis,'assessment_confidence':'HEURISTIC','inherited_event_ids':[previous_event],
        'newly_applied_event_ids':[event],'total_pts':total,'status':'VERIFIED'},
    'some_milestones':{'interval_pts':1000,'highest_threshold_reached_pts':14000,'crossed_this_run':[],'ready_package_ids':[],
        'pending_milestones':[],'next_threshold_pts':next_threshold,'points_to_next_threshold':next_threshold-total,
        'milestone_ledger_ref':'activity_ledger122.json','package_file_refs':[],'package_creation_status':'NOT_DUE',
        'external_publication_status':'NOT_REQUESTED','scientific_route_changed_by_points':False}}
save('handoff122.json',handoff)
short=f"""# Bubbleverse · Resultatindtag V122

**V121 er godkendt. En ny optisk beregning er afgrænset til 1.304 delintervaller.**

Den betingede elektronforskel E>q/16 er dokumenteret fra z≈687,2975
ned til z=50 på 1.281 HMLA-celler. Sammen med de tidligere beviser
dækker grænsen [50,800] under de fastlåste forudsætninger.

Den næste opgave anvender V66's positive vægte fra z=50 til z≈692,77,
fordelt på 1.292 oprindelige vægtrækker og 13 eksisterende bins.
V111's allerede medregnede halv-q-bidrag begynder ved det øvre
endepunkt. De to områder deler kun endepunktet.

Det senest validerede betingede Thomson-interval er cirka
[3,98967×10⁻⁶, 4,56102×10⁻⁵]. V122 har kontrolleret dets
proveniens og forberedt næste beregning. En ny nedre talgrænse
afventer hovedberegningen og den separate kontrol. Q052 er fortsat
åbent, og det native fejlcertifikat mangler.

**Næste motor** Matematikmotor 2.3.0. Brug `{NEXT}` og ZIP-filen.
Den fulde journal bevarer V121 byte for byte og tilføjer V122.
Pakkehåndoffet har de verificerede GitHub-referencer og forslag
til upload af de fire nye filer.

Runden giver {points} point. Totalen er 14.780 og der er {next_threshold-total}
point til næste SoMe-pakke. M014 er allerede leveret.
"""
(OUT/SHORT).write_text(short)
append=f"""

---

# Q052 V122 — V121 optaget og optisk opgave forberedt

UTC {now}. Run `{rid}`. Q052 ACTIVE / INCONCLUSIVE.
Evidensgrænse Q052 til og med V122. Resultatindtag og routing 2.3.0.

## Oprindeligt spørgsmål

{t['exact_question']}

## Resultat og verificeret domæne

`{claim}` er optaget én gang under de fastlåste kilde-,
baggrunds-, start- og baneforudsætninger. q/16-randen er godkendt
for alle 1.281 HMLA-celler fra {r['exact_z_ascending'][1]} til
z=50. De 21 separate grupper og 42 vellykkede subprocesser
er kontrolleret i de gemte kvitteringer. V121-efterkontrollen
gendannede sine gemte bytes uden at genkøre feltmetoderne.
Samlet med V117, V119 og den tidligere stærkere halv-q-grænse
dækker resultatet [50,800]. E>q/16 ved fasegrænsen er streng
og den ekstra afstand er uopgjort.

## Optisk baseline og næste beregning

V111-arkivet er byteidentisk med V112's indlejrede, godkendte
arkiv. V112 og V66 er verificeret mod GitHub. V66-receiptet
matcher V111's inputpin og den arkiverede separate kontrol.
V19/V62 matcher den frosne beregningskæde. Det senest godkendte
globale interval er præcis
`{baseline['global_interval'][0]}` til
`{baseline['global_interval'][1]}`.
Dets bredde er `{baseline['global_width']}`.
V110 og V109 er verificeret som forældre til den optiske
baseline. Alle V111-bidrag, tidligere bins og øvre endepunkter
er afstemt med V112's godkendelse.

Nyt optisk domæne [50, {domain[1]}].
Det består af 1.304 lukkede delintervaller fra 1.292 V66-bokse
fordelt over 13 bins. Alle vægtlofter og vægtgulve er positive
og kompatible med den arkiverede konvention. Den gamle
V111-strimmel [{domain[1]},700] berører kun ved det fælles
endepunkt. Hver ny delcelle har en V66-forældercelle og ét
q/16-bevis. Geometrien, baseline og inputpins står i ZIP-filen.
Denne runde har ingen nye optiske evalueringer, feltberegninger,
native par eller integrationer.

Næste motor {engine}. Den faste opgave `{NEXT}` kræver én
rational hovedberegning og én separat kontrol. Den nedre
værdi afrundes ned på 2⁻¹⁰⁰-gitter per delcelle, og de arvede
øvre endepunkter fastholdes. Den nye globale bredde skal
sammenlignes med V112 og det foreløbige mål 4×10⁻⁹.
Stop ved første uafklarede identitet eller dækningsfejl, efter
120 sekunder eller efter præcis overensstemmelse.
Status PREPARED_NOT_EXECUTED. Fingeraftryk
`{nexttask['fingerprint_sha256']}`.

Q052's faktiske native baner, reproducerbarhed og validerede
numeriske fejl står åbne. V93's gamle fase-6-resultat og
V115's begrænsning bevares med deres tidligere rækkevidder.
CONTINUE_SAME_Q=true.

## Proveniens og point

GitHub-baseline `{repo}` matcher V121, V112, V110, V109, V66
og motoridentiteterne. V111 gendannet i identiske bytes fra
V112. Historisk journalpræfiks er byteidentisk. Nye filer er
klar til manuel upload, jf. `github_memory_update122.json`.

POINTS_EVENT RESEARCH_RUN. `{event}` efter `{previous_event}`.
Analyse 24, beregning 8, kildesporing 10, validering 18.
RUN POINTS {points}. TOTAL {total}. Næste tærskel {next_threshold}.
Der er {next_threshold-total} point til næste SoMe-pakke.
PUBLICATION_STATE NOT_DUE. M001–M014 står som leveret.

{basis}
"""
(OUT/JOURNAL).write_bytes(prefix+append.encode())
(ROOT/'journal_append122.md').write_text(append)
(ROOT/'LAES_MIG_V122.txt').write_text(f"""V122. Start med {SHORT}.

Næste motor bruger {NEXT}, {JOURNAL} og denne ZIP.
Det originale V66-vægtarkiv og V121-resultat ligger i history/.
De præcise optiske baseline-receipts er i input/. De originale
V111 og V112 arkiver kan findes via kildekortet. De er ikke
påkrævede for den næste optiske beregning, hvis de pakkede
pinde og receipts matcher.

V122 har kun kontrolleret arkivdata og intervalgeometri.
Den nye beregningsopgave er forberedt og afventer udførelse.
Dette er en almindelig ZIP. Alle fire leverede filer er under
25.000.000 byte. GitHub-vejledning ligger i github_memory_update122.json.
""")
names=['audit122.py','build122.py','repository122.json','audit122.json','geometry122.json','baseline122.json','source_register122.json',
    'handoff122.json','activity_ledger122.json','github_memory_update122.json','journal_append122.md','LAES_MIG_V122.txt']
members={n:(ROOT/n).read_bytes() for n in names}
members.update({n:(OUT/n).read_bytes() for n in [SHORT,JOURNAL,NEXT]})
for p in (ROOT/'input').rglob('*'):
    if p.is_file():
        members[str(p.relative_to(ROOT))]=p.read_bytes()
members[kernel_ref]=(ROOT/kernel_ref).read_bytes()
members['history/'+P121]=(UPLOAD/P121).read_bytes()
assert sha(members['history/'+P121])==a['repository_files'][P121]['sha256']
for n,d in refs.items():
    assert sha(members[n])==d
manifest={'version':'V122','target_q':'Q052','run_id':rid,'created_utc':now,
    'parent_journal_sha256':sha(prefix),'parent_prefix_bytes':len(prefix),'append_sha256':sha(append.encode()),
    'task_fingerprint':nexttask['fingerprint_sha256'],'max_deliverable_bytes':LIMIT,'github_memory_update':memory,
    'self_hash_convention':'Manifest excludes itself from member hashes.',
    'members':[{'path':n,'size_bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())]}
members['manifest122.json']=enc(manifest)
with ZipFile(OUT/ZIP,'w',ZIP_DEFLATED,compresslevel=6) as z:
    for n,b in sorted(members.items()):
        z.writestr(n,b)
with ZipFile(OUT/ZIP) as z:
    assert z.testzip() is None and set(z.namelist())==set(members)
    for n,b in members.items():
        assert z.read(n)==b and len(b)<LIMIT
        if n.endswith('.json'):
            json.loads(b)
    assert z.read(JOURNAL)==prefix+append.encode()
    assert len(json.loads(z.read('geometry122.json')))==1304
    check=json.loads(z.read(NEXT))
    assert check['engine']==engine and check['target_q']=='Q052'
    check_h=check.pop('fingerprint_sha256')
    assert fingerprint(check)==check_h
delivery=[]
for n in [ZIP,SHORT,JOURNAL,NEXT]:
    b=(OUT/n).read_bytes()
    assert 0<len(b)<LIMIT
    delivery.append({'path':n,'bytes':len(b),'sha256':sha(b)})
save('delivery122.json',{'status':'PASS','files':delivery,'journal_prefix':'BYTE_IDENTICAL','zip_crc':'PASS','new_optical_evaluations':0})
save('upload122.json',{'uploads':[{'local_path':str(OUT/x['path']),'purpose':'create_library_file',
    'library_artifact_type':'report' if x['path'].endswith('.md') else 'other'} for x in delivery]})
print(json.dumps(delivery,indent=2))
